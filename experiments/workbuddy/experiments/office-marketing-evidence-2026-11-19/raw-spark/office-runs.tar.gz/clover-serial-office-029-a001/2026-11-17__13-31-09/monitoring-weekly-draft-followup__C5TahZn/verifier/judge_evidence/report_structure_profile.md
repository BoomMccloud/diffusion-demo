# Report structure profile

This profile summarizes Markdown/text structure for Judge review. It is derived from the submitted report text and does not add hidden facts.

```json
{
  "text_length": 5219,
  "table_count": 1,
  "sections_present": {
    "title": true,
    "overview": true,
    "confirmed": true,
    "abnormal": true,
    "pending": true,
    "next_week": true,
    "source_boundary": true
  },
  "section_lengths": {
    "overview": 754,
    "confirmed": 2318,
    "abnormal": 180,
    "pending": 818,
    "next_week": 377,
    "source_boundary": 523
  },
  "section_line_counts": {
    "overview": 8,
    "confirmed": 19,
    "abnormal": 4,
    "pending": 7,
    "next_week": 5,
    "source_boundary": 6
  },
  "pending_table_row_count_estimate": 5,
  "source_paths_mentioned_count": 8,
  "source_paths_mentioned": [
    "pump_room_walkthrough.md",
    "hvac_alarm_digest.md",
    "water_quality_followups.md",
    "lighting_patrol_log.md",
    "late_retest_status_queue.md",
    "source_alias_cards.md",
    "ops_sync_excerpt.md",
    "state/00_state_gate.md"
  ],
  "issue_mentions_by_section": {
    "pump_vibration": {
      "overview": true,
      "confirmed": true,
      "abnormal": true,
      "pending": true,
      "next_week": true,
      "source_boundary": true
    },
    "water_turbidity": {
      "overview": true,
      "confirmed": true,
      "abnormal": true,
      "pending": true,
      "next_week": true,
      "source_boundary": true
    },
    "lighting_north_walk": {
      "overview": true,
      "confirmed": true,
      "abnormal": true,
      "pending": true,
      "next_week": true,
      "source_boundary": false
    },
    "optional_container": {
      "overview": false,
      "confirmed": false,
      "abnormal": false,
      "pending": true,
      "next_week": false,
      "source_boundary": true
    },
    "hvac_noise": {
      "overview": true,
      "confirmed": true,
      "abnormal": true,
      "pending": true,
      "next_week": true,
      "source_boundary": true
    }
  }
}
```
