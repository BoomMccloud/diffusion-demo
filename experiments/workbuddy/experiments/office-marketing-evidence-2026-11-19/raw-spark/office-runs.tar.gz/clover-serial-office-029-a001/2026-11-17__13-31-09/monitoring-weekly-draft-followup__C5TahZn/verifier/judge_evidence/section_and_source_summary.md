# Section and source summary

```json
{
  "sections_present": {
    "title": true,
    "overview": true,
    "confirmed": true,
    "abnormal": true,
    "pending": true,
    "next_week": true,
    "source_boundary": true
  },
  "source_paths_mentioned": [
    "pump_room_walkthrough.md",
    "hvac_alarm_digest.md",
    "water_quality_followups.md",
    "lighting_patrol_log.md",
    "late_retest_status_queue.md",
    "source_alias_cards.md",
    "ops_sync_excerpt.md",
    "state/00_state_gate.md"
  ]
}
```
