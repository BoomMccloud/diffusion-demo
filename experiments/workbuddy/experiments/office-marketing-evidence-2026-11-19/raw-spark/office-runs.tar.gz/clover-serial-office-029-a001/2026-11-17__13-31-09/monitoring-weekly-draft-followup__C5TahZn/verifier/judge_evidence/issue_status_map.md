# Issue status map

This profile is derived from the submitted report text and deterministic failed-check names. It is Judge evidence only; deterministic scoring remains in the verifier checks.

```json
{
  "source_paths_mentioned_count": 8,
  "source_paths_mentioned": [
    "pump_room_walkthrough.md",
    "hvac_alarm_digest.md",
    "water_quality_followups.md",
    "lighting_patrol_log.md",
    "late_retest_status_queue.md",
    "source_alias_cards.md",
    "ops_sync_excerpt.md",
    "state/00_state_gate.md"
  ],
  "issues": {
    "pump_vibration": {
      "section_status": {
        "overview": "pending_or_caveated",
        "confirmed": "pending_or_caveated",
        "abnormal": "settled_or_progressed",
        "pending": "pending_or_caveated",
        "next_week": "pending_or_caveated",
        "source_boundary": "pending_or_caveated"
      },
      "section_evidence_lines": {
        "overview": [
          "- 东区泵站：入口压力交接口头描述为\"仍稳\"（06/27），但未见正式数值表；排水沟于 06/25 有清理动作且当时未见持续渗漏；2号泵振动早期带问号记录（06/24），晚到队列中有 VM-2 手持表复测 3.2 mm/s 的补录线索，需核实设备绑定与可写状态。",
          "- 南门水质采样点：06/22 采样单显示余氯 0.32 mg/L、浊度 0.7 NTU；06/23 复测余氯 0.45 mg/L，浊度格为空并注\"试纸批次换新后再补\"；06/26 电话备注称\"没有新增异味投诉\"属背景信息；06/28 晚到队列中出现 0.8 NTU 纸条但样本标签为 SG-WQ-A，与南门常用标签 SG-WQ-B 不一致，需确认绑定关系。"
        ],
        "confirmed": [
          "- **2号泵振动**：06/24 手写 `vib 4.8 mm/s?`，旁注\"探头贴合不稳，等维护组复看\"；06/28 09:05 维护交接补录显示 VM-2 手持表复测 3.2 mm/s，标注\"探头重新贴合后复测，作为 W26 复测值\"。**注意**：该补录是否对应东区泵站 2号泵仍需绑定核实（别名卡提示 P2/P2 vib?/VM-2 可能混用），且早期问号读数不能单独作为正式值。来源：`notes/field_fragments",
          "- **06/22 采样单**：南门点位，余氯 0.32 mg/L，浊度 0.7 NTU。来源：`notes/field_fragments/water_quality_followups.md`。"
        ],
        "abnormal": [
          "- 东区泵站：已见排水沟清理相关线索；振动项需核对是否有可作为本周正式复测的后续记录。"
        ],
        "pending": [
          "| 关键待跟进项 | 东区泵站 2号泵振动复测值（3.2 mm/s）的可靠性 | 06/28 09:05 维护交接补录显示 VM-2 手持表复测 3.2 mm/s；但别名卡提示 P2/vib?/VM-2 可能混用，需核实是否对应东区泵站 2号泵 | 维护组/周报整理 | 下周例会前 | 需确认仪表号绑定、探头贴合状态及可写状态 |"
        ],
        "next_week": [
          "- **东区泵站**：核实 VM-2 手持表（3.2 mm/s）与 2号泵的绑定关系，确认该数值可作为 W26 正式复测值录入；若无法绑定则继续保留 pending。"
        ],
        "source_boundary": [
          "- **别名与标签差异**：P2/vib?/VM-2、SG-WQ-A vs SG-WQ-B 等别名/标签差异已在对应条目中注明，避免误绑。"
        ]
      },
      "related_failed_checks": [
        "confirmed_pump_vibration_retest_resolved_with_provenance",
        "late_pump_vibration_retest_resolved_with_provenance",
        "status_consistency_pump_vibration_not_both_confirmed_and_pending",
        "cross_source_late_pump_retest_binding_complete",
        "no_pump_3_2_formal_without_full_provenance"
      ]
    },
    "water_turbidity": {
      "section_status": {
        "overview": "pending_or_caveated",
        "confirmed": "pending_or_caveated",
        "abnormal": "settled_or_progressed",
        "pending": "pending_or_caveated",
        "next_week": "pending_or_caveated",
        "source_boundary": "pending_or_caveated"
      },
      "section_evidence_lines": {
        "overview": [
          "- 南门水质采样点：06/22 采样单显示余氯 0.32 mg/L、浊度 0.7 NTU；06/23 复测余氯 0.45 mg/L，浊度格为空并注\"试纸批次换新后再补\"；06/26 电话备注称\"没有新增异味投诉\"属背景信息；06/28 晚到队列中出现 0.8 NTU 纸条但样本标签为 SG-WQ-A，与南门常用标签 SG-WQ-B 不一致，需确认绑定关系。"
        ],
        "confirmed": [
          "- **06/22 采样单**：南门点位，余氯 0.32 mg/L，浊度 0.7 NTU。来源：`notes/field_fragments/water_quality_followups.md`。",
          "- **06/23 复测**：余氯 0.45 mg/L；浊度格为空，旁注\"试纸批次换新后再补\"。来源：`notes/field_fragments/water_quality_followups.md`。",
          "- **06/27 内部便签**：采样点标签已重新贴好；本页未说明是否已完成浊度复测。来源：`notes/field_fragments/water_quality_followups.md`。"
        ],
        "abnormal": [
          "- 南门水质采样点：余氯复测可先核对数值与日期；浊度和样本标签需查清后再决定是否列入已确认事实。"
        ],
        "pending": [
          "| 关键待跟进项 | 南门水质浊度复测值（0.8 NTU）的样本绑定 | 06/28 晚到队列纸条显示 0.8 NTU，样本标签 SG-WQ-A；南门常用标签为 SG-WQ-B | 采样值班/周报整理 | 下周例会前 | 需确认样本标签与南门点位绑定关系 |"
        ],
        "next_week": [
          "- **南门水质采样点**：确认 SG-WQ-A 样本是否属于南门点位；若否，则 0.8 NTU 数据仅作为背景参考，不列入已确认事实。"
        ],
        "source_boundary": [
          "- **别名与标签差异**：P2/vib?/VM-2、SG-WQ-A vs SG-WQ-B 等别名/标签差异已在对应条目中注明，避免误绑。"
        ]
      },
      "related_failed_checks": [
        "water_turbidity_source_binding_conflict_retained",
        "water_alias_card_not_sufficient_to_bind_sg_wq_a"
      ]
    },
    "lighting_north_walk": {
      "section_status": {
        "overview": "pending_or_caveated",
        "confirmed": "pending_or_caveated",
        "abnormal": "settled_or_progressed",
        "pending": "pending_or_caveated",
        "next_week": "pending_or_caveated",
        "source_boundary": "absent"
      },
      "section_evidence_lines": {
        "overview": [
          "- 公共照明回路：南侧停车区两段线路（L-South-1、L-South-2）已于 06/24 完成巡检；北侧步道 06/26 因降雨未完成，晚到路线卡拆出 A/B 段——B 段雨后补巡完成，A 段因通道锁闭未巡，不应合并成全段完成。旧 archive 模板中的\"待巡检\"表述可能已被本周材料更新。"
        ],
        "confirmed": [
          "- **北侧步道**：06/26 未完成（当晚降雨，改约下周）；06/28 晚到路线卡拆出 A/B 段——L-North-Walk-B 雨后补巡完成，L-North-Walk-A 因通道锁闭未巡。来源：`notes/field_fragments/lighting_patrol_log.md`、`notes/field_fragments/late_retest_status_queue.md`。"
        ],
        "abnormal": [
          "- 公共照明回路：南侧停车区已有巡检记录；北侧步道是否全段完成需看路线段记录。"
        ],
        "pending": [
          "| 关键待跟进项 | 北侧步道 L-North-Walk-A 段巡检完成状态 | 06/26 记录未完成（降雨改约）；06/28 路线卡标注 A 段因通道锁闭未巡 | 巡检班组 | 下周巡检前 | 需物业开通道后方可完成，不应合并成北步道全段完成 |"
        ],
        "next_week": [
          "- **公共照明回路**：协调物业开通 L-North-Walk-A 通道锁闭，完成 A 段补巡并单独记录。"
        ],
        "source_boundary": []
      },
      "related_failed_checks": [
        "pending_lighting_north_walk_pending_present",
        "pending_lighting_north_walk_pending_cautious_phrasing"
      ]
    },
    "optional_container": {
      "section_status": {
        "overview": "absent",
        "confirmed": "absent",
        "abnormal": "absent",
        "pending": "pending_or_caveated",
        "next_week": "absent",
        "source_boundary": "pending_or_caveated"
      },
      "section_evidence_lines": {
        "overview": [],
        "confirmed": [],
        "abnormal": [],
        "pending": [
          "| 关键待跟进项 | optional briefing/container 准备条件审核 | 关键字段完整性不完整；存在 unresolved 关键待跟进项；未见状态门要求的明确授权语句 | 值班协调 | 状态门满足后 | 当前 blocked 状态下不允许新建任何可选容器文件 |"
        ],
        "next_week": [],
        "source_boundary": [
          "- **可选容器**：当前 state gate 为 BLOCKED，key fields 未全部 confirmed，存在 unresolved 关键待跟进项，且无值班主管明确授权语句，故不创建任何 briefing/container/PPTX/slide/deck/brief 类输出。"
        ]
      },
      "related_failed_checks": [
        "optional_container_late_oral_note_not_authorization",
        "pending_optional_container_gate_blocked_present",
        "pending_optional_container_gate_blocked_cautious_phrasing",
        "trajectory_no_optional_container_creation",
        "final_response_mentions_optional_container_blocked"
      ]
    },
    "hvac_noise": {
      "section_status": {
        "overview": "pending_or_caveated",
        "confirmed": "pending_or_caveated",
        "abnormal": "settled_or_progressed",
        "pending": "pending_or_caveated",
        "next_week": "pending_or_caveated",
        "source_boundary": "pending_or_caveated"
      },
      "section_evidence_lines": {
        "overview": [
          "- 北侧通风机组：AHU-N2 风压短时偏低（06/23 09:15，约 5 分钟后恢复，同屏有疑似重复行）；AHU-N1 过滤网维护已完成并附 closed-note（06/25）；AHU-N2 噪声投诉登记为 open（06/27），无 dB 或复测时段，仅有线上电话听感反馈（06/28），不能据此推断关闭。",
          "- 南门水质采样点：06/22 采样单显示余氯 0.32 mg/L、浊度 0.7 NTU；06/23 复测余氯 0.45 mg/L，浊度格为空并注\"试纸批次换新后再补\"；06/26 电话备注称\"没有新增异味投诉\"属背景信息；06/28 晚到队列中出现 0.8 NTU 纸条但样本标签为 SG-WQ-A，与南门常用标签 SG-WQ-B 不一致，需确认绑定关系。"
        ],
        "confirmed": [
          "- **AHU-N2 风压短时偏低**：06/23 09:15 事件文字\"风压偏低\"，auto-clear，约 5 分钟后恢复；同屏有相邻重复行（06/23 09:16 low pressure duplicate?），疑似重复转写。来源：`notes/field_fragments/hvac_alarm_digest.md`。",
          "- **AHU-N1 过滤网维护**：06/24 14:30 filter service acknowledged（白板写\"等维护回填\"）；06/25 10:05 closed-note 过滤网更换确认，维护组备注\"更换完成，运行观察\"。来源：`notes/field_fragments/hvac_alarm_digest.md`。",
          "- **AHU-N2 噪声投诉**：06/27 18:05 open，投诉来自晚班登记，未附 dB 或复测时段；06/28 07:55 风压状态巡检 normal-note 只写风压恢复，没有提噪声投诉；06/28 11:20 电话备注 AHU-N2 现场反馈\"没听到明显噪声\"，但无 dB 值、复测时段或 closed-note。来源：`notes/field_fragments/hvac_alarm_digest.md`、`notes"
        ],
        "abnormal": [
          "- 北侧通风机组：过滤网维护、风压短时恢复和噪声投诉不是同一事项；需合并同源重复告警后再落文。"
        ],
        "pending": [
          "| 关键待跟进项 | AHU-N2 噪声投诉是否关闭 | 06/27 18:05 open 登记无 dB/复测时段；06/28 11:20 电话反馈\"没听到明显噪声\"但无 dB 值、时段或 closed-note；06/28 07:55 风压 normal-note 未提噪声 | 维护组/值班协调 | 下周例会前 | 缺复测值、时段或关闭记录时不能写已关闭 |"
        ],
        "next_week": [
          "- **北侧通风机组**：跟进 AHU-N2 噪声投诉的 dB 复测或 closed-note；合并 06/23 风压告警的疑似重复行后更新处置进展。"
        ],
        "source_boundary": [
          "- **处理原则**：缺复测值、缺关闭记录、只有电话背景或口头备注时，写入「待跟进事项」而非补编完成状态。",
          "- **重复告警合并**：AHU-N2 风压告警的同屏重复行（06/23 09:15 / 09:16）已按同源事件合并描述，不当作独立异常。"
        ]
      },
      "related_failed_checks": []
    }
  }
}
```
