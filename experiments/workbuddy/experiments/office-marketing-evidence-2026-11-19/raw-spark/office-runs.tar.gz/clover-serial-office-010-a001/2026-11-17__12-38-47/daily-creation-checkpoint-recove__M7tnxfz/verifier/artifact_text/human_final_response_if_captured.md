# Human final response if captured

Final response was not captured; do not fail solely for absence because final-response capture is optional by contract.
