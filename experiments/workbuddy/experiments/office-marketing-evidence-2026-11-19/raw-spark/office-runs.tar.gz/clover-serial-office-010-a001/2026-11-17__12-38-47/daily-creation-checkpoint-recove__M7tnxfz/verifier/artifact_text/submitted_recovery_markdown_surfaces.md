# Submitted recovery Markdown surfaces

## input/workspace/current/daily-log-continue.md

# daily-log-continue

## 09:18 延续记录

- 先确认 `current/latest-checkpoint.md` 与 `state/creation_state.current.json` 的时间接近，均晚于 archive 旧影子。
- `DC-201`、`DC-205`、`DC-213` 作为已保留/已完成上下文，不应被重做。
- `DC-207` 的半成品在 `drafts/` 中存在，不是空白任务；任何后续更新都必须保留标题、三条要点和已写开头。
- `DC-208` 的素材状态在 active board 写“待补证据”，handoff 写“缺口清单可整理”，两者不冲突：只能同步缺口，不可发布。
- `DC-209 -> DC-218` 是一条 blocker 依赖链；`DC-216 -> DC-221` 是另一条 blocker 依赖链。
- `DC-214` 与 `morning-question-list`、`恢复问答` 存在别名压力，先看 alias JSON，不要直接作为新成品。

## 今日纠偏与同步记录（本轮）

### 重复抑制
- **ALIAS-17**：`cover-mini-summary`、`封面摘要草稿` → canonical: `DC-205`，标记为 merge_alias_note_only，不产生新任务。
- **ALIAS-24**：`晨间问答`、`恢复问答`、`morning-question-list` → canonical: `DC-207`，confidence medium，保留 review 语义；`drafts/DC-214-question-list-title-variant.md` 保留为支撑问题草稿，不发布。

### 纠偏
- archive 旧表中的 `DC-205 pending` 和 `DC-209 continue` 已确认为过期影子，以 current/handoff/state 为准。
- `scratch/temp-alias-list.md` 的临时合并建议不等同于确认结果。

### 阻塞保留
- 两条 blocker 链完整暴露——`BLK-A2 -> DC-209 -> DC-218`（CHAIN-A）和 `BLK-C4 -> DC-216 -> DC-221`（CHAIN-C），全部保持 blocked/paused/carryover_blocked 状态，未伪造来源或提前标记完成。

### 草稿保护
- `drafts/DC-207-learning-card-partial.md`：标题、三条要点、开头例子均保留，仅允许补充衔接说明。
- `drafts/DC-208-weekend-review-notes.md`：只同步素材缺口和下一步，不声称发布完成。
- `drafts/DC-214-question-list-title-variant.md`：保留为支撑问题草稿，不发布为独立项。

### Markdown ↔ JSON ↔ progress-state 同步
三个文件在 item_id、status marker、next_action 层面保持一致；`progress_capture.json` 补充了实际更新的文件清单和 no-live-service confirmation。

## 旧行纠偏提示

- archive 中 `DC-205 pending` 是旧导出，不覆盖当前 done/alias-watch 线索。
- scratch 中 `DC-226 maybe today` 是临时想法，read_only 原始 brief 没把它列入今天恢复范围。
- 如果最终需要写中文摘要，请引用本地路径或章节名作为依据，不要写"我查了平台"。

## 今日纠偏与同步记录（本轮）

- **重复抑制**：`DC-205` 的别名 `cover-mini-summary`、`封面摘要草稿` 已在 `state/alias_candidates.json` 归入 ALIAS-17；`DC-214` 的别名压力通过 ALIAS-24 组处理，标记为 review 语义而非独立成品。
- **纠偏**：archive 旧表中的 `DC-205 pending` 和 `DC-209 continue` 已确认为过期影子，以 current/handoff/state 为准。
- **阻塞保留**：两条 blocker 链完整暴露——`BLK-A2 -> DC-209 -> DC-218`（CHAIN-A）和 `BLK-C4 -> DC-216 -> DC-221`（CHAIN-C），下游条目状态不变。
- **草稿保护**：`drafts/DC-207-learning-card-partial.md` 标题、三条要点、开头例子均保留；`drafts/DC-208-weekend-review-notes.md` 只允许缺口清单同步；`drafts/DC-214-question-list-title-variant.md` 保留为支撑问题草稿，不发布。
- **Markdown ↔ JSON ↔ progress-state 同步**：三个文件在 item_id、status marker、next_action 层面保持一致；`progress_capture.json` 补充了实际更新的文件清单和 no-live-service confirmation。


## input/workspace/handoff/reviewer-questions.md

# reviewer questions

## unresolved local questions

- Q1: `DC-214` 的“晨间问答”是否只是 `DC-207` 学习卡片的支撑材料？可见证据：`state/alias_candidates.json` 给 medium confidence，`scratch/temp-alias-list.md` 更激进，handoff 要求保留 review 语义。
- Q2: `DC-208` 的素材缺口清单能否算推进？当前口径：只能算状态同步/缺口整理，不是发布完成。
- Q3: `DC-218` 是否能在没有 `DC-209` 的情况下补一段通用说明？当前口径：不能，因为配图说明依赖公开出处说明。
- Q4: `DC-226` 在 archive 中出现多次，是否加入今天？当前口径：不要加入，除非后续有新的 current/handoff 证据。

## distractor note

- `style-card-blue` 是早期排版想法，只影响语气，不影响恢复状态。

## Reconciliation Summary (本轮更新)

### Alias 归并处理
- **ALIAS-17**（`cover-mini-summary`、`封面摘要草稿`）→ canonical: `DC-205`，标记为 merge_alias_note_only，不产生新任务。
- **ALIAS-24**（`晨间问答`、`恢复问答`、`morning-question-list`）→ canonical: `DC-207`，confidence medium，保留 review 语义；`drafts/DC-214-question-list-title-variant.md` 作为支撑问题草稿保留，不发布。

### Blocker 链保留
- **CHAIN-A**: `BLK-A2 → DC-209 → DC-218`，全部保持 blocked/paused 状态，未伪造来源或提前标记完成。
- **CHAIN-C**: `BLK-C4 → DC-216 → DC-221`，全部保持 paused/carryover_blocked 状态，未伪造来源或提前标记完成。

### Archive Drift 纠偏
- `archive/backlog-shadow-older.md` 中 `DC-205 pending` → 以 current/latest-checkpoint.md 为准，标记 done_alias_watch。
- `archive/backlog-shadow-older.md` 中 `DC-209 continue` → 以 state/dependency_state.json 为准，标记 blocked_by_source。
- `archive/duplicate-watch-archive.md` 中旧线索仅做参考，不覆盖较新工作区状态。

### Draft 保护
- `drafts/DC-207-learning-card-partial.md`：标题、三条要点、开头例子均保留，仅允许补充衔接说明。
- `drafts/DC-208-weekend-review-notes.md`：只同步素材缺口和下一步，不声称发布完成。
- `drafts/DC-214-question-list-title-variant.md`：保留为支撑问题草稿，不发布为独立项。
- `drafts/abandoned/DC-226-topic-pool-old-draft.md`：归档废弃草稿，不参与本次恢复。

