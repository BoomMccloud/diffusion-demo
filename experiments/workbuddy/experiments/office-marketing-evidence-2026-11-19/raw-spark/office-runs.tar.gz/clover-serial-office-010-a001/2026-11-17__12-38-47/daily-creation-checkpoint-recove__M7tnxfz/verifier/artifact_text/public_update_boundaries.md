{
  "boundary_version": "public-hardened-v1",
  "local_only": true,
  "allowed_write_scopes": [
    {
      "scope": "public_state_sync",
      "paths": [
        "input/workspace/current/daily-log-continue.md",
        "input/workspace/state/creation_state.current.json",
        "input/workspace/state/progress_state.progress.json",
        "environment/local_progress_state/progress_capture.json"
      ],
      "allowed": "sync visible status notes without inventing completion"
    },
    {
      "scope": "handoff_notes",
      "paths": [
        "input/workspace/handoff/reviewer-questions.md"
      ],
      "allowed": "add local reconciliation notes if needed"
    }
  ],
  "preserve_paths": [
    "input/workspace/drafts/DC-207-learning-card-partial.md",
    "input/workspace/drafts/DC-208-weekend-review-notes.md",
    "input/workspace/read_only/original-brief.md"
  ],
  "do_not_create": [
    "额外交付文件",
    "预设状态模板",
    "校验脚本",
    "额外检查配置",
    "测试用目录",
    "运行数据包",
    "delivery template artifact"
  ],
  "not_a_verifier": true
}
