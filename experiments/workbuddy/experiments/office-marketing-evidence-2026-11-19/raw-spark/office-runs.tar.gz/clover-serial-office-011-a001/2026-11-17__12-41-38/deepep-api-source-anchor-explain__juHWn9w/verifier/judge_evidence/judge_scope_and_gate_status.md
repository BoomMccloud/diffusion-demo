# Judge scope and deterministic gate status

This verifier-produced evidence record is public-safe deterministic component transparency for a bounded text-only WB Judge.

## Deterministic component status

- submitted_output: `source_anchor_report.md`
- output_exists_at_expected_path: True
- passed_count: 70
- total_count: 105
- pass_rate: 0.6667
- deterministic_passed: False
- preflight_passed_count: 6
- preflight_total_count: 11
- preflight_passed: False
- failed_checks: anchor_min_distinct_source_anchors, anchor_min_distinct_source_paths, anchors_use_input_workspace_prefix, citations_limited_to_public_workspace, anchor_min_core_source_paths, core_source_required_paths_present, documentation_anchor_present, notes_or_maintenance_anchor_present, line_anchors_preferred_for_key_claims, api_export_wrapper_anchor_coverage, generated_binding_anchor_coverage, cxx_binding_header_interface_anchor_coverage, pybind_route_module_table_bridge_explained, runtime_bridge_queue_state_anchor_coverage, runtime_queue_state_terms_present, runtime_submission_ticket_and_queue_explained, backend_selection_implementation_anchor_coverage, backend_selector_branch_terms_present, implementation_candidates_bound_to_source, device_packet_launch_to_kernel_explained, host_deferred_outcomes_not_erased, chain_mentions_backend_selection_then_launch, chain_order_core_symbols, implementation_not_docs_only, stale_notes_not_authoritative, generated_files_source_vs_docs_boundary, examples_tests_tools_context_not_authority, static_source_snapshot_caveat_present, source_vs_doc_boundary_has_source_and_doc_anchors, route_status_candidate_excluded, native_stub_runtime_not_used_as_proof, small_group_candidate_downgraded, context_variant_np_route_submit_with_context_downgraded, candidate_exclusion_has_source_anchors, single_markdown_delivery_named
- llm_judge_activation_allowed: False

## Deterministic-owned scope that Judge must not rescore or recover

- output file existence/path, only-main-output contract, Markdown parseability, required sections, and structural output facts
- source-anchor syntax, repo-relative path containment, line/symbol validity, exact anchor/path/source-family coverage, exact source-chain/order facts, and hidden expected facts
- input workspace state diff/no-mutation/no-side-effect checks
- no external/live/private/runtime/GPU/compile/OCR/VLM/MCP/Skill safety checks and secret/private-marker scans

## Judge-admissible bounded semantic scope

- semantic source fidelity from the submitted report and visible cited public source-anchor extracts
- source-vs-doc conflict reasoning, candidate-exclusion/downgrade quality, caveat discipline, and explanation coherence

## Evidence exclusions

This evidence set excludes hidden gold, oracle output, construction notes, construction-only relation graphs, private trace/source context, private paths, private URLs, credentials, customer data, proprietary code, unpublished assets, model logs, final-agent replies, external web knowledge, runtime/compile/GPU execution, OCR, VLM, images, video, audio, browser/API/live-service behavior, MCP, and Skill evidence.

## Modality

Text-only non-multimodal Judge evidence; VLM/image/OCR/pixel/render/browser/API/live-service/runtime/compile/GPU/MCP/Skill behavior is outside scope.