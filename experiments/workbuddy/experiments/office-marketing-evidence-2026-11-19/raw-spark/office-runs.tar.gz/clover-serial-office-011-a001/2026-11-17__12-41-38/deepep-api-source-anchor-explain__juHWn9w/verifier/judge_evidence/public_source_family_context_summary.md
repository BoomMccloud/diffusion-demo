# Public source-family context summary

This summary is built from the public input workspace and the submitted report only. It is for bounded text-only Judge context, not for deterministic path, line, exact coverage, safety, or state-diff scoring.

Public workspace root: `input/nimbuspipe_workspace/`
Public file count observed: 106
Submitted report cites or mentions 52 distinct public workspace paths detected by verifier extraction.

## Artifact families

### Python API/export/wrapper/generated binding surfaces
- Public files in family: 23
- Cited or mentioned by submitted report: 15
- Cited/mentioned examples:
  - `input/nimbuspipe_workspace/python/nimbuspipe/__init__.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/_generated/README.md`
  - `input/nimbuspipe_workspace/python/nimbuspipe/_generated/binding_index.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/_generated/collective_bindings.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/_generated/route_schema.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/_generated/routing_bindings.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/aliases.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/api.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/errors.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/options.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/routing/__init__.py`
  - `input/nimbuspipe_workspace/python/nimbuspipe/routing/batch_route.py`
- Other public files in this family, for context only:
  - `input/nimbuspipe_workspace/python/nimbuspipe/_native.py`

### C/C++ headers, generated tables, and binding descriptors
- Public files in family: 24
- Cited or mentioned by submitted report: 13
- Cited/mentioned examples:
  - `input/nimbuspipe_workspace/include/nimbuspipe/backend/cuda_route_backend.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/backend_choice.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/generated/binding_dispatch_ids.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/generated/binding_route_table.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/queue/ticket_store.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/route_api.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/route_request.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/route_ticket.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/runtime_context.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/state/window_state.h`
  - `input/nimbuspipe_workspace/src/bindings/generated_route_table.cpp`
  - `input/nimbuspipe_workspace/src/bindings/py_collective_module.cpp`
- Other public files in this family, for context only:
  - `input/nimbuspipe_workspace/include/nimbuspipe/backend/backend_selector.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/backend/host_route_backend.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/queue/queue_policy.h`
  - `input/nimbuspipe_workspace/include/nimbuspipe/queue/route_queue.h`

### runtime bridge, queue, ticket, stream, and state sources
- Public files in family: 11
- Cited or mentioned by submitted report: 2
- Cited/mentioned examples:
  - `input/nimbuspipe_workspace/src/runtime/queue/route_queue.cpp`
  - `input/nimbuspipe_workspace/src/runtime/route_normalize.cpp`
- Other public files in this family, for context only:
  - `input/nimbuspipe_workspace/src/runtime/queue/queue_policy.cpp`
  - `input/nimbuspipe_workspace/src/runtime/queue/ticket_store.cpp`
  - `input/nimbuspipe_workspace/src/runtime/route_request.cpp`
  - `input/nimbuspipe_workspace/src/runtime/route_runtime.cpp`
  - `input/nimbuspipe_workspace/src/runtime/route_ticket.cpp`
  - `input/nimbuspipe_workspace/src/runtime/runtime_bridge.cpp`

### backend selector and implementation candidates including CUDA-style source files
- Public files in family: 12
- Cited or mentioned by submitted report: 3
- Cited/mentioned examples:
  - `input/nimbuspipe_workspace/src/backend/backend_selector.cpp`
  - `input/nimbuspipe_workspace/src/backend/host_route_backend.cpp`
  - `input/nimbuspipe_workspace/src/backend/route_backend_matrix.cpp`
- Other public files in this family, for context only:
  - `input/nimbuspipe_workspace/cuda/collective_exchange_kernel.cu`
  - `input/nimbuspipe_workspace/cuda/packet_format_kernel.cu`
  - `input/nimbuspipe_workspace/cuda/route_observer_kernel.cu`
  - `input/nimbuspipe_workspace/cuda/route_packet_kernel.cu`
  - `input/nimbuspipe_workspace/cuda/route_reduce_kernel.cu`
  - `input/nimbuspipe_workspace/cuda/route_small_group_kernel.cu`
  - `input/nimbuspipe_workspace/cuda/route_window_kernel.cu`

### docs, notes, examples, tests, and tools context
- Public files in family: 33
- Cited or mentioned by submitted report: 19
- Cited/mentioned examples:
  - `input/nimbuspipe_workspace/BUILD_NOTES.txt`
  - `input/nimbuspipe_workspace/README.md`
  - `input/nimbuspipe_workspace/docs/api/collectives.md`
  - `input/nimbuspipe_workspace/docs/api/route_options.md`
  - `input/nimbuspipe_workspace/docs/api/routing.md`
  - `input/nimbuspipe_workspace/docs/design/generated_bindings.md`
  - `input/nimbuspipe_workspace/docs/design/routing_pipeline.md`
  - `input/nimbuspipe_workspace/docs/design/stream_policy.md`
  - `input/nimbuspipe_workspace/docs/maintenance/route_review_notes.md`
  - `input/nimbuspipe_workspace/docs/release_notes/0.8-routing.md`
  - `input/nimbuspipe_workspace/docs/release_notes/1.0-source-layout.md`
  - `input/nimbuspipe_workspace/examples/route_basic.py`
- Other public files in this family, for context only:
  - `input/nimbuspipe_workspace/docs/api/status_and_tickets.md`
  - `input/nimbuspipe_workspace/docs/design/backend_choice.md`

## Deterministic-only boundaries preserved

The deterministic verifier remains authoritative for artifact existence/path, Markdown parseability and sections, source-anchor syntax, path and line/symbol validity, exact source-family coverage, exact source-chain/order checks, state diff/no-mutation checks, and safety scans for external/live/private/runtime/GPU/compile/OCR/VLM/MCP/Skill claims.
WB Judge evidence must not include or rely on hidden gold, oracle output, construction-only relation graphs, private traces, model logs, final-agent replies, external web knowledge, live service behavior, code execution, compilation, GPU runtime, screenshots, OCR, VLM, or image/video/audio evidence.