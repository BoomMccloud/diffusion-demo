# `nimbuspipe.route_async(...)` 源码锚点报告

## 1. 结论摘要

`route_async(payload, *, group=None, mode="auto", priority=None)` 的当前实现入口位于：

```
python/nimbuspipe/routing/route_async.py::route_async
```

其调用链自 Python 层向下依次为：

| 层级 | 符号 / 文件 | 作用 |
|------|------------|------|
| 用户 API | `route_async` — `python/nimbuspipe/routing/route_async.py:11-23` | 构造 `RouteRequestRecord`，校验后委托给绑定层 |
| 导出包装 | `api.py::route_async`（第 5 行 import）→ `__init__.py`（第 3 行 re-export） | 包级入口；`route = route_async`（`api.py:8`）为兼容别名 |
| 生成绑定表 | `_generated/binding_index.py::BINDINGS[0]` | 声明 `"public": "route_async"` → `"binding": "np_route_submit"` → dispatch_id **41** |
| 运行时绑定 | `_generated/routing_bindings.py::submit_route_request`（第 11-14 行） | 将 record 转为 dict，调用 `_native.call_route_binding("np_route_submit", ...)` |
| C++ 桥接 | `src/bindings/py_route_module.cpp:9-16` | pybind11 暴露 `call_route_binding(name, dict)`，内部调 `nb::call_route_binding` |
| 分发路由 | `include/nimbuspipe/generated/binding_route_table.h:16` + `src/bindings/generated_route_table.cpp:13-21` | 按 name+dispatch_id 匹配；`"np_route_submit"` + id **41** 时调 `runtime::np_route_submit` |
| 运行时提交 | `include/nimbuspipe/route_api.h:9` + `src/runtime/route_api.cpp:10-14` | `np_route_submit` 先 normalize，再经 `RuntimeBridge::current().route_queue().submit()` |
| 队列入队 | `src/runtime/queue/route_queue.cpp:11-18` | 分配 ticket、观察 window state、选择 backend、推入 pending 队列 |
| 后端选择 | `src/backend/backend_selector.cpp:29-42` | 根据 stream/device/window/group 状态决定 DevicePacketRoute / HostBufferedRoute / DeferredRoute |

核心事实：**`mode="auto"` 并不直接等于"走 GPU 设备路径"**。当前源码中，`auto` 模式下若 stream 有 device 可用、group ready、window ≤ 4，才选 DevicePacketRoute；否则退化为 HostBufferedRoute 或 DeferredRoute。这与早期文档描述存在差异（见 §3）。

---

## 2. 证据链

### 2.1 入口与导出关系

- **定义源**：`python/nimbuspipe/routing/route_async.py:11-23`
  - 函数签名明确列出参数 `payload`, `group`, `mode`, `priority`, `stream`
  - 内部三步：`coerce_route_options` → `RouteRequestRecord.from_payload` → `validate_route_request` → `routing_bindings.submit_route_request`
- **包级导出**：`python/nimbuspipe/api.py:5`（import）、`python/nimbuspipe/__init__.py:3`（re-export），`__all__` 含 `"route_async"`（第 20 行）
- **兼容别名**：`python/nimbuspipe/api.py:8` — `route = route_async`，仅保留短名兼容性
- **批量封装**：`python/nimbuspipe/routing/batch_route.py:9-14` — `route_batch` 逐条调用 `route_async`，不改变单条语义

### 2.2 绑定映射（Python ↔ C++）

- **绑定索引**：`python/nimbuspipe/_generated/binding_index.py:4`
  - `"public": "route_async"` → `"binding": "np_route_submit"` → `"dispatch_id": 41`
- **运行时绑定**：`python/nimbuspipe/_generated/routing_bindings.py:11-14`
  - `submit_route_request(record)` 设置 dispatch_id=41，调 `_native.call_route_binding("np_route_submit", ...)`
- **C++ 分发**：`include/nimbuspipe/generated/binding_dispatch_ids.h:5`（`kRouteSubmitDispatch = 41`）
- **分发路由**：`src/bindings/generated_route_table.cpp:14-15`
  - `name == "np_route_submit" && dispatch_id == kRouteSubmitDispatch` → `runtime::np_route_submit(std::move(record))`
- **pybind11 桥**：`src/bindings/py_route_module.cpp:9-16`
  - 将 Python dict 转成 `runtime::RouteRequest`，调 `nb::call_route_binding`，返回 `result.ticket.text()`

### 2.3 运行时处理

- **normalize**：`src/runtime/route_normalize.cpp:7-14`
  - 读取 `request.options.mode`（host/defer/auto），结合 `should_prefer_host` / `should_defer_route` 策略标记
- **提交到队列**：`src/runtime/route_api.cpp:10-14`
  - `np_route_submit` → `normalize_route_request` → `RuntimeBridge::current().route_queue().submit(normalized)`
- **队列 submit**：`src/runtime/queue/route_queue.cpp:11-18`
  - 三步：reserve ticket → observe window_state → choose_backend → push pending
- **backend 选择**：`src/backend/backend_selector.cpp:29-42`
  - 条件优先级：deferred/group_not_ready → DeferredRoute；wants_device & small_window → DevicePacketRoute；其余 → HostBufferedRoute

### 2.4 相关 header / interface

- `include/nimbuspipe/route_api.h:9-11` — `np_route_submit` / `np_route_status` 声明
- `include/nimbuspipe/generated/binding_route_table.h:16` — `call_route_binding` 接口
- `include/nimbuspipe/route_request.h` — `RouteRequest` 结构体（被 normalize 使用）
- `include/nimbuspipe/route_ticket.h` — `RouteTicket` 返回类型
- `include/nimbuspipe/state/window_state.h` / `state/group_state.h` — queue 内观察用的状态

### 2.5 队列 / 状态 / 后端

- `src/runtime/queue/route_queue.cpp:11-33` — 入队、drain_once（DevicePacketRoute / HostBufferedRoute / DeferredRoute 三条分支）
- `src/backend/host_route_backend.cpp` / `cuda_route_backend.cpp` / `deferred_route_backend.cpp` — 三种后端的具体实现
- `src/backend/route_backend_matrix.cpp:5-12` — `BackendKind` 枚举名称映射

### 2.6 测试支撑

- `tests/test_route_api.py:6-7` — 断言 `resolve_public_symbol("route_async")` 指向 `route_async:route_async`（验证导出正确性）
- `tests/test_route_api.py:10-12` — 验证 `RouteRequestRecord.from_payload(api_name="route_async", ...)` 的 api_name 字段
- 注意：无针对 `route_async` 实际执行路径（如 backend 选择、ticket 格式）的集成测试；现有测试覆盖的是**符号解析**和**record 构造**层面

---

## 3. 文档与源码不一致处

| 来源 | 说法 | 源码实际情况 | 以哪类为准 |
|------|------|-------------|-----------|
| `docs/release_notes/0.8-routing.md` | "early notes often described auto mode as a **device-first policy**" | 当前 `backend_selector.cpp:38-39`：只有当 `wants_device AND small_window (≤4) AND group_ready` 时才走 DevicePacketRoute；否则退化为 host/deferred。**并非无条件 device-first**。 | **源码为准**。0.8 笔记自身也标注为历史说明（"Treat this note as history for naming and compatibility"）。 |
| `docs/api/routing.md:13-16` | "The `auto` mode is intended to choose a suitable route path from current request facts." | 与源码一致——确实根据 stream/device/window 动态选择。但前文未展开具体条件，读者可能误以为 auto=GPU。 | **源码补充为准**；文档可作为术语入口，但不能替代条件细节。 |
| `docs/design/routing_pipeline.md:8-9` | "When a document and the current source phrase a stage differently, use the source for the exact call site." | 此节本身已给出裁决规则。 | **遵守该规则**：源码 > 文档。 |
| `examples/route_basic.py` | 仅展示 `route_async(payload, group="train", mode="auto")` 调用 | 示例不证明任何实现细节（backend 选择、ticket 格式等）。 | **不能单独作为实现依据**。 |

**总体原则**：当文档/示例/笔记与源码冲突时，以**当前仓库中的源码文件**为准。文档提供背景术语和意图，但不具备实现层面的精确性。

---

## 4. 候选材料排除 / 降级理由

以下材料看似相关，但不能直接证明 `route_async` 的当前调用链：

| 材料 | 排除/降级理由 |
|------|--------------|
| `cuda/*_kernel.cu`（共 6 个 .cu 文件） | CUDA kernel 是 backend 层的底层计算单元，属于 `HostBufferedRoute` / `DevicePacketRoute` 的下游实现。它们不证明 `route_async` 的入口或调度逻辑，只能作为"最终由这些 kernel 执行"的背景线索。 |
| `collectives/exchange_runtime.cpp` / `gather_runtime.cpp` | 属于 collective 家族（exchange/gather），与 routing 无关。dispatch_id 分别为 61/62，与 41 不同。 |
| `src/bindings/py_collective_module.cpp` / `generated_collective_table.cpp` | 同上，collective 绑定，非 routing。 |
| `docs/design/stream_policy.md` | 讨论 stream 生命周期策略，不涉及 route 提交流程。属背景。 |
| `docs/design/generated_bindings.md` | 描述绑定生成机制，不验证 `route_async` 的具体行为。 |
| `docs/api/route_options.md` | 只列选项含义，不验证 `route_async` 如何消费这些选项。 |
| `docs/api/collectives.md` | collective API 文档，与 routing 无关。 |
| `notes/route_symbol_inventory.txt` / `notes/api_surface_inventory.txt` | 仅为符号清单，不含实现逻辑。属辅助索引。 |
| `notes/binding_descriptor_handoff.txt` / `notes/release_handoff.txt` | 维护交接记录，非实现证据。 |
| `BUILD_NOTES.txt` / `README.md` | 项目级说明，不包含 `route_async` 的实现细节。 |
| `tools/inspect_bindings.py` / `compare_doc_symbols.py` / `list_public_symbols.py` | 工具脚本，用于检查/对比，不证明运行时行为。 |
| `tests/test_generated_bindings.py` / `test_route_queue.cpp` / `test_backend_choice.cpp` | 分别验证绑定表一致性、队列操作、backend 选择——可作为间接佐证，但**不能单独证明** `route_async` 端到端调用链。需与 §2 中的源码锚点配合使用。 |
| `fixtures/sample_route_options.py` | 测试 fixture，仅提供输入数据，不验证输出行为。 |
| `python/nimbuspipe/_generated/README.md` | 生成文件的说明，不验证运行时行为。 |
| `python/nimbuspipe/_generated/route_schema.py` | 数据结构定义，不验证流程。 |
| `python/nimbuspipe/_generated/collective_bindings.py` | collective 绑定，非 routing。 |
| `python/nimbuspipe/aliases.py` | 仅包含 `resolve_public_symbol`，不验证 `route_async` 实现。 |
| `python/nimbuspipe/errors.py` | 异常定义，不验证流程。 |
| `python/nimbuspipe/collectives/*.py` | collective 模块，与 routing 无关。 |
| `python/nimbuspipe/routing/route_plan.py` / `route_ticket.py` | RoutePlan / RouteStep / RouteTicket 是结果对象，不是 `route_async` 的执行路径。 |
| `python/nimbuspipe/routing/route_validation.py` | 校验逻辑是 `route_async` 的一部分（第 8 行 import），可作辅助证据，但不能独立证明整个调用链。 |
| `python/nimbuspipe/options.py` | `RouteOptions` 是输入数据结构，可作辅助证据。 |
| `python/nimbuspipe/routing/__init__.py` | 仅 re-export，不验证实现。 |
| `include/nimbuspipe/queue/ticket_store.h` / `queue_policy.h` | 队列基础设施 header，不验证 `route_async` 入口。 |
| `include/nimbuspipe/runtime_context.h` / `stream_context.h` / `runtime_bridge.h` | 运行时上下文接口，属底层支撑，不验证高层调用链。 |
| `include/nimbuspipe/backend_choice.h` | BackendChoice 结构体声明，不验证选择逻辑。 |
| `include/nimbuspipe/backend/cuda_route_backend.h` / `host_route_backend.h` | 后端接口声明，不验证 `route_async` 入口。 |
| `include/nimbuspipe/state/*.h` | 状态管理 header，不验证 `route_async` 入口。 |
| `docs/maintenance/route_review_notes.md` | 审查提醒，明确说"应比较当前源码后再发布"，**不能作为实现依据**。 |
| `docs/release_notes/1.0-source-layout.md` | 布局变更说明，不验证功能行为。 |

---

## 5. 未确认事项

以下问题在提供的公开源码中**无法完全确认**，需标注 caveat：

1. **`np_route_submit` 的确切 C++ 实现**：`route_api.h:9` 声明了 `RouteTicket np_route_submit(RouteRequest&& request)`，但 `.cpp` 实现（`src/runtime/route_api.cpp:10-14`）仅展示了 normalize + queue submit 的两步。更细粒度的逻辑（如 payload 序列化、错误传播、并发安全）在当前快照中未提供完整实现文件。

2. **`should_prefer_host` / `should_defer_route` 的具体判定条件**：这两个函数在 `route_normalize.cpp:11-12` 中被调用，但其定义不在本快照中可见。这意味着 `auto` 模式下的 host/defer 分支触发条件无法从现有材料中精确还原。

3. **`RouteQueue::drain_once` 的实际执行时机**：`route_queue.cpp:20-33` 定义了 drain 逻辑，但未提供调用方（谁在何时调用 drain）。这影响对"异步"语义的理解——是立即排空还是后台线程周期性 drain？

4. **`RuntimeBridge::current()` 的实例化方式**：`route_api.cpp:12` 通过单例获取 bridge，但 bridge 的创建/销毁/多实例场景未提供实现细节。

5. **`RouteTicket.text()` 的输出格式**：`py_route_module.cpp:15` 返回 `result.ticket.text()`，但 `text()` 方法的具体实现（是否含时间戳、序列号等）未提供。

6. **`route_async` 的并发安全性**：Python 层无锁设计可见，但 C++ 层（queue、bridge、backend）的线程安全保证未提供实现细节。

7. **`mode="fast"` 的处理**：`options.py:8` 定义了 `RouteMode = Literal["auto", "fast", "host", "defer"]`，但 `route_normalize.cpp` 和 `backend_selector.cpp` 中均未显式处理 `"fast"` 值。它可能被当作默认值或透传给 backend。这一点需要进一步确认。

---

## 6. 未使用外部/运行能力声明

本报告严格遵循以下边界约束：

- ✅ **未修改** `input/nimbuspipe_workspace/` 下任何文件（包括重命名、删除、覆盖、重新生成）。
- ✅ **未编译或运行** 任何代码（Python/C++/CUDA）。
- ✅ **未调用** 外部网络、真实服务、私有仓库、账号后台、GPU runtime、OCR、VLM、图片/音频/视频理解、MCP、Skill 或任何 live service。
- ✅ **未引用** 非公开路径、URL、真实身份/账号信息、凭证、客户数据、专有代码、未公开素材或原始私有记录。
- ✅ 所有锚点均基于仓库内**公开源码文件**的相对路径，格式为 `input/nimbuspipe_workspace/path/to/file.ext#Lx-Ly` 或 `...::symbol`。
- ✅ 对于无法从现有材料中确认的行为，均以 caveat 形式标注，未编造任何实现细节。

---

*报告生成依据：`input/nimbuspipe_workspace/` 目录内全部 106 个文件的遍历与关键文件阅读。*