# Cited public source-anchor extracts

This verifier-produced Judge evidence is derived only from source anchors cited in the submitted `source_anchor_report.md` and files under `input/nimbuspipe_workspace/`.
It does not use hidden gold, oracle output, construction records, private traces, model logs, external knowledge, runtime execution, compilation, or GPU behavior.

## `python/nimbuspipe/routing/route_async.py::route_async`

Public path: `input/nimbuspipe_workspace/python/nimbuspipe/routing/route_async.py`

```text
8: from nimbuspipe.routing.route_validation import validate_route_request
9: 
10: 
11: def route_async(
12:     payload: Any,
13:     *,
14:     group: str | None = None,
15:     mode: str = "auto",
16:     priority: int | None = None,
17:     stream=None,
18: ) -> str:
19:     """Submit a routing request and return a ticket string without blocking."""
```
