{
  "case_id": "analyst_forecast_extract_2026Q1",
  "workbook": "analyst_forecast_extract.xlsx",
  "target_company": "澜星航空服务股份有限公司",
  "sheet_row_counts": {
    "forecast_fields": 8,
    "rating_changes": 5,
    "target_price_table": 5,
    "missing_fields": 6
  },
  "normalization_contract": {
    "company_normalization": "Use active alias (active='Y') from company_dictionary.xlsx to map aliases '澜星航服', '澜星航空服务', 'LX AirSvc' to canonical_company '澜星航空服务股份有限公司'",
    "rating_normalization": "Map source rating text via rating_codebook.json only; do not infer ratings from sentiment words outside the codebook.",
    "date_format": "YYYY-MM-DD",
    "fiscal_year_format": "YYYY (four-digit)",
    "net_profit_unit": "CNY_mn",
    "eps_unit": "CNY",
    "target_price_unit": "CNY/share",
    "distractor_policy": "Non-target company rows, aggregate summaries, and rolling statistics are excluded from main fact tables and written to missing_fields per schema rules.",
    "no_inference": "Do not infer or guess missing numeric forecasts, target prices, or fiscal years; record them as missing_fields entries instead."
  }
}