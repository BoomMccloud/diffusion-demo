# Workbook: forecast_workbook.xlsx

## Sheet 1: forecast_fields
Dimensions: 9 rows x 8 columns
R1: institution | report_date | canonical_company | fiscal_year | net_profit_cny_mn | eps_cny | source_file | source_row_or_section
R2: 晨桥证券 | 2026-03-18 | 澜星航空服务股份有限公司 | 2026 | 842.5 | 0.84 | broker_summaries/summary_chenqiao_sec_2026-03-18.md | forecast_detail_export!row2
R3: 晨桥证券 | 2026-03-18 | 澜星航空服务股份有限公司 | 2027 | 973 | 0.97 | broker_summaries/summary_chenqiao_sec_2026-03-18.md | forecast_detail_export!row3
R4: 北岭研究 | 2026-03-19 | 澜星航空服务股份有限公司 | 2026 | 818 | 0.82 | broker_summaries/summary_beiling_research_2026-03-19.md | forecast_detail_export!row4
R5: 北岭研究 | 2026-03-19 | 澜星航空服务股份有限公司 | 2027 | 951.6 | 0.95 | broker_summaries/summary_beiling_research_2026-03-19.md | forecast_detail_export!row5
R6: 杉岭资本 | 2026-03-21 | 澜星航空服务股份有限公司 | 2026 | 802.4 | 0.8 | broker_summaries/summary_cedar_capital_2026-03-21.md | forecast_detail_export!row6
R7: 杉岭资本 | 2026-03-21 | 澜星航空服务股份有限公司 | 2027 | 906.3 | 0.91 | broker_summaries/summary_cedar_capital_2026-03-21.md | forecast_detail_export!row7
R8: 杉岭资本 | 2026-03-21 | 澜星航空服务股份有限公司 | 2028 | 1048.8 | 1.05 | broker_summaries/summary_cedar_capital_2026-03-21.md | forecast_detail_export!row8
R9: 飞隼市场 | 2026-03-25 | 澜星航空服务股份有限公司 | 2028 | 1190.4 | 1.19 | broker_summaries/summary_feisun_markets_2026-03-25.md | forecast_detail_export!row10

## Sheet 2: rating_changes
Dimensions: 6 rows x 7 columns
R1: institution | report_date | canonical_company | source_rating_text | standard_rating | action_type | source_file
R2: 晨桥证券 | 2026-03-18 | 澜星航空服务股份有限公司 | 维持买入 | buy | maintain | broker_summaries/summary_chenqiao_sec_2026-03-18.md
R3: 北岭研究 | 2026-03-19 | 澜星航空服务股份有限公司 | 由审慎增持调整为增持 | outperform | upgrade | broker_summaries/summary_beiling_research_2026-03-19.md
R4: 杉岭资本 | 2026-03-21 | 澜星航空服务股份有限公司 | 下调至中性 | neutral | downgrade | broker_summaries/summary_cedar_capital_2026-03-21.md
R5: 飞隼市场 | 2026-03-25 | 澜星航空服务股份有限公司 | 增持 | outperform | current | broker_summaries/summary_feisun_markets_2026-03-25.md
R6: 关口证券 | 2026-03-26 | 澜星航空服务股份有限公司 | 中性 | neutral | current | broker_summaries/summary_guankou_sec_2026-03-26.md

## Sheet 3: target_price_table
Dimensions: 6 rows x 6 columns
R1: institution | report_date | canonical_company | target_price_cny_per_share | target_price_status | source_file
R2: 晨桥证券 | 2026-03-18 | 澜星航空服务股份有限公司 | 18.6 | present | broker_summaries/summary_chenqiao_sec_2026-03-18.md
R3: 北岭研究 | 2026-03-19 | 澜星航空服务股份有限公司 |  | missing | broker_summaries/summary_beiling_research_2026-03-19.md
R4: 杉岭资本 | 2026-03-21 | 澜星航空服务股份有限公司 | 17.2 | present | broker_summaries/summary_cedar_capital_2026-03-21.md
R5: 飞隼市场 | 2026-03-25 | 澜星航空服务股份有限公司 |  | missing | broker_summaries/summary_feisun_markets_2026-03-25.md
R6: 关口证券 | 2026-03-26 | 澜星航空服务股份有限公司 | 16.8 | present | broker_summaries/summary_guankou_sec_2026-03-26.md

## Sheet 4: missing_fields
Dimensions: 7 rows x 6 columns
R1: institution | report_date | company_alias | missing_type | evidence | source_file
R2: 晨桥证券 | 2026-03-18 | 澜星航服 | missing_numeric_forecast | 摘要段提及FY2028盈利预测但未披露具体数值，预测表亦无对应行 | broker_summaries/summary_chenqiao_sec_2026-03-18.md
R3: 东港证券 | 2026-03-23 | 海岚机场服务 | non_target_company | 东港证券在2026-03-23发布的报告中覆盖海岚机场服务（首次覆盖，评级推荐，目标价12.20元/股），但海岚机场服务不是目标公司 | broker_summaries/summary_donggang_sec_2026-03-23.md
R4: 飞隼市场 | 2026-03-25 | LX AirSvc | missing_numeric_forecast | 飞隼市场对LX AirSvc的预测表仅包含2028E行；2026E数值未在本报告提供 | broker_summaries/summary_feisun_markets_2026-03-25.md
R5: 飞隼市场 | 2026-03-25 | LX AirSvc | missing_numeric_forecast | 飞隼市场对LX AirSvc的预测表仅包含2028E行；2027E数值未在本报告提供 | broker_summaries/summary_feisun_markets_2026-03-25.md
R6: 关口证券 | 2026-03-26 | 澜星航服 | missing_numeric_forecast | 关口证券对澜星航服2027E行的归母净利润和EPS均为空值（破折号占位） | broker_summaries/summary_guankou_sec_2026-03-26.md
R7: 页面统计区 | 2026-03-27 | 多公司 | aggregate_summary_not_report_row | 近六个月共有9家机构更新交通服务板块覆盖的滚动统计摘要，非单条机构报告 | broker_summaries/summary_rollup_statistics_2026-03-27.md
