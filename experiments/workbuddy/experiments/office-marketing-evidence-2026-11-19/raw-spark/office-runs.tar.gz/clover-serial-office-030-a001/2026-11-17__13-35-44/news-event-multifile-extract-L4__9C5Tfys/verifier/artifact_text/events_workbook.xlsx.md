# Workbook: events_workbook.xlsx

## Sheet 1: events
Dimensions: 9 rows x 9 columns
R1: event_id | event_date | category | category_zh | canonical_entity_or_topic | core_fact | source_files | citation_anchors | merged_source_count
R2: EVT-001 | 2026-04-10 | policy_update | 政策更新 | 渠道设备更新专项 | 合成发展改革办公室发布首批试点清单，试点范围包括仓配终端、冷链周转柜和门店节能改造；首批额度为42.0亿元，项目申报从2026-04-15开始。 | morning_finance_page_0410.md;policy_meeting_release.pdf | morning_finance_page_0410.md｜宏观与政策｜'首批额度为 42.0 亿元'\npolicy_meeting_release.pdf｜附件：二季度重点工具摘要｜'首批试点清单｜42.0 亿元' | 2
R3: EVT-002 | 2026-04-10 | macro_data | 宏观数据 | 澜舟物流景气指数 | 发布3月综合读数51.6，较上月回升1.1点；样本覆盖18个城市仓配节点。 | morning_finance_page_0410.md | morning_finance_page_0410.md｜宏观与政策｜'综合读数为 51.6，较上月回升 1.1 点' | 1
R4: EVT-003 | 2026-04-10 | company_disclosure | 企业公告 | 星澈云服股份 | 披露一季度经营快报，企业云托管收入同比增长18.4%，海外节点迁移费用增加；公司未披露二季度收入指引。 | morning_finance_page_0410.md;a_share_flash_stream_0410.txt;evening_notice_rollup_0410.md | morning_finance_page_0410.md｜公司消息｜'云托管收入同比增长 18.4%'\na_share_flash_stream_0410.txt｜A股公告｜'披露一季度经营快报，云托管收入同比增长 18.4%'\nevening_notice_rollup_0410.md｜品大事｜'发布一季度经营快报' | 3
R5: EVT-004 | 2026-04-11 | company_disclosure | 企业公告 | 北衡智造股份 | 董事会审议通过设备采购合同，合同金额6.8亿元；公告正文落款日期为2026-04-11，交付周期覆盖2026年6月至2027年1月。 | a_share_flash_stream_0410.txt;evening_notice_rollup_0410.md | a_share_flash_stream_0410.txt｜A股公告｜'董事会审议通过设备采购合同，合同金额 6.8 亿元'\nevening_notice_rollup_0410.md｜品大事｜'公告正文落款日期为 2026-04-11' | 2
R6: EVT-005 | 2026-04-10 | market_movement | 股市动态 | 沪澜综合指数 | 截至午间上涨0.5%，云服务与智能制造板块成交活跃。该数据经市场数据快报更正确认为2026-04-10午间表现。 | morning_finance_page_0410.md | morning_finance_page_0410.md｜市场表现｜'沪澜综合指数上涨 0.5%' | 1
R7: EVT-006 | 2026-04-11 | market_movement | 股市动态 | 沪澜综合指数 | 收涨0.7%，盘中一度下探0.4%；智能制造和云服务权重贡献较高。 | market_data_brief_0411.txt | market_data_brief_0411.txt｜【指数】｜'沪澜综合指数收涨 0.7%' | 1
R8: EVT-007 | 2026-04-11 | policy_update | 政策更新 | 小微票据周转便利 | 延长期限至2026-06-30，适用范围覆盖合成区内中小企业票据再贴现需求。 | policy_meeting_release.pdf | policy_meeting_release.pdf｜会议内容｜'延长小微票据周转便利期限至 2026-06-30'\npolicy_meeting_release.pdf｜附件：二季度重点工具摘要｜'延长期限｜延至 2026-06-30' | 1
R9: EVT-008 | 2026-04-11 | policy_update | 政策更新 | 渠道设备更新专项配套服务 | 配合渠道设备更新专项，推动金融机构完善项目申报配套服务。 | policy_meeting_release.pdf | policy_meeting_release.pdf｜会议内容｜'配合渠道设备更新专项，推动金融机构完善项目申报配套服务' | 1

## Sheet 2: entity_mentions
Dimensions: 10 rows x 6 columns
R1: canonical_entity | alias_seen | entity_type | source_file | source_section | first_mention_order
R2: 星澈云服股份 | 星澈云; 星澈云服 | listed_company | morning_finance_page_0410.md | 公司消息 | 1
R3: 北衡智造股份 | 北衡智能; 北衡智造 | listed_company | a_share_flash_stream_0410.txt | A股公告 | 1
R4: 星澄云服集团 | 星澄云服 | listed_company | evening_notice_rollup_0410.md | 观业绩 | 1
R5: 澜舟物流景气指数 | 澜舟物流指数 | macro_indicator | morning_finance_page_0410.md | 宏观与政策 | 1
R6: 渠道设备更新专项 | 渠道更新专项 | policy_program | morning_finance_page_0410.md | 宏观与政策 | 1
R7: 沪澜综合指数 | 沪澜综合 | market_index | morning_finance_page_0410.md | 市场表现 | 1
R8: 合成发展改革办公室 |  | policy_issuer | morning_finance_page_0410.md | 宏观与政策 | 1
R9: 合成金融服务局 |  | policy_issuer | policy_meeting_release.pdf | 会议内容 | 1
R10: 样本资金利率 |  | market_rate | market_data_brief_0411.txt | 资金 | 1

## Sheet 3: category_summary
Dimensions: 6 rows x 5 columns
R1: category | category_zh | event_count | merged_source_count | notes
R2: policy_update | 政策更新 | 3 | 4 | 含渠道设备更新专项首批试点清单（跨文件合并）、小微票据周转便利延长期限、配套服务推动三项。
R3: company_disclosure | 企业公告 | 2 | 5 | 星澈云服股份一季报（三源合并）、北衡智造设备采购合同（两源合并）。
R4: macro_data | 宏观数据 | 1 | 1 | 澜舟物流景气指数3月读数发布。
R5: market_movement | 股市动态 | 2 | 2 | 沪澜综合指数午间上涨0.5%（已更正确认日期）与收盘上涨0.7%为两个独立事件。
R6: other_finance | 其他财经 | 0 | 0 | 本批次内无符合 other_finance 分类的事件。

## Sheet 4: unclassified_items
Dimensions: 7 rows x 5 columns
R1: item_id | source_file | source_section | reason_code | evidence_snippet
R2: UC-001 | weekend_preview_page_0412.md | 全文 | outside_target_date_range | 发布时间：2026-04-12 08:20（超出目标窗口 2026-04-10 ~ 2026-04-11）
R3: UC-002 | city_service_notice_0410.txt | 全文 | non_finance_topic | 南湾市交通提示，周末部分道路分时段封闭，建议市民提前规划出行。
R4: UC-003 | product_ad_snippets.txt | 全文 | page_noise_or_site_module | 客户端下载提示：安装合成财经客户端，查看自选股提醒、基金问答和视频栏目。热门推荐：城市服务、消费观察、周末生活方式。
R5: UC-004 | evening_notice_rollup_0410.md | 观业绩 | background_or_forecast_only | 星澄云服管理层在交流纪要中表示，二季度软件运维需求'可能保持平稳'。该段为展望性表述。
R6: UC-005 | market_data_brief_0411.txt | 评论 | background_or_forecast_only | 多位受访人士认为，下周资金面仍需观察税期扰动。
R7: UC-006 | market_data_brief_0411.txt | 资金 | background_or_forecast_only | 样本资金利率小幅回落，短端品种成交保持活跃。无具体数据期或测量值报告。
