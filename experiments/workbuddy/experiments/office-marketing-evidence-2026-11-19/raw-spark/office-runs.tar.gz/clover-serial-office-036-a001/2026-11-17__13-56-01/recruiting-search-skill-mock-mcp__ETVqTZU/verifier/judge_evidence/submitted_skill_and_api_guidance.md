# Submitted Skill and API guidance

- SKILL.md read_status: `ok`
- mock_api_notes.md read_status: `ok`
- Canonical method exact matching is deterministic-owned; this file is for semantic actionability and scope context.

## Canonical method namespace expected by public contract
- `recruiting_search_lab.discover_surface`
- `recruiting_search_lab.search_profiles`
- `recruiting_search_lab.inspect_profile`
- `recruiting_search_lab.save_evidence`
- `recruiting_search_lab.export_shortlist`
- `recruiting_search_lab.snapshot_state`
- `recruiting_search_lab.audit_diff`

## Skill markdown excerpt
```markdown
# Recruiting Search Skill（recruiting_search.v2.hardened）

> 维护状态：已对齐专用候选人检索 `recruiting_search_lab` MCP catalog。旧 method/field 仅作为 drift/distractor 说明，不得作为最终主引用。

## Skill 目标

帮助 recruiting operations 同事在专用候选人检索工作区中完成以下工作：

1. 根据岗位关键词构造离线招聘 profile search。
2. 对 search 结果做 detail/inspect，抽取职位相关 evidence labels。
3. 保存 evidence，导出 shortlist bundle，并记录 snapshot/audit。
4. 输出中文状态说明，说明 method、schema、evidence、export 和 safety boundary。

## Current workflow（discovery/search/detail-or-inspect/save evidence/export/snapshot/audit）

1. **Discovery**：调用 `recruiting_search_lab.discover_surface(args)` 确认当前可用 method classes、catalog/schema version、主要 request/response 字段、deprecated aliases 和 safety boundary。常用 args：
   ```json
   {
     "include_deprecated_aliases": true,
     "include_field_summary": true,
     "include_state_capabilities": true
   }
   ```

2. **Search**：用 role/skill/location/time-window 等职位相关 query 运行 `recruiting_search_lab.search_profiles(args)`。search result 只应视为摘要，不等于完整证据。返回摘要字段示例：
   - `profile_id`
   - `profile_handle`
   - `headline`
   - `skill_tags`
   - `availability_window`
   - `search_score_band`
   - `summary_evidence_labels`

3. **Inspect**：对候选 `profile_id` 做 `recruiting_search_lab.inspect_profile(args)`，读取 evidence labels、skill tags、availability window、project snippets 等职位相关字段。常见 sections：
   - `role_alignment`
   - `project_evidence`
   - `skill_depth`
   - `availability`
   - `risk_or_followup`

4. **Save evidence**：先保存 evidence labels，再导出 shortlist。不要在没有 save evidence 的情况下声称 export bundle complete。

5. **Export**：调用 `recruiting_search_lab.export_shortlist(args)` 导出已保存 evidence 的 shortlist bundle 或本地 export ref。不能替代 inspect/save 步骤。

6. **Snapshot/Audit**：记录 before/after snapshot 或 audit diff，支撑状态报告。
   - `recruiting_search_lab.snapshot_state(args)`：记录当前本地 runtime state label。
   - `recruiting_search_lab.audit_diff(args)`：比较两个 snapshot labels，返回公开可审计差异。

## Deprecated aliases（drift/distractor 说明）

这些名字可能出现在旧 Skill、archive、template 或 transcript seed 中，但不应把它们作为 current method contract：

- `candidate_lookup` → replacement: `recruiting_search_lab.search_profiles`
- `talentSearchV1` → replacement: `recruiting_search_lab.search_profiles`
- `lookup_detail` → replacement: `recruiting_search_lab.inspect_profile`
- `bulkExportCsv` → replacement: `recruiting_search_lab.export_shortlist`
- `mark_exported` → replacement: `recruiting_search_lab.export_shortlist plus recruiting_search_lab.snapshot_state/audit_diff`

## 输出结构要求

最终 Skill 应要求 agent 生成或维护：

- `shortlist[]`
  - `profile_id`
  - `profile_handle`
  - `headline`
  - `matched_skill_tags`
  - `evidence_labels`
  - `fit_summary_zh`
  - `limitations_or_followup`
- `search_summary`
  - query intent
  - filters used
  - method refs
- `evidence_export`
  - saved evidence count
  - export ref
  - snapshot/audit refs
- `safety_boundary`
  - task-provided profiles only
  - no live service
  - no contact data retrieval

## Safety boundary

- 只使用公开工作区文件和专用候选人检索 MCP。
- 不调用真实 ATS、招聘平台、邮箱、IM、外部 API、浏览器后台、网络 URL、私有账号或 live service。
- 不请求、不生成、不保存、不导出真实联系信息。
- 不写真实姓名、真实学校/公司、真实联系方式、地址、社交链接、account ID、token、private path 或 private URL。
- 示例只允许使用本任务提供的 `RP-2xx` profile ID 和职位相关非 PII 字段。

## 方法前置条件与状态更新（参考 state_transition_contract.json）

| Method | Preconditions | State Updates | Returns |
|---|---|---|---|
| `discover_surface` | — | api_surface_verified=true; append discovery call to log | catalog_version, schema_version, canonical_methods, deprecated_aliases, field_summary, safety_boundary |
| `search_profiles` | surface discovered or file catalog checked | append search run; shortlist_created may become true | search_run_id, profile summaries, result_count, query echo |
| `inspect_profile` | profile_id exists in public_profile_index | detail_fetched=true; append inspection to log | profile_id, sections_returned, evidence labels/snippets, risk_or_followup |
| `save_evidence` | evidence labels available from inspect_profile | append saved labels to profile/session; evidence_complete may update | save_ref, saved_labels, rejected_labels_if_any |
| `export_shortlist` | at least one saved evidence label exists; shortlist_id or selected profile list exists | append export_ref; export_requested/bundle_ready=true | export_ref, included_profile_ids, included_evidence_labels, artifact_hint |
| `snapshot_state` | — | append snapshot_label | snapshot_label, snapshot_summary |
| `audit_diff` | before_label and after_label exist | append diff_ref; audit_diff_recorded=true | diff_ref, changed_flags, method_counts, saved_evidence_delta, export_delta, artifact_ref_delta |

## 字段迁移提示

| Old/draft field | Current direction |
|---|---|
| `candidateName` | use `profile_handle`; do not use real names |
| `skillsText` | use `skill_tags` plus inspected evidence snippets |
| `evidenceRefs` | use `evidence_labels` from inspect/save flow |
| `contactAvailable` | remove or mark not applicable; contact data is out of scope |
| `export_path` handwritten | use export ref from mock export state |

## Evidence label style

Current style: `RP-###:E##` (e.g., `RP-204:E01`, `RP-218:E02`) from inspect/save flow. Stale pattern: `EV-[0-9]+`.

## Maintenance notes

- All artifacts must be consistent with each other: schema, template, example, API notes, evidence log, status report.
- No claim of export/snapshot/audit completion without corresponding entries in evidence_log/runtime state.
- Contact-data retrieval is explicitly prohibited; neutralize any old placeholder.

```

## Mock API notes excerpt
```markdown
# Recruiting search API notes — recruiting_search_lab（当前公开 interface）

本 notes 描述专用候选人检索 MCP 接口面。它是公开、面向使用者的接口说明，但不是完成报告模板，也不列出应最终选择哪些 profile。

## 基本边界

- Server ID: `recruiting_search_lab`
- Execution: offline recruiting-search interface only
- Data: fictional task-provided profiles only
- No live recruiting service, no ATS/CRM/email/IM/webhook/browser/network
- No real contact data. Contact-data retrieval/export is not supported or needed.
- Current catalog version should be discovered or cross-checked before final package claims.

## Method classes

### A. Discovery / surface

`recruiting_search_lab.discover_surface(args)`

用途：返回当前可用 method classes、catalog/schema version、主要 request/response 字段、deprecated aliases 和 safety boundary。

常用 args：

```json
{
  "include_deprecated_aliases": true,
  "include_field_summary": true,
  "include_state_capabilities": true
}
```

### B. Search

`recruiting_search_lab.search_profiles(args)`

用途：按岗位关键词和职位相关 filters 返回本任务提供的 profile handles 与摘要。Search 结果不返回完整 evidence bundle。

返回摘要字段示例：

- `profile_id`
- `profile_handle`
- `headline`
- `skill_tags`
- `availability_window`
- `search_score_band`
- `summary_evidence_labels`

### C. Detail / inspect

`recruiting_search_lab.inspect_profile(args)`

用途：按 `profile_id` 和 `sections` 返回结构化 profile detail、职位相关 evidence snippets、可引用 evidence labels。

常见 sections：

- `role_alignment`
- `project_evidence`
- `skill_depth`
- `availability`
- `risk_or_followup`

### D. Evidence save / export

`recruiting_search_lab.save_evidence(args)`

用途：把 inspect 看到的 evidence labels 保存到当前 shortlist/session。只有已保存的 labels 才能进入 export。

`recruiting_search_lab.export_shortlist(args)`

用途：导出已保存 evidence 的 shortlist bundle 或本地 export ref。不能替代 inspect/save 步骤。

### E. Snapshot / audit

`recruiting_search_lab.snapshot_state(args)`

用途：记录当前本地 runtime state label，例如 before/after package update。

`recruiting_search_lab.audit_diff(args)`

用途：比较两个 snapshot labels，返回 method calls、saved evidence、export refs、artifact refs 等公开可审计差异。

## Deprecated aliases visible in support files

这些名字可能出现在旧 Skill、archive、template 或 transcript seed 中：

- `candidate_lookup`
- `talentSearchV1`
- `lookup_detail`
- `bulkExportCsv`
- `mark_exported`

最终正式产物中可以把它们列为 deprecated drift，但不应把它们作为 current method contract。

## Field migration hints

| Old/draft field | Current direction |
|---|---|
| `candidateName` | use `profile_handle`; do not use real names |
| `skillsText` | use `skill_tags` plus inspected evidence snippets |
| `evidenceRefs` | use `evidence_labels` from inspect/save flow |
| `contactAvailable` | remove or mark not applicable; contact data is out of scope |
| `export_path` handwritten | use export ref from mock export state |

## State notes

- Discovery should set API-surface verification in runtime state.
- Search should append a search run; inspect should mark profile detail as fetched.
- Save evidence should update saved label lists.
- Export should be available only after evidence is saved.
- Snapshot/audit should demonstrate before/after changes instead of relying on final report claims.

```
