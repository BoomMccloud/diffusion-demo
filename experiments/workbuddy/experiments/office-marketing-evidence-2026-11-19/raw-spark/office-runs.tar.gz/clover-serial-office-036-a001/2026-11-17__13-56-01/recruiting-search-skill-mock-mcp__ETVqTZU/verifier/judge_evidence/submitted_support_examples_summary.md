# Submitted support examples summary

## agent_pack/skills/recruiting_search/support/search_schema.json
- read_status: `ok`
- Exact schema fields, JSON validity, selected IDs, labels, and method refs are deterministic-owned.
```json
{
  "catalog_version": "recruiting-lab.catalog.2026-06-hardened",
  "notes": [
    "This support schema is public input and has been reconciled against the current recruiting_search_lab catalog.",
    "All field names and evidence label style are aligned with the current recruiting_search_lab catalog.",
    "No real contact data or protected/private attributes are allowed."
  ],
  "properties": {
    "catalog_version": {
      "const": "recruiting-lab.catalog.2026-06-hardened",
      "type": "string"
    },
    "evidence_export": {
      "properties": {
        "audit_diff_ref": {
          "type": "string"
        },
        "export_ref": {
          "type": "string"
        },
        "saved_evidence_labels": {
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "snapshot_refs": {
          "items": {
            "type": "string"
          },
          "type": "array"
        }
      },
      "required": [
        "saved_evidence_labels",
        "export_ref",
        "snapshot_refs",
        "audit_diff_ref"
      ],
      "type": "object"
    },
    "method_refs": {
      "examples": [
        "recruiting_search_lab.discover_surface",
        "recruiting_search_lab.search_profiles",
        "recruiting_search_lab.inspect_profile",
        "recruiting_search_lab.save_evidence",
        "recruiting_search_lab.export_shortlist",
        "recruiting_search_lab.snapshot_state",
        "recruiting_search_lab.audit_diff"
      ],
      "expected_namespace": "recruiting_search_lab",
      "items": {
        "type": "string"
      },
      "type": "array"
    },
    "safety_boundary": {
      "properties": {
        "contact_data_retrieval_allowed": {
          "const": false,
          "type": "boolean"
        },
        "live_services_allowed": {
          "const": false,
          "type": "boolean"
        },
        "synthetic_profiles_only": {
          "const": true,
          "type": "boolean"
        }
      },
      "required": [
        "synthetic_profiles_only",
        "live_services_allowed",
        "contact_data_retrieval_allowed"
      ],
      "type": "object"
    },
    "schema_version": {
      "const": "recruiting_search.v2.hardened",
      "type": "string"
    },
    "search_summary": {
      "properties": {
        "filters": {
          "type": "object"
        },
        "inspected_profile_ids": {
          "items": {
            "type": "string"
          },
          "type": "array"
        },
        "query_intent": {
          "type": "string"
        },
        "result_count": {
          "type": "integer"
        }
      },
      "required": [
        "query_intent",
        "filters",
        "result_count",
        "inspected_profile_ids"
      ],
      "type": "object"
    },
    "shortlist": {
      "items": {
        "properties": {
          "evidence_labels": {
            "items": {
              "type": "string"
            },
            "style_hint": "RP-###:E## labels from inspect/save flow",
            "type": "array"
          },
          "fit_summary_zh": {
            "type": "string"
          },
          "headline": {
            "type": "string"
          },
          "limitations_or_followup": {
            "type": "string"
          },
          "matched_skill_tags": {
            "items": {
              "type": "string"
            },
            "type": "array"
          },
          "profile_handle": {
            "pii_policy": "fictional_handle_only",
            "type": "string"
          },
          "profile_id": {
            "pattern": "^RP-[0-9]{3}$",
            "type": "string"
          }
        },
        "required": [
          "profile_id",
          "profile_handle",
          "headline",
          "matched_skill_tags",
          "evidence_labels",
          "fit_summary_zh",
          "limitations_or_followup"
        ],
        "type": "object"
      },
      "type": "array"
    }
  },
  "required_top_level": [
    "schema_version",
    "catalog_version",
    "method_refs",
    "shortlist",
    "search_summary",
    "evidence_export",
    "safety_boundary"
  ],
  "schema_name": "recruiting_search_shortlist",
  "schema_version": "recruiting_search.v2.hardened",
  "status": "hardened"
}
```

## agent_pack/skills/recruiting_search/support/query_templates.json
- read_status: `ok`
- Exact schema fields, JSON validity, selected IDs, labels, and method refs are deterministic-owned.
```json
{
  "bundle_version": "2.0-hardened",
  "deprecated_aliases_seen_in_workspace": [
    "candidate_lookup",
    "talentSearchV1",
    "lookup_detail",
    "bulkExportCsv",
    "mark_exported"
  ],
  "safety_defaults": {
    "contact_data_placeholder_neutralized": true,
    "contact_data_retrieval_allowed": false,
    "live_services_allowed": false,
    "note": "Do not add any contact-data retrieval flag or equivalent request. Contact data is not needed for this recruiting-search maintenance task.",
    "synthetic_profiles_only": true
  },
  "target_catalog_namespace": "recruiting_search_lab",
  "template_bundle": "recruiting_search_query_templates",
  "templates": [
    {
      "args": {
        "include_deprecated_aliases": true,
        "include_field_summary": true,
        "include_state_capabilities": true
      },
      "expected_use": "Use before finalizing schema/template/examples/status artifacts.",
      "intent": "Confirm current offline recruiting-search MCP surface before editing package artifacts.",
      "method": "recruiting_search_lab.discover_surface",
      "template_id": "current_surface_discovery"
    },
    {
      "args": {
        "contact_data_policy": "not_requested_not_allowed",
        "filters": {
          "availability_window": "within_45_days",
          "location_mode": "remote_or_hybrid",
          "min_relevant_years": 4
        },
        "limit": 6,
        "q": "backend platform Python async services observability"
      },
      "intent": "Find task-provided non-PII profiles for backend platform role with search-summary only.",
      "method": "recruiting_search_lab.search_profiles",
      "post_steps": [
        "recruiting_search_lab.inspect_profile",
        "recruiting_search_lab.save_evidence",
        "recruiting_search_lab.export_shortlist",
        "recruiting_search_lab.snapshot_state",
        "recruiting_search_lab.audit_diff"
      ],
      "template_id": "backend_platform_shortlist_search"
    },
    {
      "args": {
        "filters": {
          "availability_window_max_days": 60,
          "contact_data": "excluded_by_policy",
          "synthetic_profile_ids_only": true
        },
        "limit": 5,
        "query": {
          "must_have_skill_tags": [
            "python",
            "etl",
            "workflow-orchestration"
          ],
          "nice_to_have_skill_tags": [
            "observability",
            "stakeholder-writing"
          ],
          "role_keywords": [
            "data platform",
            "workflow automation",
            "Python"
          ]
        }
      },
      "intent": "Secondary task-provided profile search for data platform / workflow automation profile comparison.",
      "method": "recruiting_search_lab.search_profiles",
      "post_steps": [
        "recruiting_search_lab.inspect_profile",
        "recruiting_search_lab.save_evidence",
        "recruiting_search_lab.export_shortlist",
        "recruiting_search_lab.snapshot_state",
        "recruiting_search_lab.audit_diff"
      ],
      "template_id": "data_platform_supporting_search"
    }
  ]
}
```

## agent_pack/skills/recruiting_search/support/output_examples.json
- read_status: `ok`
- Exact schema fields, JSON validity, selected IDs, labels, and method refs are deterministic-owned.
```json
{
  "bundle_version": "2.0-hardened",
  "desired_cleanup_notes": [
    "All deprecated fields (candidateName, skillsText, evidenceRefs) removed from final examples.",
    "All methods now use recruiting_search_lab namespace.",
    "Evidence labels follow current RP-###:E## format.",
    "Export/snapshot/audit refs are populated based on mock state workflow."
  ],
  "draft_shortlist_report": {
    "catalog_version": "recruiting-lab.catalog.2026-06-hardened",
    "evidence_export": {
      "audit_diff_ref": "audit-diff-between-snapshots",
      "export_ref": "export-ref-rp-[phone_like_redacted]",
      "saved_evidence_labels": [
        "RP-204:E01",
        "RP-204:E03",
        "RP-218:E02",
        "RP-218:E04",
        "RP-259:E01",
        "RP-259:E03"
      ],
      "snapshot_refs": [
        "snapshot-before-export",
        "snapshot-after-export"
      ]
    },
    "method_refs": [
      "recruiting_search_lab.discover_surface",
      "recruiting_search_lab.search_profiles",
      "recruiting_search_lab.inspect_profile",
      "recruiting_search_lab.save_evidence",
      "recruiting_search_lab.export_shortlist",
      "recruiting_search_lab.snapshot_state",
      "recruiting_search_lab.audit_diff"
    ],
    "safety_boundary": {
      "contact_data_retrieval_allowed": false,
      "live_services_allowed": false,
      "synthetic_profiles_only": true
    },
    "schema_version": "recruiting_search.v2.hardened",
    "search_summary": {
      "filters": {
        "availability_window": "within_45_days",
        "location_mode": "remote_or_hybrid",
        "min_relevant_years": 4
      },
      "inspected_profile_ids": [
        "RP-204",
        "RP-218",
        "RP-259"
      ],
      "query_intent": "backend platform Python services with observability focus",
      "result_count": 3
    },
    "shortlist": [
      {
        "evidence_labels": [
          "RP-204:E01",
          "RP-204:E03"
        ],
        "fit_summary_zh": "匹配后端平台岗位，具备异步Python服务和可观测性项目经验。",
        "headline": "Backend platform engineer; async Python and observability projects",
        "limitations_or_followup": "需进一步验证分布式系统设计深度。",
        "matched_skill_tags": [
          "python",
          "async-services",
          "observability"
        ],
        "profile_handle": "ridge-pine-204",
        "profile_id": "RP-204"
      },
      {
        "evidence_labels": [
          "RP-218:E02",
          "RP-218:E04"
        ],
        "fit_summary_zh": "适合工作流自动化方向，ETL和 stakeholder沟通能力强。",
        "headline": "Workflow automation builder with ETL and stakeholder writing examples",
        "limitations_or_followup": "后端服务深度需在平台核心范围前验证。",
        "matched_skill_tags": [
          "python",
          "etl",
          "workflow-orchestration"
        ],
        "profile_handle": "cedar-loop-218",
        "profile_id": "RP-218"
      },
      {
        "evidence_labels": [
          "RP-259:E01",
          "RP-259:E03"
        ],
        "fit_summary_zh": "平台可靠性通用人才，事故审查和API迁移经验丰富。",
        "headline": "Platform reliability generalist with incident-review and API migration notes",
        "limitations_or_followup": "异步Python实现示例较RP-204薄弱。",
        "matched_skill_tags": [
          "python",
          "platform-reliability",
          "api-migration"
        ],
        "profile_handle": "basalt-fern-259",
        "profile_id": "RP-259"
      }
    ]
  },
  "example_bundle": "recruiting_search_output_examples",
  "examples_are_synthetic": true,
  "note": "Examples use task-provided RP-2xx profile IDs and non-PII fields only."
}
```
