{
  "metadata": {
    "case_id": "CL-HR-HB-2026.03",
    "handbook_title": "澄岭科技员工手册",
    "handbook_version": "2026.03",
    "handbook_doc_id": "CL-HR-HB-2026.03",
    "notice_doc_id": "澄岭人通〔2026〕030号",
    "notice_effective_date": "2026-06-01",
    "source_files": [
      "/workspace/input/employee_handbook.docx",
      "/workspace/input/handbook_change_notice_030.pdf"
    ],
    "output_path": "/workspace/output/handbook_update_state.json"
  },
  "inserted_updates": [
    {
      "update_id": "HN-030-01",
      "target_section": "第二章 工作时间与考勤",
      "insert_after_heading": "2.3 弹性工作申请",
      "normalized_text": "新增 2.3.1 跨时区协作登记：连续两周参与 20:00 后跨时区会议累计达到 4 次的员工，应在当周五前通过 HRIS 提交协作登记；直属经理需在 2 个工作日内确认补休安排。",
      "object_type": "paragraph",
      "preserved_numbering": true,
      "source_doc": "handbook_change_notice_030.pdf"
    },
    {
      "update_id": "HN-030-02",
      "target_section": "第四章 薪酬与补贴",
      "insert_after_heading": "4.2 加班餐补",
      "normalized_text": "新增 4.2.1 夜间交通补贴：经审批在 22:00 后离开办公场所的员工，可按实际发生凭票报销单程交通费用，每次上限 80 元。\n新增 4.2.2 周末值守餐补：经部门排班在周末现场值守满 4 小时的员工，可申领餐补 45 元/天；与项目专项补贴不重复享受。",
      "object_type": "numbered_list",
      "preserved_numbering": true,
      "source_doc": "handbook_change_notice_030.pdf"
    },
    {
      "update_id": "HN-030-03",
      "target_section": "第六章 信息安全与设备",
      "insert_after_heading": "6.1 办公设备领用（设备借用期限表）",
      "normalized_text": "设备类别=临时安全令牌；最长借用期限=14日；审批人=信息安全负责人；归还要求=到期前1个工作日归还或完成续借。",
      "object_type": "table_row",
      "preserved_numbering": false,
      "source_doc": "handbook_change_notice_030.pdf"
    }
  ],
  "unchanged_sections": [
    "第一章 总则",
    "1.1 手册适用范围",
    "1.2 手册维护",
    "2.1 标准工作时间",
    "2.2 考勤记录",
    "3.1 年休假",
    "3.2 调休申请",
    "4.1 工资发放",
    "5.1 差旅报销",
    "5.2 业务招待",
    "6.2 账号与权限",
    "7.1 商业行为",
    "7.2 纪律处理",
    "8.1 生效与解释"
  ],
  "excluded_notice_text": [
    "通知抬头：澄岭科技人力运营组 / 澄岭人通〔2026〕030号 / 关于整理员工手册若干补充事项的通知",
    "主送：各中心、各区域办公室",
    "抄送：总经理办公室、财务共享中心、园区物业",
    "执行说明：各部门只需在下次培训时提示，不另行回签；本段不作为手册正文。",
    "会议纪要节选：夏季水果供应和茶水间清洁频次另由行政支持确认，不纳入员工手册。",
    "联系人：人力运营组 张岚，分机 6021",
    "附件清单：员工手册更新状态表模板（空表）",
    "页脚：澄岭科技人力运营组 内部通知 第 1 页 / 共 2 页",
    "页脚：澄岭科技人力运营组 内部通知 第 2 页 / 共 2 页",
    "落款日期：2026年5月28日"
  ],
  "summary": {
    "total_formal_updates": 3,
    "paragraph_updates": 1,
    "numbered_list_updates": 1,
    "table_row_updates": 1,
    "unchanged_section_count": 14,
    "excluded_notice_text_count": 10,
    "requires_docx_overwrite": false
  }
}
