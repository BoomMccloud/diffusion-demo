# Submitted topic-board JSON summary

- package_date: `2026-06-18`
- source_bundle_id: `tech_source_digest_2026-06-18`

## Primary topics
### Rank 1: 端侧智能助手从'无感执行'到'必须确认'：权限标签和撤销入口正在成为新标准
- angle: 从厂商营销话术到实际用户可控性，跨应用动作仍需确认授权，应用市场试点给 AI 功能加权限标签
- source_ids: TS-001, TS-002, TS-003, TS-049, TS-050, TS-052
- evidence_summary: TS-001：两家手机系统团队本地演示离线摘要、跨应用意图识别和日程提醒，但反复提示需要用户确认授权；TS-002：发布会使用'全场景无感执行'宣传语，案例集中在订票、改签等；TS-003：开发者问答把'无感执行'改写为半自动流程——预填和提醒可以，发送、支付、删除必须确认；TS-049：应用市场试点给 AI 功能增加权限标签和数据使用说明；TS-050：用户权益组织建议权限标签用人话说明数据流向；TS-052：编辑部串联摘记将端侧助手与应用权限标签统一为'AI 能力需要可控解释'线索
- latest_state_resolution: 以 TS-003 的开发者问答为准修正 TS-002 的宣传说法（DN-001）；TS-049 仍是试点，不能写成所有应用已全面上线；TS-052 仅作桥接线索，事实支撑来自原始记录而非摘记本身
- novelty_vs_recent_history: HIST-002 曾写'端侧大模型跑分热背后的体验落差'，本轮不重复跑分或参数比较，而是讲权限确认、可控执行和应用市场标签的新动作
- reader_fit: 关心手机体验、隐私提示和产品设计的非技术读者；关注功能上线、用户提示的产品/运营从业者
- risk_or_boundary_note: 不要写成全自动或无感执行；隐私收益只能按材料中的限定表达；TS-002 的营销口径不能作为主叙事核心
- rank_rationale: 在'来源强度 vs 读者适配'轴上，本选题两者兼得：有多源证据支撑，同时能被普通读者理解。Close-call 对比见 CC-001

### Rank 2: 浏览器把 AI 搜索摘要改成引用卡片后，用户核验习惯需要怎么变？
- angle: 不是'为什么标引用'科普，而是引用卡片如何改变用户核验流程和工作习惯
- source_ids: TS-005, TS-006, TS-007
- evidence_summary: TS-005：三款浏览器把 AI 搜索摘要改为引用卡片模式，先给摘要卡片再显示原文入口和遗漏限定条件提示；TS-006：高校图书馆工作坊建议学生把 AI 摘要当作入口而非引用依据，教师展示三个遗漏前提条件的案例；TS-007：编辑摘记提醒 6 月上旬已做过引用标注解释，若继续应换角度
- latest_state_resolution: 以 TS-005 的浏览器更新为主消息，TS-006 提供可操作习惯补充，TS-007 用于去重判断但不单独承担事实判断
- novelty_vs_recent_history: HIST-001 已做'AI 搜索摘要为什么必须标引用'，本轮转向'引用卡片如何改变用户核验流程'这一新工作流角度，避开重复
- reader_fit: 搜索、浏览器和信息核验习惯的公共读者；也适合产品读者看提示设计
- risk_or_boundary_note: 不要声称摘要已经解决误读问题；部分功能仅在桌面端灰度，不能写成全平台；TS-008 的插件厂商案例可作为反面材料说明引用卡片不能被营销成原文替代品
- rank_rationale: 在'读者行动性 vs 证据完整性'轴上，本选题行动性强但证据相对单薄（仅三款浏览器）。Close-call 对比见 CC-001

### Rank 3: AI 代码评审不再只找 bug：团队约定、回滚计划和上下文说明成为新重点
- angle: 从发现明显 bug 转向检查团队约定、边界条件和迁移清单，PR 模板新增约定说明、变更背景、回滚计划
- source_ids: TS-009, TS-010, TS-029, TS-031
- evidence_summary: TS-009：开源推理框架同日更新端侧量化、云端路由和日志接口，社区讨论集中在开发门槛下降与治理成本上升；TS-010：两个开发者社区提到 AI 评审最有价值的部分正从发现明显 bug 转向检查团队约定、边界条件和迁移清单，PR 模板新增约定检查、变更背景、回滚说明和测试证据栏位；TS-029：周报汇总两个开源社区的变更，AI 评审提示也随之变化；TS-031：维护者访谈说最有用的 AI 评审提示是提醒变更背景没有写清楚
- latest_state_resolution: 以 TS-010 的 PR 模板变化和 TS-031 的维护者访谈为主事实，TS-009 和 TS-029 提供工具链和社区讨论背景
- novelty_vs_recent_history: HIST-008 已做'AI 代码助手从补全走向评审'泛化角度，本轮聚焦 PR 模板具体变化和团队约定检查这一新证据点
- reader_fit: 开发者和技术管理者；也能转译给产品团队理解协作流程变化
- risk_or_boundary_note: 社区样本偏开源维护者，不等于所有公司都已采用；不能写成'所有团队都在用'；TS-030 的厂商节省工时说法缺少误报漏报说明，不应承载主判断
- rank_rationale: 在'具体证据 vs 受众广度'轴上，本选题证据具体但受众偏窄。Close-call 对比见 CC-002

### Rank 4: 企业知识库接入大模型后，最先暴露的不是准确率，而是过期文档和出处回链
- angle: 从泛泛误区清单转向文档状态管理、权限标签和出处回链的具体工作流
- source_ids: TS-025, TS-026, TS-053
- evidence_summary: TS-025：企业知识库接入大模型后，最先暴露的是权限和过期文档问题，团队上线问答前需要清理过期文档、角色权限和引用来源显示；TS-026：知识库治理模板列出文档所有者、更新时间、可引用范围和过期处理，强调大模型问答必须能回到出处；TS-053：会议纪要工具新增出处回链和权限提示，连接企业知识库治理、应用权限提示和 AI 摘要的引用问题
- latest_state_resolution: 以 TS-025 的企业案例和 TS-026 的模板样章为主事实，TS-053 提供桥接价值但范围较宽，需控制主角
- novelty_vs_recent_history: HIST-007 已做'企业知识库接入大模型的三种误区'，本轮聚焦'文档状态和出处回链'这一新工作流角度，避开泛泛误区清单
- reader_fit: 技术管理者、产品运营和企业服务读者；也可向泛商业读者解释治理成本
- risk_or_boundary_note: 偏 B2B，需翻译成普通读者也能理解的语言；TS-027 的供应商准确率图表不可复核，不应单独支撑结论；TS-053 桥接价值高但容易变成大拼盘，需明确主角
- rank_rationale: 在'受众广度 vs 证据具体性'轴上，本选题受众广但证据相对抽象。Close-call 对比见 CC-002

### Rank 5: 家用传感器旧固件漏洞已修复：安全报道如何不教坏人
- angle: 强调影响范围、修复版本和用户低风险动作，不展示复现细节
- source_ids: TS-013, TS-014, TS-015, TS-016
- evidence_summary: TS-013：匿名论坛称某类家用传感器可被远程接管，但没有提供可复核编号、厂商公告或研究者署名；TS-014：厂商安全公告确认问题只影响旧固件，修复包已发布，建议用户更新设备固件，没有公开攻击步骤；TS-015：社区科普稿建议媒体使用影响范围、修复版本和用户检查入口来组织报道，避免演示攻击过程；TS-016：安全研究者提醒智能硬件报道要先确认修复状态，确认修复后也应避免写可复现步骤
- latest_state_resolution: 以 TS-014 的厂商公告为准（已验证修复信息），TS-013 的未证实说法仅作为背景说明；TS-015 和 TS-016 提供安全写作边界指导（DN-002）
- novelty_vs_recent_history: HIST-006 已做'智能硬件漏洞报道如何不教坏人'，本轮延续同一安全写作原则，但结合新的修复包发布事件，有新鲜时间锚点
- reader_fit: 关心智能家居安全的普通读者；也适合内容编辑理解安全报道边界
- risk_or_boundary_note: 绝对不能输出操作步骤、教程或规避方式；不能写成漏洞教程；用户建议只能停留在更新固件和查看官方提示这类低风险层面；TS-013 的帖子不能传播可操作细节
- rank_rationale: 在'时效性 vs 安全风险'轴上，本选题有时效性但安全风险最高，因此排最后但仍保留在主推位置。Close-call 对比见 CC-003

## Reserve / downranked topics
- 机器人巡检标准草案要求人工复核——从设备采购到流程治理 — source_ids: TS-017, TS-018, TS-020
  - downrank_reason: HIST-003 已做'机器人巡检不是无人值守'，本轮需要找新钩子（如异常交接流程改造）才能进入主推；TS-019 的供应商白皮书主打回本周期，未披露维护成本和误报率，属于促销/单一厂商材料（DN-012）；单案例工厂访谈不能写成行业普遍变化
  - condition_to_promote: 如果后续能找到具体的异常交接流程改造案例（如夜班员工如何与机器人交接），或标准草案有具体条款变化，可升为主推
- 虚拟主播工具把标注责任前置到脚本校验——创作者工作流的新变化 — source_ids: TS-045, TS-046, TS-048
  - downrank_reason: HIST-011 刚做'AI 内容标识为什么不是一行小字'基础解释，本轮需要强调'把标注责任前置到脚本/发布前流程'这一新工作流角度；TS-047 的玩法分享涉及换脸和拟声，安全敏感不能输出教程（DN-004）；样本不大，不能泛化为所有创作者
  - condition_to_promote: 如果后续能获得多个创作者的实际工作流变化案例，或平台规则有具体条款更新，可升为主推
- 车载语音和低空调度——信息入口与人工确认，不是自动控制 — source_ids: TS-033, TS-034, TS-035
  - downrank_reason: HIST-009 已做'车载语音助手还缺哪一步'，HIST-010 指出低空经济调度多为概念想象；TS-035 明确提醒这些案例多是信息入口和人工确认流程，不可写成规模化自动控制；TS-036 的创业公司发布稿包装过度、部署细节少，属于过度联想风险（DN-016）；概念验证多，落地证据不足
  - condition_to_promote: 如果后续能获得真实部署案例和用户反馈，或专家评论有具体约束条件更新，可升为主推

## close_call_matrix
[
  {
    "case_id": "CC-001",
    "comparison_name": "端侧智能助手（Rank 1）vs. 浏览器搜索引用卡片（Rank 2）",
    "sources_involved": [
      "TS-001",
      "TS-002",
      "TS-003",
      "TS-049",
      "TS-050",
      "TS-052",
      "TS-005",
      "TS-006",
      "TS-007"
    ],
    "why_close": "端侧助手胜在证据链完整性和更正关系的清晰度；浏览器搜索胜在读者行动性和具体产品更新动作。两者都进入主推，因为各自优势不同",
    "final_handling": "端侧智能助手 → 主推 Rank 1；浏览器搜索引用卡片 → 主推 Rank 2",
    "visible_reason": "端侧助手胜在六源证据支撑和明确的更正替代关系（TS-002→TS-003）；浏览器搜索胜在读者可操作的核验步骤和具体的产品灰度更新。两者互补，不构成竞争"
  },
  {
    "case_id": "CC-002",
    "comparison_name": "AI 代码评审治理（Rank 3）vs. 企业知识库治理（Rank 4）",
    "sources_involved": [
      "TS-009",
      "TS-010",
      "TS-029",
      "TS-031",
      "TS-025",
      "TS-026",
      "TS-053"
    ],
    "why_close": "代码评审胜在具体证据（PR 模板新增栏位）和维护者访谈的人话场景；知识库治理胜在受众广度和 B2B 翻译能力。两者都进入主推，因为各自优势不同",
    "final_handling": "AI 代码评审治理 → 主推 Rank 3；企业知识库治理 → 主推 Rank 4",
    "visible_reason": "代码评审有具体的 PR 模板变更证据（新增约定检查、变更背景、回滚计划等栏位）；知识库治理能把 B2B 题材翻译成普通读者能理解的组织成本问题。两者覆盖不同的读者段"
  },
  {
    "case_id": "CC-003",
    "comparison_name": "家用传感器安全（Rank 5）vs. 机器人巡检标准（Reserve 1）",
    "sources_involved": [
      "TS-013",
      "TS-014",
      "TS-015",
      "TS-016",
      "TS-017",
      "TS-018",
      "TS-020"
    ],
    "why_close": "传感器安全胜在时效性（修复包今天发布）和明确的安全写作边界；机器人巡检输在近期覆盖冲突和缺乏新钩子。两者都保留，因为各自定位不同",
    "final_handling": "家用传感器安全 → 主推 Rank 5；机器人巡检标准 → Reserve 1",
    "visible_reason": "传感器安全有明确的时间锚点（修复包发布）和安全降调处理的必要性；机器人巡检虽有权威标准草案，但 HIST-003 已覆盖相近角度，需要新钩子才能进入主推"
  },
  {
    "case_id": "CC-004",
    "comparison_name": "创作者工具标注（Reserve 2）vs. 车载/低空入口（Reserve 3）",
    "sources_involved": [
      "TS-045",
      "TS-046",
      "TS-048",
      "TS-033",
      "TS-034",
      "TS-035"
    ],
    "why_close": "创作者工具胜在具体流程变化但受限于近期覆盖；车载/低空输在概念过多、证据不足和过度联想风险。两者都不进入主推，因为各自都有明显短板",
    "final_handling": "创作者工具标注 → Reserve 2；车载/低空入口 → Reserve 3",
    "visible_reason": "创作者工具有具体流程变化（脚本校验、发布前检查），但 HIST-011 刚覆盖基础解释；车载/低空多为概念验证，TS-036 的发布稿包装过度。两者都保留在 reserve 位置"
  }
]

## source_state_notes
[
  {
    "note_id": "DN-001",
    "affected_sources": [
      "TS-001",
      "TS-002",
      "TS-003"
    ],
    "handling": "TS-002 的'全场景无感执行'是发布会宣传语；TS-003 后续问答把它收敛为'需用户确认的半自动流程'。主推 Rank 1 以 TS-003 为准修正 TS-002"
  },
  {
    "note_id": "DN-002",
    "affected_sources": [
      "TS-013",
      "TS-014",
      "TS-015",
      "TS-016"
    ],
    "handling": "TS-013 是未证实且安全敏感的论坛说法；TS-014 提供了已验证的旧固件影响范围和修复包信息。主推 Rank 5 以 TS-014 为准，TS-013 仅作背景"
  },
  {
    "note_id": "DN-003",
    "affected_sources": [
      "TS-033",
      "TS-034",
      "TS-035",
      "TS-036"
    ],
    "handling": "车载语音与低空调度材料容易被包装成自动控制。Reserve 3 明确标注此风险，TS-036 的发布稿不作为主角"
  },
  {
    "note_id": "DN-004",
    "affected_sources": [
      "TS-045",
      "TS-046",
      "TS-047",
      "TS-048"
    ],
    "handling": "创作者工具更新可以讲发布前检查、脚本校验和合成内容标注。Reserve 2 强调新工作流角度，TS-047 的玩法分享不输出教程"
  },
  {
    "note_id": "DN-005",
    "affected_sources": [
      "TS-005",
      "TS-006",
      "TS-007",
      "HIST-001"
    ],
    "handling": "AI 搜索摘要'为什么标引用'已经做过。主推 Rank 2 换成'引用卡片如何改变用户核验流程'这一新角度"
  },
  {
    "note_id": "DN-006",
    "affected_sources": [
      "TS-017",
      "TS-018",
      "TS-020",
      "HIST-003"
    ],
    "handling": "机器人巡检'不是无人值守'已覆盖过。Reserve 1 需要从异常交接、人工复核或流程改造讲起"
  },
  {
    "note_id": "DN-007",
    "affected_sources": [
      "TS-021",
      "TS-022",
      "TS-023",
      "TS-024",
      "HIST-005"
    ],
    "handling": "教育工具材料同时有促销和近期重复压力。未进入主推，相关 source_ids 记录在 non-selection logs"
  },
  {
    "note_id": "DN-008",
    "affected_sources": [
      "TS-025",
      "TS-026",
      "TS-028",
      "TS-053",
      "HIST-007"
    ],
    "handling": "企业知识库接入误区已写过。主推 Rank 4 聚焦'文档状态和出处回链'而非再做误区清单"
  },
  {
    "note_id": "DN-009",
    "affected_sources": [
      "TS-029",
      "TS-031",
      "TS-032",
      "HIST-008"
    ],
    "handling": "AI 代码评审的泛化角度近期已出现。主推 Rank 3 聚焦 PR 模板、团队约定和回滚计划等新证据"
  },
  {
    "note_id": "DN-010",
    "affected_sources": [
      "TS-045",
      "TS-046",
      "TS-048",
      "HIST-011"
    ],
    "handling": "AI 内容标识刚覆盖过基础解释。Reserve 2 需要强调创作者工具把标注责任前置到脚本/发布前流程"
  }
]

## non_selection_downrank_log
{
  "near_duplicate_collapsed": [
    {
      "source_ids": [
        "TS-001",
        "TS-002",
        "TS-003"
      ],
      "merge_explanation": "TS-002 的发布会宣传语被 TS-003 的开发者问答修正，三者合并为一个主推选题（Rank 1），TS-002 不再单独成题"
    },
    {
      "source_ids": [
        "TS-029",
        "TS-031",
        "TS-032"
      ],
      "merge_explanation": "TS-032 是旧技术观察（过窗背景），TS-029 和 TS-031 互相印证，合并为一个主推选题（Rank 3），TS-032 仅作背景"
    }
  ],
  "stale_background_only": [
    {
      "source_ids": [
        "TS-011"
      ],
      "explanation": "三个月前的技术博客，解释量化格式差异，对理解 TS-009 有背景价值，但没有本周新动作"
    },
    {
      "source_ids": [
        "TS-020"
      ],
      "explanation": "四月旧稿，解释巡检机器人部署的流程改造难点，适合作为背景材料，不能替代当前标准草案或访谈"
    },
    {
      "source_ids": [
        "TS-032"
      ],
      "explanation": "四月旧观察，从代码补全到代码评审的工具演进线，本地 6 月 14 日已有相近角度，本轮更适合作为背景"
    },
    {
      "source_ids": [
        "TS-044"
      ],
      "explanation": "六月十二日的电力调度科普，解释算力负载错峰安排，能帮助读者理解 TS-041 的削峰逻辑，但不是主消息"
    }
  ],
  "promotional_or_single_vendor": [
    {
      "source_ids": [
        "TS-008"
      ],
      "explanation": "搜索增强插件声称让用户不再打开原文页面，单一厂商、促销语气强，不宜作为主叙事核心，可作为反面材料"
    },
    {
      "source_ids": [
        "TS-019"
      ],
      "explanation": "巡检机器人供应商白皮书主打回本周期，未披露维护成本和误报率，适合放入非选择或风险说明"
    },
    {
      "source_ids": [
        "TS-021"
      ],
      "explanation": "教育 SaaS 案例稿需要销售线索表单，数据来自自家白皮书，即使教育话题被保留也不应让它主导论证"
    },
    {
      "source_ids": [
        "TS-027"
      ],
      "explanation": "企业服务供应商准确率图表不可复核，且忽略权限和文档状态，可作为营销口径对照"
    },
    {
      "source_ids": [
        "TS-030"
      ],
      "explanation": "代码工具厂商节省工时说法缺少误报、漏报和团队约定适配说明，应避免写成效率承诺"
    },
    {
      "source_ids": [
        "TS-036"
      ],
      "explanation": "车载/低空创业公司发布稿串联概念多、部署细节少，容易过度联想"
    },
    {
      "source_ids": [
        "TS-038"
      ],
      "explanation": "可穿戴厂商健康压力识别宣传稿，健康相关表述需保守，不能输出医疗建议"
    },
    {
      "source_ids": [
        "TS-040"
      ],
      "explanation": "单品智能眼镜发布摘要，单一厂商和营销口吻较重，选题需避免导购"
    },
    {
      "source_ids": [
        "TS-043"
      ],
      "explanation": "液冷设备厂商的成本降幅没有测算边界，不宜单独支撑数据中心节能结论"
    }
  ],
  "unverified_or_safety_sensitive": [
    {
      "source_ids": [
        "TS-013"
      ],
      "explanation": "匿名论坛称某类家用传感器可被远程接管，未提供可复核编号、厂商公告或研究者署名，未证实且安全敏感，不能传播可操作细节"
    },
    {
      "source_ids": [
        "TS-047"
      ],
      "explanation": "短视频模板分享扩散换脸和拟声玩法，评论区有人提醒肖像和误导风险，安全敏感，不能输出教程、模板路径或规避方式"
    }
  ],
  "recent_history_or_channel_fit_conflict": [
    {
      "source_ids": [
        "TS-022",
        "TS-023",
        "TS-024"
      ],
      "explanation": "教育工具材料近期覆盖重复风险高，除非有新的教师复核证据或政策边界，否则更适合降级"
    },
    {
      "source_ids": [
        "TS-028"
      ],
      "explanation": "六月十二日已写过企业知识库接入大模型的三种误区，本轮若采用应避开泛泛的误区清单"
    },
    {
      "source_ids": [
        "TS-029"
      ],
      "explanation": "社区周报汇总代码评审变更，但本地历史 6 月 14 日写过代码助手从补全走向评审，需要找更具体证据角度"
    },
    {
      "source_ids": [
        "TS-032"
      ],
      "explanation": "旧技术观察，本地 6 月 14 日已有相近角度，本轮更适合作为背景而非主线"
    },
    {
      "source_ids": [
        "TS-036"
      ],
      "explanation": "创业公司发布稿，容易引发自动控制误读，促销和过度联想风险高"
    },
    {
      "source_ids": [
        "TS-038",
        "TS-040"
      ],
      "explanation": "可穿戴和智能眼镜材料中，健康压力识别和单品硬件卖点都需要保守处理"
    },
    {
      "source_ids": [
        "TS-047"
      ],
      "explanation": "换脸和拟声玩法分享，安全敏感，不适合作为玩法指南"
    },
    {
      "source_ids": [
        "TS-048"
      ],
      "explanation": "创作者访谈样本不大，不能泛化为所有创作者，但可作为 Reserve 2 的背景补充"
    }
  ],
  "bridge_too_broad": [
    {
      "source_ids": [
        "TS-054"
      ],
      "explanation": "社区周报横跨手机、车机和眼镜的多设备入口专题，举例跨度太大，容易泛化，不适合替代具体主角"
    }
  ],
  "supporting_context_only": [
    {
      "source_ids": [
        "TS-012"
      ],
      "explanation": "开源许可圆桌观点摘要，缺少具体项目案例，应搭配 TS-009 或 TS-010"
    },
    {
      "source_ids": [
        "TS-051"
      ],
      "explanation": "法规科普旧文，没有本周新动作，有助于理解 TS-049 的权限标签试点，但不应单独成为主推"
    }
  ]
}

## local_only_self_checks
{
  "all_source_ids_from_local_jsonl": true,
  "no_live_search_or_browser": true,
  "no_private_services_or_account_data": true,
  "no_multimedia_or_publish_actions": true,
  "markdown_json_consistency_verified": true,
  "five_primary_topics_count": true,
  "two_to_three_reserve_count": true,
  "no_real_urls_or_credentials": true,
  "no_full_article_body_generated": true
}

## markdown_json_consistency
{
  "primary_topics_rank_match": true,
  "primary_topics_title_match": true,
  "primary_topics_source_ids_match": true,
  "primary_topics_risk_or_boundary_note_match": true,
  "reserve_topics_match_between_files": true,
  "close_call_matrix_match_between_files": true,
  "source_state_notes_match_between_files": true,
  "non_selection_logs_match_between_files": true
}

Deterministic-only note: schema, field presence, source ID validity, counts, and Markdown correspondence are scored by eval.py, not by Judge.
