# Judge scope and gate status

- deterministic_passed: `False`
- deterministic_score: `73/89`
- deterministic_pass_rate: `0.8202`
- preflight_score: `9/12`
- text_only_boundary: `true`
- wb_judge_invoked_by_eval_py: `false`

## Failed deterministic checks
- markdown_has_five_topic_cards_or_rank_markers
- json_markdown_consistency_checked_true
- required_core_clusters_selected
- primary_disallowed_clusters_not_selected
- primary_topic_source_ids_within_cluster_allowed_support
- no_promotional_source_ids_in_primary_topics
- no_unverified_source_ids_in_primary_topics
- no_safety_sensitive_source_ids_in_primary_topics
- top_three_include_required_public_core_clusters
- rank_rationales_substantive_per_topic
- ranking_rationales_cover_at_least_4_tradeoff_axes
- topic_angles_substantive_and_distinct
- latest_state_resolution_fields_substantive
- json_close_call_matrix_substantive
- markdown_contains_json_source_state_ids
- no_live_search_external_api_or_private_service_claim

## Check-group summary
{
  "output_contract": {
    "passed": 21,
    "total": 23
  },
  "local_safety_boundary": {
    "passed": 10,
    "total": 11
  },
  "source_binding_and_schema": {
    "passed": 13,
    "total": 16
  },
  "filtering_and_exclusions": {
    "passed": 12,
    "total": 15
  },
  "ranking_tradeoffs": {
    "passed": 8,
    "total": 13
  },
  "cross_artifact_consistency": {
    "passed": 9,
    "total": 11
  },
  "preflight_public_surface": {
    "passed": 3,
    "total": 5
  },
  "preflight_isolation": {
    "passed": 2,
    "total": 2
  },
  "preflight_mechanism_boundary": {
    "passed": 0,
    "total": 1
  },
  "preflight_judge_boundary": {
    "passed": 1,
    "total": 1
  },
  "preflight_expected_state": {
    "passed": 3,
    "total": 3
  }
}

## Deterministic-owned scopes not scored by Judge
File contract, parseability, schema, exact topic counts, source binding, duplicate/exclusion hard facts, correction/supersession hard facts, Markdown/JSON consistency, hard safety/leakage, local-only/no-live/no-private/no-full-article/no-multimodal boundaries.

## Boundary
Judge evidence is text-only and public-safe. It contains submitted Markdown/JSON extracts and public input summaries only; no hidden gold, oracle output, final-answer artifact, private trace text, private paths/URLs, credentials, account IDs, customer data, proprietary content, unpublished assets, VLM/image/video/audio/OCR/render/live platform/browser/API/Skill/MCP/account operation evidence.
