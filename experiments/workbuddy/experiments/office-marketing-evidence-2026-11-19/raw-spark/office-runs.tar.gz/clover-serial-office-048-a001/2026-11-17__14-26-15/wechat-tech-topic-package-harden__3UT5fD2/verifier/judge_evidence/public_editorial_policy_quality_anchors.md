# Public editorial policy and quality anchors

## Instruction



## Editorial guide and visible quality anchors

# 技术选题决策板选择规则

本文件是公开可见的本地编辑规则，用来指导本任务的选题筛选、排序、Markdown/JSON 输出和质量自检。它不是预设答案、成稿模板、发布后台规则或固定选题清单，也不包含最终选题或最终排序。

## 1. 范围与交付

规划日：`2026-06-18`。

只能使用以下本地文件：

- `input/source_board/tech_source_digest_2026-06-18.jsonl`
- `input/source_board/recent_coverage_history_2026-06.md`
- `input/source_board/channel_audience_brief.md`
- `input/source_board/desk_note_source_state_log.md`
- `input/editorial_guide/topic_board_selection_policy.md`
- `environment/local_workspace_boundary.md`

必须生成且只生成两个正式交付文件：

- `output/topic_package/wechat_topic_board_2026-06-18.md`
- `output/topic_package/wechat_topic_board_2026-06-18.json`

交付物是选题规划/决策板，不是文章正文、发布包、封面图、视频、音频、网页、脚本或真实排期。

## 2. 输出结构要求

### Markdown

Markdown 建议包含这些一级或二级区域：

1. 前置取舍摘要：2-4 句话说明本轮最强方向、整体组合和主要降级原则。
2. 5 个排序主推选题卡：正好 5 个，必须有 rank。
3. Reserve / downranked topics：2 或 3 个，不少于 2，不多于 3。
4. Close-call matrix：至少 3 组候选比较。
5. Source-state notes：说明更正、替代、未证实、安全敏感、近期重复等状态如何处理。
6. Non-selection / downrank logs：覆盖重复合并、过窗背景、促销/低证据、未证实或安全敏感、近期覆盖或频道适配冲突。
7. 资料包内自检：确认只用本地材料、未联网、未使用私有/多媒体/发布能力、Markdown/JSON 一致。

每个主推选题卡至少包含：

- `rank`
- 标题
- 话题角度
- `source_id` 列表
- 来源/证据摘要
- 最新状态处理
- 近期覆盖差异
- 目标读者
- 推荐理由
- 风险或边界提示
- 排序取舍说明

### JSON sidecar

JSON 是正式输出的一部分，必须与 Markdown 镜像一致。建议顶层字段为：

- `package_date`
- `source_bundle_id`
- `primary_topics`
- `reserve_or_downranked_topics`
- `close_call_matrix`
- `source_state_notes`
- `non_selection_downrank_log`
- `local_only_self_checks`
- `markdown_json_consistency`

`primary_topics` 中每项至少包含：

- `rank`
- `title`
- `angle`
- `source_ids`
- `evidence_summary`
- `latest_state_resolution`
- `novelty_vs_recent_history`
- `reader_fit`
- `risk_or_boundary_note`
- `rank_rationale`

Markdown 和 JSON 的主推排序、标题、source_ids、风险/边界备注必须一致。Reserve/downranked、close-call matrix、source-state notes 和 non-selection/downrank logs 也应互相印证。

## 3. 先过滤和合并，再排序

在排序前先做这些处理：

1. **同事件或近重复合并**：同一事件、同一产品动作或同一状态链不能拆成多个主推名额。可以合并为一个选题，也可以把弱证据记录放到 supporting/context 或 non-selection/downrank logs。
2. **更正和替代状态优先**：更晚、更清楚、更可复核的更正、问答、公告或边界说明，优先于更早、宣传化或未证实说法。
3. **过窗背景降级**：旧科普、旧观察和历史摘记可以作为背景或 novelty 判断，不应单独作为本轮主推核心。
4. **促销和单一厂商降级**：供应商白皮书、案例稿、发布稿和营销指标不能单独支撑主推核心。若使用，应说明其局限。
5. **未证实或安全敏感降调**：论坛传闻、安全漏洞、可被滥用玩法、健康/压力识别等材料不得放大，不输出操作步骤、教程或诊断建议。
6. **近期覆盖去重**：如果本地历史已覆盖相近角度，必须说明新的角度差异；没有差异时放入 reserve/downranked 或 non-selection。
7. **频道适配检查**：偏 B2B、术语密集、概念过宽的材料，如果不能翻译给频道读者，应降级或用更可读的来源补足。

## 4. 排名轴与取舍规则

排名不能只按日期、来源数量、风险词或单一标签。建议综合：

- 最新状态是否清楚，是否解决了更正/替代/未证实链条。
- 来源是否足够支撑具体角度，而不是 source_id 堆砌。
- 与近期覆盖历史相比是否有新角度。
- 目标读者是否明确，标题是否可用。
- 选题之间是否有差异，避免 5 个都变成同一种 AI 效率故事。
- 是否能把技术材料转译成产品、工作流、权限、治理、基础设施或安全边界问题。
- 是否避免促销、夸大、漏洞教程、医疗/健康建议和自动化过度承诺。
- 是否适合放在主推、reserve/downranked，还是仅在 non-selection/downrank logs 中说明。

### 常见 tie-breakers

- 已确认的当前状态胜过更戏剧化但被收敛或被替代的说法。
- 有新角度的中等强度材料，可能胜过权威但近期重复的材料。
- 能被普通读者理解的具体工作流，可能胜过术语密集但难标题化的材料。
- 桥接材料只有在角度清晰时才加分；如果会变成大拼盘，应降级。
- 安全敏感材料即使日期最新，也不能因为“新”而被主推成教程式话题。
- 促销材料只能作为对照或风险说明，不能因为信息完整或口号强而进入主推核心。

## 5. Close-call matrix 应写什么

Close-call matrix 至少比较 3 组候选。每组建议包含：

- `case_id` 或比较对象名称。
- 被比较的 `source_id` 列表或候选角度。
- 为什么接近：例如来源更强 vs 读者适配更弱、更新更近 vs 安全风险更高、近期重复 vs 有新工作流、桥接价值 vs 角度过宽。
- 最终处理：主推、reserve/downranked、合并、背景、排除。
- 可见理由：必须来自本地材料，不依赖预设答案或外部事实。

## 6. Reserve/downranked 和 non-selection/downrank logs

Reserve/downranked 选题应是“接近但暂不主推”的候选，不是随便列垃圾桶。每项说明：

- 标题或候选角度。
- source_ids。
- downrank_reason。
- condition_to_promote：如果后续有更强证据、新状态或更清楚频道角度，什么条件会改变判断。

Non-selection/downrank logs 应覆盖：

- `near_duplicate_collapsed`
- `stale_background_only`
- `promotional_or_single_vendor`
- `unverified_or_safety_sensitive`
- `recent_history_or_channel_fit_conflict`
- 可选：`bridge_too_broad`、`supporting_context_only`

## 7. 本地-only 与安全边界

禁止：

- live search、浏览器、外部 API、真实公众号后台、私有服务、MCP、Skill、账号数据、VPN 或 资料包外材料。
- 图片、视频、音频、OCR、VLM、截图、封面生成器、海报、HTML/SVG、发布包、上传包、真实平台排期、完整文章正文。
- 漏洞复现、绕过检测、规避风控、攻击步骤、账号规避、高风险教程、医疗/健康诊断建议。
- 真实 URL、联系方式、账号 ID、凭据、token、cookie、客户/用户数据、私有路径、私有 URL、未公开资产、原始私有 trace 文本。
- 预设答案、内部校验细节、评审配置或评分实现。

## 8. 公开质量锚点（供交付自检参考）

本节是公开可见的质量锚点，只用于说明好/坏输出的编辑质量边界。它不是发布后台规则、不是提示模板、不是固定示例、不是后台证据。确定性事实和文件行为应由交付自检与本地材料一致性要求负责，本节不替代规则验证。

### 8.1 最新状态 / 来源冲突处理

- 符合要求示例：能识别更正、替代、未证实和最新已验证状态；例如不重复被后续问答收敛的宣传语，不把未证实安全帖写成当前事实。
- 常见问题示例：把早期营销话术、论坛传闻或过期背景当作当前事实；忽略 desk note 中的更正链；用戏剧性但不稳定的说法做主推。

### 8.2 多来源 grounding，但不 stuffing

- 符合要求示例：每个主推选题的 source_ids 都服务于具体角度，能区分主事实、补充背景、风险边界和历史去重。
- 常见问题示例：堆很多 source_id 但证据摘要泛泛；引用编辑摘记替代原始记录；source_ids 与标题和理由没有关系。

### 8.3 Close-call tradeoff specificity

- 符合要求示例：close-call matrix 明确比较接近候选的输赢原因，例如读者适配 vs 权威性、近期重复 vs 新工作流、安全降调 vs 新鲜度。
- 常见问题示例：只写“综合考虑后选择 A”；不说明 reserve/downranked 为什么输了；或把排序写成简单日期/来源数量排序。

### 8.4 新颖性与近期覆盖差异

- 符合要求示例：能利用 recent coverage history 避免重复，并说明新角度如何避开已做过的主题。
- 常见问题示例：重复“AI 搜索要标引用”“机器人不是无人值守”“AI 教育工具课堂边界”等近期角度，却没有新证据或新切法。

### 8.5 读者适配与标题可用性

- 符合要求示例：标题和角度能被频道读者理解，既有具体对象又不夸张；能把 B2B 或开发者材料翻译成工作流、治理或用户体验问题。
- 常见问题示例：标题像论文摘要、厂商软文或惊悚热搜；无法说明目标读者；直接堆术语或营销口号。

### 8.6 安全降调和促销风险控制

- 符合要求示例：安全敏感、健康边界、合成内容、自动控制和漏洞材料都保守表达；促销材料被标为对照、背景或降级，不承担主事实。
- 常见问题示例：输出漏洞/玩法教程、暗示自动控制已成熟、给健康建议、把供应商指标当事实或写成导购软文。

### 8.7 Reserve / non-selection reasoning

- 符合要求示例：reserve/downranked 与 non-selection/downrank logs 具体、可追溯，覆盖重复、旧闻、促销、低证据、未证实、安全敏感、近期历史和频道适配问题。
- 常见问题示例：未选说明只有“证据不足”等空话，或完全不解释接近候选为什么未主推。

### 8.8 Package coherence

- 符合要求示例：5 个主推形成一个有层次的技术选题板，覆盖产品体验、开发者/团队流程、治理/权限、基础设施或安全边界等不同侧面，彼此不重复。
- 常见问题示例：5 个题都像同一个“AI 工具提升效率”变体，或把多个桥接材料混成一个没有主角的大拼盘。

## 9. 最后自检

提交前检查：

- 两个输出文件路径完全正确。
- 主推选题正好 5 个，reserve/downranked 为 2 或 3 个。
- 所有 source_id 都来自本地 JSONL。
- Markdown 与 JSON 的主推排序、标题、source_ids、风险/边界备注一致。
- close-call matrix、source-state notes、non-selection/downrank logs 在 Markdown 和 JSON 中都可追溯。
- 没有联网、没有外部事实、没有私有服务、没有真实账号数据、没有完整文章、没有多媒体或发布动作。


## Local workspace boundary

# 本地工作区边界

本资料包只使用离线整理的公开文本材料。请把工作区视为一个离线的编辑桌面，不连接任何真实平台或外部服务。

## 允许读取的本地材料

- `input/source_board/tech_source_digest_2026-06-18.jsonl`
- `input/source_board/recent_coverage_history_2026-06.md`
- `input/source_board/channel_audience_brief.md`
- `input/source_board/desk_note_source_state_log.md`
- `input/editorial_guide/topic_board_selection_policy.md`
- `environment/local_workspace_boundary.md`

## 必须生成的本地输出

- `output/topic_package/wechat_topic_board_2026-06-18.md`
- `output/topic_package/wechat_topic_board_2026-06-18.json`

这两个输出都是文本文件。JSON sidecar 是模型可见的正式交付，用来镜像 Markdown 技术选题决策板；它不是临时草稿或附属说明，也不提供预设选题。

## 不存在的能力或服务

本任务没有以下任何依赖或可用资源：

- live search、网页浏览器、搜索引擎或新闻 API
- 真实微信公众号后台、内容管理系统、阅读量/热搜/粉丝画像/账号数据
- 私有服务、内部数据库、外部插件、外部插件、专用工具包、账号登录、API key、token、cookie
- 图片、视频、音频、OCR、VLM、截图、封面生成器、海报生成器、raster 或 pixel-level 工作流
- 真实发布系统、上传包、排期系统或自动发布动作
- 附加模板、脚本、运行包、后台配置或发布材料

## 禁止输出或声明

- 不要声称“我已检索最新网页”“根据真实后台数据”“根据某真实账号”“根据内部资料”或类似外部/私有来源。
- 不要输出真实 URL、邮箱、联系人、账号 ID、凭据、token、cookie、客户/用户数据、私有路径、私有 URL、未公开资产或原始私有 trace 文本。
- 不要输出完整文章正文、封面图、海报、视频、音频、HTML/SVG、截图、脚本、发布包、上传包或真实平台排期。
- 不要输出绕过校验、漏洞复现、攻击步骤、账号规避、高风险教程、医疗/健康诊断建议或其他高风险操作说明。
- 不要创建预设答案文件、成稿模板、内部校验配置、后台配置、运行数据包、测试脚手架或额外交付模板。

## 本地-only 自检

完成输出前请确认：

- 所有引用的 `source_id` 都来自本地 JSONL。
- Markdown 与 JSON 的主推 rank、title、source_ids、risk_or_boundary_note 一致。
- Reserve/downranked topics 为 2 或 3 个，并与 Markdown/JSON 互相印证。
- Close-call matrix、source-state notes 和 non-selection/downrank logs 覆盖重复、过窗背景、促销/低证据、未证实或安全敏感、近期覆盖或频道适配冲突。
- 没有使用或声称使用外部、私有、真实账号、多媒体或发布系统能力。
- 没有生成完整文章、图片/视频/音频、HTML/SVG、截图、脚本、发布包或真实排期。


Deterministic verifier owns exact output structure, schema, counts, source binding, local-only/leakage checks, no-full-article/no-multimodal checks, and Markdown/JSON consistency.
