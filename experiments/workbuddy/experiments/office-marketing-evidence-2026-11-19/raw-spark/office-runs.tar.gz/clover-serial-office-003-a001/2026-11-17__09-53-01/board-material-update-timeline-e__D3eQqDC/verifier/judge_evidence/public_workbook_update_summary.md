# Public Workbook Update Summary

This Judge evidence is derived only from the approved public source workbook and hidden deterministic contract fields that mirror the public workbook after P6/P8 surface approval. It summarizes visible source rows without exposing hidden oracle prose or private trace material.

Exact workbook facts, date normalization, hashes, and source binding remain deterministic-only checks.

- Current workbook scope value: 本次治理会材料
- Material date for footers: 2026-07-01
- Current version display: v1.8 当前

## Current-scope rows
- record=CHG-0601; item=M-101 晨光社区服务站签约; scope=本次治理会材料; status=已完成，进入会后回访准备; date=6月30日; targets=总览, 时间线, 工作流A; note=旧稿中仍写待签署，需与时间线和总览保持一致
- record=CHG-0602; item=M-205 服务包数据回收口径; scope=本次治理会材料; status=已完成初筛，进入抽样复核; date=7月3日; targets=总览, 时间线, 工作流B; note=不要把‘草案待抽样’保留为当前状态
- record=CHG-0603; item=M-310 志愿者培训启动; scope=本次治理会材料; status=启动日已锁定; date=7月15日; targets=时间线, 工作流A, 资源沟通; note=与回访节奏联动，但无需新增一页
- record=CHG-0604; item=M-206 成本测算与风险口径; scope=本次治理会材料; status=黄色关注，保留专项跟踪; date=8月第一周; targets=总览, 工作流B, 决策风险; note=旧稿橙色风险不再作为当前表述
- record=CHG-0605; item=DEC-044 服务包采购口径审定; scope=本次治理会材料; status=待治理会确认; date=7月5日前; targets=决策风险, 资源沟通; note=仍为决策项，不应写成已完成
- record=CHG-0606; item=M-407 抽样复核包冻结; scope=本次治理会材料; status=冻结口径已确认，先于采购审定; date=7月4日; targets=工作流B, 决策风险, 资源沟通; note=采购口径审定依赖该冻结口径，不能写成仅监控或后续草稿
- record=CHG-0607; item=RISK-118 风险降级条件; scope=本次治理会材料; status=7月12日前提交降级证据，8月第一周复盘; date=7月12日前; targets=总览, 决策风险, 资源沟通; note=与 M-206 的黄色关注联动，不能写成风险已解除

## Excluded or distractor rows
- record=CHG-0608; item=M-112 试点二期扩展; scope=后续版本草稿; status=后续版本草稿; date=8月中旬; targets=不进入本次治理会正文; note=可在会后备忘中保留，但不覆盖当前 M-101
- record=CHG-0609; item=ARCH-2025 北岸书屋合作点确认; scope=归档页保留; status=已归档; date=2025年6月20日; targets=历史归档; note=同名近似事项，仅用于区分，不替换当前页
- record=CHG-0610; item=MON-014 短期回访观察; scope=仅监控; status=仅监控，暂不写入正文; date=7月下旬; targets=不进入正文替换; note=可解释风险，但不作为完成状态

## Alias and scope reminders
- 别名组=AL-GUANG-01; 备注=旧稿常用简称，需要按事项编号和工作流确认; 易混淆项=北岸书屋合作点确认; 材料中可能写法=晨光中心；晨光社区站；合作点确认; 正式写法=晨光社区服务站签约; 适用范围=当前治理包 M-101
- 别名组=AL-DATA-02; 备注=同词在历史页出现时不更新; 易混淆项=2025 年数据回收归档; 材料中可能写法=问卷回收；数据采集口径；服务包数据; 正式写法=服务包数据回收口径; 适用范围=当前治理包 M-205
- 别名组=AL-TRAIN-03; 备注=看页面类型和事项编号; 易混淆项=模板页培训占位; 材料中可能写法=志愿者培训；组长通知；培训启动; 正式写法=志愿者培训启动; 适用范围=当前治理包 M-310
- 别名组=AL-RISK-04; 备注=风险等级与采购决策不是同一字段; 易混淆项=仅监控观察项; 材料中可能写法=成本测算；预算压力；采购口径风险; 正式写法=成本测算与风险口径; 适用范围=当前治理包 M-206/DEC-044
- 别名组=AL-SAMPLE-05; 备注=样本冻结是采购审定前置条件，不等于采购已完成; 易混淆项=仅监控抽样观察; 材料中可能写法=复核样本包；样本冻结；抽样包; 正式写法=抽样复核包冻结; 适用范围=当前治理包 M-407
- 别名组=AL-DOWNGRADE-06; 备注=降级条件只说明证据提交期限，不表示黄色关注已解除; 易混淆项=后续风险观察; 材料中可能写法=降级条件；专项跟踪条件；复盘门槛; 正式写法=风险降级条件; 适用范围=当前治理包 RISK-118
- out_of_scope: 为何暂不纳入=旧年度归档; 出现位置=历史归档页; 名称=北岸书屋合作点确认; 容易误用的原因=名称接近 M-101; 建议处理=保留历史页原文; 记录号=HIS-2025-01
- out_of_scope: 为何暂不纳入=v1.9 draft 未生效; 出现位置=后续版本草稿; 名称=试点二期扩展; 容易误用的原因=看起来像当前合作点扩展; 建议处理=不写入本次正文; 记录号=FUT-1901
- out_of_scope: 为何暂不纳入=观察项未形成治理会决策; 出现位置=仅监控清单; 名称=短期回访观察; 容易误用的原因=可能被误写成风险结论; 建议处理=可作为背景但不替换状态; 记录号=MON-014
- out_of_scope: 为何暂不纳入=未形成冻结口径; 出现位置=仅监控清单; 名称=抽样复核观察; 容易误用的原因=容易与 M-407 混淆; 建议处理=不替换当前样本冻结口径; 记录号=MON-SAMPLE
- out_of_scope: 为何暂不纳入=占位说明，不是业务事实; 出现位置=模板页; 名称=模板页样例行动项; 容易误用的原因=含有‘培训’和‘状态’字样; 建议处理=保留模板页用途; 记录号=TPL-ROW
