# Judge Scope and Deterministic Gate Status

This evidence is produced by the deterministic verifier for supplemental text-only WB Judge consumption.

## Deterministic status
- passed_count: 267
- total_count: 379
- pass_rate: 0.7045
- deterministic_gated_pass: false
- deterministic_safety_or_leakage_failed: false
- llm_judge_activation_allowed: true
- failed_checks: old_footer_version_absent, slide_03_current_overview_mapping, slide_04_date_normalization, slide_07_decision_deadline_and_risk_window, distractor_future_draft_not_promoted, slide_01_required_text_00, slide_01_forbidden_text_00_absent, slide_02_required_text_00, slide_02_forbidden_text_00_absent, slide_03_required_text_00, slide_03_required_text_01, slide_03_required_text_02, slide_03_required_text_03, slide_03_required_text_04, slide_03_required_text_05, slide_03_required_text_07, slide_03_required_text_08, slide_03_required_text_09, slide_03_required_text_10, slide_03_required_text_12, slide_03_required_text_13, slide_03_required_text_14, slide_03_required_text_15, slide_03_forbidden_text_00_absent, slide_03_forbidden_text_01_absent, slide_03_forbidden_text_02_absent, slide_03_forbidden_text_03_absent, slide_03_forbidden_text_04_absent, slide_03_forbidden_text_05_absent, slide_03_forbidden_text_06_absent, slide_03_forbidden_text_07_absent, slide_04_required_text_00, slide_04_required_text_02, slide_04_required_text_03, slide_04_required_text_04, slide_04_required_text_05, slide_04_required_text_06, slide_04_required_text_07, slide_04_required_text_08, slide_04_required_text_09, slide_04_forbidden_text_04_absent, slide_05_required_text_00, slide_05_required_text_01, slide_05_required_text_03, slide_05_required_text_04, slide_05_required_text_05, slide_05_required_text_07, slide_05_required_text_08, slide_06_required_text_00, slide_06_required_text_01, slide_06_required_text_02, slide_06_required_text_03, slide_06_required_text_04, slide_06_required_text_06, slide_06_required_text_07, slide_06_required_text_08, slide_06_forbidden_text_01_absent, slide_06_forbidden_text_02_absent, slide_07_required_text_01, slide_07_required_text_02, slide_07_required_text_04, slide_07_required_text_05, slide_07_required_text_06, slide_07_required_text_07, slide_07_required_text_08, slide_07_required_text_09, slide_07_required_text_11, slide_07_forbidden_text_00_absent, slide_07_forbidden_text_01_absent, slide_07_forbidden_text_02_absent, slide_07_forbidden_text_03_absent, slide_07_forbidden_text_04_absent, slide_08_required_text_00, slide_08_required_text_01, slide_08_required_text_03, slide_08_required_text_04, slide_08_required_text_06, slide_08_required_text_07, slide_08_required_text_08, slide_08_required_text_10, slide_08_required_text_12, slide_08_required_text_13, slide_08_required_text_14, slide_08_forbidden_text_00_absent, slide_08_forbidden_text_01_absent, slide_08_forbidden_text_02_absent, slide_08_forbidden_text_03_absent, slide_09_required_text_00, slide_09_required_text_02, sync_M_101_slide_03, sync_M_101_slide_08, sync_M_205_slide_04, sync_M_407_slide_03, sync_M_407_slide_04, sync_M_407_slide_06, sync_M_407_slide_07, sync_M_407_slide_08, sync_M_310_slide_03, sync_M_310_slide_08, sync_M_206_slide_04, sync_M_206_slide_07, sync_DEC_044_slide_03, sync_DEC_044_slide_08, sync_RISK_118_slide_03, sync_RISK_118_slide_07, sync_RISK_118_slide_08, co_location_slide_03_sample_risk_rows, co_location_slide_06_sample_purchase_precondition, co_location_slide_06_sample_row_precondition, co_location_slide_07_decision_sample_precondition, co_location_slide_08_resource_sample_notification, co_location_slide_08_scope_list_updated

LLM Judge may run when required judge_evidence files exist and deterministic safety/leakage checks pass. Deterministic component score, failed_checks, objective file/structure/source/safety failures, and gate status must remain separate and visible.

## Judge modality and allowed scope
- Text-only artifact-level semantic review over submitted slide text, base-vs-submitted text delta, and public workbook/deck summaries.
- Judge may assess narrative integration, prioritization, governance-style concision, non-mechanical patch quality, and synthesized risk/decision framing consistency.

## Deterministic-owned scope not scored by Judge
- exact workbook facts, exact date/status/version correctness, co-location checks, output file existence, PPTX parseability, slide count/order, object/table structure, input hashes, safety/leakage, external dependencies, and forbidden artifacts
- visual rendering, OCR, VLM, pixel-level similarity, hidden oracle phrase matching, model process/tool trace quality, or private trace fidelity

## Exclusion boundary
This file excludes raw private trace text, private paths, private URLs, private emails, account IDs, credentials, customer data, proprietary code, unpublished assets, and hidden oracle prose.
