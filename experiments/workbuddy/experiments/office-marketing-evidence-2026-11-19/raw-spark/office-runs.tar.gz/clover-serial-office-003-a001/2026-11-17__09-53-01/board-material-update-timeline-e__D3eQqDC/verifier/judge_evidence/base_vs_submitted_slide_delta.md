# Base vs Submitted Slide Text Delta

This evidence compares extractable PPTX text only. It does not use rendered images, OCR, VLM, pixel scoring, hidden oracle prose, private trace material, or external services.

## Slide 1
### Added or revised submitted text
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜封面
### Removed or replaced base text
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜封面

## Slide 2
### Added or revised submitted text
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜目录
### Removed or replaced base text
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜目录

## Slide 3
### Added or revised submitted text
- 口径已完成初筛，进入抽样复核
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜总览
### Removed or replaced base text
- 口径草案待抽样
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜总览

## Slide 4
### Added or revised submitted text
- 6月30日 已完成
- 7月3日 完成初筛
- 7月15日启动日已锁定
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜时间线
### Removed or replaced base text
- 6/20 待确认
- 6/26 草案
- 7月上旬待排期
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜时间线

## Slide 5
### Added or revised submitted text
- 旧稿状态：已完成，进入会后回访准备
- 旧稿日期：6月30日
- 旧稿状态：启动日已锁定
- 旧稿日期：7月15日
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜工作流A
### Removed or replaced base text
- 旧稿状态：待签署
- 旧稿日期：6/20
- 旧稿状态：待排期
- 旧稿日期：7月上旬
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜工作流A

## Slide 6
### Added or revised submitted text
- 旧稿：已完成初筛，进入抽样复核
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜工作流B
### Removed or replaced base text
- 旧稿：草案待抽样
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜工作流B

## Slide 7
### Added or revised submitted text
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜决策风险
### Removed or replaced base text
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜决策风险

## Slide 8
### Added or revised submitted text
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜资源沟通
### Removed or replaced base text
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜资源沟通

## Slide 9
### Added or revised submitted text
- 旧稿页脚：v1.8 当前
- 旧稿资料口径：2026-07-01
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜附录
### Removed or replaced base text
- 旧稿页脚：v1.7 草稿
- 旧稿资料口径：2026-06-12
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜附录

## Slide 10
### Added or revised submitted text
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜历史归档
### Removed or replaced base text
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜历史归档

## Slide 11
### Added or revised submitted text
- 春晖公益协同计划｜治理会材料 v1.8 当前｜资料口径：2026-07-01｜模板页
### Removed or replaced base text
- 春晖公益协同计划｜治理会材料 v1.7 草稿｜资料口径：2026-06-12｜模板页
