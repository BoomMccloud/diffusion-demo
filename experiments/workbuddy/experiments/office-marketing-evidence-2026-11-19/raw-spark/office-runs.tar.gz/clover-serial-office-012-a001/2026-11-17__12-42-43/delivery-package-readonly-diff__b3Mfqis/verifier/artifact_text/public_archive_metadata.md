{
  "archive_label": "edu-toolkit-1.4.0-candidate.zip",
  "archive_view_created_utc": "2026-09-18T13:58:00Z",
  "container_byte_hash": "sha256:8146534f8ba9e634",
  "entry_count_from_archive_tool": 82,
  "text_first_boundary": true,
  "archive_not_to_be_repacked": true,
  "notes": [
    "This JSON is archive metadata and a listing index, not a final reconciliation report.",
    "Use observed_path, bytes, and sha256_prefix with the reference manifest and hash notes to classify entries.",
    "Do not edit, delete, copy, or repack the candidate archive or listing files as the solution."
  ],
  "views": [
    "input/workspace/candidate_package_view/listings/candidate_archive_listing.csv",
    "input/workspace/candidate_package_view/listings/candidate_tree_view.txt"
  ]
}
