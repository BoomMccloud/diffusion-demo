2026-09-18T14:04:12Z pkgdiff --reference reference_manifest.csv --candidate candidate_archive_listing.csv --mode prefix-hash
INFO loaded reference rows: 79
INFO loaded candidate listing rows: 82
WARN compare aborted early at row-window=docs/reference after stale cache mismatch; partial output follows
WARN do not use this aborted run as a complete missing/extra/changed list
PARTIAL mismatch path=edu_toolkit/docs/reference/api/v1_4/schema/student_record.yaml evidence=hash-prefix
PARTIAL missing-probe path=edu_toolkit/docs/guides/localization/en_GB/overview.md evidence=exact-path-probe
PARTIAL observed-only path=edu_toolkit/docs/guides/localization/en-GB/overview.md evidence=listing-row
PARTIAL observed-only path=edu_toolkit/src/validation/__pycache__/check_paths.cpython-311.pyc evidence=listing-row
ERROR stale cache key references release=1.3.9; rerun recommended, but source files must remain read-only
状态: partial / aborted; 请交叉核对 manifest + listing + hash notes, 不要把这里当完整答案表.
