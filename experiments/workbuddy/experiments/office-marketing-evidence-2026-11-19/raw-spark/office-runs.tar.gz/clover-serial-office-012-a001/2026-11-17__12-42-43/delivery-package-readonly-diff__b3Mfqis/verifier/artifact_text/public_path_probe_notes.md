# listing-check analyst notes

Current candidate listing includes near-match names. Treat these as evidence prompts, not as bucket labels.
The archive tool sometimes normalizes repeated slashes but does not normalize locale punctuation (`en_GB` vs `en-GB`).

## Observed-only path stems noticed during quick scan
- observed stem: edu_toolkit/config/template/local_run/paths.yaml (path_variant_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/config/templates/archive/include-patterns.txt (path_variant_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/config/templates/privacy_flags.yaml (hash_size_review_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/data/samples/classroom/roster_beta.csv (hash_size_review_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/data/samples/classroom/roster_beta_old.csv (candidate_variant_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/data/samples/events/2026-09-week02.jsonl (hash_size_review_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/data/samples/events/2026-09-week02.tmp.jsonl (candidate_variant_note); compare with reference manifest before deciding
- observed stem: edu_toolkit/data/samples/templates/event_import_template.csv (hash_size_review_note); compare with reference manifest before deciding

## Partial path probes
- `docs/references/` and `docs/reference/` both appear in notes; only listing rows and manifest rows should decide exact path status.
- `include-patterns.txt` and `include_patterns.txt` are not automatically equivalent.
- `paged-query.json` may be a renamed current export or a stray helper; check manifest ID and hash evidence.
- Media manifest rows are checksum/metadata entries; do not open image/audio/video content or use OCR/VLM.
