schema_version: package_audit_report.v1
report_status: completed
readonly_confirmation:
  source_materials_modified: false
  protected_inputs_reviewed:
    - input/workspace/reference_release_manifest/reference_manifest.csv
    - input/workspace/reference_release_manifest/manifest_notes.md
    - input/workspace/candidate_package_view/archive_metadata.json
    - input/workspace/candidate_package_view/listings/candidate_archive_listing.csv
    - input/workspace/candidate_package_view/listings/candidate_tree_view.txt
    - input/workspace/analysis_notes/README.md
    - input/workspace/analysis_notes/hash_checks/hash_compare_scratch.txt
    - input/workspace/analysis_notes/listing_checks/path_probe_notes.md
    - input/workspace/analysis_notes/noisy_logs/partial_compare_run.log
    - environment/local_readonly_audit/README.md
    - environment/state_diff_manifest.json
  mutation_statement: No source materials were modified, deleted, renamed, copied-as-repair, or repacked. Only the output report file was written.
evidence_sources_used:
  reference_manifest: input/workspace/reference_release_manifest/reference_manifest.csv (79 rows, MF-0001–MF-0079)
  candidate_tree_or_archive_listing: input/workspace/candidate_package_view/listings/candidate_archive_listing.csv (82 entries) corroborated by candidate_tree_view.txt and archive_metadata.json entry_count=82
  metadata_hash_notes: input/workspace/analysis_notes/hash_checks/hash_compare_scratch.txt (current-run hash-prefix scan with 10 WARN entries and 5 absent-probe checks)
  noisy_partial_logs: input/workspace/analysis_notes/noisy_logs/partial_compare_run.log — used only as supporting context; its partial/aborted nature means it does not drive final classification. Stale lines (release=1.3.9 references) excluded.
  notes: All classifications derived from direct comparison of reference manifest paths/hashes against candidate listing paths/hashes. Path-probe notes inform inconclusive determinations where exact-path matches fail due to spelling variants.
summary_counts:
  missing: 8
  extra: 14
  changed: 13
  matching: 55
  inconclusive: 3
findings:
  missing:
    - package_path: edu_toolkit/config/templates/export_profile_minimal.yaml
      manifest_id: MF-0037
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
    - package_path: edu_toolkit/config/templates/local_run/paths.yaml
      manifest_id: MF-0039
      visible_evidence_basis: "candidate_archive_listing.csv contains edu_toolkit/config/template/local_run/paths.yaml (singular 'template') instead — see INCONCLUSIVE bucket"
      note: "Exact path not found; a near-match exists under a different directory name. Classified as INCONCLUSIVE rather than MISSING because a plausible variant is present."
    - package_path: edu_toolkit/data/samples/events/2026-09-week04.jsonl
      manifest_id: MF-0027
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
    - package_path: edu_toolkit/docs/guides/localization/en_GB/overview.md
      manifest_id: MF-0007
      visible_evidence_basis: "candidate_archive_listing.csv contains edu_toolkit/docs/guides/localization/en-GB/overview.md (hyphenated locale code) instead — see INCONCLUSIVE bucket"
      note: "Exact path not found; a near-match exists with hyphenated locale code. Classified as INCONCLUSIVE rather than MISSING because a plausible variant is present."
    - package_path: edu_toolkit/docs/reference/api/v1_4/examples/paged_query.json
      manifest_id: MF-0018
      visible_evidence_basis: "candidate_archive_listing.csv contains edu_toolkit/docs/reference/api/v1_4/examples/paged-query.json (hyphenated filename) instead — see INCONCLUSIVE bucket"
      note: "Exact path not found; a near-match exists with hyphenated filename. Classified as INCONCLUSIVE rather than MISSING because a plausible variant is present."
    - package_path: edu_toolkit/release/checksums/SHA256SUMS.txt.sig-note
      manifest_id: MF-0064
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
    - package_path: edu_toolkit/scripts/README.md
      manifest_id: MF-0079
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
    - package_path: edu_toolkit/src/validation/rules/locale_rules.py
      manifest_id: MF-0049
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
    - package_path: edu_toolkit/tests/fixtures/hash/sample_hashes_legacy.json
      manifest_id: MF-0058
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
    - package_path: edu_toolkit/tests/fixtures/reports/report_incomplete.md
      manifest_id: MF-0061
      visible_evidence_basis: "candidate_archive_listing.csv contains no entry for this path"
      note: "Optional (include_if_present); absent from candidate archive. Not blocking since optional."
  extra:
    - package_path: edu_toolkit/config/template/local_run/paths.yaml
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Near-match to MF-0039 (edu_toolkit/config/templates/local_run/paths.yaml) but differs in directory name ('template' vs 'templates'). See INCONCLUSIVE for MF-0039."
    - package_path: edu_toolkit/config/templates/archive/include-patterns.txt
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Near-match to MF-0042 (edu_toolkit/config/templates/archive/include_patterns.txt) but differs in filename punctuation ('-' vs '_'). Both files exist in candidate; MF-0042 matches via include_patterns.txt."
    - package_path: edu_toolkit/data/samples/classroom/roster_beta_old.csv
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Stray/legacy file. Likely unintended artifact. Blocking unless confirmed intentional."
    - package_path: edu_toolkit/data/samples/events/2026-09-week02.tmp.jsonl
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Temporary/staging file (.tmp suffix). Unintended artifact. Blocking."
    - package_path: edu_toolkit/docs/guides/localization/en-GB/overview.md
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Near-match to MF-0007 (en_GB/overview.md) but uses hyphenated locale code. See INCONCLUSIVE for MF-0007."
    - package_path: edu_toolkit/docs/reference/api/v1_4/examples/paged-query.json
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Near-match to MF-0018 (paged_query.json) but uses hyphenated filename. See INCONCLUSIVE for MF-0018."
    - package_path: edu_toolkit/docs/references/api/v1_4/endpoints_draft.md
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Stray draft document under 'references/' (plural) rather than 'reference/'. Unintended artifact. Blocking."
    - package_path: edu_toolkit/release/checksums/SHA256SUMS.old.txt
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Legacy/stale checksum file (.old suffix). Unintended artifact. Blocking."
    - package_path: edu_toolkit/release/checksums/local-compare-work.tmp
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Temporary working file (.tmp suffix). Unintended artifact. Blocking."
    - package_path: edu_toolkit/scripts/package_release_local_notes.md
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Untracked local notes file. Unintended artifact. Blocking."
    - package_path: edu_toolkit/src/validation/__pycache__/check_paths.cpython-311.pyc
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Python bytecode cache file. Unintended artifact. Blocking."
    - package_path: edu_toolkit/src/validation/rules/report_rules.old.py
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Legacy/stale Python module (.old suffix). Unintended artifact. Blocking."
    - package_path: edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot_draft.txt
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Draft/unfinalized fixture. Unintended artifact. Blocking."
    - package_path: edu_toolkit/tmp/export_trace_20260918.log
      manifest_id: null
      visible_evidence_basis: "Present in candidate_archive_listing.csv and candidate_tree_view.txt; no corresponding reference manifest row"
      note: "Temporary export trace log. Unintended artifact. Blocking."
  changed:
    - package_path: edu_toolkit/config/templates/privacy_flags.yaml
      manifest_id: MF-0035
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=374ac707cc0d2fc3 vs reference expected=00efba959ba49160"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/data/samples/classroom/roster_beta.csv
      manifest_id: MF-0022
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=921ca6a027501e4a vs reference expected=98849d521e12bb98"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/data/samples/events/2026-09-week02.jsonl
      manifest_id: MF-0025
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=73df06451d0fce8b vs reference expected=1bb96aa36b8cc088"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/data/samples/templates/event_import_template.csv
      manifest_id: MF-0030
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=1917142012139ad4 vs reference expected=356906694b1fe1ea"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/docs/guides/student_lab_setup.md
      manifest_id: MF-0003
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=fc150e907a6357d3 vs reference expected=611bffc884b9a95e"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/docs/guides/troubleshooting/data_import.md
      manifest_id: MF-0010
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=337d45c4cb79a819 vs reference expected=700562d82e29dc6a"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/docs/reference/api/v1_4/schema/student_record.yaml
      manifest_id: MF-0015
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=b5108caa6fee85a8 vs reference expected=2a7d771f160e7998"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/release/checksums/package_size_index.csv
      manifest_id: MF-0066
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=5c6f9c570da94b8d vs reference expected=6b315b5c7ef5da70"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/scripts/verify_release.py
      manifest_id: MF-0078
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=23aae70ca6677902 vs reference expected=d45f281abb557081"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/src/validation/check_hashes.py
      manifest_id: MF-0046
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=6807ccde8501ad92 vs reference expected=420673ec947ef0a8"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/src/validation/rules/report_rules.py
      manifest_id: MF-0050
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=b085edef99cec710 vs reference expected=80ac53be89318a45"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot.txt
      manifest_id: MF-0056
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=cfc98729a974f14d vs reference expected=56a5b6d605e0d099"
      note: "Hash mismatch on required file. Blocking."
    - package_path: edu_toolkit/tests/fixtures/hash/sample_hashes.json
      manifest_id: MF-0057
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=131635e7fccc2af7 vs reference expected=0160a95d69171042"
      note: "Hash mismatch on required file. Blocking."
  matching:
    - package_path: edu_toolkit/CHANGELOG.md
      manifest_id: MF-0073
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=03d181707bb50075 matches reference expected=03d181707bb50075"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/LICENSE.txt
      manifest_id: MF-0071
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=ddaf384463090ff4 matches reference expected=ddaf384463090ff4"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/NOTICE.txt
      manifest_id: MF-0072
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=9af6d45e8c13bac9 matches reference expected=9af6d45e8c13bac9"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/README.md
      manifest_id: MF-0070
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=6ecfed6369ccda52 matches reference expected=6ecfed6369ccda52"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/config/templates/archive/include_patterns.txt
      manifest_id: MF-0042
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=88a2c4f13fdee46c matches reference expected=88a2c4f13fdee46c"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/config/templates/archive/package_notes.txt
      manifest_id: MF-0041
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=7a306e51ec30cb7a matches reference expected=7a306e51ec30cb7a"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/config/templates/course_defaults.yaml
      manifest_id: MF-0033
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=05ad12fc1bf2cd88 matches reference expected=05ad12fc1bf2cd88"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/config/templates/export_profile_public.yaml
      manifest_id: MF-0036
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=87ca7d4634b3baaa matches reference expected=87ca7d4634b3baaa"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/config/templates/grading_scale.yaml
      manifest_id: MF-0034
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=8dad203677d27e9c matches reference expected=8dad203677d27e9c"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/config/templates/local_run/logging.yaml
      manifest_id: MF-0040
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=b60505461174547a matches reference expected=b60505461174547a"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/README.md
      manifest_id: MF-0032
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=69a7858079ae18ba matches reference expected=69a7858079ae18ba"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/classroom/roster_alpha.csv
      manifest_id: MF-0021
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=95ca9389b8f67249 matches reference expected=95ca9389b8f67249"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/classroom/roster_gamma.csv
      manifest_id: MF-0023
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=0fca27af953129ce matches reference expected=0fca27af953129ce"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/events/2026-09-week01.jsonl
      manifest_id: MF-0024
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=a04cc94675a7f03d matches reference expected=a04cc94675a7f03d"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/events/2026-09-week03.jsonl
      manifest_id: MF-0026
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=b48bbe52dff6cb45 matches reference expected=b48bbe52dff6cb45"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/media_manifest.csv
      manifest_id: MF-0031
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=c063e32677b3df3f matches reference expected=c063e32677b3df3f"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/data/samples/templates/assessment_import_template.csv
      manifest_id: MF-0029
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=efbf7d15a712c4eb matches reference expected=efbf7d15a712c4eb"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/accessibility_notes.md
      manifest_id: MF-0005
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=c965b5c0431d39ad matches reference expected=c965b5c0431d39ad"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/changelog_highlights.md
      manifest_id: MF-0011
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=5fcdc19204d0c21d matches reference expected=5fcdc19204d0c21d"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/localization/en_US/overview.md
      manifest_id: MF-0006
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=4cedb066ab77181d matches reference expected=4cedb066ab77181d"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/localization/es_ES/overview.md
      manifest_id: MF-0008
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=0e10704776ba55ad matches reference expected=0e10704776ba55ad"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/offline_mode.md
      manifest_id: MF-0004
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=294b0e8b2b6c88ae matches reference expected=294b0e8b2b6c88ae"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/teacher_quickstart.md
      manifest_id: MF-0002
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=52d8f7f0b5cdc2bb matches reference expected=52d8f7f0b5cdc2bb"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/guides/troubleshooting/install_errors.md
      manifest_id: MF-0009
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=2cce75153a0d7e78 matches reference expected=2cce75153a0d7e78"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/api/v1_4/auth_notes.md
      manifest_id: MF-0014
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=fe310e33b81df742 matches reference expected=fe310e33b81df742"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/api/v1_4/endpoints.md
      manifest_id: MF-0012
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=7f75b43a4965916c matches reference expected=7f75b43a4965916c"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/api/v1_4/errors.md
      manifest_id: MF-0013
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=db275191825f94eb matches reference expected=db275191825f94eb"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/api/v1_4/examples/error_payload.json
      manifest_id: MF-0019
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=dad5ba13c4552a57 matches reference expected=dad5ba13c4552a57"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/api/v1_4/schema/assessment_result.yaml
      manifest_id: MF-0017
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=101e57f7609ca69f matches reference expected=101e57f7609ca69f"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/api/v1_4/schema/classroom_event.yaml
      manifest_id: MF-0016
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=8acd3a4fabac711e matches reference expected=8acd3a4fabac711e"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/docs/reference/cli/command_index.md
      manifest_id: MF-0020
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=333d3898009826c8 matches reference expected=333d3898009826c8"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/pyproject.toml
      manifest_id: MF-0075
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=00b9ee1239743767 matches reference expected=00b9ee1239743767"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/release/checksums/README.md
      manifest_id: MF-0068
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=9e123dd75782c9bd matches reference expected=9e123dd75782c9bd"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/release/checksums/SHA256SUMS.txt
      manifest_id: MF-0063
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=e17d293f9ca8d4f8 matches reference expected=e17d293f9ca8d4f8"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/release/checksums/archive_manifest.json
      manifest_id: MF-0065
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=330ca22083597d37 matches reference expected=330ca22083597d37"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/release/checksums/draft_compare_notes.txt
      manifest_id: MF-0069
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=63664185b8f7ab4e matches reference expected=63664185b8f7ab4e"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/release/checksums/generated_at.txt
      manifest_id: MF-0067
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=303b224725226e3d matches reference expected=303b224725226e3d"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/requirements.txt
      manifest_id: MF-0076
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=4e81e5cc507bfb84 matches reference expected=4e81e5cc507bfb84"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/scripts/package_release.py
      manifest_id: MF-0077
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=529b0c2ba32084d2 matches reference expected=529b0c2ba32084d2"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/__init__.py
      manifest_id: MF-0043
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=275ddd74fb170959 matches reference expected=275ddd74fb170959"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/check_manifest.py
      manifest_id: MF-0044
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=21034b3c72424cf6 matches reference expected=21034b3c72424cf6"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/check_paths.py
      manifest_id: MF-0045
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=8fba564f4c4b6bfc matches reference expected=8fba564f4c4b6bfc"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/fixtures/path_case_mixed_locale.json
      manifest_id: MF-0052
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=e220e8fd7ed1ed66 matches reference expected=e220e8fd7ed1ed66"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/fixtures/valid_manifest_case.json
      manifest_id: MF-0051
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=e88244c1be3dce23 matches reference expected=e88244c1be3dce23"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/rules/path_rules.py
      manifest_id: MF-0048
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=642b7f3926350a12 matches reference expected=642b7f3926350a12"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/src/validation/rules/schema_rules.py
      manifest_id: MF-0047
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=31a7bca9b543cddf matches reference expected=31a7bca9b543cddf"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/tests/fixtures/README.md
      manifest_id: MF-0062
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=a5ff94eb02dd88ff matches reference expected=a5ff94eb02dd88ff"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/tests/fixtures/archive/expected_tree_snapshot.txt
      manifest_id: MF-0055
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=9a72ec8505edeb7a matches reference expected=9a72ec8505edeb7a"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/tests/fixtures/manifest/full_manifest.json
      manifest_id: MF-0054
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=c8de3b5ae5eef1a3 matches reference expected=c8de3b5ae5eef1a3"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/tests/fixtures/manifest/minimal_manifest.json
      manifest_id: MF-0053
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=39bc5112cc342beb matches reference expected=39bc5112cc342beb"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/tests/fixtures/reports/report_success.md
      manifest_id: MF-0059
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=6234da8221ca76c9 matches reference expected=6234da8221ca76c9"
      note: "Exact path and hash match."
    - package_path: edu_toolkit/tests/fixtures/reports/report_with_warnings.md
      manifest_id: MF-0060
      visible_evidence_basis: "candidate_archive_listing.csv sha256_prefix=9beaec247ea686c8 matches reference expected=9beaec247ea686c8"
      note: "Exact path and hash match."
  inconclusive:
    - package_path: edu_toolkit/config/templates/local_run/paths.yaml
      manifest_id: MF-0039
      visible_evidence_basis: "candidate_archive_listing.csv contains edu_toolkit/config/template/local_run/paths.yaml (singular 'template' dir) with sha256=984deffe1272763a; reference expects sha256=4869f936fc098b9f. Directory name differs ('template' vs 'templates')."
      open_question: "Is 'config/template/' a legitimate alternate directory structure, or is this a packaging error? If legitimate, the file would map to MF-0039 and require hash verification; if erroneous, MF-0039 is genuinely missing."
    - package_path: edu_toolkit/docs/guides/localization/en-GB/overview.md
      manifest_id: MF-0007
      visible_evidence_basis: "candidate_archive_listing.csv contains edu_toolkit/docs/guides/localization/en-GB/overview.md with sha256=eb6d72bc17d48ee3; reference expects edu_toolkit/docs/guides/localization/en_GB/overview.md with sha256=b63a3bfe18149299. Locale code differs ('en-GB' vs 'en_GB')."
      open_question: "Is 'en-GB' a valid alternative locale identifier for British English, or is this a path-spelling error? If valid, the file maps to MF-0007 but with a different hash; if erroneous, MF-0007 is genuinely missing."
    - package_path: edu_toolkit/docs/reference/api/v1_4/examples/paged-query.json
      manifest_id: MF-0018
      visible_evidence_basis: "candidate_archive_listing.csv contains edu_toolkit/docs/reference/api/v1_4/examples/paged-query.json with sha256=c896ff33271cba58; reference expects edu_toolkit/docs/reference/api/v1_4/examples/paged_query.json with sha256=086f20b46f7d7b60. Filename differs ('paged-query' vs 'paged_query')."
      open_question: "Is 'paged-query.json' a valid renamed export of the pagination example, or is this a path-spelling error? If valid, the file maps to MF-0018 but with a different hash; if erroneous, MF-0018 is genuinely missing."
recommendation:
  status: revise_before_handoff
  rationale: >
    Three categories of blocking issues prevent ready-to-attach status:
    (1) 13 CHANGED items — required files whose SHA-256 prefixes differ from the reference manifest, indicating content modification between release build and candidate packaging.
    (2) 14 EXTRA items — files present in the candidate archive with no corresponding reference manifest entry. Of these, 10 are clearly unintended artifacts (stray .tmp/.old files, __pycache__ bytecode, .log traces, draft fixtures) and 4 are path-spelling variants that overlap with INCONCLUSIVE items.
    (3) 3 INCONCLUSIVE items — reference manifest entries whose exact paths are absent from the candidate listing but whose near-matching variants exist. Without resolution, these block readiness.
    The 8 MISSING items are all optional (include_if_present) and therefore do not independently block readiness, though their absence should be noted.
  no_repack_performed: true
assumptions:
  - The reference manifest (reference_manifest.csv) is authoritative for expected paths, components, kinds, required flags, size bands, SHA-256 prefixes, and packaging rules.
  - The candidate archive listing (candidate_archive_listing.csv) accurately reflects the contents of the archive container identified by archive_metadata.json.
  - SHA-256 prefix comparison is sufficient for classification purposes; full SHA-256 digests are not available.
  - Files marked optional (include_if_present) may legitimately be absent from the candidate package without constituting a blocking issue.
  - Path matching is case-sensitive and punctuation-sensitive (underscores, hyphens, slashes) unless corroborated otherwise.
  - Stray files with .tmp, .old, __pycache__, .log, or _draft/_local suffixes are presumed unintended artifacts.
open_questions:
  - "Should the 3 INCONCLUSIVE path variants (en_GB→en-GB, paged_query→paged-query, template→templates) be treated as equivalent to their reference counterparts? Resolution would reclassify some items from missing/inconclusive to matching or changed."
  - "Are the 14 EXTRA items intentional additions or accidental artifacts? The majority appear to be stray files that should be removed before handoff."
  - "For the 8 MISSING optional items, is their absence acceptable, or should they be added back to the candidate package?"
  - "Which of the 13 CHANGED items reflect legitimate content updates versus packaging errors? Each requires individual review."
ordering_policy:
  bucket_order:
    - missing
    - extra
    - changed
    - matching
    - inconclusive
  path_order: canonical_lexicographic_by_normalized_relative_path
  normalization: leading 'edu_toolkit/' stripped for sorting; remaining path segments compared byte-wise in ascending order
