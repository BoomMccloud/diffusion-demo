manifest_id,expected_path,component,kind,required,expected_size_band,expected_sha256_prefix,release_note,packaging_rule,sensitivity
MF-0001,edu_toolkit/docs/guides/getting_started.md,docs_guides,markdown,required,small,sha256:0089d69316ecea7a,Intro guide; cited by course staff,include_in_zip,public
MF-0002,edu_toolkit/docs/guides/teacher_quickstart.md,docs_guides,markdown,required,small,sha256:52d8f7f0b5cdc2bb,Instructor onboarding,include_in_zip,public
MF-0003,edu_toolkit/docs/guides/student_lab_setup.md,docs_guides,markdown,required,medium,sha256:611bffc884b9a95e,Lab setup path should be stable,include_in_zip,public
MF-0004,edu_toolkit/docs/guides/offline_mode.md,docs_guides,markdown,optional,small,sha256:294b0e8b2b6c88ae,Optional field-school mode,include_if_present,public
MF-0005,edu_toolkit/docs/guides/accessibility_notes.md,docs_guides,markdown,required,small,sha256:c965b5c0431d39ad,Accessibility checklist,include_in_zip,public
MF-0006,edu_toolkit/docs/guides/localization/en_US/overview.md,docs_guides,markdown,required,small,sha256:4cedb066ab77181d,US English locale overview,include_in_zip,public
MF-0007,edu_toolkit/docs/guides/localization/en_GB/overview.md,docs_guides,markdown,optional,small,sha256:b63a3bfe18149299,British English locale overview,include_if_present,public
MF-0008,edu_toolkit/docs/guides/localization/es_ES/overview.md,docs_guides,markdown,optional,small,sha256:0e10704776ba55ad,Spanish locale overview,include_if_present,public
MF-0009,edu_toolkit/docs/guides/troubleshooting/install_errors.md,docs_guides,markdown,required,medium,sha256:2cce75153a0d7e78,Install error guide,include_in_zip,public
MF-0010,edu_toolkit/docs/guides/troubleshooting/data_import.md,docs_guides,markdown,required,medium,sha256:700562d82e29dc6a,Data import guide,include_in_zip,public
MF-0011,edu_toolkit/docs/guides/changelog_highlights.md,docs_guides,markdown,required,small,sha256:5fcdc19204d0c21d,Release highlight doc,include_in_zip,public
MF-0012,edu_toolkit/docs/reference/api/v1_4/endpoints.md,docs_reference,markdown,required,medium,sha256:7f75b43a4965916c,Public API endpoint doc,include_in_zip,public
MF-0013,edu_toolkit/docs/reference/api/v1_4/errors.md,docs_reference,markdown,required,small,sha256:db275191825f94eb,API error table,include_in_zip,public
MF-0014,edu_toolkit/docs/reference/api/v1_4/auth_notes.md,docs_reference,markdown,required,small,sha256:fe310e33b81df742,Sandbox auth explanation only,include_in_zip,public
MF-0015,edu_toolkit/docs/reference/api/v1_4/schema/student_record.yaml,docs_reference,yaml,required,medium,sha256:2a7d771f160e7998,Student record schema,include_in_zip,public
MF-0016,edu_toolkit/docs/reference/api/v1_4/schema/classroom_event.yaml,docs_reference,yaml,required,medium,sha256:8acd3a4fabac711e,Classroom event schema,include_in_zip,public
MF-0017,edu_toolkit/docs/reference/api/v1_4/schema/assessment_result.yaml,docs_reference,yaml,required,medium,sha256:101e57f7609ca69f,Assessment result schema,include_in_zip,public
MF-0018,edu_toolkit/docs/reference/api/v1_4/examples/paged_query.json,docs_reference,json,optional,small,sha256:086f20b46f7d7b60,Pagination example,include_if_present,public
MF-0019,edu_toolkit/docs/reference/api/v1_4/examples/error_payload.json,docs_reference,json,optional,small,sha256:dad5ba13c4552a57,Error payload example,include_if_present,public
MF-0020,edu_toolkit/docs/reference/cli/command_index.md,docs_reference,markdown,required,small,sha256:333d3898009826c8,CLI command index,include_in_zip,public
MF-0021,edu_toolkit/data/samples/classroom/roster_alpha.csv,data_samples,csv,required,medium,sha256:95ca9389b8f67249,Sample classroom roster,include_in_zip,public
MF-0022,edu_toolkit/data/samples/classroom/roster_beta.csv,data_samples,csv,required,medium,sha256:98849d521e12bb98,Sample classroom roster,include_in_zip,public
MF-0023,edu_toolkit/data/samples/classroom/roster_gamma.csv,data_samples,csv,optional,medium,sha256:0fca27af953129ce,Sample classroom roster,include_if_present,public
MF-0024,edu_toolkit/data/samples/events/2026-09-week01.jsonl,data_samples,jsonl,required,large,sha256:a04cc94675a7f03d,Week 01 event stream,include_in_zip,public
MF-0025,edu_toolkit/data/samples/events/2026-09-week02.jsonl,data_samples,jsonl,required,large,sha256:1bb96aa36b8cc088,Week 02 event stream,include_in_zip,public
MF-0026,edu_toolkit/data/samples/events/2026-09-week03.jsonl,data_samples,jsonl,required,large,sha256:b48bbe52dff6cb45,Week 03 event stream,include_in_zip,public
MF-0027,edu_toolkit/data/samples/events/2026-09-week04.jsonl,data_samples,jsonl,optional,large,sha256:e528084f4865af1e,Week 04 event stream,include_if_present,public
MF-0028,edu_toolkit/data/samples/templates/student_import_template.csv,data_samples,csv,required,small,sha256:cebd6874bb981e94,Import template,include_in_zip,public
MF-0029,edu_toolkit/data/samples/templates/assessment_import_template.csv,data_samples,csv,required,small,sha256:efbf7d15a712c4eb,Import template,include_in_zip,public
MF-0030,edu_toolkit/data/samples/templates/event_import_template.csv,data_samples,csv,required,small,sha256:356906694b1fe1ea,Import template,include_in_zip,public
MF-0031,edu_toolkit/data/samples/media_manifest.csv,data_samples,csv,required,small,sha256:c063e32677b3df3f,Lists media-like training placeholders as metadata only,include_in_zip,public
MF-0032,edu_toolkit/data/samples/README.md,data_samples,markdown,required,small,sha256:69a7858079ae18ba,Sample data readme,include_in_zip,public
MF-0033,edu_toolkit/config/templates/course_defaults.yaml,config_templates,yaml,required,small,sha256:05ad12fc1bf2cd88,Course defaults,include_in_zip,public
MF-0034,edu_toolkit/config/templates/grading_scale.yaml,config_templates,yaml,required,small,sha256:8dad203677d27e9c,Grading scale,include_in_zip,public
MF-0035,edu_toolkit/config/templates/privacy_flags.yaml,config_templates,yaml,required,small,sha256:00efba959ba49160,Demo privacy flags,include_in_zip,public
MF-0036,edu_toolkit/config/templates/export_profile_public.yaml,config_templates,yaml,required,small,sha256:87ca7d4634b3baaa,Public export profile,include_in_zip,public
MF-0037,edu_toolkit/config/templates/export_profile_minimal.yaml,config_templates,yaml,optional,small,sha256:f382d0fdf4a03a90,Minimal export profile,include_if_present,public
MF-0038,edu_toolkit/config/templates/local_run/checks.yaml,config_templates,yaml,required,small,sha256:40cc9357c15e7704,Local run checks,include_in_zip,public
MF-0039,edu_toolkit/config/templates/local_run/paths.yaml,config_templates,yaml,required,small,sha256:4869f936fc098b9f,Path defaults,include_in_zip,public
MF-0040,edu_toolkit/config/templates/local_run/logging.yaml,config_templates,yaml,required,small,sha256:b60505461174547a,Logging defaults,include_in_zip,public
MF-0041,edu_toolkit/config/templates/archive/package_notes.txt,config_templates,txt,optional,small,sha256:7a306e51ec30cb7a,Archive note,include_if_present,public
MF-0042,edu_toolkit/config/templates/archive/include_patterns.txt,config_templates,txt,required,small,sha256:88a2c4f13fdee46c,Include patterns,include_in_zip,public
MF-0043,edu_toolkit/src/validation/__init__.py,src_validation,python,required,small,sha256:275ddd74fb170959,Validation package marker,include_in_zip,public
MF-0044,edu_toolkit/src/validation/check_manifest.py,src_validation,python,required,medium,sha256:21034b3c72424cf6,Manifest validation helper,include_in_zip,public
MF-0045,edu_toolkit/src/validation/check_paths.py,src_validation,python,required,medium,sha256:8fba564f4c4b6bfc,Path validation helper,include_in_zip,public
MF-0046,edu_toolkit/src/validation/check_hashes.py,src_validation,python,required,medium,sha256:420673ec947ef0a8,Hash validation helper,include_in_zip,public
MF-0047,edu_toolkit/src/validation/rules/schema_rules.py,src_validation,python,required,medium,sha256:31a7bca9b543cddf,Schema rule helpers,include_in_zip,public
MF-0048,edu_toolkit/src/validation/rules/path_rules.py,src_validation,python,required,medium,sha256:642b7f3926350a12,Path rule helpers,include_in_zip,public
MF-0049,edu_toolkit/src/validation/rules/locale_rules.py,src_validation,python,optional,small,sha256:3cc36a6c4d8f8d54,Locale rule helpers,include_if_present,public
MF-0050,edu_toolkit/src/validation/rules/report_rules.py,src_validation,python,required,medium,sha256:2816cb3aa3ffd09e,Report rule helpers,include_in_zip,public
MF-0051,edu_toolkit/src/validation/fixtures/valid_manifest_case.json,src_validation,json,required,small,sha256:e88244c1be3dce23,Validation fixture,include_in_zip,public
MF-0052,edu_toolkit/src/validation/fixtures/path_case_mixed_locale.json,src_validation,json,optional,small,sha256:e220e8fd7ed1ed66,Locale path fixture,include_if_present,public
MF-0053,edu_toolkit/tests/fixtures/manifest/minimal_manifest.json,tests_fixtures,json,required,small,sha256:39bc5112cc342beb,Test fixture,include_in_zip,public
MF-0054,edu_toolkit/tests/fixtures/manifest/full_manifest.json,tests_fixtures,json,required,medium,sha256:c8de3b5ae5eef1a3,Test fixture,include_in_zip,public
MF-0055,edu_toolkit/tests/fixtures/archive/expected_tree_snapshot.txt,tests_fixtures,txt,required,small,sha256:9a72ec8505edeb7a,Expected tree fixture,include_in_zip,public
MF-0056,edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot.txt,tests_fixtures,txt,required,small,sha256:56a5b6d605e0d099,Candidate tree fixture,include_in_zip,public
MF-0057,edu_toolkit/tests/fixtures/hash/sample_hashes.json,tests_fixtures,json,required,small,sha256:0160a95d69171042,Hash fixture,include_in_zip,public
MF-0058,edu_toolkit/tests/fixtures/hash/sample_hashes_legacy.json,tests_fixtures,json,optional,small,sha256:60b17f086ce2d8eb,Legacy hash fixture,include_if_present,public
MF-0059,edu_toolkit/tests/fixtures/reports/report_success.md,tests_fixtures,markdown,required,small,sha256:6234da8221ca76c9,Report fixture,include_in_zip,public
MF-0060,edu_toolkit/tests/fixtures/reports/report_with_warnings.md,tests_fixtures,markdown,required,small,sha256:9beaec247ea686c8,Report fixture,include_in_zip,public
MF-0061,edu_toolkit/tests/fixtures/reports/report_incomplete.md,tests_fixtures,markdown,optional,small,sha256:84ebdbcf568b5c36,Report fixture,include_if_present,public
MF-0062,edu_toolkit/tests/fixtures/README.md,tests_fixtures,markdown,required,small,sha256:a5ff94eb02dd88ff,Fixture readme,include_in_zip,public
MF-0063,edu_toolkit/release/checksums/SHA256SUMS.txt,release_checksums,txt,required,medium,sha256:e17d293f9ca8d4f8,Checksum list,include_in_zip,public
MF-0064,edu_toolkit/release/checksums/SHA256SUMS.txt.sig-note,release_checksums,txt,optional,small,sha256:76cebf6436de8984,Human signature note; not a cryptographic service,include_if_present,public
MF-0065,edu_toolkit/release/checksums/archive_manifest.json,release_checksums,json,required,small,sha256:330ca22083597d37,Archive metadata,include_in_zip,public
MF-0066,edu_toolkit/release/checksums/package_size_index.csv,release_checksums,csv,required,small,sha256:6b315b5c7ef5da70,Size index,include_in_zip,public
MF-0067,edu_toolkit/release/checksums/generated_at.txt,release_checksums,txt,required,small,sha256:303b224725226e3d,Generation timestamp note,include_in_zip,public
MF-0068,edu_toolkit/release/checksums/README.md,release_checksums,markdown,required,small,sha256:9e123dd75782c9bd,Checksum readme,include_in_zip,public
MF-0069,edu_toolkit/release/checksums/draft_compare_notes.txt,release_checksums,txt,optional,small,sha256:63664185b8f7ab4e,Draft comparison note,include_if_present,public
MF-0070,edu_toolkit/README.md,root,markdown,required,medium,sha256:6ecfed6369ccda52,Top-level readme,include_in_zip,public
MF-0071,edu_toolkit/LICENSE.txt,root,txt,required,small,sha256:ddaf384463090ff4,Sample permissive license note,include_in_zip,public
MF-0072,edu_toolkit/NOTICE.txt,root,txt,required,small,sha256:9af6d45e8c13bac9,Notice file,include_in_zip,public
MF-0073,edu_toolkit/CHANGELOG.md,root,markdown,required,medium,sha256:03d181707bb50075,Changelog,include_in_zip,public
MF-0074,edu_toolkit/CONTRIBUTING.md,root,markdown,optional,small,sha256:40b83cfe3fd4b4cd,Contribution guide,include_if_present,public
MF-0075,edu_toolkit/pyproject.toml,root,toml,required,small,sha256:00b9ee1239743767,Build metadata,include_in_zip,public
MF-0076,edu_toolkit/requirements.txt,root,txt,required,small,sha256:4e81e5cc507bfb84,Local install requirements,include_in_zip,public
MF-0077,edu_toolkit/scripts/package_release.py,root,python,required,medium,sha256:529b0c2ba32084d2,Package helper,include_in_zip,public
MF-0078,edu_toolkit/scripts/verify_release.py,root,python,required,medium,sha256:d45f281abb557081,Verification helper,include_in_zip,public
MF-0079,edu_toolkit/scripts/README.md,root,markdown,optional,small,sha256:a5279795d6118f68,Script readme,include_if_present,public
