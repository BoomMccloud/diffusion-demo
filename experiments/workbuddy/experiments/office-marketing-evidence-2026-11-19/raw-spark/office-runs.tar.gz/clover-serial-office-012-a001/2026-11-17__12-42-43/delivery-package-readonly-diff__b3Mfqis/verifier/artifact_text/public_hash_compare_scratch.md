# hash check scratch notes - public package handoff
# Current candidate run: pkg-hash-check 2026-09-18T14:02Z
# This file is intentionally partial; corroborate with manifest and candidate listing before classifying.

[current-run] checker=hash-prefix-scan source=candidate_archive_listing.csv
WARN metadata review MF-0003 edu_toolkit/docs/guides/student_lab_setup.md expected=sha256:611bffc884b9a95e observed=sha256:fc150e907a6357d3 note=metadata review note
WARN metadata review MF-0010 edu_toolkit/docs/guides/troubleshooting/data_import.md expected=sha256:700562d82e29dc6a observed=sha256:337d45c4cb79a819 note=metadata review note
WARN metadata review MF-0015 edu_toolkit/docs/reference/api/v1_4/schema/student_record.yaml expected=sha256:2a7d771f160e7998 observed=sha256:b5108caa6fee85a8 note=metadata review note
WARN metadata review MF-0018 edu_toolkit/docs/reference/api/v1_4/examples/paged_query.json expected=sha256:086f20b46f7d7b60 observed=sha256:c896ff33271cba58 note=path spelling plus metadata review note
WARN metadata review MF-0022 edu_toolkit/data/samples/classroom/roster_beta.csv expected=sha256:98849d521e12bb98 observed=sha256:921ca6a027501e4a note=metadata review note
WARN metadata review MF-0025 edu_toolkit/data/samples/events/2026-09-week02.jsonl expected=sha256:1bb96aa36b8cc088 observed=sha256:73df06451d0fce8b note=metadata review note
WARN metadata review MF-0030 edu_toolkit/data/samples/templates/event_import_template.csv expected=sha256:356906694b1fe1ea observed=sha256:1917142012139ad4 note=metadata review note
WARN metadata review MF-0035 edu_toolkit/config/templates/privacy_flags.yaml expected=sha256:00efba959ba49160 observed=sha256:374ac707cc0d2fc3 note=metadata review note
WARN metadata review MF-0046 edu_toolkit/src/validation/check_hashes.py expected=sha256:420673ec947ef0a8 observed=sha256:6807ccde8501ad92 note=metadata review note
WARN metadata review MF-0050 edu_toolkit/src/validation/rules/report_rules.py expected=sha256:80ac53be89318a45 observed=sha256:b085edef99cec710 note=metadata review note

[current-run] absent probes with inconclusive wording until listing/manifest are reconciled
CHECK absent? MF-0007 edu_toolkit/docs/guides/localization/en_GB/overview.md no exact path observed in quick archive probe
CHECK absent? MF-0027 edu_toolkit/data/samples/events/2026-09-week04.jsonl no exact path observed in quick archive probe
CHECK absent? MF-0037 edu_toolkit/config/templates/export_profile_minimal.yaml no exact path observed in quick archive probe
CHECK absent? MF-0049 edu_toolkit/src/validation/rules/locale_rules.py no exact path observed in quick archive probe
CHECK absent? MF-0060 edu_toolkit/tests/fixtures/hash/sample_hashes_legacy.json no exact path observed in quick archive probe

[stale-run 2026-09-17] DO NOT TRUST WITHOUT CURRENT LISTING
stale WARN edu_toolkit/docs/reference/api/v1_3/endpoints.md hash drift from older release line
stale OK edu_toolkit/data/samples/events/2026-08-week04.jsonl old release only
状态: 旧记录, 仅作噪声线索; do not copy this as final classification.
