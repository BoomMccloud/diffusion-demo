# Reference manifest package notes

This release manifest describes the expected package contents for the Edu Toolkit learning-data release candidate.
It is not a solved diff table: there is no diff_status, no bucket assignment, and no final reconciliation counts.

## Component count hints from the release coordinator

- root: 10 expected manifest rows
- docs_guides: 11 expected manifest rows
- docs_reference: 9 expected manifest rows
- data_samples: 12 expected manifest rows
- config_templates: 10 expected manifest rows
- src_validation: 10 expected manifest rows
- tests_fixtures: 10 expected manifest rows
- release_checksums: 7 expected manifest rows

## Packaging rules

- `include_in_zip`: expected to be present in the candidate archive unless visible evidence shows the manifest row is stale.
- `include_if_present`: optional in product terms, but still reconcile it if the manifest lists it for this handoff.
- Do not infer candidate status from this note alone; compare against the candidate listing and hash notes.
- Locale folders are case- and punctuation-sensitive for path matching unless the manifest and listing provide direct corroboration.
- Media-like sample files, if mentioned in sample metadata, are file entries and checksum objects only; do not use OCR, image, audio, or video understanding.

## Provenance

All paths, IDs, checksums, timestamps, and release notes are sample values for this handoff package.
