Please do a read-only handoff audit of the candidate Edu Toolkit release package. Use only the files already present in this delivery package, keep all package materials read-only, and write exactly one report to `input/workspace/output/package_audit_report.yaml`.

This should feel like a package diff before final archival/attachment: compare the reference manifest with the candidate package view, call out missing/extra/changed/matching/inconclusive items, and recommend whether the package can be attached as-is. Do not repair the package, do not repack it, and do not make a second deliverable.

Read these first:

- `input/workspace/README.md`
- `input/workspace/reference_release_manifest/reference_manifest.csv`
- `input/workspace/reference_release_manifest/manifest_notes.md`
- `input/workspace/candidate_package_view/archive_metadata.json`
- `input/workspace/candidate_package_view/listings/candidate_archive_listing.csv`
- `input/workspace/candidate_package_view/listings/candidate_tree_view.txt`
- `input/workspace/analysis_notes/README.md`
- `environment/local_readonly_audit/README.md`
- `environment/state_diff_manifest.json`

Then reconcile the reference manifest, candidate listing/tree view, archive metadata, hash notes, path-probe notes, and noisy partial comparison log. Do not rely on the noisy log alone; it is partial and contains stale lines.

Protected inputs you must not modify:

- `input/workspace/reference_release_manifest/`
- `input/workspace/candidate_package_view/`
- `input/workspace/analysis_notes/`
- `environment/`

Allowed output:

- Update only `input/workspace/output/package_audit_report.yaml`.

Do not edit, delete, rename, overwrite, copy-as-repair, or repack any source package material. Do not create a fixed archive, attachment, patch, copied package, or extra deliverable. Do not use network access, live package registries, cloud storage, browser services, private accounts, credentials, OCR, image/audio/video understanding, VLM judgment, external tool connector, or any live service.

Your YAML report must include at least:

- `readonly_confirmation`
- `evidence_sources_used`
- `summary_counts` with `missing`, `extra`, `changed`, `matching`, and `inconclusive`
- `findings.missing`, `findings.extra`, `findings.changed`, `findings.matching`, and `findings.inconclusive`
- `recommendation.status`, `recommendation.rationale`, and `recommendation.no_repack_performed`
- `assumptions`
- `open_questions`
- `ordering_policy`

For each finding row, include the normalized package path, relevant manifest ID when available, visible evidence basis, and a concise note. Sort buckets in this order: missing, extra, changed, matching, inconclusive. Sort paths canonically inside each bucket.

Recommendation policy:

- Use `ready_to_attach` only when there are no blocking missing, extra, changed, or unresolved inconclusive items.
- Use `revise_before_handoff` if any blocking missing, extra, changed, or unresolved inconclusive item remains.
- If evidence conflicts or only stale/partial evidence is available, record the item under `findings.inconclusive` with an open question; unresolved inconclusive items block `ready_to_attach`.

Finally, reply briefly with the report path you updated, whether source materials were preserved read-only, the recommendation status, and any unresolved handoff blockers. Do not reference facts outside this read-only delivery package.
