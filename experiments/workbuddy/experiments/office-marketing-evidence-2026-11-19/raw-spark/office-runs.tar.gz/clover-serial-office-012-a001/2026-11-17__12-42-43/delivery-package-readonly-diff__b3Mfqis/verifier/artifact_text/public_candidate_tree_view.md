# candidate package tree/archive listing
# Public listing extracted from edu-toolkit-1.4.0-candidate.zip metadata view.
# This is a listing surface only; it is not a solved reference-vs-candidate diff.

dir  edu_toolkit/
file edu_toolkit/CHANGELOG.md     5721 bytes  sha256:03d181707bb50075  2026-09-18 11:31:00Z
file edu_toolkit/LICENSE.txt     2147 bytes  sha256:ddaf384463090ff4  2026-09-18 15:43:00Z
file edu_toolkit/NOTICE.txt     1760 bytes  sha256:9af6d45e8c13bac9  2026-09-18 16:07:00Z
file edu_toolkit/README.md     5977 bytes  sha256:6ecfed6369ccda52  2026-09-17 14:42:00Z
dir  edu_toolkit/config/
dir  edu_toolkit/config/template/
dir  edu_toolkit/config/template/local_run/
file edu_toolkit/config/template/local_run/paths.yaml     2164 bytes  sha256:984deffe1272763a  2026-09-18 09:53:00Z
dir  edu_toolkit/config/templates/
dir  edu_toolkit/config/templates/archive/
file edu_toolkit/config/templates/archive/include-patterns.txt     1031 bytes  sha256:26ec38e136a48743  2026-09-16 09:29:00Z
file edu_toolkit/config/templates/archive/include_patterns.txt     1492 bytes  sha256:88a2c4f13fdee46c  2026-09-17 10:21:00Z
file edu_toolkit/config/templates/archive/package_notes.txt     2088 bytes  sha256:7a306e51ec30cb7a  2026-09-16 10:50:00Z
file edu_toolkit/config/templates/course_defaults.yaml     2254 bytes  sha256:05ad12fc1bf2cd88  2026-09-18 12:58:00Z
file edu_toolkit/config/templates/export_profile_public.yaml     1567 bytes  sha256:87ca7d4634b3baaa  2026-09-17 16:19:00Z
file edu_toolkit/config/templates/grading_scale.yaml     2148 bytes  sha256:8dad203677d27e9c  2026-09-16 11:44:00Z
dir  edu_toolkit/config/templates/local_run/
file edu_toolkit/config/templates/local_run/checks.yaml     2110 bytes  sha256:40cc9357c15e7704  2026-09-17 14:42:00Z
file edu_toolkit/config/templates/local_run/logging.yaml     1901 bytes  sha256:b60505461174547a  2026-09-16 13:50:00Z
file edu_toolkit/config/templates/privacy_flags.yaml     1859 bytes  sha256:374ac707cc0d2fc3  2026-09-17 11:17:00Z
dir  edu_toolkit/data/
dir  edu_toolkit/data/samples/
file edu_toolkit/data/samples/README.md     2194 bytes  sha256:69a7858079ae18ba  2026-09-16 12:54:00Z
dir  edu_toolkit/data/samples/classroom/
file edu_toolkit/data/samples/classroom/roster_alpha.csv     5637 bytes  sha256:95ca9389b8f67249  2026-09-17 09:22:00Z
file edu_toolkit/data/samples/classroom/roster_beta.csv     5964 bytes  sha256:921ca6a027501e4a  2026-09-18 11:38:00Z
file edu_toolkit/data/samples/classroom/roster_beta_old.csv     5920 bytes  sha256:cb399e047103aa22  2026-09-17 15:30:00Z
file edu_toolkit/data/samples/classroom/roster_gamma.csv     5241 bytes  sha256:0fca27af953129ce  2026-09-16 16:29:00Z
dir  edu_toolkit/data/samples/events/
file edu_toolkit/data/samples/events/2026-09-week01.jsonl    19992 bytes  sha256:a04cc94675a7f03d  2026-09-18 16:18:00Z
file edu_toolkit/data/samples/events/2026-09-week02.jsonl    21464 bytes  sha256:73df06451d0fce8b  2026-09-17 14:49:00Z
file edu_toolkit/data/samples/events/2026-09-week02.tmp.jsonl    14802 bytes  sha256:80e35df7421409c7  2026-09-18 09:15:00Z
file edu_toolkit/data/samples/events/2026-09-week03.jsonl    23776 bytes  sha256:b48bbe52dff6cb45  2026-09-18 09:21:00Z
file edu_toolkit/data/samples/media_manifest.csv     1786 bytes  sha256:c063e32677b3df3f  2026-09-16 15:32:00Z
dir  edu_toolkit/data/samples/templates/
file edu_toolkit/data/samples/templates/assessment_import_template.csv     2021 bytes  sha256:efbf7d15a712c4eb  2026-09-17 16:54:00Z
file edu_toolkit/data/samples/templates/event_import_template.csv     1420 bytes  sha256:1917142012139ad4  2026-09-16 10:40:00Z
file edu_toolkit/data/samples/templates/student_import_template.csv     1576 bytes  sha256:cebd6874bb981e94  2026-09-18 12:33:00Z
dir  edu_toolkit/docs/
dir  edu_toolkit/docs/guides/
file edu_toolkit/docs/guides/accessibility_notes.md     1686 bytes  sha256:c965b5c0431d39ad  2026-09-18 11:08:00Z
file edu_toolkit/docs/guides/changelog_highlights.md     1720 bytes  sha256:5fcdc19204d0c21d  2026-09-18 11:45:00Z
file edu_toolkit/docs/guides/getting_started.md     1460 bytes  sha256:0089d69316ecea7a  2026-09-17 13:06:00Z
dir  edu_toolkit/docs/guides/localization/
dir  edu_toolkit/docs/guides/localization/en-GB/
file edu_toolkit/docs/guides/localization/en-GB/overview.md     1824 bytes  sha256:eb6d72bc17d48ee3  2026-09-16 09:02:00Z
dir  edu_toolkit/docs/guides/localization/en_US/
file edu_toolkit/docs/guides/localization/en_US/overview.md     1782 bytes  sha256:4cedb066ab77181d  2026-09-16 10:02:00Z
dir  edu_toolkit/docs/guides/localization/es_ES/
file edu_toolkit/docs/guides/localization/es_ES/overview.md     2188 bytes  sha256:0e10704776ba55ad  2026-09-18 12:05:00Z
file edu_toolkit/docs/guides/offline_mode.md     1724 bytes  sha256:294b0e8b2b6c88ae  2026-09-16 13:18:00Z
file edu_toolkit/docs/guides/student_lab_setup.md     5807 bytes  sha256:fc150e907a6357d3  2026-09-17 13:28:00Z
file edu_toolkit/docs/guides/teacher_quickstart.md     2263 bytes  sha256:52d8f7f0b5cdc2bb  2026-09-16 14:04:00Z
dir  edu_toolkit/docs/guides/troubleshooting/
file edu_toolkit/docs/guides/troubleshooting/data_import.md     6177 bytes  sha256:337d45c4cb79a819  2026-09-16 12:29:00Z
file edu_toolkit/docs/guides/troubleshooting/install_errors.md     5587 bytes  sha256:2cce75153a0d7e78  2026-09-16 09:42:00Z
dir  edu_toolkit/docs/reference/
dir  edu_toolkit/docs/reference/api/
dir  edu_toolkit/docs/reference/api/v1_4/
file edu_toolkit/docs/reference/api/v1_4/auth_notes.md     2224 bytes  sha256:fe310e33b81df742  2026-09-18 11:54:00Z
file edu_toolkit/docs/reference/api/v1_4/endpoints.md     5477 bytes  sha256:7f75b43a4965916c  2026-09-16 13:58:00Z
file edu_toolkit/docs/reference/api/v1_4/errors.md     1969 bytes  sha256:db275191825f94eb  2026-09-17 15:54:00Z
dir  edu_toolkit/docs/reference/api/v1_4/examples/
file edu_toolkit/docs/reference/api/v1_4/examples/error_payload.json     2203 bytes  sha256:dad5ba13c4552a57  2026-09-17 13:07:00Z
file edu_toolkit/docs/reference/api/v1_4/examples/paged-query.json     2244 bytes  sha256:c896ff33271cba58  2026-09-17 11:58:00Z
dir  edu_toolkit/docs/reference/api/v1_4/schema/
file edu_toolkit/docs/reference/api/v1_4/schema/assessment_result.yaml     5538 bytes  sha256:101e57f7609ca69f  2026-09-17 09:06:00Z
file edu_toolkit/docs/reference/api/v1_4/schema/classroom_event.yaml     5359 bytes  sha256:8acd3a4fabac711e  2026-09-16 09:17:00Z
file edu_toolkit/docs/reference/api/v1_4/schema/student_record.yaml     5824 bytes  sha256:b5108caa6fee85a8  2026-09-16 11:18:00Z
dir  edu_toolkit/docs/reference/cli/
file edu_toolkit/docs/reference/cli/command_index.md     1526 bytes  sha256:333d3898009826c8  2026-09-16 15:49:00Z
dir  edu_toolkit/docs/references/
dir  edu_toolkit/docs/references/api/
dir  edu_toolkit/docs/references/api/v1_4/
file edu_toolkit/docs/references/api/v1_4/endpoints_draft.md     2416 bytes  sha256:de61a109f9e3b936  2026-09-16 16:08:00Z
file edu_toolkit/pyproject.toml     1488 bytes  sha256:00b9ee1239743767  2026-09-17 12:46:00Z
dir  edu_toolkit/release/
dir  edu_toolkit/release/checksums/
file edu_toolkit/release/checksums/README.md     2183 bytes  sha256:9e123dd75782c9bd  2026-09-16 13:28:00Z
file edu_toolkit/release/checksums/SHA256SUMS.old.txt     3950 bytes  sha256:b45880bb0365f33a  2026-09-17 16:56:00Z
file edu_toolkit/release/checksums/SHA256SUMS.txt     5230 bytes  sha256:e17d293f9ca8d4f8  2026-09-16 13:05:00Z
file edu_toolkit/release/checksums/archive_manifest.json     1522 bytes  sha256:330ca22083597d37  2026-09-18 16:18:00Z
file edu_toolkit/release/checksums/draft_compare_notes.txt     2059 bytes  sha256:63664185b8f7ab4e  2026-09-17 14:55:00Z
file edu_toolkit/release/checksums/generated_at.txt     1712 bytes  sha256:303b224725226e3d  2026-09-17 15:41:00Z
file edu_toolkit/release/checksums/local-compare-work.tmp      894 bytes  sha256:6b8b74ff58c9e301  2026-09-17 11:53:00Z
file edu_toolkit/release/checksums/package_size_index.csv     2532 bytes  sha256:5c6f9c570da94b8d  2026-09-18 15:30:00Z
file edu_toolkit/requirements.txt     1499 bytes  sha256:4e81e5cc507bfb84  2026-09-16 10:12:00Z
dir  edu_toolkit/scripts/
file edu_toolkit/scripts/package_release.py     5907 bytes  sha256:529b0c2ba32084d2  2026-09-17 12:17:00Z
file edu_toolkit/scripts/package_release_local_notes.md     1850 bytes  sha256:3162853269ec1642  2026-09-17 11:22:00Z
file edu_toolkit/scripts/verify_release.py     5473 bytes  sha256:23aae70ca6677902  2026-09-18 13:28:00Z
dir  edu_toolkit/src/
dir  edu_toolkit/src/validation/
file edu_toolkit/src/validation/__init__.py     1953 bytes  sha256:275ddd74fb170959  2026-09-18 13:44:00Z
dir  edu_toolkit/src/validation/__pycache__/
file edu_toolkit/src/validation/__pycache__/check_paths.cpython-311.pyc     5421 bytes  sha256:d10488f1f419f51b  2026-09-17 14:08:00Z
file edu_toolkit/src/validation/check_hashes.py     6040 bytes  sha256:6807ccde8501ad92  2026-09-16 09:05:00Z
file edu_toolkit/src/validation/check_manifest.py     5579 bytes  sha256:21034b3c72424cf6  2026-09-18 09:34:00Z
file edu_toolkit/src/validation/check_paths.py     5408 bytes  sha256:8fba564f4c4b6bfc  2026-09-18 09:45:00Z
dir  edu_toolkit/src/validation/fixtures/
file edu_toolkit/src/validation/fixtures/path_case_mixed_locale.json     1884 bytes  sha256:e220e8fd7ed1ed66  2026-09-17 15:36:00Z
file edu_toolkit/src/validation/fixtures/valid_manifest_case.json     2189 bytes  sha256:e88244c1be3dce23  2026-09-17 11:16:00Z
dir  edu_toolkit/src/validation/rules/
file edu_toolkit/src/validation/rules/path_rules.py     5270 bytes  sha256:642b7f3926350a12  2026-09-16 16:20:00Z
file edu_toolkit/src/validation/rules/report_rules.old.py     3902 bytes  sha256:cc2657fa39486569  2026-09-16 13:55:00Z
file edu_toolkit/src/validation/rules/report_rules.py     5437 bytes  sha256:b085edef99cec710  2026-09-16 10:39:00Z
file edu_toolkit/src/validation/rules/schema_rules.py     5460 bytes  sha256:31a7bca9b543cddf  2026-09-17 09:45:00Z
dir  edu_toolkit/tests/
dir  edu_toolkit/tests/fixtures/
file edu_toolkit/tests/fixtures/README.md     1922 bytes  sha256:a5ff94eb02dd88ff  2026-09-18 15:38:00Z
dir  edu_toolkit/tests/fixtures/archive/
file edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot.txt     2074 bytes  sha256:cfc98729a974f14d  2026-09-17 14:53:00Z
file edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot_draft.txt     2796 bytes  sha256:143810e2cf6dbfd2  2026-09-16 13:12:00Z
file edu_toolkit/tests/fixtures/archive/expected_tree_snapshot.txt     2198 bytes  sha256:9a72ec8505edeb7a  2026-09-17 10:26:00Z
dir  edu_toolkit/tests/fixtures/hash/
file edu_toolkit/tests/fixtures/hash/sample_hashes.json     2033 bytes  sha256:131635e7fccc2af7  2026-09-16 10:28:00Z
dir  edu_toolkit/tests/fixtures/manifest/
file edu_toolkit/tests/fixtures/manifest/full_manifest.json     5892 bytes  sha256:c8de3b5ae5eef1a3  2026-09-18 10:20:00Z
file edu_toolkit/tests/fixtures/manifest/minimal_manifest.json     1497 bytes  sha256:39bc5112cc342beb  2026-09-16 09:56:00Z
dir  edu_toolkit/tests/fixtures/reports/
file edu_toolkit/tests/fixtures/reports/report_success.md     2172 bytes  sha256:6234da8221ca76c9  2026-09-18 09:02:00Z
file edu_toolkit/tests/fixtures/reports/report_with_warnings.md     1546 bytes  sha256:9beaec247ea686c8  2026-09-16 13:33:00Z
dir  edu_toolkit/tmp/
file edu_toolkit/tmp/export_trace_20260918.log     2119 bytes  sha256:edea1cc3c2fc71ab  2026-09-16 16:53:00Z
