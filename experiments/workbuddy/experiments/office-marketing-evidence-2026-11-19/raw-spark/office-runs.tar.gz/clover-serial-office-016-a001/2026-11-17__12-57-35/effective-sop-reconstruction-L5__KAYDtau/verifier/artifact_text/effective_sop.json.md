{
  "metadata": {
    "case_id": "case_effective_sop_reconstruction_034",
    "as_of_date": "2026-07-15",
    "target_region": "华东二仓",
    "source_root": "input",
    "source_files_count": 10,
    "output_path": "output/effective_sop.json",
    "authority_order": ["regulator_notice", "signed_addendum", "base_sop", "faq_clarification"],
    "excluded_statuses": ["archive", "draft"],
    "current_sop_code": "QS-SOP-034",
    "source_docs_used": [
      "formal/base_sop_QS-SOP-034_v2.md",
      "addendum/signed_addendum_EAST-2026-04.md",
      "notice/regulator_notice_NQI-2026-19.md",
      "faq/FAQ_QS-SOP-034_2026-06.md",
      "appendix/appendix_A_roles.csv",
      "appendix/appendix_B_sampling_temperature_limits.csv",
      "appendix/appendix_C_deviation_matrix.csv",
      "appendix/appendix_D_cold_chain_handoff.csv"
    ]
  },
  "effective_sections": [
    {
      "section_id": "S1",
      "title": "入库预约与批次接收",
      "steps": [
        {
          "step_id": "BASE-S1.1",
          "text": "供应商到货前至少 1 个工作日完成预约登记，记录采购单号、批号、预计到仓时段和温控要求。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "BASE-S1.2",
          "text": "收货员核对外箱批号、封签号、温度记录仪编号和运输交接单，异常项必须登记到批次接收记录。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "BASE-S1.3",
          "text": "未预约或批号不一致的货品先进入待判定区，不得直接并入可用库存。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        }
      ],
      "warnings": [
        {
          "warning_id": "WARN-S1-A",
          "text": "超过预约窗口 4 小时的到货批次需质控主管复核后才能继续接收。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md"
        }
      ],
      "tables": ["APP-A"],
      "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
      "authority_level": "base_sop",
      "applicable_region": "华东二仓",
      "replaced_steps": []
    },
    {
      "section_id": "S2",
      "title": "抽样判定与留样",
      "steps": [
        {
          "step_id": "BASE-S2.1",
          "text": "常规批次按 APP-B 的品类与箱数分层抽样，抽样记录必须关联采购单号和供应商批号。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "ADD-EAST-S2.2",
          "text": "华东二仓低温件抽样必须由仓储操作员与 QA 取样员双人见证，双签不得事后补录。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
          "authority_level": "signed_addendum"
        }
      ],
      "warnings": [],
      "tables": ["APP-A", "APP-B"],
      "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
      "authority_level": "signed_addendum",
      "applicable_region": "华东二仓",
      "replaced_steps": ["BASE-S2.2"]
    },
    {
      "section_id": "S3",
      "title": "温控偏差与隔离判定",
      "steps": [
        {
          "step_id": "BASE-S3.1",
          "text": "冷链批次到仓后读取温度记录仪，并把曲线截图绑定到批次记录。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "NOTICE-S3.1",
          "text": "截至 2026-07-15，任一温度探头出现 ≤2°C、>8°C 或记录断点超过 20 分钟时，批次立即进入 QA 隔离判定。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        },
        {
          "step_id": "BASE-S3.3",
          "text": "隔离批次可由 QA 经理审批后恢复流转。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "NOTICE-S3.3",
          "text": "需放行的隔离批次必须同时取得 QA 负责人和法规联络人书面批准。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        }
      ],
      "warnings": [
        {
          "warning_id": "WARN-S3-A",
          "text": "不得采用 FAQ-Q4 的 45 分钟断点口径；监管通知 NQI-2026-19 已将阈值收紧为 20 分钟。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md"
        },
        {
          "warning_id": "WARN-S3-B",
          "text": "签署版区域附录中的加急放行条款在温控偏差场景下失效。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md"
        }
      ],
      "tables": ["APP-B"],
      "source_doc": "notice/regulator_notice_NQI-2026-19.md",
      "authority_level": "regulator_notice",
      "applicable_region": "华东二仓",
      "replaced_steps": ["BASE-S3.2", "ADD-EAST-S3.2"]
    },
    {
      "section_id": "S4",
      "title": "标签复核与放行记录",
      "steps": [
        {
          "step_id": "BASE-S4.1",
          "text": "放行前扫描内部标签并与供应商批号、到货批号和留样编号逐项核对。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "ADD-EAST-S4.2",
          "text": "华东二仓冷链批次必须附 APP-D 冷链交接单，交接单缺项时不得进入放行复核。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
          "authority_level": "signed_addendum"
        },
        {
          "step_id": "ADD-EAST-S4.3",
          "text": "当班主管在同一班次内完成放行清单复核，并把复核记录绑定到批次接收记录。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
          "authority_level": "signed_addendum"
        }
      ],
      "warnings": [
        {
          "warning_id": "WARN-S4-A",
          "text": "缺少 APP-D 的冷链交接字段时，不得用聊天截图或邮件截屏替代。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md"
        }
      ],
      "tables": ["APP-A", "APP-D"],
      "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
      "authority_level": "signed_addendum",
      "applicable_region": "华东二仓",
      "replaced_steps": ["BASE-S4.2"]
    },
    {
      "section_id": "S5",
      "title": "异常升级与记录保存",
      "steps": [
        {
          "step_id": "NOTICE-S5.1",
          "text": "N1/N2 偏差须在下一个工作日内录入质量系统，并绑定批次 ID、供应商批号和责任岗位。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        },
        {
          "step_id": "NOTICE-S5.2",
          "text": "N3 偏差立即暂停相关批次流转，并在 2 小时内通知 QA 负责人、仓库经理和法规联络人。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        },
        {
          "step_id": "NOTICE-S5.3",
          "text": "当前有效 SOP 夹必须同时保留签署版区域附录与监管通知；归档旧版和未签署草案仅可作历史追溯。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        },
        {
          "step_id": "BASE-S5.2",
          "text": "来料接收记录保存 180 天，重大偏差记录保存 2 年。（注：记录保存期限现按 APP-C 与监管通知执行）",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        }
      ],
      "warnings": [
        {
          "warning_id": "WARN-S5-A",
          "text": "归档旧版的 90 天记录保存期已失效；当前有效保存期按 APP-C 与监管通知执行。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md"
        }
      ],
      "tables": ["APP-C"],
      "source_doc": "notice/regulator_notice_NQI-2026-19.md",
      "authority_level": "regulator_notice",
      "applicable_region": "华东二仓",
      "replaced_steps": ["BASE-S5.1"]
    }
  ],
  "inactive_steps": [
    {
      "step_id": "ARCH-S5.1",
      "original_section": "S5",
      "inactive_reason": "归档旧版记录保存期（90 天）已失效，被监管通知 NQI-2026-19 取代",
      "replaced_by": "NOTICE-S5.1",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-S1.1",
      "original_section": "S1",
      "inactive_reason": "v1 时期简化接收核对项（仅批号 + 采购单号）已被 v2 取代",
      "replaced_by": "BASE-S1.1",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-S2.1",
      "original_section": "S2",
      "inactive_reason": "v1 时期固定 5% 抽样比例已被 v2 按 APP-B 品类分层抽样取代",
      "replaced_by": "BASE-S2.1",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-S3.1",
      "original_section": "S3",
      "inactive_reason": "v1 时期 60 分钟温控断点阈值已被监管通知收紧至 20 分钟",
      "replaced_by": "NOTICE-S3.1",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-S4.1",
      "original_section": "S4",
      "inactive_reason": "v1 时期单签放行已被区域附录双签覆盖",
      "replaced_by": "ADD-EAST-S4.2",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-S5.1",
      "original_section": "S5",
      "inactive_reason": "v1 时期 90 天记录保存期已失效，按 v2 + 监管通知执行",
      "replaced_by": "NOTICE-S5.1",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-DEV-1",
      "original_section": "S5",
      "inactive_reason": "v1 时期轻微偏差口径（仅区分严重/非严重两级）已被 N1/N2/N3 三级分级取代",
      "replaced_by": "N1-ROUTINE",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-DEV-2",
      "original_section": "S5",
      "inactive_reason": "v1 时期重大偏差口径已被 N2/N3 分级取代",
      "replaced_by": "N2-REPEAT-30D",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-TRAIN-1",
      "original_section": "S5",
      "inactive_reason": "v1 时期培训矩阵简化（仅区分 QA/非 QA 两类）已被 v2 培训矩���取代",
      "replaced_by": "BG-TRAIN-1",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-TRAIN-2",
      "original_section": "S5",
      "inactive_reason": "v1 时期未引入 training_release_matrix 自动门控",
      "replaced_by": "BG-TRAIN-2",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-APPR-1",
      "original_section": "S5",
      "inactive_reason": "v1 时期试点项目负责人审批流程已变更（起草人已离职）",
      "replaced_by": "BG-SITE-SIG-4",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-APPR-2",
      "original_section": "S5",
      "inactive_reason": "v1 时期 QA 经理复核流程已变更（复核人已离职）",
      "replaced_by": "BG-SITE-SIG-2",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "LEGACY-v1-APPR-3",
      "original_section": "S5",
      "inactive_reason": "v1 时期质量负责人审批流程已变更",
      "replaced_by": "BG-SITE-SIG-4",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "DRAFT-ADD-S4.4",
      "original_section": "S4",
      "inactive_reason": "未签署草案且与监管通知冲突，不得纳入当前有效 SOP",
      "replaced_by": null,
      "source_doc": "archive/draft_addendum_EAST-2026-06_unsigned.md"
    },
    {
      "step_id": "DRAFT-ADD-S3.4",
      "original_section": "S3",
      "inactive_reason": "未签署草案且与监管通知冲突，不得纳入当前有效 SOP",
      "replaced_by": null,
      "source_doc": "archive/draft_addendum_EAST-2026-06_unsigned.md"
    },
    {
      "step_id": "FAQ-Q4-old-example",
      "original_section": "S3",
      "inactive_reason": "FAQ 旧示例行（45 分钟断点）不得作为当前温控断点阈值，被监管通知取代",
      "replaced_by": "NOTICE-S3.1",
      "source_doc": "faq/FAQ_QS-SOP-034_2026-06.md"
    },
    {
      "step_id": "ADD-EAST-S3.2",
      "original_section": "S3",
      "inactive_reason": "加急放行条款在温控偏差场景下被监管通知 NQI-2026-19 失效",
      "replaced_by": "NOTICE-S3.1",
      "source_doc": "addendum/signed_addendum_EAST-2026-04.md"
    }
  ],
  "appendix_bindings": [
    {
      "table_id": "APP-A",
      "title": "岗位与职责矩阵",
      "bound_sections": ["S1", "S2", "S4"],
      "source_doc": "appendix/appendix_A_roles.csv",
      "authority_level": "base_sop",
      "binding_status": "effective",
      "required_rows": [
        "WH-OP",
        "QA-L",
        "QA-MGR",
        "REG-LIAISON",
        "BG-DOC-CTRL",
        "BG-PROC-OWN",
        "BG-CAPA-LEAD",
        "BG-AUDIT-LEAD"
      ],
      "binding_notes": "包含 legacy roles (LEGACY-v1-WH-ASSIST, LEGACY-v1-QA-ASSIST) 标记为 inactive_archive，仅供追溯"
    },
    {
      "table_id": "APP-B",
      "title": "抽样与温控阈值表",
      "bound_sections": ["S2", "S3"],
      "source_doc": "appendix/appendix_B_sampling_temperature_limits.csv",
      "authority_level": "mixed",
      "binding_status": "effective",
      "required_rows": [
        "B-SAMPLE-BASE",
        "B-SAMPLE-EAST",
        "B-TEMP-NOTICE",
        "BG-B-EXPIRY-CLOSE",
        "BG-B-VENDOR-NEW",
        "BG-B-VENDOR-CAPA",
        "BG-B-CTRL-1",
        "BG-B-IMPORT",
        "BG-B-RETURN",
        "BG-B-REPACK",
        "BG-B-RECALL-WATCH",
        "BG-B-VIP-EAST",
        "BG-B-FROZEN-OOS",
        "BG-B-AMBIENT-OOS",
        "BG-B-DRY-OOS"
      ],
      "binding_notes": "B-TEMP-BASE（基础 SOP 30 分钟断点）和 B-TEMP-OLD（FAQ 45 分钟示例）标记为 inactive；LEGACY rows 标记为 inactive_archive；B-TEMP-NOTICE（监管通知 20 分钟规则）为当前有效温控断点阈值"
    },
    {
      "table_id": "APP-C",
      "title": "异常等级与升级时限表",
      "bound_sections": ["S5"],
      "source_doc": "appendix/appendix_C_deviation_matrix.csv",
      "authority_level": "regulator_notice",
      "binding_status": "effective",
      "required_rows": [
        "N1-ROUTINE",
        "N2-REPEAT-30D",
        "N3-LINE-STOP",
        "BG-C-OBS",
        "BG-C-INFO",
        "BG-C-AUDIT-FROZEN",
        "BG-C-MAINT-PAUSE",
        "BG-C-CAPA-OPEN",
        "BG-C-CAPA-CLOSED",
        "BG-C-RECALL-NOTICE",
        "BG-C-RECALL-IN-PROCESS",
        "BG-C-COMPLAINT-OPEN",
        "BG-C-DOC-INCOMPLETE",
        "BG-C-DOC-COMPLETE",
        "BG-C-RECV-PENDING"
      ],
      "binding_notes": "ARCH-KEEP-90（历史 90 天保存期）标记为 inactive_archive；LEGACY rows 标记为 inactive_archive；N2-REPEAT-30D 和 N3-LINE-STOP 由监管通知明确引用作为升级判定依据"
    },
    {
      "table_id": "APP-D",
      "title": "华东冷链交接字段表",
      "bound_sections": ["S4"],
      "source_doc": "appendix/appendix_D_cold_chain_handoff.csv",
      "authority_level": "signed_addendum",
      "binding_status": "effective",
      "required_rows": [
        "D-HANDOFF-01",
        "D-HANDOFF-02",
        "D-HANDOFF-03",
        "BG-D-RECALL",
        "BG-D-VIP",
        "BG-D-EMERGENCY",
        "BG-D-INTERNAL"
      ],
      "binding_notes": "仅适用于华东二仓冷链交接字段，不能错误绑定到温控隔离判定；LEGACY rows 标记为 inactive_archive"
    }
  ],
  "summary": {
    "section_count": 5,
    "active_step_count": 16,
    "warning_count": 5,
    "section_table_reference_count": 7,
    "appendix_binding_count": 4,
    "inactive_step_count": 17,
    "notice_overridden_step_count": 5,
    "faq_clarification_count": 17,
    "archive_or_draft_excluded_count": 15,
    "source_documents_used_count": 8
  }
}
