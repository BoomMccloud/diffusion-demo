# Workbook: valuation_workbook.xlsx

## Sheet 1: valuation_detail
Dimensions: 29 rows x 16 columns
R1: 持仓ID | 组合编号 | 账户编号 | 证券代码 | 证券名称 | 资产类型 | 行业归一代码 | 行业归一名称 | 币种 | 数量 | 估值价格 | 汇率(CNY) | 价格状态 | 市值(元) | 权重(%) | 异常标记
R2: HLD-0001 | PF-晨星稳健-01 | ACC-A | CASH-CNY | 人民币现金 | 现金 | CASH | 现金 | CNY | 1 | 1 | 1 | VALID | 1850000 | 2.41 | 
R3: HLD-0002 | PF-晨星稳健-01 | ACC-A | 600118.SH | 华北机电A | 股票 | MFG_ADV | 高端制造 | CNY | 240000 | 8.42 | 1 | VALID | 2020800 | 2.64 | 
R4: HLD-0003 | PF-晨星稳健-01 | ACC-A | 000731.SZ | 南方新材 | 股票 | MAT_BASIC | 材料 | CNY | 310000 | 8.11 | 1 | VALID | 2514100 | 3.28 | 
R5: HLD-0004 | PF-晨星稳健-01 | ACC-A | 002771.SZ | 西江材料 | 股票 | MAT_BASIC | 原材料 | CNY | 210000 | 6.85 | 1 | VALID | 1438500 | 1.88 | 
R6: HLD-0005 | PF-晨星稳健-01 | ACC-A | 688519.SH | 星河芯片 | 股票 | TECH_SEMI | 半导体 | CNY | 180000 | 13.66 | 1 | VALID | 2458800 | 3.21 | 
R7: HLD-0006 | PF-晨星稳健-01 | ACC-A | 688260.SH | 海通设备 | 股票 | TECH_SEMI | 信息技术-硬件 | CNY | 95000 | 28.4 | 1 | VALID | 2698000 | 3.52 | 
R8: HLD-0007 | PF-晨星稳健-01 | ACC-A | 513880.SH | 亚太科技ETF | 基金 | TECH_SOFT | 信息技术 | CNY | 900000 | 11.09 | 1 | VALID | 9981000 | 13.02 | 
R9: HLD-0008 | PF-晨星稳健-01 | ACC-B | 110091.IB | 26华东高债01 | 债券 | CREDIT_BOND | 信用债 | CNY | 25000 | 101.36 | 1 | VALID | 2534000 | 3.31 | 
R10: HLD-0009 | PF-晨星稳健-01 | ACC-B | 123456.IB | 24城投债02 | 债券 | CITY_BOND | 城投债 | CNY | 18000 | 102.1 | 1 | VALID | 1837800 | 2.4 | 
R11: HLD-0010 | PF-晨星稳健-01 | ACC-B | HK0988 | 海岬能源H | 股票 | ENERGY | 能源 | HKD | 160000 | 8.91 | 0.92 | VALID | 1311552 | 1.71 | 
R12: HLD-0011 | PF-晨星稳健-01 | ACC-B | 00883.HK | 东海能源 | 股票 | ENERGY | 油气 | HKD | 95000 | 6.72 | 0.92 | VALID | 587328 | 0.77 | 
R13: HLD-0012 | PF-晨星稳健-01 | ACC-B | USQ123 | Orion Cloud Inc. | 股票 | TECH_SOFT | 软件服务 | USD | 22000 | 17.8 | 7.25 | VALID | 2839100 | 3.7 | 
R14: HLD-0013 | PF-晨星稳健-01 | ACC-B | USM456 | Northstar Software | 股票 | TECH_SOFT | 云服务 | USD | 18000 | 24.3 | 7.25 | VALID | 3171150 | 4.14 | 
R15: HLD-0015 | PF-晨星稳健-01 | ACC-C | 600276.SH | 瑞康医药 | 股票 | HEALTH | 医药生物 | CNY | 120000 | 42.5 | 1 | VALID | 5100000 | 6.65 | 
R16: HLD-0016 | PF-晨星稳健-01 | ACC-C | 159926.SZ | 消费ETF | 基金 | CONSUMER | 可选消费 | CNY | 760000 | 1.27 | 1 | VALID | 965200 | 1.26 | 
R17: HLD-0017 | PF-晨星稳健-01 | ACC-C | 601377.SH | 长江证券A | 股票 | FIN_NB | 非银金融 | CNY | 500000 | 6.1 | 1 | VALID | 3050000 | 3.98 | 
R18: HLD-0018 | PF-晨星稳健-01 | ACC-C | 600958.SH | 华东券商 | 股票 | FIN_NB | 证券 | CNY | 260000 | 7.8 | 1 | VALID | 2028000 | 2.65 | 
R19: HLD-0019 | PF-晨星稳健-01 | ACC-C | 000858.SZ | 川府消费 | 股票 | CONSUMER | 消费 | CNY | 65000 | 128.4 | 1 | VALID | 8346000 | 10.89 | 
R20: HLD-0020 | PF-晨星稳健-01 | ACC-C | 603288.SH | 南岭食品 | 股票 | CONSUMER | 消费服务 | CNY | 52000 | 117.2 | 1 | VALID | 6094400 | 7.95 | 
R21: HLD-0021 | PF-晨星稳健-01 | ACC-D | 511880.SH | 银华货币ETF | 基金 | CASH_MGMT | 现金管理 | CNY | 1100000 | 1.001 | 1 | VALID | 1101100 | 1.44 | 
R22: HLD-0023 | PF-晨星稳健-01 | ACC-D | 019876.IB | 26国开债07 | 债券 | RATE_BOND | 利率债 | CNY | 12000 | 100.82 | 1 | VALID | 1209840 | 1.58 | 
R23: HLD-0025 | PF-晨星稳健-01 | ACC-D | 301001.SZ | 云创软件 | 股票 | TECH_SOFT | 信息技术-软件 | CNY | 145000 | 19.6 | 1 | VALID | 2842000 | 3.71 | 
R24: HLD-0026 | PF-晨星稳健-01 | ACC-D | 688888.SH | 启明硬件 | 股票 | TECH_SEMI | 芯片 | CNY | 88000 | 31.2 | 1 | VALID | 2745600 | 3.58 | 
R25: HLD-0027 | PF-晨星稳健-01 | ACC-D | 000001.SZ | 平安银行A | 股票 | FIN_BANK | 银行 | CNY | 280000 | 10.45 | 1 | VALID | 2926000 | 3.82 | 
R26: HLD-0028 | PF-晨星稳健-01 | ACC-D | 830001.BJ | 北交制造 | 股票 | MFG_ADV | 装备制造 | CNY | 160000 | 14.3 | 1 | VALID | 2288000 | 2.98 | 
R27: HLD-0029 | PF-晨星稳健-01 | ACC-D | 600118.SH | 华北机电A | 股票 | MFG_ADV | 高端制造 | CNY | 180000 | 8.42 | 1 | VALID | 1515600 | 1.98 | 
R28: HLD-0030 | PF-晨星稳健-01 | ACC-D | CASH-USD | 美元现金 | 现金 | CASH | 现金 | USD | 1 | 1 | 7.25 | VALID | 870000 | 1.13 | 
R29: HLD-0031 | PF-晨星稳健-01 | ACC-D | CASH-HKD | 港币现金 | 现金 | CASH | 现金 | HKD | 1 | 1 | 0.92 | VALID | 331200 | 0.43 | 

## Sheet 2: limit_breaches
Dimensions: 11 rows x 9 columns
R1: 范围类型 | 范围ID | 规则ID | 违规代码 | 实际值(%) | 阈值(%) | 分母 | 边界说明 | 源行
R2: single_security | 000858.SZ | R-SN-01 | SINGLE_NAME_OVER | 10.89 | 10 | 基金资产净值 | > 10.00% | HLD-0019
R3: single_security | 513880.SH | R-SN-01 | SINGLE_NAME_OVER | 13.02 | 10 | 基金资产净值 | > 10.00% | HLD-0007
R4: sector | CONSUMER | R-SECTOR-01 | SECTOR_OVER | 18.84 | 18 | 基金资产净值 | >= 18.00% | N/A
R5: asset_class | EQUITY | R-ASSET-01 | EQUITY_BAND_HIGH | 73.02 | 62 | 基金资产净值 | > 62.00% | N/A
R6: asset_class | BOND | R-ASSET-02 | BOND_BAND_LOW | 7.28 | 12 | 基金资产净值 | < 12.00% | N/A
R7: asset_class | FUND | R-FUND-01 | FUND_WEIGHT_OVER | 16.37 | 16 | 非现金基金资产 | > 16.00% | N/A
R8: security | 300882.SZ | R-PRICE-01 | PRICE_MISSING | N/A | N/A | 不适用 | 价格状态为 MISSING | HLD-0014
R9: security | 501018.SH | R-PRICE-01 | PRICE_MISSING | N/A | N/A | 不适用 | 价格状态为 MISSING | HLD-0022
R10: security | 113009.SH | R-PRICE-01 | PRICE_MISSING | N/A | N/A | 不适用 | 价格状态为 MISSING | HLD-0024
R11: ALL_BREACHES | ALL | R-MULTI-01 | MULTI_BREACH_RETAIN | N/A | N/A | 不适用 | 同一对象命中多条规则时必须全部保留 | N/A

## Sheet 3: deviation_review_flags
Dimensions: 25 rows x 7 columns
R1: 证券代码 | 证券名称 | 实际权重(%) | 基准权重(%) | 偏离值(%) | 复核标记 | 源行
R2: 513880.SH | 亚太科技ETF | 13.02 | 6.03 | 6.99 | REVIEW_POSITIVE_DEVIATION | HLD-0007
R3: 600118.SH | 华北机电A | 4.61 | 0.62 | 4 | NO_REVIEW_FLAG | HLD-0002,HLD-0029
R4: 600276.SH | 瑞康医药 | 6.65 | 2.66 | 4 | NO_REVIEW_FLAG | HLD-0015
R5: 603288.SH | 南岭食品 | 7.95 | 3.96 | 4 | NO_REVIEW_FLAG | HLD-0020
R6: 000858.SZ | 川府消费 | 10.89 | 6.89 | 3.99 | NO_REVIEW_FLAG | HLD-0019
R7: USM456 | Northstar Software | 4.14 | 2.1 | 2.04 | NO_REVIEW_FLAG | HLD-0013
R8: 688888.SH | 启明硬件 | 3.58 | 2 | 1.58 | NO_REVIEW_FLAG | HLD-0026
R9: 830001.BJ | 北交制造 | 2.98 | 1.6 | 1.38 | NO_REVIEW_FLAG | HLD-0028
R10: 688260.SH | 海通设备 | 3.52 | 2.4 | 1.12 | NO_REVIEW_FLAG | HLD-0006
R11: 301001.SZ | 云创软件 | 3.71 | 2.9 | 0.81 | NO_REVIEW_FLAG | HLD-0025
R12: 000001.SZ | 平安银行A | 3.82 | 3.4 | 0.42 | NO_REVIEW_FLAG | HLD-0027
R13: 600958.SH | 华东券商 | 2.65 | 2.7 | -0.05 | NO_REVIEW_FLAG | HLD-0018
R14: 688519.SH | 星河芯片 | 3.21 | 3.5 | -0.29 | NO_REVIEW_FLAG | HLD-0005
R15: 511880.SH | 银华货币ETF | 1.44 | 2 | -0.56 | NO_REVIEW_FLAG | HLD-0021
R16: 000731.SZ | 南方新材 | 3.28 | 4 | -0.72 | NO_REVIEW_FLAG | HLD-0003
R17: 002771.SZ | 西江材料 | 1.88 | 2.6 | -0.72 | NO_REVIEW_FLAG | HLD-0004
R18: USQ123 | Orion Cloud Inc. | 3.7 | 4.6 | -0.9 | NO_REVIEW_FLAG | HLD-0012
R19: 601377.SH | 长江证券A | 3.98 | 5 | -1.02 | NO_REVIEW_FLAG | HLD-0017
R20: HK0988 | 海岬能源H | 1.71 | 2.8 | -1.09 | NO_REVIEW_FLAG | HLD-0010
R21: 00883.HK | 东海能源 | 0.77 | 1.9 | -1.13 | NO_REVIEW_FLAG | HLD-0011
R22: 159926.SZ | 消费ETF | 1.26 | 3 | -1.74 | NO_REVIEW_FLAG | HLD-0016
R23: 019876.IB | 26国开债07 | 1.58 | 6.5 | -4.92 | NO_REVIEW_FLAG | HLD-0023
R24: 123456.IB | 24城投债02 | 2.4 | 9 | -6.6 | NO_REVIEW_FLAG | HLD-0009
R25: 110091.IB | 26华东高债01 | 3.31 | 18 | -14.69 | NO_REVIEW_FLAG | HLD-0008

## Sheet 4: portfolio_summary
Dimensions: 7 rows x 6 columns
R1: 汇总类型 | 汇总键 | 金额(元) | 权重(%) | 数量 | 备注
R2: total | 基金资产净值 | 76655070 | 100 | 28 | 所有有效估值持仓市值折人民币求和；现金行按汇率折人民币计入
R3: subtotal | 非现金基金资产 | 73603870 | 96.02 | 25 | 基金资产净值扣除CASH的现金持仓市值
R4: asset_class | 债券投资 | 5581640 | 7.28 | 4 | 债券类持仓市值（含缺价）
R5: asset_class | 基金投资 | 12047300 | 15.72 | 4 | 基金类持仓市值（含缺价）
R6: asset_class | 现金投资 | 3051200 | 3.98 | 3 | 现金类持仓市值（含缺价）
R7: asset_class | 股票投资 | 55974930 | 73.02 | 20 | 股票类持仓市值（含缺价）
