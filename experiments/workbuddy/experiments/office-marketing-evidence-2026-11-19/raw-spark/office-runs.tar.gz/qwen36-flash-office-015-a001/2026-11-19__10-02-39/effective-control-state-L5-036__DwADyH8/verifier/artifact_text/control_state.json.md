{
  "metadata": {
    "case_id": "PROC-CC-036-EFFECTIVE-STATE-20260820",
    "as_of_date": "2026-08-20",
    "target_site": "华南冷链库",
    "target_role": "夜班QA复核员",
    "source_root": "/workspace/input",
    "output_path": "output/effective_control_state.json",
    "authority_order": [
      "regulatory_notice",
      "incident_triggered_control",
      "signed_site_appendix",
      "training_gate",
      "base_sop",
      "faq"
    ],
    "excluded_statuses": [
      "archived",
      "unsigned_draft",
      "superseded_notice",
      "future_training_for_target_role"
    ],
    "source_docs_used": [
      "controlled/base_PROC-CC-036_rev3.md",
      "notices/regulatory_notice_RC-2026-17.md",
      "notices/regulatory_notice_RC-2026-22.md",
      "notices/regulatory_notice_RC-2026-22A.md",
      "notices/regulatory_notice_RC-2026-23.md",
      "site/signed_site_appendix_SC-2026-07.md",
      "draft/unsigned_site_appendix_SC-2026-08.md",
      "training/training_release_matrix.csv",
      "incidents/incident_digest_august.csv",
      "register/document_register.csv",
      "appendix/appendix_A_role_matrix.csv",
      "appendix/appendix_B_hold_codes.csv",
      "appendix/appendix_C_record_retention.csv",
      "faq/FAQ_PROC-CC-036.md",
      "archive/base_PROC-CC-036_rev1_archived.md",
      "archive/base_PROC-CC-036_rev2_archived.md"
    ]
  },
  "control_states": [
    {
      "control_id": "C1",
      "title": "到货温控接收",
      "effective_steps": [
        {
          "step_id": "SITE-C1.2",
          "text": "华南冷链库夜班到货必须由仓储收货员和夜班QA复核员双签接收，替代 BASE-C1.2。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix",
          "applies_to": {
            "site": "华南冷链库",
            "shift": "夜班(18:00-08:00)",
            "roles": ["仓储收货员", "夜班QA复核员"]
          },
          "training_gate": null
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C1-SITE",
          "text": "双签要求只在华南冷链库夜班接收场景生效。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md"
        },
        {
          "warning_id": "WARN-C1-BASE",
          "text": "单人接收不适用于已签署双签站点。",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-A",
          "binding_reason": "ROLE-WH-RECV(仓储收货员)和ROLE-NIGHT-QA(夜班QA复核员)的权限定义",
          "required_rows": ["ROLE-WH-RECV", "ROLE-NIGHT-QA"]
        },
        {
          "appendix_id": "APP-B",
          "binding_reason": "DOC-COMPLETE/DOC-INCOMPLETE 状态码用于接收记录完整性判定",
          "required_rows": ["DOC-COMPLETE", "DOC-INCOMPLETE"]
        },
        {
          "appendix_id": "APP-C",
          "binding_reason": "H1复核记录保留365天，观察项/信息记录保留90天",
          "required_rows": ["RET-H1-365", "RET-OBS-90", "RET-INFO-90"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "BASE-C1.2",
          "reason": "被 SITE-C1.2 取代（签署站点附录优先级高于基础SOP）",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md"
        }
      ],
      "source_doc": "site/signed_site_appendix_SC-2026-07.md",
      "authority_level": "signed_site_appendix",
      "site_scope": "华南冷链库",
      "role_scope": ["仓储收货员", "夜班QA复核员"]
    },
    {
      "control_id": "C2",
      "title": "温控断点与隔离判定",
      "effective_steps": [
        {
          "step_id": "NOTICE22-C2.1",
          "text": "任一温度记录断点超过 12 分钟或探头低于 2°C/高于 8°C 时，批次立即转入 QA 隔离。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": {
            "site": "全国冷链仓",
            "roles": ["所有角色"],
            "note": "目标角色'夜班QA复核员'的 TR-036-NQ-23 培训在 2026-08-30 释放，as_of_date 前未完成，故仍按 RC-2026-22 的 12 分钟执行，不按 RC-2026-23 的 10 分钟执行"
          },
          "training_gate": {
            "training_id": "TR-036-NQ-23",
            "release_date": "2026-08-30",
            "status": "future_training",
            "completed_by_as_of_date": false,
            "effect": "目标角色未完成培训，不触发 NOTICE23-C2.1 的 10 分钟阈值"
          }
        },
        {
          "step_id": "NOTICE22A-C2.4",
          "text": "自 2026-08-01 起，同一站点同一承运商 7 天内重复温控断点立即升级为 H2，覆盖原 INC-C2.3 的 14 天口径。",
          "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
          "authority_level": "regulatory_notice",
          "applies_to": {
            "site": "华南冷链库",
            "roles": ["所有角色"],
            "retroactive_effective_date": "2026-08-01",
            "note": "追溯生效不依赖培训完成，已签署即生效；仅适用于颁发日(2026-08-19)之前未关闭的同站点同承运商断点对"
          },
          "training_gate": null
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C2-NOTICE22",
          "text": "不得沿用 20 分钟或 30 分钟断点。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md"
        },
        {
          "warning_id": "WARN-C2-RETRO22A",
          "text": "追溯生效自 2026-08-01；2026-08-01 至颁发日之间发生的事件需按本附件重新分类。",
          "source_doc": "notices/regulatory_notice_RC-2026-22A.md"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-B",
          "binding_reason": "TEMP-BREAK-12、H1、H2 等偏差等级码的定义及门禁条件",
          "required_rows": ["TEMP-BREAK-12", "H1", "H2", "H3"]
        },
        {
          "appendix_id": "APP-C",
          "binding_reason": "H2/H3 追溯包保留 540 天",
          "required_rows": ["RET-H2H3-540", "TRACE-PACK"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "BASE-C2.1",
          "reason": "被 NOTICE22-C2.1 取代（监管通知优先级高于基础SOP），原始 30 分钟阈值已失效",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md"
        },
        {
          "ref_id": "NOTICE23-C2.1",
          "reason": "目标角色培训未完成(TR-036-NQ-23 release_date=2026-08-30 > as_of_date=2026-08-20)，对目标角色 pending，仍按 NOTICE22-C2.1 的 12 分钟执行",
          "source_doc": "notices/regulatory_notice_RC-2026-23.md"
        },
        {
          "ref_id": "LEGACY-C2",
          "reason": "rev2 归档版 45 分钟阈值，已被 rev3 + RC-2026-17 + RC-2026-22 逐步取代",
          "source_doc": "archive/base_PROC-CC-036_rev2_archived.md"
        }
      ],
      "source_doc": "notices/regulatory_notice_RC-2026-22.md",
      "authority_level": "regulatory_notice",
      "site_scope": "全国冷链仓（RC-2026-22A 限定华南冷链库）",
      "role_scope": ["所有角色"]
    },
    {
      "control_id": "C3",
      "title": "复核权限与放行门禁",
      "effective_steps": [
        {
          "step_id": "NOTICE22-C3.3",
          "text": "H2/H3 放行门禁以 RC-2026-22 为准，不得采用 RC-2026-17 的单主管口径。必须等待 QA 负责人和法规联络人双批准。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": {
            "site": "全国冷链仓",
            "roles": ["所有角色"],
            "gate_condition": "H2/H3 放行需要 QA 负责人 + 法规联络人双批准"
          },
          "training_gate": null
        },
        {
          "step_id": "NOTICE22-C2.2",
          "text": "隔离批次不得由夜班单人放行，必须等待 QA 负责人和法规联络人双批准。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": {
            "site": "全国冷链仓",
            "roles": ["所有角色"],
            "gate_condition": "夜班禁止单人解除隔离"
          },
          "training_gate": null
        },
        {
          "step_id": "SITE-C3.1",
          "text": "夜班QA复核员可完成记录完整性复核，但不得单独解除 QA 隔离。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix",
          "applies_to": {
            "site": "华南冷链库",
            "shift": "夜班(18:00-08:00)",
            "roles": ["夜班QA复核员"],
            "scope": "仅允许登记记录完整性复核意见，不允许独立解除隔离"
          },
          "training_gate": null
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C3-GATE",
          "text": "H2/H3 禁止夜班单人解除隔离。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-A",
          "binding_reason": "ROLE-QA-LEAD(H2/H3 放行批准)、ROLE-NIGHT-QA(记录完整性复核)的权限定义",
          "required_rows": ["ROLE-QA-LEAD", "ROLE-NIGHT-QA"]
        },
        {
          "appendix_id": "APP-B",
          "binding_reason": "H2/H3 的门禁条件：QA负责人+法规联络双批准",
          "required_rows": ["H2", "H3"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "BASE-C3.1",
          "reason": "被 NOTICE22-C3.3 + NOTICE22-C2.2 + SITE-C3.1 取代（监管通知和签署附录优先级高于基础SOP），原始'夜班QA复核员可以登记记录完整性复核'口径被补充限制",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md"
        },
        {
          "ref_id": "NOTICE17-C3.1",
          "reason": "被 RC-2026-22 取代（单主管批准改为双批准）",
          "source_doc": "notices/regulatory_notice_RC-2026-17.md"
        }
      ],
      "source_doc": "notices/regulatory_notice_RC-2026-22.md",
      "authority_level": "regulatory_notice",
      "site_scope": "全国冷链仓（SITE-C3.1 限定华南冷链库夜班）",
      "role_scope": ["所有角色"]
    },
    {
      "control_id": "C4",
      "title": "记录保留与追溯包",
      "effective_steps": [
        {
          "step_id": "NOTICE22-C4.2",
          "text": "H2/H3 事件追溯包保留 540 天，并附法规联络确认。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": {
            "site": "全国冷链仓",
            "roles": ["所有角色"],
            "retention_days": 540,
            "requirement": "追溯包须附法规联络确认"
          },
          "training_gate": null
        },
        {
          "step_id": "SITE-C4.3",
          "text": "华南冷链库夜班交接记录需绑定班次、设备编号和 QA 复核员工号。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix",
          "applies_to": {
            "site": "华南冷链库",
            "shift": "夜班(18:00-08:00)",
            "roles": ["仓储收货员", "夜班QA复核员"],
            "binding_fields": ["班次", "设备编号", "QA复核员工号"]
          },
          "training_gate": null
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C4-RETENTION",
          "text": "追溯包保留期以 540 天为准。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-C",
          "binding_reason": "H2/H3 追溯包 540 天、温度曲线/签名/法规确认 540 天、投诉记录 540 天",
          "required_rows": ["RET-H2H3-540", "TRACE-PACK", "RET-COMPLAINT-540"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "BASE-C4.1",
          "reason": "被 NOTICE22-C4.2 补充（明确 540 天保留期和法规联络确认要求）",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md"
        },
        {
          "ref_id": "NOTICE17-C4.2",
          "reason": "被 RC-2026-22 取代（365 天改为 540 天）",
          "source_doc": "notices/regulatory_notice_RC-2026-17.md"
        },
        {
          "ref_id": "ARCH-180",
          "reason": "归档旧口径（180 天），已被 rev3 + RC-2026-22 的 540 天取代",
          "source_doc": "archive/base_PROC-CC-036_rev2_archived.md"
        }
      ],
      "source_doc": "notices/regulatory_notice_RC-2026-22.md",
      "authority_level": "regulatory_notice",
      "site_scope": "全国冷链仓（SITE-C4.3 限定华南冷链库夜班）",
      "role_scope": ["所有角色"]
    }
  ],
  "inactive_controls": [
    {
      "object_id": "NOTICE23-C2.1",
      "title": "RC-2026-23 10 分钟断点阈值",
      "inactive_reason": "训练-生效错窗：RC-2026-23 生效日期 2026-08-18 早于 as_of_date，但其要求的角色培训 TR-036-NQ-23 的 release_date=2026-08-30 晚于 as_of_date，对目标角色'夜班QA复核员' pending",
      "replaced_by": "NOTICE22-C2.1（12 分钟阈值继续对目标角色有效）",
      "source_doc": "notices/regulatory_notice_RC-2026-23.md",
      "status": "training_pending_target_role",
      "details": {
        "notice_effective_date": "2026-08-18",
        "training_release_date": "2026-08-30",
        "training_id": "TR-036-NQ-23",
        "training_completion_status": "future_training",
        "pending_for_role": "夜班QA复核员",
        "fallback_step": "NOTICE22-C2.1"
      }
    },
    {
      "object_id": "NOTICE17-C2.1",
      "title": "RC-2026-17 20 分钟断点阈值",
      "inactive_reason": "被 RC-2026-22 完全取代（superseded_notice）",
      "replaced_by": "NOTICE22-C2.1（12 分钟阈值）",
      "source_doc": "notices/regulatory_notice_RC-2026-17.md",
      "status": "superseded_notice",
      "details": {
        "superseded_by_doc": "notices/regulatory_notice_RC-2026-22.md",
        "superseded_date": "2026-08-05"
      }
    },
    {
      "object_id": "NOTICE17-C3.1",
      "title": "RC-2026-17 单主管批准 H2/H3 放行",
      "inactive_reason": "被 RC-2026-22 取代（改为 QA 负责人 + 法规联络人双批准）",
      "replaced_by": "NOTICE22-C3.3 + NOTICE22-C2.2",
      "source_doc": "notices/regulatory_notice_RC-2026-17.md",
      "status": "superseded_notice",
      "details": {
        "superseded_by_doc": "notices/regulatory_notice_RC-2026-22.md",
        "superseded_date": "2026-08-05"
      }
    },
    {
      "object_id": "NOTICE17-C4.2",
      "title": "RC-2026-17 H2/H3 追溯包保留 365 天",
      "inactive_reason": "被 RC-2026-22 取代（扩展至 540 天）",
      "replaced_by": "NOTICE22-C4.2（540 天）",
      "source_doc": "notices/regulatory_notice_RC-2026-17.md",
      "status": "superseded_notice",
      "details": {
        "superseded_by_doc": "notices/regulatory_notice_RC-2026-22.md",
        "superseded_date": "2026-08-05"
      }
    },
    {
      "object_id": "BASE-C1.2",
      "title": "基础SOP 常规到货可由仓储收货员单人接收",
      "inactive_reason": "被签署站点附录 SITE-C1.2 取代（华南冷链库夜班必须双签）",
      "replaced_by": "SITE-C1.2",
      "source_doc": "controlled/base_PROC-CC-036_rev3.md",
      "status": "superseded_by_appendix",
      "details": {
        "replacing_doc": "site/signed_site_appendix_SC-2026-07.md",
        "applicable_scenario": "华南冷链库夜班接收"
      }
    },
    {
      "object_id": "BASE-C2.1",
      "title": "基础SOP 温度记录断点超过 30 分钟进入 QA 隔离",
      "inactive_reason": "被监管通知 NOTICE22-C2.1 取代（收紧至 12 分钟）",
      "replaced_by": "NOTICE22-C2.1",
      "source_doc": "controlled/base_PROC-CC-036_rev3.md",
      "status": "superseded_by_regulatory_notice",
      "details": {
        "replacing_doc": "notices/regulatory_notice_RC-2026-22.md",
        "threshold_change": "30分钟 -> 12分钟"
      }
    },
    {
      "object_id": "DRAFT-C1.4",
      "title": "未签署草案 建议夜班高峰时取消 QA 双签",
      "inactive_reason": "unsigned_draft，未签署不生效，且与签署附录 SC-2026-07 冲突",
      "replaced_by": null,
      "source_doc": "draft/unsigned_site_appendix_SC-2026-08.md",
      "status": "unsigned_draft",
      "details": {
        "conflicts_with": "SITE-C1.2（签署附录要求双签）",
        "resolution": "签署附录优先于未签署草案"
      }
    },
    {
      "object_id": "DRAFT-C2.5",
      "title": "未签署草案 建议夜班主管可口头批准温控隔离放行",
      "inactive_reason": "unsigned_draft，未签署不生效，且违反监管通知双批准要求",
      "replaced_by": null,
      "source_doc": "draft/unsigned_site_appendix_SC-2026-08.md",
      "status": "unsigned_draft",
      "details": {
        "conflicts_with": "NOTICE22-C2.2（禁止夜班单人放行，必须双批准）",
        "resolution": "监管通知优先级高于未签署草案"
      }
    },
    {
      "object_id": "DRAFT-C3.4",
      "title": "未签署草案 建议夜班QA复核员可单独解除 H2 隔离",
      "inactive_reason": "unsigned_draft，未签署不生效，且违反监管通知和签署附录",
      "replaced_by": null,
      "source_doc": "draft/unsigned_site_appendix_SC-2026-08.md",
      "status": "unsigned_draft",
      "details": {
        "conflicts_with": "NOTICE22-C3.3 + SITE-C3.1（禁止夜班QA复核员单独解除隔离）",
        "resolution": "监管通知和签署附录均优先于未签署草案"
      }
    },
    {
      "object_id": "LEGACY-rev1-C2",
      "title": "rev1 归档版 60 分钟温控断点阈值",
      "inactive_reason": "archived，已被 rev2 取代",
      "replaced_by": "LEGACY-C2 (rev2, 45分钟) -> NOTICE22-C2.1 (12分钟)",
      "source_doc": "archive/base_PROC-CC-036_rev1_archived.md",
      "status": "archived",
      "details": {
        "archived_date": "2024-12-31",
        "archived_by": "rev2"
      }
    },
    {
      "object_id": "LEGACY-C4 (rev2)",
      "title": "rev2 归档版 追溯包保留 180 天",
      "inactive_reason": "archived，已被 rev3 + RC-2026-22 取代（540 天）",
      "replaced_by": "NOTICE22-C4.2（540 天）",
      "source_doc": "archive/base_PROC-CC-036_rev2_archived.md",
      "status": "archived",
      "details": {
        "archived_date": "2025-10-30",
        "archived_by": "rev3"
      }
    },
    {
      "object_id": "TEMP-BREAK-30-LEGACY",
      "title": "断点超过 30 分钟（已被 12 分钟取代）",
      "inactive_reason": "archived，历史门槛码，已被 RC-2026-22 的 TEMP-BREAK-12 取代",
      "replaced_by": "TEMP-BREAK-12",
      "source_doc": "appendix/appendix_B_hold_codes.csv",
      "status": "superseded_by_new_threshold",
      "details": {
        "replacing_code": "TEMP-BREAK-12",
        "replacing_source": "notices/regulatory_notice_RC-2026-22.md"
      }
    },
    {
      "object_id": "TEMP-BREAK-20-LEGACY",
      "title": "断点超过 20 分钟（已被 12 分钟取代）",
      "inactive_reason": "archived，历史门槛码，源自 RC-2026-17，已被 RC-2026-22 取代",
      "replaced_by": "TEMP-BREAK-12",
      "source_doc": "appendix/appendix_B_hold_codes.csv",
      "status": "superseded_by_new_threshold",
      "details": {
        "replacing_code": "TEMP-BREAK-12",
        "replacing_source": "notices/regulatory_notice_RC-2026-22.md",
        "original_source": "notices/regulatory_notice_RC-2026-17.md"
      }
    },
    {
      "object_id": "ARCH-180",
      "title": "归档旧口径 180 天保留期",
      "inactive_reason": "archived，历史保留期，已被 RC-2026-22 的 540 天取代",
      "replaced_by": "RET-H2H3-540",
      "source_doc": "appendix/appendix_C_record_retention.csv",
      "status": "archived",
      "details": {
        "replacing_object": "RET-H2H3-540",
        "replacing_source": "notices/regulatory_notice_RC-2026-22.md"
      }
    }
  ],
  "conflict_register": [
    {
      "conflict_id": "CONF-001",
      "losing_source": "notices/regulatory_notice_RC-2026-23.md (NOTICE23-C2.1, 10分钟)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md (NOTICE22-C2.1, 12分钟)",
      "active_winner": true,
      "resolution": "训练-生效错窗：RC-2026-23 虽生效日期(2026-08-18)早于 as_of_date，但其要求的角色培训 TR-036-NQ-23 的 release_date(2026-08-30)晚于 as_of_date，对目标角色'夜班QA复核员' pending。按 FAQ-BG-FAQ-13，培训未完成的角色应继续按上一版本步骤执行。",
      "requires_manual_note": false,
      "affected_control": "C2",
      "details": {
        "rule": "training_gate > base_sop，但培训未完成时回退到上一有效版本",
        "non_target_roles_affected": "仓储收货员已完成 TR-036-WH-23，按 NOTICE23-C2.1 的 10 分钟执行（见 role_specific_overrides）"
      }
    },
    {
      "conflict_id": "CONF-002",
      "losing_source": "notices/regulatory_notice_RC-2026-17.md (全步骤)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md (全步骤)",
      "active_winner": true,
      "resolution": "RC-2026-22 明确替代 RC-2026-17 中温控断点、H2/H3 门禁和追溯包保留期。document_register 标记 RC-2026-17 为 superseded_notice。",
      "requires_manual_note": false,
      "affected_control": ["C2", "C3", "C4"],
      "details": {
        "supersession_type": "full_supersession_on_scope",
        "scope": "温控断点阈值、H2/H3 放行门禁、追溯包保留期"
      }
    },
    {
      "conflict_id": "CONF-003",
      "losing_source": "draft/unsigned_site_appendix_SC-2026-08.md (DRAFT-C1.4, DRAFT-C2.5, DRAFT-C3.4)",
      "winning_source": "site/signed_site_appendix_SC-2026-07.md + notices/regulatory_notice_RC-2026-22.md",
      "active_winner": true,
      "resolution": "未签署草案不具有业务规则效力。签署附录 SC-2026-07 和监管通知 RC-2026-22 的授权层级均高于 unsigned_draft。草案中的'取消双签''口头批准''单独解除隔离'均被明确否决。",
      "requires_manual_note": false,
      "affected_control": ["C1", "C2", "C3"],
      "details": {
        "authority_comparison": "signed_site_appendix > unsigned_draft, regulatory_notice > unsigned_draft"
      }
    },
    {
      "conflict_id": "CONF-004",
      "losing_source": "controlled/base_PROC-CC-036_rev3.md (BASE-C1.2, 单人接收)",
      "winning_source": "site/signed_site_appendix_SC-2026-07.md (SITE-C1.2, 双签接收)",
      "active_winner": true,
      "resolution": "签署站点附录在本地化范围内补充执行细则，优先级高于基础SOP。BG-LOC-1 明确'各站点可在签署附录范围内进行本地化执行'。",
      "requires_manual_note": false,
      "affected_control": "C1",
      "details": {
        "scope_limitation": "双签要求仅限华南冷链库夜班接收场景"
      }
    },
    {
      "conflict_id": "CONF-005",
      "losing_source": "controlled/base_PROC-CC-036_rev3.md (BASE-C3.1, 夜班QA可登记复核)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md (NOTICE22-C3.3, 双批准) + site/signed_site_appendix_SC-2026-07.md (SITE-C3.1, 不得单独解除隔离)",
      "active_winner": true,
      "resolution": "监管通知优先级高于基础SOP。BASE-C3.1 允许的'登记记录完整性复核'仍然有效，但'解除隔离'权限被 NOTICE22-C3.3 和 SITE-C3.1 明确限制。",
      "requires_manual_note": false,
      "affected_control": "C3",
      "details": {
        "partial_supersession": "BASE-C3.1 的部分内容（复核登记）仍有效，但解除隔离权限被取代"
      }
    },
    {
      "conflict_id": "CONF-006",
      "losing_source": "INC-C2.3 (隐含, 14天承运商重复断点窗口)",
      "winning_source": "notices/regulatory_notice_RC-2026-22A.md (NOTICE22A-C2.4, 7天窗口)",
      "active_winner": true,
      "resolution": "RC-2026-22A 在 RC-2026-22 框架内追溯收紧 INC-C2.3 的承运商重复断点 H2 触发窗口，从 14 天缩短至 7 天。追溯生效日期 2026-08-01。",
      "requires_manual_note": false,
      "affected_control": "C2",
      "details": {
        "retroactive_effective_date": "2026-08-01",
        "scope": "华南冷链库，同站点同承运商"
      }
    }
  ],
  "appendix_bindings": {
    "APP-A": {
      "appendix_id": "APP-A",
      "title": "角色权限矩阵",
      "source_doc": "appendix/appendix_A_role_matrix.csv",
      "bindings": [
        {
          "control_id": "C1",
          "binding_detail": "ROLE-WH-RECV(仓储收货员)负责到货接收签名，ROLE-NIGHT-QA(夜班QA复核员)负责记录完整性复核——双签接收的基础",
          "required_rows": ["ROLE-WH-RECV", "ROLE-NIGHT-QA"]
        },
        {
          "control_id": "C3",
          "binding_detail": "ROLE-QA-LEAD(QA负责人)负责 H2/H3 放行批准，ROLE-NIGHT-QA(夜班QA复核员)仅能登记复核意见——双批准门禁的角色基础",
          "required_rows": ["ROLE-QA-LEAD", "ROLE-NIGHT-QA"]
        }
      ]
    },
    "APP-B": {
      "appendix_id": "APP-B",
      "title": "冻结/挂起代码表",
      "source_doc": "appendix/appendix_B_hold_codes.csv",
      "bindings": [
        {
          "control_id": "C2",
          "binding_detail": "TEMP-BREAK-12(断点超过12分钟立即QA隔离)、H1(轻微偏差)、H2(重复或中度偏差)、H3(严重偏差)——温控断点判定的核心代码",
          "required_rows": ["TEMP-BREAK-12", "H1", "H2", "H3"]
        },
        {
          "control_id": "C1",
          "binding_detail": "DOC-COMPLETE(文件完整进入QA复核)、DOC-INCOMPLETE(文件不完整退回收货员补全)——接收记录完整性判定",
          "required_rows": ["DOC-COMPLETE", "DOC-INCOMPLETE"]
        }
      ]
    },
    "APP-C": {
      "appendix_id": "APP-C",
      "title": "记录保留期限表",
      "source_doc": "appendix/appendix_C_record_retention.csv",
      "bindings": [
        {
          "control_id": "C4",
          "binding_detail": "RET-H2H3-540(H2/H3追溯包540天)、TRACE-PACK(温度曲线/签名/法规确认540天)——RC-2026-22 的核心保留期要求",
          "required_rows": ["RET-H2H3-540", "TRACE-PACK"]
        },
        {
          "control_id": "C1",
          "binding_detail": "RET-H1-365(H1复核记录365天)、RET-OBS-90(观察项记录90天)、RET-INFO-90(信息记录90天)——C1 产生的记录保留期",
          "required_rows": ["RET-H1-365", "RET-OBS-90", "RET-INFO-90"]
        }
      ]
    }
  },
  "role_specific_overrides": [
    {
      "role": "仓储收货员",
      "site": "华南冷链库",
      "control_id": "C2",
      "base_step_id": "NOTICE22-C2.1",
      "overriding_step_id": "NOTICE23-C2.1",
      "training_evidence_id": "TR-036-WH-23",
      "training_release_date": "2026-08-15",
      "notice_effective_date": "2026-08-18",
      "effective_for_role_from": "2026-08-18",
      "reason": "仓储收货员已完成 TR-036-WH-23 培训(released, 2026-08-15)，满足 RC-2026-23 的培训前提条件，自通知生效日(2026-08-18)起按 10 分钟断点阈值执行，较 NOTICE22-C2.1 的 12 分钟更严格"
    }
  ],
  "retroactive_actions": [
    {
      "action_id": "RETRO-001",
      "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
      "issue_date": "2026-08-19",
      "retroactive_effective_date": "2026-08-01",
      "as_of_date": "2026-08-20",
      "affected_record": "IR-036-001",
      "affected_record_event_date": "2026-08-02",
      "original_severity": "H1",
      "new_severity": "H2",
      "trigger_rule": "RPT-CARRIER-14D",
      "paired_with": "IR-036-002",
      "paired_with_event_date": "2026-08-08",
      "rationale": "RC-2026-22A 追溯生效自 2026-08-01，将同一站点同一承运商 7 天内重复温控断点的 H2 触发窗口从 14 天收紧至 7 天。IR-036-001(2026-08-02, 冷捷承运, 13分钟)与 IR-036-002(2026-08-08, 冷捷承运, 14分钟)发生在同一站点(华南冷链库)、同一承运商(冷捷承运)、事件间隔 6 天 < 7 天窗口，按 NOTICE22A-C2.4 升级为 H2。原 severity_hint=H1 按新规则重分类为 H2。"
    },
    {
      "action_id": "RETRO-002",
      "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
      "issue_date": "2026-08-19",
      "retroactive_effective_date": "2026-08-01",
      "as_of_date": "2026-08-20",
      "affected_record": "IR-036-002",
      "affected_record_event_date": "2026-08-08",
      "original_severity": "H1",
      "new_severity": "H2",
      "trigger_rule": "RPT-CARRIER-14D",
      "paired_with": "IR-036-001",
      "paired_with_event_date": "2026-08-02",
      "rationale": "RC-2026-22A 追溯生效自 2026-08-01，将同一站点同一承运商 7 天内重复温控断点的 H2 触发窗口从 14 天收紧至 7 天。IR-036-002(2026-08-08, 冷捷承运, 14分钟)与 IR-036-001(2026-08-02, 冷捷承运, 13分钟)发生在同一站点(华南冷链库)、同一承运商(冷捷承运)、事件间隔 6 天 < 7 天窗口，按 NOTICE22A-C2.4 升级为 H2。原 severity_hint=H1 按新规则重分类为 H2。此行动与 RETRO-001 为配对关系。"
    }
  ],
  "summary": {
    "total_control_ids": 4,
    "active_control_count": 4,
    "inactive_control_count": 14,
    "conflict_count": 6,
    "appendix_binding_count": 3,
    "role_override_count": 1,
    "retroactive_action_count": 2,
    "key_findings": [
      "目标角色'夜班QA复核员'在 as_of_date=2026-08-20 时，C2 断点阈值仍为 12 分钟(NOTICE22-C2.1)，因 TR-036-NQ-23 培训尚未释放(2026-08-30)。",
      "非目标角色'仓储收货员'已完成 TR-036-WH-23 培训，C2 断点阈值为 10 分钟(NOTICE23-C2.1)，出现在 role_specific_overrides 中。",
      "RC-2026-22A 追溯生效(2026-08-01)导致华南冷链库 2 条 incident(IR-036-001, IR-036-002)从 H1 重分类为 H2，触发 RETRO-001 和 RETRO-002。",
      "RC-2026-17 全部步骤被 RC-2026-22 取代，标记为 superseded_notice。",
      "未签署草案 SC-2026-08 的 3 条建议(DRAFT-C1.4/C2.5/C3.4)全部无效，与签署附录和监管通知冲突。",
      "华南冷链库签署附录 SC-2026-07 在 C1(双签接收)、C3(不得单独解除隔离)、C4(交接记录绑定字段)层面补充基础SOP。",
      "APP-A/APP-B/APP-C 分别绑定到 C1/C2/C3/C4 的具体控制步骤，required_rows 已在 appendix_bindings 中明示。"
    ]
  }
}
