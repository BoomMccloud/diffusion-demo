# Workbook: credit_workbook.xlsx

## Sheet 1: summary
Dimensions: 5 rows x 3 columns
R1: classification | line_count | total_recommended_credit
R2: credit_due | 4 | 480
R3: already_credited | 3 | 0
R4: not_eligible | 4 | 0
R5: manual_review | 1 | 0

## Sheet 2: credit_due
Dimensions: 5 rows x 8 columns
R1: invoice_line_id | canonical_account_id | service_month | classification_reason_code | eligible_incident_ids | existing_credit_memo_ids | recommended_credit_amount | evidence_note
R2: IL-1001 | ACC-001 | 2026-04 | CD_MULTI_INCIDENTS | INC-501; INC-502 |  | 240 | Contract: CT-ACME-ENT (active, credit enabled, max=$300, rank≤2). Eligible incidents (2): INC-501, INC-502. Severity: P1, status: customer_confirmed, customer_visible: Y. Raw incident credit: $120.0 × 2 = $240.0; capped at $300 = $240.0. No existing posted service credits found.
R3: IL-1002 | ACC-001 | 2026-04 | CD_SINGLE_INCIDENT | INC-503 | CM-701 | 50 | Contract: CT-ACME-PLAT (active, credit enabled, max=$150, rank≤2). Eligible incidents (1): INC-503. Severity: P2, status: credit_approved, customer_visible: Y. Raw incident credit: $90.0 × 1 = $90.0; capped at $150 = $90.0. Existing posted service credits: CM-701 totaling $40; net deduction applied.
R4: IL-1005 | ACC-004 | 2026-04 | CD_SINGLE_INCIDENT | INC-507 |  | 100 | Contract: CT-DELTA-OLD (active, credit enabled, max=$100, rank≤2). Eligible incidents (1): INC-507. Severity: P1, status: customer_confirmed, customer_visible: Y. Raw incident credit: $100.0 × 1 = $100.0; capped at $100 = $100.0. No existing posted service credits found.
R5: IL-1008 | ACC-008 | 2026-04 | CD_MULTI_INCIDENTS | INC-510; INC-511 |  | 90 | Contract: CT-NOVA-PRO (active, credit enabled, max=$90, rank≤2). Eligible incidents (2): INC-510, INC-511. Severity: P1, status: customer_confirmed, customer_visible: Y. Raw incident credit: $75.0 × 2 = $150.0; capped at $90 = $90. No existing posted service credits found.

## Sheet 3: already_credited
Dimensions: 4 rows x 8 columns
R1: invoice_line_id | canonical_account_id | service_month | classification_reason_code | eligible_incident_ids | existing_credit_memo_ids | recommended_credit_amount | evidence_note
R2: IL-1003 | ACC-002 | 2026-04 | AC_FULLY_COVERED | INC-504 | CM-702 | 0 | Contract: CT-BETA-PRO (active, credit enabled, max=$100, rank≤2). Eligible incidents (1): INC-504. Severity: P2, status: resolved_confirmed, customer_visible: Y. Raw incident credit: $80.0 × 1 = $80.0; capped at $100 = $80.0. Existing posted service credits: CM-702 totaling $80; net deduction applied.
R3: IL-1007 | ACC-006 | 2026-04 | AC_FULLY_COVERED | INC-509 | CM-704 | 0 | Contract: CT-FOX-PRO (active, credit enabled, max=$100, rank≤2). Eligible incidents (1): INC-509. Severity: P2, status: resolved_confirmed, customer_visible: Y. Raw incident credit: $60.0 × 1 = $60.0; capped at $100 = $60.0. Existing posted service credits: CM-704 totaling $60; net deduction applied.
R4: IL-1010 | ACC-009 | 2026-04 | AC_FULLY_COVERED | INC-512 | CM-708 | 0 | Contract: CT-HILO-ENT (active, credit enabled, max=$120, rank≤2). Eligible incidents (1): INC-512. Severity: P1, status: customer_confirmed, customer_visible: Y. Raw incident credit: $100.0 × 1 = $100.0; capped at $120 = $100.0. Existing posted service credits: CM-708 totaling $100; net deduction applied.

## Sheet 4: not_eligible
Dimensions: 5 rows x 8 columns
R1: invoice_line_id | canonical_account_id | service_month | classification_reason_code | eligible_incident_ids | existing_credit_memo_ids | recommended_credit_amount | evidence_note
R2: IL-1004 | ACC-003 | 2026-04 | NE_NO_ELIGIBLE_INCIDENT |  |  | 0 | No eligible incident found for 'IL-1004'. Checked account_ref=AL-GAMMA, tier=Pro, product_line=API.
R3: IL-1009 |  | 2026-04 | NE_VOIDED_LINE |  |  | 0 | Invoice line status 'Void' — not settlement evidence.
R4: IL-1011 | ACC-010 | 2026-04 | NE_NO_ELIGIBLE_INCIDENT |  |  | 0 | No eligible incident found for 'IL-1011'. Checked account_ref=AL-INDIGO, tier=Pro, product_line=API.
R5: IL-1012 | ACC-011 | 2026-04 | NE_CREDIT_DISABLED |  |  | 0 | Contract 'CT-JADE-PRO' has service_credit_enabled=N; no incident credit applicable.

## Sheet 5: manual_review
Dimensions: 2 rows x 8 columns
R1: invoice_line_id | canonical_account_id | service_month | classification_reason_code | eligible_incident_ids | existing_credit_memo_ids | recommended_credit_amount | evidence_note
R2: IL-1006 | ACC-005 | 2026-04 | MR_AMBIGUOUS_CONTRACT |  |  | 0 | Multiple active contracts for account 'ACC-005': CT-ECHO-A, CT-ECHO-B. Need manual determination of governing contract.
