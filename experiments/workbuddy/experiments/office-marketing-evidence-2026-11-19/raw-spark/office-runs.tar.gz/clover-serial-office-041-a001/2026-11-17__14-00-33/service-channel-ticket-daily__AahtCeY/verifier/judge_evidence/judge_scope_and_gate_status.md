# Judge scope and gate status

submitted_report_path: /workspace/service_channel_daily_report.md
submitted_report_present: True
deterministic_passed: 265/273
deterministic_pass_rate: 0.9707
judge_scope: text-only submitted Markdown daily report quality; no hidden gold, source recomputation, VLM/OCR/pixel checks, or live-service evidence.
verifier_owned: exact filtering, counts, category/status/progress aggregates, detail rows, source rows, ordering, no-live boundary, hidden-SLA boundary, and leakage checks.
failed_deterministic_checks_sample:
- overview_candidate_record_count
- overview_unclosed_ticket_count
- overview_excluded_record_count
- exclusion_outside_window_count
- exclusion_wrong_service_desk_count
- exclusion_wrong_service_channel_count
- detail_sort_order_exact
- detail_TCK-CS-3110_priority
