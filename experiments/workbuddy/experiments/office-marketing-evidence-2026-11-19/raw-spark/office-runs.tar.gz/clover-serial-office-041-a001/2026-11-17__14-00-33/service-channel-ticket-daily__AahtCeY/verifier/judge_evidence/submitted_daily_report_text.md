# 社区服务通道工单日报

## 范围与数据来源

- **报告日期**：2026-05-18（Asia/Shanghai）
- **时间窗口**：2026-05-18 00:00:00 至 2026-05-18 23:59:59（含边界）
- **目标服务台**：东区民生服务中心
- **目标服务通道**：社区热线-东区服务台
- **数据来源文件**：
  - `input/ticket_export.csv`（行级导出记录，主要事件/更新表）
  - `input/ticket_state_snapshot.json`（快照状态、update arrays、key_aliases 别名映射）
  - `input/channel_status_guidance.md`（统计口径、去重规则、状态解释、输出结构）
  - `environment/mock_ticket_api_description.md`（接口说明边界）

所有统计均基于上述公开材料计算；未连接任何真实工单系统或外部 API。

## 今日总览

| 指标 | 数值 |
|---|---|
| 窗口内目标通道候选记录数 | 51 |
| 去重后唯一工单数 | 19 |
| 有多条窗口内更新的唯一工单数 | 17 |
| 仅一条窗口内更新的唯一工单数 | 2 |
| 最新状态为未闭环类（new / assigned / in_progress / pending_resident / pending_external / resolved / reopened）的唯一工单数 | 17 |
| 最新状态为已闭环类（closed）的唯一工单数 | 2 |
| 排除记录概览 | 见"排除与去重说明"节 |

## 分类汇总

按 latest eligible update 所在工单的 category 统计：

| 分类 | 唯一工单数 | ticket_id 列表 |
|---|---|---|
| 路面/设施 | 3 | TCK-CS-3101, TCK-CS-3115, TCK-CS-3116 |
| 环境卫生 | 3 | TCK-CS-3102, TCK-CS-3113, TCK-CS-3119 |
| 便民咨询 | 3 | TCK-CS-3103, TCK-CS-3105, TCK-CS-3112 |
| 供水/排水 | 2 | TCK-CS-3111, TCK-CS-3117 |
| 市容秩序 | 1 | TCK-CS-3104 |
| 动物协助 | 1 | TCK-CS-3106 |
| 排水/积水 | 1 | TCK-CS-3107 |
| 噪声/扰民 | 1 | TCK-CS-3108 |
| 无障碍设施 | 1 | TCK-CS-3109 |
| 绿化养护 | 1 | TCK-CS-3110 |
| 楼道维护 | 1 | TCK-CS-3114 |
| 居家关怀 | 1 | TCK-CS-3118 |

按优先级统计：

| 优先级 | 唯一工单数 | ticket_id 列表 |
|---|---|---|
| 高 | 8 | TCK-CS-3102, TCK-CS-3107, TCK-CS-3109, TCK-CS-3111, TCK-CS-3113, TCK-CS-3115, TCK-CS-3116, TCK-CS-3118 |
| 中 | 9 | TCK-CS-3101, TCK-CS-3103, TCK-CS-3104, TCK-CS-3106, TCK-CS-3108, TCK-CS-3110, TCK-CS-3114, TCK-CS-3117, TCK-CS-3119 |
| 低 | 2 | TCK-CS-3105, TCK-CS-3112 |

## 状态与进展摘要

### 状态分布

| 当前状态 | 唯一工单数 | ticket_id 列表 |
|---|---|---|
| new | 0 | — |
| assigned | 3 | TCK-CS-3103, TCK-CS-3110, TCK-CS-3115 |
| in_progress | 5 | TCK-CS-3106, TCK-CS-3111, TCK-CS-3113, TCK-CS-3118, TCK-CS-3119 |
| pending_resident | 2 | TCK-CS-3102, TCK-CS-3108 |
| pending_external | 1 | TCK-CS-3117 |
| resolved | 2 | TCK-CS-3101, TCK-CS-3107 |
| reopened | 3 | TCK-CS-3104, TCK-CS-3109, TCK-CS-3116 |
| closed | 2 | TCK-CS-3105, TCK-CS-3112 |

### 进展区间分布

| 进展区间 | 唯一工单数 | ticket_id 列表 |
|---|---|---|
| 0-24% | 2 | TCK-CS-3110(15%), TCK-CS-3115(20%) |
| 25-59% | 5 | TCK-CS-3103(25%), TCK-CS-3106(40%), TCK-CS-3108(55%), TCK-CS-3113(50%), TCK-CS-3119(55%) |
| 60-99% | 7 | TCK-CS-3102(60%), TCK-CS-3104(65%), TCK-CS-3109(80%), TCK-CS-3111(85%), TCK-CS-3116(70%), TCK-CS-3117(90%), TCK-CS-3118(60%) |
| 100% | 5 | TCK-CS-3101(100%), TCK-CS-3105(100%), TCK-CS-3107(100%), TCK-CS-3112(100%), TCK-CS-3114(100%) |

## 需要关注的运营提示

1. **TCK-CS-3101（路面/设施，中）**：latest_eligible_update 为 R-003 (resolved, 100%)，但 snapshot 显示次日凌晨有 R-004 的 reopened 更新（outside window）。若复核发现间歇闪烁持续，需关注是否应在下一工作日重新打开处理。

2. **TCK-CS-3104（市容秩序，中）**：经历 resolved → reopened 反转，latest 状态为 reopened (65%)，因复核发现需补充围挡提示。建议安排二次现场核查。

3. **TCK-CS-3109（无障碍设施，高）**：经历 resolved → reopened 反转，latest 状态为 reopened (80%)，居民反馈固定点仍突出需再次处理。属高优先级，应优先跟进。

4. **TCK-CS-3116（路面/设施，高）**：经 alias 合并（east-manual:TCK-CS-3116 → east:TCK-CS-3116），latest 状态为 reopened (70%)，复查发现仍有晃动需二次加固。R-047 次日凌晨施工队到场二次加固的更新在窗口外，不在日报统计范围内，但可作为后续跟踪参考。

5. **TCK-CS-3117（供水/排水，中）**：latest 状态为 pending_external (90%)，等待供水单位回传压力复测。due_at 为 2026-05-18 22:00，last_responded_at 为 2026-05-18 22:31:00，可见 last_responded_at 晚于 due_at。R-052 次日凌晨标记闭环的更新在窗口外。

6. **TCK-CS-3118（居家关怀，高）**：经历 resolved → reopened → in_progress 反转链，latest 状态为 in_progress (60%)，值班册已补登记等待次日窗口复核。first_response_at 为空，需注意首次响应时效。

7. **TCK-CS-3102（环境卫生，高）**：latest 状态为 pending_resident (60%)，清运完成但需居民确认异味是否消除。建议主动回访确认。

8. **TCK-CS-3108（噪声/扰民，中）**：latest 状态为 pending_resident (55%)，等待居民补充夜间录音材料。建议提醒居民及时提交材料以推进处理。

9. **TCK-CS-3113（环境卫生，高）**：first_response_at 为空，last_responded_at 为 2026-05-18 18:20:00。建议关注首次响应是否被遗漏。

10. **TCK-CS-3119（环境卫生，中）**：first_response_at 为空，last_responded_at 为 2026-05-18 15:11:00。同样存在首次响应缺失的情况。

## 明细审计表

排序规则：priority 从高到低（高 > 中 > 低），同优先级内 latest_eligible_update 时间升序，再相同则 ticket_id 升序。

| ticket_id | normalized_ticket_key | 分类 | 当前状态 | 进展 | 优先级 | latest_eligible_update | included_record_ids | included_source_rows | 状态/进展依据 | 范围说明 |
|---|---|---|---|---|---|---|---|---|---|---|
| TCK-CS-3102 | east:TCK-CS-3102 | 环境卫生 | pending_resident | 60% | 高 | R-007 @ 2026-05-18 14:22:10 | R-005, R-006, R-007 | row-005, row-006, row-007 | 状态流转：created→new→in_progress→pending_resident；latest 采用 R-007 的 status=pending_resident, progress_pct=60 | 服务台、通道、窗口均合格 |
| TCK-CS-3113 | east:TCK-CS-3113 | 环境卫生 | in_progress | 50% | 高 | R-032 @ 2026-05-18 18:15:45 | R-031, R-032 | row-031, row-032 | 状态流转：created→new→in_progress；latest 采用 R-032 的 status=in_progress, progress_pct=50 | 服务台、通道、窗口均合格 |
| TCK-CS-3116 | east:TCK-CS-3116 | 路面/设施 | reopened | 70% | 高 | R-046 @ 2026-05-18 18:42:09 | R-043, R-044, R-045, R-046 | row-043, row-044, row-045, row-046 | alias 合并：east-manual:TCK-CS-3116(R-044,R-046) → canonical east:TCK-CS-3116；状态流转：created→new→assigned→resolved→reopened；latest 采用 R-046 的 status=reopened, progress_pct=70 | 服务台、通道、窗口均合格；alias 来源已在 included_record_ids 中标注 |
| TCK-CS-3109 | east:TCK-CS-3109 | 无障碍设施 | reopened | 80% | 高 | R-025 @ 2026-05-18 19:30:37 | R-023, R-024, R-025 | row-023, row-024, row-025 | 状态流转：created→new→resolved→reopened；latest 采用 R-025 的 status=reopened, progress_pct=80 | 服务台、通道、窗口均合格 |
| TCK-CS-3118 | east:TCK-CS-3118 | 居家关怀 | in_progress | 60% | 高 | R-056 @ 2026-05-18 22:18:44 | R-053, R-054, R-055, R-056 | row-053, row-054, row-055, row-056 | 状态流转：created→new→resolved→reopened→in_progress；latest 采用 R-056 的 status=in_progress, progress_pct=60 | 服务台、通道、窗口均合格 |
| TCK-CS-3111 | east:TCK-CS-3111 | 供水/排水 | in_progress | 85% | 高 | R-029 @ 2026-05-18 22:45:33 | R-028, R-029 | row-028, row-029 | 状态流转：created→new→in_progress；latest 采用 R-029 的 status=in_progress, progress_pct=85 | 服务台、通道、窗口均合格 |
| TCK-CS-3115 | east:TCK-CS-3115 | 路面/设施 | assigned | 20% | 高 | R-037 @ 2026-05-18 23:10:02 | R-036, R-037 | row-036, row-037 | 状态流转：created→new→assigned；latest 采用 R-037 的 status=assigned, progress_pct=20 | 服务台、通道、窗口均合格 |
| TCK-CS-3107 | east:TCK-CS-3107 | 排水/积水 | resolved | 100% | 高 | R-019 @ 2026-05-18 23:59:59 | R-016, R-017, R-018, R-019 | row-016, row-017, row-018, row-019 | 状态流转：created→new→assigned→in_progress→resolved；latest 采用 R-019 的 status=resolved, progress_pct=100 | 服务台、通道、窗口均合格；R-019 恰好在窗口终点时刻 |
| TCK-CS-3106 | east:TCK-CS-3106 | 动物协助 | in_progress | 40% | 中 | R-015 @ 2026-05-18 13:15:14 | R-014, R-015 | row-014, row-015 | 状态流转：created→new→in_progress；latest 采用 R-015 的 status=in_progress, progress_pct=40 | 服务台、通道、窗口均合格 |
| TCK-CS-3103 | east:TCK-CS-3103 | 便民咨询 | assigned | 25% | 中 | R-009 @ 2026-05-18 15:05:31 | R-008, R-009 | row-008, row-009 | 状态流转：created→new→assigned；latest 采用 R-009 的 status=assigned, progress_pct=25 | 服务台、通道、窗口均合格 |
| TCK-CS-3119 | east:TCK-CS-3119 | 环境卫生 | in_progress | 55% | 中 | R-060 @ 2026-05-18 15:10:07 | R-057, R-058, R-059, R-060 | row-057, row-058, row-059, row-060 | 状态流转：created→new→assigned→pending_external→in_progress；latest 采用 R-060 的 status=in_progress, progress_pct=55 | 服务台、通道、窗口均合格 |
| TCK-CS-3104 | east:TCK-CS-3104 | 市容秩序 | reopened | 65% | 中 | R-012 @ 2026-05-18 16:05:20 | R-010, R-011, R-012 | row-010, row-011, row-012 | 状态流转：created→new→resolved→reopened；latest 采用 R-012 的 status=reopened, progress_pct=65 | 服务台、通道、窗口均合格 |
| TCK-CS-3114 | east:TCK-CS-3114 | 楼道维护 | resolved | 100% | 中 | R-035 @ 2026-05-18 16:55:09 | R-034, R-035 | row-034, row-035 | 状态流转：created→new→assigned→resolved；latest 采用 R-035 的 status=resolved, progress_pct=100 | 服务台、通道、窗口均合格；R-033 发生在前一日（2026-05-17 22:30:18），属于窗口外更新，不计入 included_record_ids |
| TCK-CS-3110 | east:TCK-CS-3110 | 绿化养护 | assigned | 15% | 中 | R-027 @ 2026-05-18 17:05:19 | R-026, R-027 | row-026, row-027 | 状态流转：created→new→assigned；latest 采用 R-027 的 status=assigned, progress_pct=15 | 服务台、通道、窗口均合格 |
| TCK-CS-3101 | east:TCK-CS-3101 | 路面/设施 | resolved | 100% | 中 | R-003 @ 2026-05-18 17:40:03 | R-001, R-002, R-003 | row-001, row-002, row-003 | 状态流转：created→new→assigned→resolved；latest 采用 R-003 的 status=resolved, progress_pct=100 | 服务台、通道、窗口均合格；snapshot 中有 R-004 次日 reopened 更新（outside window），未覆盖当天口径 |
| TCK-CS-3108 | east:TCK-CS-3108 | 噪声/扰民 | pending_resident | 55% | 中 | R-022 @ 2026-05-18 21:10:08 | R-020, R-021, R-022 | row-020, row-021, row-022 | 状态流转：created→new→pending_external→pending_resident；latest 采用 R-022 的 status=pending_resident, progress_pct=55 | 服务台、通道、窗口均合格 |
| TCK-CS-3117 | east:TCK-CS-3117 | 供水/排水 | pending_external | 90% | 中 | R-051 @ 2026-05-18 22:30:18 | R-049, R-050, R-051 | row-049, row-050, row-051 | 状态流转：created→new→assigned→in_progress→pending_external；latest 采用 R-051 的 status=pending_external, progress_pct=90 | 服务台、通道、窗口均合格；R-048（2026-05-17 21:35:00）和 R-052（2026-05-19 00:04:11）均为窗口外更新，不计入 included_record_ids |
| TCK-CS-3112 | east:TCK-CS-3112 | 便民咨询 | closed | 100% | 低 | R-030 @ 2026-05-18 12:00:00 | R-030 | row-030 | 状态流转：created→closed；latest 采用 R-030 的 status=closed, progress_pct=100 | 服务台、通道、窗口均合格 |
| TCK-CS-3105 | east:TCK-CS-3105 | 便民咨询 | closed | 100% | 低 | R-013 @ 2026-05-18 15:18:09 | R-013 | row-013 | 状态流转：created→closed；latest 采用 R-013 的 status=closed, progress_pct=100 | 服务台、通道、窗口均合格 |

## 排除与去重说明

### 窗口外排除

以下 CSV 行的 occurred_at 超出 2026-05-18 00:00:00–23:59:59 窗口，虽 service_desk 和 service_channel 匹配但不计入候选记录：

| record_id | source_row | occurred_at | 所属工单 | 备注 |
|---|---|---|---|---|
| R-004 | row-004 | 2026-05-19 00:12:18 | TCK-CS-3101 | 次日凌晨 reopened 更新 |
| R-033 | row-033 | 2026-05-17 22:30:18 | TCK-CS-3114 | 前一日晚间创建更新 |
| R-041 | row-041 | 2026-05-17 23:50:19 | TCK-CS-3123 | 前一日夜间创建更新 |
| R-042 | row-042 | 2026-05-19 00:08:02 | TCK-CS-3124 | 次日凌晨创建更新 |
| R-047 | row-047 | 2026-05-19 00:20:16 | TCK-CS-3116 | 次日凌晨二次加固更新 |
| R-048 | row-048 | 2026-05-17 21:35:00 | TCK-CS-3117 | 前一日晚间低压报修 |
| R-052 | row-052 | 2026-05-19 00:04:11 | TCK-CS-3117 | 次日凌晨标记闭环 |

### 错误服务台排除

以下记录的 service_desk 不等于"东区民生服务中心"：

| record_id | source_row | service_desk | 原因 |
|---|---|---|---|
| R-038 | row-038 | 西区民生服务中心 | 服务台不匹配 |
| R-039 | row-039 | 北区民生服务中心 | 服务台不匹配 |
| R-061 | row-061 | 东区民生服务站 | 名称相近但非精确目标服务台 |
| R-064 | row-064 | 东区民生服务中心综合窗口 | 服务台名称包含目标词但不是精确目标服务台 |

### 错误服务通道排除

以下记录的 service_channel 不等于"社区热线-东区服务台"：

| record_id | source_row | service_channel | 原因 |
|---|---|---|---|
| R-040 | row-040 | 物业协同-转办 | 渠道类型不同 |
| R-062 | row-062 | 社区热线-东区夜间服务台 | 夜间子通道，非目标主通道 |
| R-063 | row-063 | 社区热线-东区服务台-回访 | 回访子通道，非目标主通道 |

### Alias 合并说明

根据 `ticket_state_snapshot.json` 的 `key_aliases` 公开映射：

- **alias_key**: `east-manual:TCK-CS-3116` → **canonical_key**: `east:TCK-CS-3116`
- **canonical_ticket_id**: `TCK-CS-3116`
- **alias_ticket_ids**: `["TCK-CS-3116A"]`
- **reason**: 坐席补录产生临时编号；CSV 行和 snapshot update arrays 指向同一桥下护栏事项。

合并涉及的合格记录：R-043（canonical key）、R-044（alias key）、R-045（canonical key）、R-046（alias key）。这些记录均已纳入 TCK-CS-3116 的 included_record_ids。

### Snapshot 状态未用于覆盖

本日报严格采用窗口内 latest eligible update 的 status 和 progress_pct 作为当前状态与进展判断依据。snapshot 中的 snapshot_status 和 snapshot_progress_pct 可能反映窗口外更新后的最终状态，不用于覆盖当天日报口径。例如：

- TCK-CS-3101：snapshot_status = "reopened", snapshot_progress_pct = 70（来自 R-004 次日更新），但日报采用 R-003 的 resolved/100%。
- TCK-CS-3116：snapshot_status = "in_progress", snapshot_progress_pct = 80（来自 R-047 次日更新），但日报采用 R-046 的 reopened/70%。
- TCK-CS-3117：snapshot_status = "closed", snapshot_progress_pct = 100（来自 R-052 次日更新），但日报采用 R-051 的 pending_external/90%。

以上差异均在明细审计表的"状态/进展依据"列中注明。
