# Workbook: rank_ic_workbook.xlsx

## Sheet 1: rank_ic_by_period
Dimensions: 5 rows x 9 columns
R1: period_end | baseline_rank_ic | model_rank_ic | baseline_n | model_n | model_minus_baseline | baseline_positive_flag | model_positive_flag | source_trace
R2: 2025-06-30 | 0.05 | 0.228932 | 9 | 8 | 0.178932 | True | True | FCT-test-period; score_version=normal
R3: 2025-07-31 | 0.025105 | -0.295361 | 9 | 9 | -0.320466 | True | False | FCT-test-period; score_version=normal
R4: 2025-08-29 | 0.85 | 0.97619 | 9 | 8 | 0.12619 | True | True | FCT-test-period; score_version=normal
R5: 2025-09-30 | 0.383333 | 0.874267 | 9 | 8 | 0.490934 | True | True | FCT-test-period; score_version=snapshot_gap

## Sheet 2: topn_selection
Dimensions: 21 rows x 12 columns
R1: period_end | selection_rank | symbol | display_name | industry_lvl1 | board | model_score | baseline_score | fwd_20_return | liquidity_rank | tie_break_note | source_trace
R2: 2025-06-30 | 1 | SY6112 | 南港材料 | 基础化工 | MAIN | 0.771 | 0.305 |  | 41 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R3: 2025-06-30 | 2 | SY6999 | 西岭新材 | 有色金属 | MAIN | 0.706 | 0.571 | 0.0315 | 3 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R4: 2025-06-30 | 3 | SY6088 | 启明半导 | 电子 | MAIN | 0.706 | 0.533 | 0.0251 | 22 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R5: 2025-06-30 | 4 | SY6207 | 云岭软件 | 计算机 | STAR | 0.681 | 0.681 | -0.0276 | 12 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R6: 2025-06-30 | 5 | SY6331 | 星河军工 | 国防军工 | MAIN | 0.659 | 0.601 | 0.0418 | 5 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R7: 2025-07-31 | 1 | SY6999 | 西岭新材 | 有色金属 | MAIN | 0.709 | 0.48 | -0.024 | 3 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R8: 2025-07-31 | 2 | SY6880 | 景川电子 | 电子 | STAR | 0.681 | 0.621 |  | 9 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R9: 2025-07-31 | 3 | SY6207 | 云岭软件 | 计算机 | STAR | 0.681 | 0.694 | 0.0115 | 12 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R10: 2025-07-31 | 4 | SY6420 | 安澜消费 | 食品饮料 | MAIN | 0.681 | 0.59 | 0.0345 | 26 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R11: 2025-07-31 | 5 | SY6088 | 启明半导 | 电子 | MAIN | 0.639 | 0.51 | 0.048 | 22 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R12: 2025-08-29 | 1 | SY6999 | 西岭新材 | 有色金属 | MAIN | 0.791 | 0.58 |  | 3 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R13: 2025-08-29 | 2 | SY6444 | 明湖消费 | 食品饮料 | MAIN | 0.742 | 0.623 | 0.044 | 35 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R14: 2025-08-29 | 3 | SY6880 | 景川电子 | 电子 | STAR | 0.735 | 0.702 | 0.05 | 9 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R15: 2025-08-29 | 4 | SY6207 | 云岭软件 | 计算机 | STAR | 0.721 | 0.66 | 0.037 | 12 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R16: 2025-08-29 | 5 | SY6123 | 海泰能源 | 电力设备 | MAIN | 0.601 | 0.491 | 0.032 | 22 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R17: 2025-09-30 | 1 | SY6331 | 星河军工 | 国防军工 | MAIN | 0.742 | 0.62 | 0.053 | 5 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R18: 2025-09-30 | 2 | SY6018 | 华东机电 | 机械设备 | MAIN | 0.742 | 0.59 | 0.06 | 18 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R19: 2025-09-30 | 3 | SY6088 | 启明半导 | 电子 | MAIN | 0.708 | 0.53 |  | 22 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R20: 2025-09-30 | 4 | SY6880 | 景川电子 | 电子 | STAR | 0.681 | 0.642 | 0.027 | 9 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5
R21: 2025-09-30 | 5 | SY6999 | 西岭新材 | 有色金属 | MAIN | 0.65 | 0.57 | 0.012 | 3 |  | sorted_by(model_score DESC, liquidity_rank ASC, symbol ASC); top_n=5

## Sheet 3: exclusion_reasons
Dimensions: 24 rows x 12 columns
R1: period_end | symbol | display_name | exclusion_scope | primary_reason | triggered_rule_codes | score_available | return_available | tradable_flag | suspended_flag | pool_status | source_trace
R2: 2025-06-30 | SY6112 | 南港材料 | IC_denominator | missing_return | RULE_MISSING_RETURN | yes | no | Y | N | active | eligibility_ok=True; has_model_score=True; has_return=False
R3: 2025-06-30 | SY6355 | 渤海医械 | IC_denominator;TopN_pool | suspended | RULE_SUSPENDED | yes | yes | Y | Y | active | eligibility_ok=False; has_model_score=True; has_return=True
R4: 2025-06-30 | SY6501 | 辰星电力 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS | yes | yes | Y | N | watch | eligibility_ok=False; has_model_score=False; has_return=True
R5: 2025-06-30 | SY6123 | 海泰能源 | TopN_pool | missing_model_score | RULE_MISSING_MODEL_SCORE | yes | yes | Y | N | active | eligibility_ok=True; has_model_score=False; has_return=True
R6: 2025-06-30 | SY6722 | 北辰物流 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS;RULE_TRADABLE | yes | yes | N | N | inactive | eligibility_ok=False; has_model_score=True; has_return=True
R7: 2025-06-30 | SY6777 | 华晨综合 | IC_denominator;TopN_pool | industry_excluded | RULE_INDUSTRY | yes | yes | Y | N | active | eligibility_ok=False; has_model_score=True; has_return=True
R8: 2025-07-31 | SY6355 | 渤海医械 | IC_denominator;TopN_pool | suspended | RULE_SUSPENDED | yes | yes | Y | Y | active | eligibility_ok=False; has_model_score=True; has_return=True
R9: 2025-07-31 | SY6880 | 景川电子 | IC_denominator | missing_return | RULE_MISSING_RETURN | yes | no | Y | N | active | eligibility_ok=True; has_model_score=True; has_return=False
R10: 2025-07-31 | SY6501 | 辰星电力 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS | yes | yes | Y | N | watch | eligibility_ok=False; has_model_score=True; has_return=True
R11: 2025-07-31 | SY6722 | 北辰物流 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS;RULE_TRADABLE | yes | yes | N | N | inactive | eligibility_ok=False; has_model_score=True; has_return=True
R12: 2025-07-31 | SY6777 | 华晨综合 | IC_denominator;TopN_pool | industry_excluded | RULE_INDUSTRY | yes | yes | Y | N | active | eligibility_ok=False; has_model_score=True; has_return=True
R13: 2025-08-29 | SY6112 | 南港材料 | TopN_pool | missing_model_score | RULE_MISSING_MODEL_SCORE | yes | yes | Y | N | active | eligibility_ok=True; has_model_score=False; has_return=True
R14: 2025-08-29 | SY6355 | 渤海医械 | IC_denominator;TopN_pool | suspended | RULE_SUSPENDED | yes | yes | Y | Y | active | eligibility_ok=False; has_model_score=True; has_return=True
R15: 2025-08-29 | SY6501 | 辰星电力 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS | yes | yes | Y | N | watch | eligibility_ok=False; has_model_score=True; has_return=True
R16: 2025-08-29 | SY6999 | 西岭新材 | IC_denominator | missing_return | RULE_MISSING_RETURN | yes | no | Y | N | active | eligibility_ok=True; has_model_score=True; has_return=False
R17: 2025-08-29 | SY6722 | 北辰物流 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS;RULE_TRADABLE | yes | yes | N | N | inactive | eligibility_ok=False; has_model_score=True; has_return=True
R18: 2025-08-29 | SY6777 | 华晨综合 | IC_denominator;TopN_pool | industry_excluded | RULE_INDUSTRY | yes | yes | Y | N | active | eligibility_ok=False; has_model_score=True; has_return=True
R19: 2025-09-30 | SY6420 | 安澜消费 | TopN_pool | missing_model_score | RULE_MISSING_MODEL_SCORE | yes | yes | Y | N | active | eligibility_ok=True; has_model_score=False; has_return=True
R20: 2025-09-30 | SY6355 | 渤海医械 | IC_denominator;TopN_pool | suspended | RULE_SUSPENDED | yes | yes | Y | Y | active | eligibility_ok=False; has_model_score=True; has_return=True
R21: 2025-09-30 | SY6501 | 辰星电力 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS | yes | yes | Y | N | watch | eligibility_ok=False; has_model_score=True; has_return=True
R22: 2025-09-30 | SY6088 | 启明半导 | IC_denominator | missing_return | RULE_MISSING_RETURN | yes | no | Y | N | active | eligibility_ok=True; has_model_score=True; has_return=False
R23: 2025-09-30 | SY6722 | 北辰物流 | IC_denominator;TopN_pool | pool_status_not_active | RULE_POOL_STATUS;RULE_TRADABLE | yes | yes | N | N | inactive | eligibility_ok=False; has_model_score=True; has_return=True
R24: 2025-09-30 | SY6777 | 华晨综合 | IC_denominator;TopN_pool | industry_excluded | RULE_INDUSTRY | yes | yes | Y | N | active | eligibility_ok=False; has_model_score=True; has_return=True

## Sheet 4: summary
Dimensions: 24 rows x 5 columns
R1: summary_group | summary_key | metric_value | count | note
R2: testing_period | number_of_test_periods | 4 | 4 | From 2025-06-30 to 2025-09-30 inclusive
R3: ic_denominator | total_baseline_ic_numerator | 36 | 4 | Sum of baseline IC denominator counts across all test periods
R4: ic_denominator | total_model_ic_numerator | 33 | 4 | Sum of model IC denominator counts across all test periods
R5: rank_ic_statistics | baseline_mean | 0.327109 | 4 | Mean of baseline Rank IC across test periods
R6: rank_ic_statistics | baseline_sample_std | 0.384955 | 4 | Sample standard deviation of baseline Rank IC (ddof=1)
R7: rank_ic_statistics | baseline_ICIR | 0.849734 | 4 | Baseline ICIR = mean / sample_std
R8: rank_ic_statistics | model_mean | 0.446007 | 4 | Mean of model Rank IC across test periods
R9: rank_ic_statistics | model_sample_std | 0.594769 | 4 | Sample standard deviation of model Rank IC (ddof=1)
R10: rank_ic_statistics | model_ICIR | 0.749883 | 4 | Model ICIR = mean / sample_std
R11: positive_ic_ratio | baseline_positive_count | 4 | 4 | 4 out of 4 test periods had positive baseline Rank IC
R12: positive_ic_ratio | baseline_positive_ratio | 1 | 4 | Positive IC ratio = count(IC > 0) / total test periods
R13: positive_ic_ratio | model_positive_count | 3 | 4 | 3 out of 4 test periods had positive model Rank IC
R14: positive_ic_ratio | model_positive_ratio | 0.75 | 4 | Positive IC ratio = count(IC > 0) / total test periods
R15: topn_summary | total_topn_rows | 20 | 4 | Total TopN selections across all test periods (top_n=5)
R16: topn_summary | unique_stocks_selected | 10 | 20 | Number of unique symbols appearing in TopN selections
R17: exclusion_reason_distribution | pool_status_not_active | 8 | 5 | Count of exclusion records with primary reason 'pool_status_not_active'
R18: exclusion_reason_distribution | missing_return | 4 | 5 | Count of exclusion records with primary reason 'missing_return'
R19: exclusion_reason_distribution | suspended | 4 | 5 | Count of exclusion records with primary reason 'suspended'
R20: exclusion_reason_distribution | industry_excluded | 4 | 5 | Count of exclusion records with primary reason 'industry_excluded'
R21: exclusion_reason_distribution | missing_model_score | 3 | 5 | Count of exclusion records with primary reason 'missing_model_score'
R22: exclusion_scope_distribution | IC_denominator;TopN_pool | 16 | 3 | Count of exclusion records scoped to 'IC_denominator;TopN_pool'
R23: exclusion_scope_distribution | IC_denominator | 4 | 3 | Count of exclusion records scoped to 'IC_denominator'
R24: exclusion_scope_distribution | TopN_pool | 3 | 3 | Count of exclusion records scoped to 'TopN_pool'
