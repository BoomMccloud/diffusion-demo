{
  "metadata": {
    "case_id": "case_effective_sop_reconstruction_034",
    "as_of_date": "2026-07-15",
    "target_region": "华东二仓",
    "source_root": "input",
    "source_files_count": 10,
    "output_path": "output/effective_sop.json",
    "authority_order": [
      "regulator_notice",
      "signed_addendum",
      "base_sop",
      "faq_clarification"
    ],
    "excluded_statuses": [
      "archive",
      "draft"
    ],
    "current_sop_code": "QS-SOP-034",
    "source_docs_used": [
      "formal/base_sop_QS-SOP-034_v2.md",
      "notice/regulator_notice_NQI-2026-19.md",
      "addendum/signed_addendum_EAST-2026-04.md",
      "faq/FAQ_QS-SOP-034_2026-06.md",
      "appendix/appendix_A_roles.csv",
      "appendix/appendix_B_sampling_temperature_limits.csv",
      "appendix/appendix_C_deviation_matrix.csv",
      "appendix/appendix_D_cold_chain_handoff.csv",
      "archive/base_sop_QS-SOP-034_v1_archived.md",
      "archive/draft_addendum_EAST-2026-06_unsigned.md"
    ]
  },
  "effective_sections": [
    {
      "section_id": "S1",
      "title": "入库预约与批次接收",
      "steps": [
        {
          "step_id": "S1-STEP-1",
          "text": "供应商到货前至少 1 个工作日完成预约登记，记录采购单号、批号、预计到仓时段和温控要求。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "S1-STEP-2",
          "text": "收货员核对外箱批号、封签号、温度记录仪编号和运输交接单，异常项必须登记到批次接收记录。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "S1-STEP-3",
          "text": "未预约或批号不一致的货品先进入待判定区，不得直接并入可用库存。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        }
      ],
      "warnings": [
        {
          "warning_id": "S1-WARN-1",
          "text": "超过预约窗口 4 小时的到货批次需质控主管复核后才能继续接收。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md"
        }
      ],
      "tables": [
        "APP-A"
      ],
      "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
      "authority_level": "base_sop",
      "applicable_region": "全国（含华东二仓）",
      "replaced_steps": []
    },
    {
      "section_id": "S2",
      "title": "抽样判定与留样",
      "steps": [
        {
          "step_id": "S2-STEP-1",
          "text": "常规批次按 APP-B 的品类与箱数分层抽样，抽样记录必须关联采购单号和供应商批号。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "S2-STEP-2",
          "text": "华东二仓低温件抽样必须由仓储操作员与 QA 取样员双人见证，双签不得事后补录。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
          "authority_level": "signed_addendum"
        }
      ],
      "warnings": [],
      "tables": [
        "APP-B",
        "APP-A"
      ],
      "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
      "authority_level": "signed_addendum",
      "applicable_region": "华东二仓",
      "replaced_steps": [
        "BASE-S2.2"
      ]
    },
    {
      "section_id": "S3",
      "title": "温控偏差与隔离判定",
      "steps": [
        {
          "step_id": "S3-STEP-1",
          "text": "冷链批次到仓后读取温度记录仪，并把曲线截图绑定到批次记录。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        },
        {
          "step_id": "S3-STEP-2",
          "text": "截至 2026-07-15，任一温度探头出现 ≤2°C、>8°C 或记录断点超过 20 分钟时，批次立即进入 QA 隔离判定。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        },
        {
          "step_id": "S3-STEP-3",
          "text": "同一供应商 30 天内重复出现温控偏差时，放行前必须建立 CAPA 跟踪单；需放行的隔离批次必须同时取得 QA 负责人和法规联络人书面批准。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        }
      ],
      "warnings": [
        {
          "warning_id": "S3-WARN-1",
          "text": "不得采用 FAQ-Q4 的 45 分钟断点口径；监管通知 NQI-2026-19 已将阈值收紧为 20 分钟。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md"
        },
        {
          "warning_id": "S3-WARN-2",
          "text": "签署版区域附录中的加急放行条款在温控偏差场景下失效。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md"
        }
      ],
      "tables": [
        "APP-B"
      ],
      "source_doc": "notice/regulator_notice_NQI-2026-19.md",
      "authority_level": "regulator_notice",
      "applicable_region": "全国（含华东二仓）",
      "replaced_steps": [
        "BASE-S3.2",
        "ADD-EAST-S3.2"
      ]
    },
    {
      "section_id": "S4",
      "title": "标签复核与放行记录",
      "steps": [
        {
          "step_id": "S4-STEP-1",
          "text": "华东二仓冷链批次必须附 APP-D 冷链交接单，交接单缺项时不得进入放行复核。当班主管在同一班次内完成放行清单复核，并把复核记录绑定到批次接收记录。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
          "authority_level": "signed_addendum"
        },
        {
          "step_id": "S4-STEP-2",
          "text": "放行前扫描内部标签并与供应商批号、到货批号和留样编号逐项核对。",
          "source_doc": "formal/base_sop_QS-SOP-034_v2.md",
          "authority_level": "base_sop"
        }
      ],
      "warnings": [
        {
          "warning_id": "S4-WARN-1",
          "text": "缺少 APP-D 的冷链交接字段时，不得用聊天截图或邮件截屏替代。",
          "source_doc": "addendum/signed_addendum_EAST-2026-04.md"
        }
      ],
      "tables": [
        "APP-A"
      ],
      "source_doc": "addendum/signed_addendum_EAST-2026-04.md",
      "authority_level": "signed_addendum",
      "applicable_region": "华东二仓",
      "replaced_steps": [
        "BASE-S4.2"
      ]
    },
    {
      "section_id": "S5",
      "title": "异常升级与记录保存",
      "steps": [
        {
          "step_id": "S5-STEP-1",
          "text": "N1/N2 偏差须在下一个工作日内录入质量系统，并绑定批次 ID、供应商批号和责任岗位。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        },
        {
          "step_id": "S5-STEP-2",
          "text": "N3 偏差立即暂停相关批次流转，并在 2 小时内通知 QA 负责人、仓库经理和法规联络人。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md",
          "authority_level": "regulator_notice"
        }
      ],
      "warnings": [
        {
          "warning_id": "S5-WARN-1",
          "text": "归档旧版的 90 天记录保存期已失效；当前有效保存期按 APP-C 与监管通知执行。",
          "source_doc": "notice/regulator_notice_NQI-2026-19.md"
        }
      ],
      "tables": [
        "APP-C"
      ],
      "source_doc": "notice/regulator_notice_NQI-2026-19.md",
      "authority_level": "regulator_notice",
      "applicable_region": "全国（含华东二仓）",
      "replaced_steps": [
        "BASE-S5.1",
        "BASE-S5.2"
      ]
    }
  ],
  "inactive_steps": [
    {
      "step_id": "BASE-S3.2",
      "original_section": "S3",
      "inactive_reason": "被监管通知 NQI-2026-19 NOTICE-S3.1 取代；温控断点阈值从 30 分钟收紧为 20 分钟",
      "replaced_by": "S3-STEP-2",
      "source_doc": "formal/base_sop_QS-SOP-034_v2.md"
    },
    {
      "step_id": "ADD-EAST-S3.2",
      "original_section": "S3",
      "inactive_reason": "被监管通知 NQI-2026-19 覆盖；签署附录中 QA 经理单签加急放行条款在温控偏差场景下失效",
      "replaced_by": "S3-STEP-3",
      "source_doc": "addendum/signed_addendum_EAST-2026-04.md"
    },
    {
      "step_id": "BASE-S4.2",
      "original_section": "S4",
      "inactive_reason": "被签署附录 EAST-ADD-034-2026-04 ADD-EAST-S4.2/ADD-EAST-S4.3 取代；全国默认的双材料放行条件不适用于华东二仓冷链批次",
      "replaced_by": "S4-STEP-1",
      "source_doc": "formal/base_sop_QS-SOP-034_v2.md"
    },
    {
      "step_id": "BASE-S5.1",
      "original_section": "S5",
      "inactive_reason": "被监管通知 NQI-2026-19 NOTICE-S5.1/NOTICE-S5.2 取代；一般偏差 2 个工作日升级为 N1/N2 下一工作日 + N3 立即暂停",
      "replaced_by": "S5-STEP-1",
      "source_doc": "formal/base_sop_QS-SOP-034_v2.md"
    },
    {
      "step_id": "BASE-S5.2",
      "original_section": "S5",
      "inactive_reason": "被监管通知 NQI-2026-19 NOTICE-S5.3 取代；记录保存期从 180 天扩展至 540 天",
      "replaced_by": "S5-STEP-2",
      "source_doc": "formal/base_sop_QS-SOP-034_v2.md"
    },
    {
      "step_id": "ARCH-S5.1",
      "original_section": "S5 (v1.0)",
      "inactive_reason": "归档旧版 SOP v1.0 步骤；记录保存 90 天已失效，已被 v2.0 及监管通知取代",
      "replaced_by": "S5-STEP-2",
      "source_doc": "archive/base_sop_QS-SOP-034_v1_archived.md"
    },
    {
      "step_id": "FAQ-Q4",
      "original_section": "S3 (FAQ)",
      "inactive_reason": "FAQ 旧培训示例口径（45 分钟断点）被监管通知 NQI-2026-19 明确覆盖失效",
      "replaced_by": "S3-STEP-2",
      "source_doc": "faq/FAQ_QS-SOP-034_2026-06.md"
    }
  ],
  "appendix_bindings": [
    {
      "table_id": "APP-A",
      "title": "岗位与职责矩阵",
      "bound_sections": [
        "S1",
        "S2",
        "S4"
      ],
      "source_doc": "appendix/appendix_A_roles.csv",
      "authority_level": "base_sop",
      "binding_status": "active",
      "required_rows": [
        "WH-OP",
        "QA-L",
        "QA-MGR",
        "REG-LIAISON",
        "BG-DOC-CTRL",
        "BG-PROC-OWN"
      ],
      "binding_notes": "APP-A 定义各岗位在来料接收流程中的职责；inactive_archive 行（LEGACY-v1-WH-ASSIST、LEGACY-v1-QA-ASSIST）仅历史参考，不作为当前作业依据"
    },
    {
      "table_id": "APP-B",
      "title": "抽样与温控阈值表",
      "bound_sections": [
        "S2",
        "S3"
      ],
      "source_doc": "appendix/appendix_B_sampling_temperature_limits.csv",
      "authority_level": "regulator_notice",
      "binding_status": "active",
      "required_rows": [
        "B-SAMPLE-BASE",
        "B-SAMPLE-EAST",
        "B-TEMP-NOTICE"
      ],
      "binding_notes": "B-TEMP-NOTICE 行（regulator_notice 权威）覆盖温控断点阈值为 20 分钟；B-TEMP-BASE（30 分钟）标记 inactive_when_notice_applies；B-TEMP-OLD（45 分钟 FAQ 旧示例）标记 inactive_faq_example；APP-B 中的旧 FAQ 示例行不得作为当前温控断点阈值"
    },
    {
      "table_id": "APP-C",
      "title": "异常等级与升级时限表",
      "bound_sections": [
        "S5"
      ],
      "source_doc": "appendix/appendix_C_deviation_matrix.csv",
      "authority_level": "regulator_notice",
      "binding_status": "active",
      "required_rows": [
        "N1-ROUTINE",
        "N2-REPEAT-30D",
        "N3-LINE-STOP"
      ],
      "binding_notes": "APP-C 用于异常等级与升级时限判定；N2-REPEAT-30D 与 N3-LINE-STOP 行由监管通知 NQI-2026-19 引入作为升级判定依据；ARCH-KEEP-90 行标记 inactive_archive，90 天保存期已失效"
    },
    {
      "table_id": "APP-D",
      "title": "华东冷链交接字段表",
      "bound_sections": [
        "S4"
      ],
      "source_doc": "appendix/appendix_D_cold_chain_handoff.csv",
      "authority_level": "signed_addendum",
      "binding_status": "active",
      "required_rows": [
        "D-HANDOFF-01",
        "D-HANDOFF-02",
        "D-HANDOFF-03"
      ],
      "binding_notes": "APP-D 只适用于华东二仓冷链交接字段，不能错误绑定到温控隔离判定；交接单缺项时不得进入放行复核，不得用聊天截图或邮件截屏替代"
    }
  ],
  "summary": {
    "section_count": 5,
    "active_step_count": 13,
    "warning_count": 3,
    "section_table_reference_count": 6,
    "appendix_binding_count": 4,
    "inactive_step_count": 7,
    "notice_overridden_step_count": 4,
    "faq_clarification_count": 1,
    "archive_or_draft_excluded_count": 2,
    "source_documents_used_count": 10
  }
}
