# Text-first Judge evidence summary

- Deterministic verifier status: fail (87/113).
- Text-first Judge evidence ready: diagnostic only; Judge scoring must not compensate or override deterministic factual/package/safety/output-contract failures.
- Submitted PPTX selected for evidence extraction: `output/community_sustainability_workshop_deck.pptx`.
- Parsed slide count for text/style summaries: 11.
- Optional non-scoring contact-sheet method: deterministic OOXML shape/text thumbnail renderer.
- Optional public-reference thumbnail method: PIL thumbnail copy of public screenshot reference.
- Optional template contact-sheet method: deterministic OOXML shape/text thumbnail renderer.
- Failed deterministic checks: root_title_present, route_safety_constraints_present, energy_lighting_coordination_present, energy_cup_crosslink_present, energy_attachment_privacy_boundary_present, circular_repair_role_present, circular_prohibited_items_present, circular_visual_cards_present, nature_family_corner_present, nature_rainwater_safety_present, audience_shop_cup_packaging_present, timing_agenda_sequence_present, timing_rounds_break_boundary_present, followup_return_visit_boundary_present, prep_only_role_separation_present, optional_materials_filtered_present, near_duplicate_checklist_separation_present, source_relationship_reuse_link_present, source_relationship_audience_shops_to_cup_present, source_relationship_timing_to_route_present, source_relationship_timing_to_commitment_present, source_relationship_near_duplicate_warning_present, template_footer_or_page_marker_present, template_action_matrix_structure_present, template_layout_family_cues_present, screenshot_lane_role_proxy_present.
- Required scoring artifacts are text or structured summaries: slide_structure_summary.md, style_structure_summary.md, reference_structure_summary.md, template_structure_summary.md, and final_presentation_text.md.
- Optional image/contact-sheet markdown files, when present, are diagnostic context only and are not required scoring artifacts for REV-P8-004.
- Judge scope is limited to text-first hierarchy/section grouping, presentation-native chunking/readability, template placeholder cleanup, and style proxy continuity from parsed PPTX records.
- Judge must not score content facts, exact topic coverage/order/count, screenshot pixels, thumbnails, OCR, package parsing, PPTX validity, deterministic safety/private leakage, hidden gold, or private-source fidelity.
