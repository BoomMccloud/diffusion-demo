# Slide structure summary

Verifier-owned text/structure summary derived from submitted PPTX slide XML. This file is the scoring artifact for text-first hierarchy and readability Judge rubrics; it is not OCR, VLM, screenshot, hidden gold, or private-source evidence.

- Slide count in parsed submitted deck: 11
- Per-slide records include ordinal index, inferred text role, first extracted text run, text/shape/connector counts, and a truncated text excerpt.
- Use this summary to judge whether the deck has presentation-native hierarchy, section grouping, and chunking. Do not use it for exact factual/content coverage, exact order/count, or hidden expected structure.

## Per-slide structure records

### Slide 1
- inferred_text_role: audience_lane
- first_text_run: 社区低碳共创工坊
- cjk_count: 70
- char_count: 76
- shape_count: 6
- connector_count: 0
- text_excerpt: 社区低碳共创工坊 周末场地版 基于思维导图内容改造的正式演示文稿 聚焦居民可行动、舒适度和公共空间改善 本材料来源于工作坊思维导图，经整理后用于公众沟通

### Slide 2
- inferred_text_role: opening_or_context
- first_text_run: 为什么今天聊这个
- cjk_count: 131
- char_count: 175
- shape_count: 18
- connector_count: 0
- text_excerpt: 为什么今天聊这个 从本地观察出发，把问题转成小行动 先问一个低门槛问题：本周哪件小事最耗电？ 楼道灯常亮 • 持续照明 • 可检查开关时间 快递包装堆放 • 占用公共空间 • 可分类回收 雨天积水绕行 • 排水不畅 • 需关注安全 关键原则：用本地观察替代宏大口号，把问题转成今天能一起试的小行动。 社区低碳共创工坊 | 第 2 页 / 共 11 页

### Slide 3
- inferred_text_role: route_or_agenda
- first_text_run: 行动站 A：电费、舒适度与公共照明
- cjk_count: 156
- char_count: 206
- shape_count: 15
- connector_count: 0
- text_excerpt: 行动站 A：电费、舒适度与公共照明 同一主题里有居民行动、公共照明、预算边界和主持降温提示 家里先做 5 分钟检查 • 离家前看插座 • 空调模式不讲成账单诊断 • 冰箱温度贴纸可做小例子 公共区域注意事项 • 公共照明：先记现象，不承诺预算 • 有人追问省多少钱时怎么接 • 舒适度比数字更容易共识 注意：过细的电费折算只做问答备份；跑偏问题写到白板右下角。 社区低碳共创工坊 | 第 3 页 / 共 11 页

### Slide 4
- inferred_text_role: route_or_agenda
- first_text_run: 行动站 B：旧物循环与不能收清单
- cjk_count: 141
- char_count: 192
- shape_count: 16
- connector_count: 2
- text_excerpt: 行动站 B：旧物循环与不能收清单 旧物交换、维修角、隐私文件和清场去向交织在一起 登记：物品类别和状态 分区：可交换 / 待维修 / 先不收 收尾：无人领取物品去向 不能收清单 • 电池、药品、液体 • 带隐私信息的文件旧手机不上桌 • 志愿者只检查袋子，不拍照上传 维修角不是承诺修好——这句要讲清楚。 结束清场不要变成公开承诺。 社区低碳共创工坊 | 第 4 页 / 共 11 页

### Slide 5
- inferred_text_role: opening_or_context
- first_text_run: 谁会听到
- cjk_count: 159
- char_count: 195
- shape_count: 23
- connector_count: 0
- text_excerpt: 谁会听到 受众轴约束语言和版面，不等于最终章节列表 老年居民 字大、步骤少、不要扫码作为唯一入口 居民家庭 先讲本周能做的小动作 物业代表 别把预算承诺写在居民页 小店店主 愿意放回收箱，但担心清运 亲子家庭 观察任务而非指标 志愿者 现场协助任务不公开联系方式 同一材料要换不同说法：对居民说第一步，对协作者说边界，对志愿者说会后记录。 社区低碳共创工坊 | 第 5 页 / 共 11 页

### Slide 6
- inferred_text_role: opening_or_context
- first_text_run: 90 分钟 / 120 分钟两种走法
- cjk_count: 149
- char_count: 212
- shape_count: 19
- connector_count: 0
- text_excerpt: 90 分钟 / 120 分钟两种走法 时间轴帮助取舍，不能按分钟机械变成页序 90 分钟线 保留内容 • 只保留两个行动站和一张承诺卡 • 签到拖延超过8分钟，开场问题缩短 • 茶歇与材料补给只作为节奏提示 120 分钟线 额外选项 • 可加10分钟分组交换 • 亲子卡移到最后或备注 • 承诺墙前预留两分钟解释回访 注意：行动站两轮不一定都讲成两页；时间不够时灵活调整。 社区低碳共创工坊 | 第 6 页 / 共 11 页

### Slide 7
- inferred_text_role: route_or_agenda
- first_text_run: 安全、隐私和物料摆放
- cjk_count: 187
- char_count: 233
- shape_count: 5
- connector_count: 0
- text_excerpt: 安全、隐私和物料摆放 部分是居民需要听到的边界，部分只是现场准备 素材/话题 可以上屏 适合备注 需避免 个人电费账单 不展示 提醒遮住住址姓名 直接展示 儿童活动照片 集体照 单独留影说明 单独留影占位 雨天路线 室内路线 湿滑楼梯提醒 使用湿滑楼梯 物料箱位置 门口右侧 会后清点 填写个人信息 绿色家庭排名 不做排名 删除旧词提醒 排行榜说法 回访语言要和隐私原则一起处理：不收手机号、不排名放在同一逻辑里。 社区低碳共创工坊 | 第 7 页 / 共 11 页

### Slide 8
- inferred_text_role: route_or_agenda
- first_text_run: 30 天之后怎么知道有没有继续做
- cjk_count: 125
- char_count: 162
- shape_count: 19
- connector_count: 0
- text_excerpt: 30 天之后怎么知道有没有继续做 收束不是口号，要把承诺、回访和隐私边界连起来 30天行动清单 自愿打卡 回访问句草稿 不收手机号 公告栏三条变化 不比较个人 志愿者复盘会 会后记录 承诺→回访 隐私边界 下一次活动只给大致时间，不收报名电话。从行动站回到承诺墙形成闭环。 社区低碳共创工坊 | 第 8 页 / 共 11 页

### Slide 9
- inferred_text_role: route_or_agenda
- first_text_run: 场地布置与志愿者协作
- cjk_count: 134
- char_count: 165
- shape_count: 24
- connector_count: 0
- text_excerpt: 场地布置与志愿者协作 场地和志愿者信息有助于备注或附录，不应把内部排班表变成公众演示正文 物料箱 门口右侧 雨水演示 靠窗边 承诺墙 靠近出口 志愿者站位 现场口头确认 雨天路线 室内路线 无障碍通道 留给行动不便居民 场务电话占位不要填写个人信息；志愿者信息应作为备注或附录。 社区低碳共创工坊 | 第 9 页 / 共 11 页

### Slide 10
- inferred_text_role: opening_or_context
- first_text_run: 备选素材和附录，不一定上屏
- cjk_count: 151
- char_count: 187
- shape_count: 23
- connector_count: 0
- text_excerpt: 备选素材和附录，不一定上屏 材料池可帮助设计页面或备注，但不是每个素材都要进入主线 亲子观察卡（雨天版） 儿童少时可移到最后 纸板屋檐演示替代 雨天备用方案 外部案例标题 正式版改成本地表达 贴纸与粗头笔 物料清单项 物料箱清点清单 会后清点参考 旧海报缩略图 只提醒色调 可选材料按时间、受众和天气决定取舍，可删可并。 社区低碳共创工坊 | 第 10 页 / 共 11 页

### Slide 11
- inferred_text_role: route_or_agenda
- first_text_run: 模板旧页和改稿痕迹
- cjk_count: 169
- char_count: 220
- shape_count: 5
- connector_count: 0
- text_excerpt: 模板旧页和改稿痕迹 PPT模板里有可复用布局，也有旧日期、版本号和占位文案，需要清理而不是保留 项目 处理方式 备注 2024秋季活动旧页脚 请核对 旧日期、版本号、占位组织名 旧版“排行榜” 删掉 与不排名原则冲突 公开检查清单 区分主持清单 只差几个字易混 备课页 可删或转备注 别塞进公众正文 占位标题 改成本地表达 视觉参考只看结构色彩 局部参考图只看层级和分组，不照抄成页序。 社区低碳共创工坊 | 第 11 页 / 共 11 页

## Role distribution

- audience_lane: 1
- opening_or_context: 4
- route_or_agenda: 6
