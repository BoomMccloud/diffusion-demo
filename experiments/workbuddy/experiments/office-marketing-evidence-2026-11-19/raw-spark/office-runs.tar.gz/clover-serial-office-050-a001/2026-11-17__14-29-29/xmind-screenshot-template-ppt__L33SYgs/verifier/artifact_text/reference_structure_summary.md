# Public reference structure summary

Text-only, public-safe summary of the reference role for the Judge. This summarizes the public screenshot-style input at a high level without requiring screenshot pixels, OCR, thumbnails, exact geometry, hidden gold, or private-source context.

- The public reference should be treated as a mind-map/workshop-structure cue: central or section focus, grouped branches, route/lane relationships, optional/collapsed markers, and compact labels.
- Accept presentation-native translations such as overview maps, route/process slides, audience/timing lanes, grouped cards, action-station comparisons, timelines, checklists, and follow-up sections.
- Do not score exact content facts, exact topic coverage, exact slide order/count, package parsing, pixel similarity, or private-source fidelity.
- Public screenshot reference file present: True.
