# Public template structure summary

Text-only, public-safe summary of template style roles derived from the public PPTX template parser. This is a style/placeholder reference for Judge rubrics, not hidden gold or a requirement to preserve exact OOXML internals.

- Public template style family: green/natural palette, cream/green background treatment, rounded card/group motifs, footer or page-marker conventions, section/tag/card roles, and clean community-workshop tone.
- Template placeholders/sample rows/instructions must be replaced by submitted final content; Judge may flag obvious retained placeholder text from final presentation text.
- Do not require exact object IDs, masters, slide layouts, theme parts, placeholder identifiers, screenshot pixels, or hidden package internals.
- Parsed public template slide count: 8
- Parsed public template color sample: 24342B, 2F6472, 35523F, 3F6B4A, 5A4C7D, 6AA56B, 7A776E, A0642E, B65B4A, D9D4C8, E8F4F7, EAF4E5, F0ECF7, F4F2EC, F6F1E6, FBF0DF, FCE7DD, FFF8E7, FFFDF7, FFFFFF
- Parsed public template top geometries: roundRect=108, rect=35, line=18
