# Style structure summary

Verifier-owned style proxy summary derived from parsed submitted PPTX OOXML records. This file supports text-first Judge assessment of template-style continuity without requiring rendered thumbnails, pixel matching, OCR, hidden gold, or private-source evidence.

- Parsed slide count: 11
- Total shape count: 173
- Total connector count: 2
- Distinct parsed colors: 29
- Parsed color set sample: 000000, 0000FF, 1F497D, 2F6472, 333333, 35523F, 4BACC6, 4F81BD, 5A4C7D, 666666, 6AA56B, 800080, 8064A2, 9BBB59, A0642E, B65B4A, C0504D, D9D4C8, E8F4F7, EAF4E5
- Top geometry counts: rect=131, roundRect=46, line=2, ellipse=1
- External relationship count: 0
- Use these style proxies only for continuity/coherence judgment. Do not require exact OOXML object IDs, exact master/layout reuse, exact theme parts, or pixel-perfect colors.

## Per-slide style proxies

### Slide 1
- shape_count: 6
- connector_count: 0
- text-bearing_shape_count: 4
- fills_sample: 333333, 35523F, 666666, EAF4E5, FFFDF7, FFFFFF
- geometry_counts_sample: rect=6

### Slide 2
- shape_count: 18
- connector_count: 0
- text-bearing_shape_count: 14
- fills_sample: 333333, 35523F, 666666, 6AA56B, EAF4E5, FFF8E7
- geometry_counts_sample: rect=14, roundRect=4

### Slide 3
- shape_count: 15
- connector_count: 0
- text-bearing_shape_count: 12
- fills_sample: 333333, 35523F, 666666, A0642E, E8F4F7, EAF4E5, FFF8E7
- geometry_counts_sample: rect=12, roundRect=3

### Slide 4
- shape_count: 16
- connector_count: 2
- text-bearing_shape_count: 11
- fills_sample: 333333, 35523F, 666666, 6AA56B, E8F4F7, EAF4E5, F4F2EC, FCE7DD, FFF8E7
- geometry_counts_sample: rect=11, roundRect=5, line=2

### Slide 5
- shape_count: 23
- connector_count: 0
- text-bearing_shape_count: 16
- fills_sample: 333333, 35523F, 666666, 6AA56B, EAF4E5, FFF8E7
- geometry_counts_sample: rect=16, roundRect=7

### Slide 6
- shape_count: 19
- connector_count: 0
- text-bearing_shape_count: 14
- fills_sample: 333333, 35523F, 666666, 6AA56B, A0642E, EAF4E5, FBF0DF, FFF8E7, FFFFFF
- geometry_counts_sample: rect=14, roundRect=5

### Slide 7
- shape_count: 5
- connector_count: 0
- text-bearing_shape_count: 4
- fills_sample: 333333, 35523F, 666666, B65B4A, FFF8E7
- geometry_counts_sample: rect=4, roundRect=1

### Slide 8
- shape_count: 19
- connector_count: 0
- text-bearing_shape_count: 13
- fills_sample: 333333, 35523F, 666666, E8F4F7, EAF4E5, F0ECF7, F4F2EC, FFF8E7, FFFFFF
- geometry_counts_sample: rect=13, roundRect=5, ellipse=1

### Slide 9
- shape_count: 24
- connector_count: 0
- text-bearing_shape_count: 16
- fills_sample: 333333, 35523F, 666666, A0642E, EAF4E5, F4F2EC, FFF8E7
- geometry_counts_sample: rect=16, roundRect=8

### Slide 10
- shape_count: 23
- connector_count: 0
- text-bearing_shape_count: 16
- fills_sample: 333333, 35523F, 666666, A0642E, E8F4F7, EAF4E5, F0ECF7, F4F2EC, FBF0DF, FCE7DD
- geometry_counts_sample: rect=16, roundRect=7

### Slide 11
- shape_count: 5
- connector_count: 0
- text-bearing_shape_count: 4
- fills_sample: 333333, 35523F, 666666, A0642E, FFF8E7
- geometry_counts_sample: rect=4, roundRect=1
