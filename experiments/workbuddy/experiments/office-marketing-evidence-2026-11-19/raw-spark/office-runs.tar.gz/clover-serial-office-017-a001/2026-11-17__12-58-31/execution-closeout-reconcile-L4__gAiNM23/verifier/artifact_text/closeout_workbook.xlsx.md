# Workbook: closeout_workbook.xlsx

## Sheet 1: execution_lifecycle
Dimensions: 35 rows x 15 columns
R1: lifecycle_id | account_id | portfolio_id | symbol | side | order_ids | exec_ids | final_state | executed_qty | avg_price | cash_impact | trade_date | settle_date | lifecycle_diagnosis | key_used
R2: AC-3107-OMS-KQ | AC-3107 | G1 | 688201 | BUY | OMS-KQ | EVM-MRA|EVN-LTV|EVP-XQH | FILLED | 1200 | 42.3125 | -50775 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R3: AC-3107-OMS-VR | AC-3107 | G1 | 688201 | BUY | OMS-VR | EVQ-ATE | PENDING | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | pending | False
R4: AC-3107-OMS-VRR | AC-3107 | G1 | 688201 | BUY | OMS-VRR|OMS-VR | EVR-BJM|EVS-CKP|EVT-DQW | FILLED | 1000 | 42.52 | -42520 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R5: AC-4820-OMS-HC | AC-4820 | G2 | 600519 | SELL | OMS-HC | EVA-FQP|EVB-NKF|EVC-HCA | PARTIAL_WITH_REMAINING | 300 | 1512.2 | 453660 | 2026-06-10 00:00:00 | 2026-06-13 00:00:00 | 300.0 shares remain | False
R6: AC-4820-OMS-XP | AC-4820 | G2 | 600519 | SELL | OMS-XP | EVD-HSA|EVE-YCN|EVF-PXA | FILLED | 200 | 1511.7 | 302340 | 2026-06-10 00:00:00 | 2026-06-13 00:00:00 | fully executed | False
R7: AC-6684-OMS-GN | AC-6684 | G2 | 159915 | BUY | OMS-GN | EVX-WDB|EVY-AVF|EVZ-FDN | FILLED | 3600 | 2.2146 | -7972.6 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R8: AC-6684-OMS-JY | AC-6684 | G2 | 601318 | SELL | OMS-JY | EWA-ZKC|EWB-FDN | FILLED | 600 | 48.62 | 29172 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R9: AC-7712-OMS-FA | AC-7712 | G2 | 333 | BUY | OMS-FA | EVG-JXE|EVH-UMC | FILLED | 1500 | 57.8 | -86700 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R10: AC-7712-OMS-ME | AC-7712 | G2 | 333 | BUY | OMS-ME | EVI-PNZ | PENDING | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | pending | False
R11: AC-7712-OMS-MEC | AC-7712 | G2 | 333 | BUY | OMS-MEC|OMS-ME | EVJ-CGA|EVK-STA | CANCELLED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | cancelled | False
R12: AC-8266-OMS-NT | AC-8266 | G3 | 300750 | SELL | OMS-NT | EVP-DFR | PENDING | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | pending | False
R13: AC-8266-OMS-NTR | AC-8266 | G3 | 300750 | SELL | OMS-NTR|OMS-NT | EVQ-RQL|EVR-AKC|EVS-RQL | FILLED | 650 | 214.02 | 139113 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R14: AC-8266-OMS-QL | AC-8266 | G3 | 300750 | SELL | OMS-QL | EVL-SHB|EVO-VLK | FILLED | 900 | 213.6 | 192240 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | fully executed | False
R15: AC-8266-OMS-QLC | AC-8266 | G3 | 300750 | SELL | OMS-QLC|OMS-QL | EVM-CXL|EVN-RJQ | CANCELLED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | cancelled | False
R16: AC-9055-OMS-BD | AC-9055 | G3 | 510300 | SELL | OMS-BD | EVV-VMW|EVW-GRS | PENDING | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | pending | False
R17: AC-9055-OMS-WS | AC-9055 | G3 | 510300 | BUY | OMS-WS | EVT-TUY|EVU-EHP | FILLED | 5000 | 4.128 | -20640 | 2026-06-10 00:00:00 | 2026-06-12 00:00:00 | fully executed | False
R18: AC-E1002-OMS-HX-TD | AC-E1002 | GX | 510300 | SELL | OMS-HX-TD | EWR-HX-TD | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R19: AC-E1015-OMS-HX-UF | AC-E1015 | GX | 588000 | BUY | OMS-HX-UF | EWR-HX-UF | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R20: AC-E1028-OMS-HX-WG | AC-E1028 | GX | 300750 | SELL | OMS-HX-WG | EWR-HX-WG | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R21: AC-E1041-OMS-HX-YL | AC-E1041 | GX | 512100 | BUY | OMS-HX-YL | EWR-HX-YL | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R22: AC-E1054-OMS-HX-ZP | AC-E1054 | GX | 333 | SELL | OMS-HX-ZP | EWR-HX-ZP | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R23: AC-E833-OMS-HX-VA | AC-E833 | GX | 601318 | BUY | OMS-HX-VA | EWR-HX-VA | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R24: AC-E846-OMS-HX-XD | AC-E846 | GX | 600519 | SELL | OMS-HX-XD | EWR-HX-XD | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R25: AC-E859-OMS-HX-ZE | AC-E859 | GX | 159915 | BUY | OMS-HX-ZE | EWR-HX-ZE | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R26: AC-E872-OMS-HX-BH | AC-E872 | GX | 688201 | SELL | OMS-HX-BH | EWR-HX-BH | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R27: AC-E885-OMS-HX-CJ | AC-E885 | GX | 510300 | BUY | OMS-HX-CJ | EWR-HX-CJ | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R28: AC-E898-OMS-HX-FL | AC-E898 | GX | 588000 | SELL | OMS-HX-FL | EWR-HX-FL | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R29: AC-E911-OMS-HX-GN | AC-E911 | GX | 300750 | BUY | OMS-HX-GN | EWR-HX-GN | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R30: AC-E924-OMS-HX-KP | AC-E924 | GX | 512100 | SELL | OMS-HX-KP | EWR-HX-KP | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R31: AC-E937-OMS-HX-LR | AC-E937 | GX | 333 | BUY | OMS-HX-LR | EWR-HX-LR | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R32: AC-E950-OMS-HX-MS | AC-E950 | GX | 601318 | SELL | OMS-HX-MS | EWR-HX-MS | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R33: AC-E963-OMS-HX-NW | AC-E963 | GX | 600519 | BUY | OMS-HX-NW | EWR-HX-NW | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False
R34: AC-E976-OMS-HX-QY | AC-E976 | GX | 159915 | SELL | OMS-HX-QY | EWR-HX-QY | UNKNOWN | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | no recognized events | False
R35: AC-E989-OMS-HX-RC | AC-E989 | GX | 688201 | BUY | OMS-HX-RC | EWR-HX-RC | ARCHIVED | 0 | 0 | 0 | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | historical record archived | False

## Sheet 2: confirmation_reconcile
Dimensions: 28 rows x 15 columns
R1: confirmation_id | account_id | symbol | side | trade_date | settle_date | confirmed_qty | confirmed_price | execution_qty | execution_avg_price | qty_delta | net_cash_delta | status | linked_exec_ids | evidence_note
R2: TRDDET | AC-9055 | 510300 | BUY | 2026-06-10 00:00:00 | 2026-06-12 00:00:00 | 5000 | 4.129 | 5000 | 4.128 | 0 | 12.11 | OK | AC-9055-OMS-WS | 
R3: TRDDET | AC-7712 | 333 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 1500 | 57.82 | 1500 | 57.8 | 0 | 59.49 | OK | AC-7712-OMS-FA | 
R4: TRDDET | AC-3107 | 688201 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 1200 | 42.336 | 1200 | 42.3125 | 0 | 45.47 | OK | AC-3107-OMS-KQ | 
R5: TRDDET | AC-3107 | 688201 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 1000 | 42.528 | 1000 | 42.52 | 0 | 22.46 | OK | AC-3107-OMS-VRR | 
R6: TRDDET | AC-6684 | 159915 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 1600 | 2.214 | 3600 | 2.2146 | 2000 | -4425.7 | MISMATCH | AC-6684-OMS-GN | 
R7: TRDDET | AC-6684 | 159915 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 2000 | 2.216 | 0 | 0 | -2000 | 4436.5 | NO_EXEC_MATCH |  | No lifecycle matched within tolerances (qty=2000.0, price=2.216)
R8: TRDDET | AC-6684 | 601318 | SELL | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 600 | 48.62 | 600 | 48.62 | 0 | 10.51 | OK | AC-6684-OMS-JY | 
R9: TRDDET | AC-4820 | 600519 | SELL | 2026-06-10 00:00:00 | 2026-06-12 00:00:00 | 300 | 1512.2 | 300 | 1512.2 | 0 | 163.32 | MISMATCH | AC-4820-OMS-HC | 
R10: TRDDET | AC-4820 | 600519 | SELL | 2026-06-10 00:00:00 | 2026-06-13 00:00:00 | 200 | 1509.45 | 0 | 0 | -200 | -301781.32 | NO_EXEC_MATCH |  | No lifecycle matched within tolerances (qty=200.0, price=1509.45)
R11: TRDDET | AC-C1009 | 300750 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 880 | 25.89 | 0 | 0 | -880 | 22791.02 | NO_EXEC_MATCH |  | Account AC-C1009 has no execution lifecycle data (likely test/historical account)
R12: TRDDET | AC-C1020 | 159915 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 950 | 27.8 | 0 | 0 | -950 | -26400.46 | NO_EXEC_MATCH |  | Account AC-C1020 has no execution lifecycle data (likely test/historical account)
R13: TRDDET | AC-C1031 | 512100 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 1020 | 29.71 | 0 | 0 | -1020 | 30314.5 | NO_EXEC_MATCH |  | Account AC-C1031 has no execution lifecycle data (likely test/historical account)
R14: TRDDET | AC-C1042 | 688201 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 1090 | 31.62 | 0 | 0 | -1090 | -34453.39 | NO_EXEC_MATCH |  | Account AC-C1042 has no execution lifecycle data (likely test/historical account)
R15: TRDDET | AC-C1053 | 333 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 1160 | 33.53 | 0 | 0 | -1160 | 38908.02 | NO_EXEC_MATCH |  | Account AC-C1053 has no execution lifecycle data (likely test/historical account)
R16: TRDDET | AC-C1064 | 510300 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 1230 | 35.44 | 0 | 0 | -1230 | -43575.51 | NO_EXEC_MATCH |  | Account AC-C1064 has no execution lifecycle data (likely test/historical account)
R17: TRDDET | AC-C1075 | 601318 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 1300 | 37.35 | 0 | 0 | -1300 | 48571.51 | NO_EXEC_MATCH |  | Account AC-C1075 has no execution lifecycle data (likely test/historical account)
R18: TRDDET | AC-C1086 | 588000 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 1370 | 39.26 | 0 | 0 | -1370 | -53766.84 | NO_EXEC_MATCH |  | Account AC-C1086 has no execution lifecycle data (likely test/historical account)
R19: TRDDET | AC-C921 | 159915 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 320 | 10.61 | 0 | 0 | -320 | 3399.7 | NO_EXEC_MATCH |  | Account AC-C921 has no execution lifecycle data (likely test/historical account)
R20: TRDDET | AC-C932 | 512100 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 390 | 12.52 | 0 | 0 | -390 | -4878.2 | NO_EXEC_MATCH |  | Account AC-C932 has no execution lifecycle data (likely test/historical account)
R21: TRDDET | AC-C943 | 688201 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 460 | 14.43 | 0 | 0 | -460 | 6642.3 | NO_EXEC_MATCH |  | Account AC-C943 has no execution lifecycle data (likely test/historical account)
R22: TRDDET | AC-C954 | 333 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 530 | 16.34 | 0 | 0 | -530 | -8655.53 | NO_EXEC_MATCH |  | Account AC-C954 has no execution lifecycle data (likely test/historical account)
R23: TRDDET | AC-C965 | 510300 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 600 | 18.25 | 0 | 0 | -600 | 10954.5 | NO_EXEC_MATCH |  | Account AC-C965 has no execution lifecycle data (likely test/historical account)
R24: TRDDET | AC-C976 | 601318 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 670 | 20.16 | 0 | 0 | -670 | -13502.05 | NO_EXEC_MATCH |  | Account AC-C976 has no execution lifecycle data (likely test/historical account)
R25: TRDDET | AC-C987 | 588000 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 740 | 22.07 | 0 | 0 | -740 | 16337.49 | NO_EXEC_MATCH |  | Account AC-C987 has no execution lifecycle data (likely test/historical account)
R26: TRDDET | AC-C998 | 600519 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 810 | 23.98 | 0 | 0 | -810 | -19416.7 | NO_EXEC_MATCH |  | Account AC-C998 has no execution lifecycle data (likely test/historical account)
R27: TRDDET | AC-8266 | 300750 | SELL | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 900 | 213.6 | 900 | 213.6 | 0 | 69.21 | OK | AC-8266-OMS-QL | 
R28: TRDDET | AC-8266 | 300750 | SELL | 2026-06-09 00:00:00 | 2026-06-13 00:00:00 | 650 | 214.04 | 650 | 214.02 | 0 | 37.09 | OK | AC-8266-OMS-NTR | 

## Sheet 3: allocation_reconcile
Dimensions: 29 rows x 17 columns
R1: allocation_unit_id | account_id | symbol | side | trade_date | settle_date | expected_alloc_qty | reported_alloc_qty | expected_net_money | reported_net_money | qty_delta | net_delta | matching_level | linked_lifecycle_ids | status | supersession_note | evidence_note
R2: IA-NAA | AC-3107 | 688201 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 0 | 900 | 0 | -38106 | -900 | 38106 | none |  | NO_EXEC_MATCH |  | No lifecycle matched within tolerances (qty=900.0, price=42.34)
R3: IA-NAB | AC-3927 | 688201 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 0 | 300 | 0 | -12702 | -300 | 12702 | none |  | NO_EXEC_MATCH |  | Account AC-3927 has no execution lifecycle data (likely test/historical account)
R4: IA-NAC | AC-3107 | 688201 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 0 | 600 | 0 | -25512 | -600 | 25512 | none |  | NO_EXEC_MATCH |  | No lifecycle matched within tolerances (qty=600.0, price=42.52)
R5: IA-NAD | AC-5178 | 688201 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 0 | 500 | 0 | -21260 | -500 | 21260 | none |  | NO_EXEC_MATCH |  | Account AC-5178 has no execution lifecycle data (likely test/historical account)
R6: IA-NAF | AC-4820 | 600519 | SELL | 2026-06-10 00:00:00 | 2026-06-13 00:00:00 | 0 | 200 | 0 | 301880 | -200 | -301880 | none |  | NO_EXEC_MATCH |  | No lifecycle matched within tolerances (qty=200.0, price=1509.4)
R7: IA-NAG | AC-7712 | 333 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 1500 | 1500 | -86700 | -86700 | 0 | 0 | individual | AC-7712-OMS-FA | OK |  | 
R8: IA-NAH | AC-8266 | 300750 | SELL | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 900 | 900 | 192240 | 192240 | 0 | 0 | individual | AC-8266-OMS-QL | OK |  | 
R9: IA-NAK | AC-8266 | 300750 | SELL | 2026-06-09 00:00:00 | 2026-06-13 00:00:00 | 587.93 | 550 | 125685.62 | 117711 | 37.93 | 7974.62 | aggregate | AC-8266-OMS-NT|AC-8266-OMS-NTR|AC-8266-OMS-QL|AC-8266-OMS-QLC | OK_AGGREGATE | supersedes ALR-ZHE | Aggregate match: total allocated qty=1450 vs total executed qty=1550
R10: IA-NAL | AC-9055 | 510300 | BUY | 2026-06-10 00:00:00 | 2026-06-12 00:00:00 | 5000 | 5000 | -20640 | -20640 | 0 | 0 | individual | AC-9055-OMS-WS | OK |  | 
R11: IA-NAN | AC-6684 | 159915 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 0 | 2200 | 0 | -4873 | -2200 | 4873 | none |  | NO_EXEC_MATCH |  | No lifecycle matched within tolerances (qty=2200.0, price=2.215)
R12: IA-NAO | AC-6891 | 159915 | BUY | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 0 | 1400 | 0 | -3101 | -1400 | 3101 | none |  | NO_EXEC_MATCH |  | Account AC-6891 has no execution lifecycle data (likely test/historical account)
R13: IA-NAP | AC-6684 | 601318 | SELL | 2026-06-09 00:00:00 | 2026-06-11 00:00:00 | 600 | 600 | 29172 | 29172 | 0 | 0 | individual | AC-6684-OMS-JY | OK |  | 
R14: IA-ROLL-NU | AC-A659 | 688201 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 350 | 0 | -3825.5 | -350 | 3825.5 | none |  | NO_EXEC_MATCH |  | Account AC-A659 has no execution lifecycle data (likely test/historical account)
R15: IA-ROLL-OV | AC-A678 | 159915 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 440 | 0 | 5482.4 | -440 | -5482.4 | none |  | NO_EXEC_MATCH |  | Account AC-A678 has no execution lifecycle data (likely test/historical account)
R16: IA-ROLL-PW | AC-A697 | 600519 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 530 | 0 | -7414.7 | -530 | 7414.7 | none |  | NO_EXEC_MATCH |  | Account AC-A697 has no execution lifecycle data (likely test/historical account)
R17: IA-ROLL-QX | AC-A716 | 601318 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 620 | 0 | 9622.4 | -620 | -9622.4 | none |  | NO_EXEC_MATCH |  | Account AC-A716 has no execution lifecycle data (likely test/historical account)
R18: IA-ROLL-RY | AC-A735 | 333 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 710 | 0 | -12105.5 | -710 | 12105.5 | none |  | NO_EXEC_MATCH |  | Account AC-A735 has no execution lifecycle data (likely test/historical account)
R19: IA-ROLL-SZ | AC-A754 | 512100 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 800 | 0 | 14864 | -800 | -14864 | none |  | NO_EXEC_MATCH |  | Account AC-A754 has no execution lifecycle data (likely test/historical account)
R20: IA-ROLL-TA | AC-A773 | 300750 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 890 | 0 | -17897.9 | -890 | 17897.9 | none |  | NO_EXEC_MATCH |  | Account AC-A773 has no execution lifecycle data (likely test/historical account)
R21: IA-ROLL-UC | AC-A792 | 588000 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 980 | 0 | 21207.2 | -980 | -21207.2 | none |  | NO_EXEC_MATCH |  | Account AC-A792 has no execution lifecycle data (likely test/historical account)
R22: IA-ROLL-VD | AC-A811 | 510300 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1070 | 0 | -24791.9 | -1070 | 24791.9 | none |  | NO_EXEC_MATCH |  | Account AC-A811 has no execution lifecycle data (likely test/historical account)
R23: IA-ROLL-WE | AC-A830 | 688201 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1160 | 0 | 28652 | -1160 | -28652 | none |  | NO_EXEC_MATCH |  | Account AC-A830 has no execution lifecycle data (likely test/historical account)
R24: IA-ROLL-XF | AC-A849 | 159915 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1250 | 0 | -32787.5 | -1250 | 32787.5 | none |  | NO_EXEC_MATCH |  | Account AC-A849 has no execution lifecycle data (likely test/historical account)
R25: IA-ROLL-YG | AC-A868 | 600519 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1340 | 0 | 37198.4 | -1340 | -37198.4 | none |  | NO_EXEC_MATCH |  | Account AC-A868 has no execution lifecycle data (likely test/historical account)
R26: IA-ROLL-ZH | AC-A887 | 601318 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1430 | 0 | -41884.7 | -1430 | 41884.7 | none |  | NO_EXEC_MATCH |  | Account AC-A887 has no execution lifecycle data (likely test/historical account)
R27: IA-ROLL-BJ | AC-A906 | 333 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1520 | 0 | 46846.4 | -1520 | -46846.4 | none |  | NO_EXEC_MATCH |  | Account AC-A906 has no execution lifecycle data (likely test/historical account)
R28: IA-ROLL-CL | AC-A925 | 512100 | BUY | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1610 | 0 | -52083.5 | -1610 | 52083.5 | none |  | NO_EXEC_MATCH |  | Account AC-A925 has no execution lifecycle data (likely test/historical account)
R29: IA-ROLL-DM | AC-A944 | 300750 | SELL | 2026-06-08 00:00:00 | 2026-06-10 00:00:00 | 0 | 1700 | 0 | 57596 | -1700 | -57596 | none |  | NO_EXEC_MATCH |  | Account AC-A944 has no execution lifecycle data (likely test/historical account)

## Sheet 4: position_close
Dimensions: 24 rows x 10 columns
R1: account_id | portfolio_id | symbol | opening_qty | execution_delta_qty | allocation_delta_qty | expected_closing_qty | statement_closing_qty | break_type | evidence_note
R2: AC-3107 | G1 | 688201 | 1960 | 2200 | 0 | 4160 | 3460 | BREAK | diff=700; exec_delta=2200 + opening=1960
R3: AC-3927 | G1 | 688201 | 120 | 0 | 300 | 420 | 420 | MATCH | position reconciles
R4: AC-4820 | G2 | 600519 | 890 | -500 | -700 | -310 | 690 | BREAK | diff=-1000; exec_delta=-500 + alloc_delta=-700 + opening=890
R5: AC-5178 | G2 | 688201 | 180 | 0 | 500 | 680 | 680 | MATCH | position reconciles
R6: AC-6684 | G2 | 159915 | 1980 | 3600 | 0 | 5580 | 5600 | BREAK | diff=-20; exec_delta=3600 + opening=1980
R7: AC-6684 | G2 | 601318 | 2340 | -600 | -1200 | 540 | 1740 | BREAK | diff=-1200; exec_delta=-600 + alloc_delta=-1200 + opening=2340
R8: AC-6891 | G2 | 159915 | 0 | 0 | 1400 | 1400 | 1400 | MATCH | position reconciles
R9: AC-7436 | G2 | 300750 | 0 | 0 | 0 | 0 | 0 | MATCH | position reconciles
R10: AC-7712 | G2 | 333 | 1770 | 1500 | 0 | 3270 | 3270 | MATCH | position reconciles
R11: AC-8266 | G3 | 300750 | 2810 | -1550 | -4550 | -3290 | 1360 | BREAK | diff=-4650; exec_delta=-1550 + alloc_delta=-4550 + opening=2810
R12: AC-9055 | G3 | 510300 | 3100 | 5000 | 0 | 8100 | 8100 | MATCH | position reconciles
R13: AC-P1010 | GX | 333 | 950 | 0 | 0 | 950 | 1180 | BREAK | diff=-230; opening=950
R14: AC-P1033 | GX | 588000 | 1005 | 0 | 0 | 1005 | 1240 | BREAK | diff=-235; opening=1005
R15: AC-P1056 | GX | 159915 | 1060 | 0 | 0 | 1060 | 1300 | BREAK | diff=-240; opening=1060
R16: AC-P803 | GX | 333 | 455 | 0 | 0 | 455 | 640 | BREAK | diff=-185; opening=455
R17: AC-P826 | GX | 588000 | 510 | 0 | 0 | 510 | 700 | BREAK | diff=-190; opening=510
R18: AC-P849 | GX | 159915 | 565 | 0 | 0 | 565 | 760 | BREAK | diff=-195; opening=565
R19: AC-P872 | GX | 333 | 620 | 0 | 0 | 620 | 820 | BREAK | diff=-200; opening=620
R20: AC-P895 | GX | 588000 | 675 | 0 | 0 | 675 | 880 | BREAK | diff=-205; opening=675
R21: AC-P918 | GX | 159915 | 730 | 0 | 0 | 730 | 940 | BREAK | diff=-210; opening=730
R22: AC-P941 | GX | 333 | 785 | 0 | 0 | 785 | 1000 | BREAK | diff=-215; opening=785
R23: AC-P964 | GX | 588000 | 840 | 0 | 0 | 840 | 1060 | BREAK | diff=-220; opening=840
R24: AC-P987 | GX | 159915 | 895 | 0 | 0 | 895 | 1120 | BREAK | diff=-225; opening=895

## Sheet 5: exceptions
Dimensions: 72 rows x 7 columns
R1: exception_id | source_layer | primary_cause | contributing_causes | severity | affected_ids | evidence_note
R2: EXC-0001 | execution_lifecycle | Order not fully executed | Final state: CANCELLED | INFO | AC-7712-OMS-MEC | Order ended in CANCELLED state
R3: EXC-0002 | execution_lifecycle | Order not fully executed | Final state: CANCELLED | INFO | AC-8266-OMS-QLC | Order ended in CANCELLED state
R4: EXC-0003 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E1002-OMS-HX-TD | State history unclear for AC-E1002-OMS-HX-TD
R5: EXC-0004 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E1028-OMS-HX-WG | State history unclear for AC-E1028-OMS-HX-WG
R6: EXC-0005 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E1054-OMS-HX-ZP | State history unclear for AC-E1054-OMS-HX-ZP
R7: EXC-0006 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E846-OMS-HX-XD | State history unclear for AC-E846-OMS-HX-XD
R8: EXC-0007 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E872-OMS-HX-BH | State history unclear for AC-E872-OMS-HX-BH
R9: EXC-0008 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E898-OMS-HX-FL | State history unclear for AC-E898-OMS-HX-FL
R10: EXC-0009 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E924-OMS-HX-KP | State history unclear for AC-E924-OMS-HX-KP
R11: EXC-0010 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E950-OMS-HX-MS | State history unclear for AC-E950-OMS-HX-MS
R12: EXC-0011 | execution_lifecycle | Unknown final state | No recognized event pattern | HIGH | AC-E976-OMS-HX-QY | State history unclear for AC-E976-OMS-HX-QY
R13: EXC-0012 | confirmation_reconcile | Quantity or cash mismatch | qty_delta=2000; net_cash_delta=-4425.70 | MEDIUM | TRDDET | Confirmed qty=1600 vs exec qty=3600
R14: EXC-0013 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R15: EXC-0014 | confirmation_reconcile | Quantity or cash mismatch | qty_delta=0; net_cash_delta=163.32 | MEDIUM | TRDDET | Confirmed qty=300 vs exec qty=300
R16: EXC-0015 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R17: EXC-0016 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R18: EXC-0017 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R19: EXC-0018 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R20: EXC-0019 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R21: EXC-0020 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R22: EXC-0021 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R23: EXC-0022 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R24: EXC-0023 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R25: EXC-0024 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R26: EXC-0025 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R27: EXC-0026 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R28: EXC-0027 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R29: EXC-0028 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R30: EXC-0029 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R31: EXC-0030 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R32: EXC-0031 | confirmation_reconcile | No matching execution found |  | MEDIUM | TRDDET | Conf TRDDET has no corresponding execution
R33: EXC-0032 | allocation_reconcile | No matching execution found |  | LOW | IA-NAA | Alloc IA-NAA has no corresponding execution
R34: EXC-0033 | allocation_reconcile | No matching execution found |  | LOW | IA-NAB | Alloc IA-NAB has no corresponding execution
R35: EXC-0034 | allocation_reconcile | No matching execution found |  | LOW | IA-NAC | Alloc IA-NAC has no corresponding execution
R36: EXC-0035 | allocation_reconcile | No matching execution found |  | LOW | IA-NAD | Alloc IA-NAD has no corresponding execution
R37: EXC-0036 | allocation_reconcile | No matching execution found |  | LOW | IA-NAF | Alloc IA-NAF has no corresponding execution
R38: EXC-0037 | allocation_reconcile | No matching execution found |  | LOW | IA-NAN | Alloc IA-NAN has no corresponding execution
R39: EXC-0038 | allocation_reconcile | No matching execution found |  | LOW | IA-NAO | Alloc IA-NAO has no corresponding execution
R40: EXC-0039 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-NU | Alloc IA-ROLL-NU has no corresponding execution
R41: EXC-0040 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-OV | Alloc IA-ROLL-OV has no corresponding execution
R42: EXC-0041 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-PW | Alloc IA-ROLL-PW has no corresponding execution
R43: EXC-0042 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-QX | Alloc IA-ROLL-QX has no corresponding execution
R44: EXC-0043 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-RY | Alloc IA-ROLL-RY has no corresponding execution
R45: EXC-0044 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-SZ | Alloc IA-ROLL-SZ has no corresponding execution
R46: EXC-0045 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-TA | Alloc IA-ROLL-TA has no corresponding execution
R47: EXC-0046 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-UC | Alloc IA-ROLL-UC has no corresponding execution
R48: EXC-0047 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-VD | Alloc IA-ROLL-VD has no corresponding execution
R49: EXC-0048 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-WE | Alloc IA-ROLL-WE has no corresponding execution
R50: EXC-0049 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-XF | Alloc IA-ROLL-XF has no corresponding execution
R51: EXC-0050 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-YG | Alloc IA-ROLL-YG has no corresponding execution
R52: EXC-0051 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-ZH | Alloc IA-ROLL-ZH has no corresponding execution
R53: EXC-0052 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-BJ | Alloc IA-ROLL-BJ has no corresponding execution
R54: EXC-0053 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-CL | Alloc IA-ROLL-CL has no corresponding execution
R55: EXC-0054 | allocation_reconcile | No matching execution found |  | LOW | IA-ROLL-DM | Alloc IA-ROLL-DM has no corresponding execution
R56: EXC-0055 | position_close | Position mismatch | diff=700; exec_delta=2200 + opening=1960 | MEDIUM | AC-3107-688201 | Exp closing=4160 vs stmt closing=3460
R57: EXC-0056 | position_close | Position mismatch | diff=-1000; exec_delta=-500 + alloc_delta=-700 + opening=890 | MEDIUM | AC-4820-600519 | Exp closing=-310 vs stmt closing=690
R58: EXC-0057 | position_close | Position mismatch | diff=-20; exec_delta=3600 + opening=1980 | MEDIUM | AC-6684-159915 | Exp closing=5580 vs stmt closing=5600
R59: EXC-0058 | position_close | Position mismatch | diff=-1200; exec_delta=-600 + alloc_delta=-1200 + opening=2340 | MEDIUM | AC-6684-601318 | Exp closing=540 vs stmt closing=1740
R60: EXC-0059 | position_close | Position mismatch | diff=-4650; exec_delta=-1550 + alloc_delta=-4550 + opening=2810 | MEDIUM | AC-8266-300750 | Exp closing=-3290 vs stmt closing=1360
R61: EXC-0060 | position_close | Position mismatch | diff=-230; opening=950 | MEDIUM | AC-P1010-333 | Exp closing=950 vs stmt closing=1180
R62: EXC-0061 | position_close | Position mismatch | diff=-235; opening=1005 | MEDIUM | AC-P1033-588000 | Exp closing=1005 vs stmt closing=1240
R63: EXC-0062 | position_close | Position mismatch | diff=-240; opening=1060 | MEDIUM | AC-P1056-159915 | Exp closing=1060 vs stmt closing=1300
R64: EXC-0063 | position_close | Position mismatch | diff=-185; opening=455 | MEDIUM | AC-P803-333 | Exp closing=455 vs stmt closing=640
R65: EXC-0064 | position_close | Position mismatch | diff=-190; opening=510 | MEDIUM | AC-P826-588000 | Exp closing=510 vs stmt closing=700
R66: EXC-0065 | position_close | Position mismatch | diff=-195; opening=565 | MEDIUM | AC-P849-159915 | Exp closing=565 vs stmt closing=760
R67: EXC-0066 | position_close | Position mismatch | diff=-200; opening=620 | MEDIUM | AC-P872-333 | Exp closing=620 vs stmt closing=820
R68: EXC-0067 | position_close | Position mismatch | diff=-205; opening=675 | MEDIUM | AC-P895-588000 | Exp closing=675 vs stmt closing=880
R69: EXC-0068 | position_close | Position mismatch | diff=-210; opening=730 | MEDIUM | AC-P918-159915 | Exp closing=730 vs stmt closing=940
R70: EXC-0069 | position_close | Position mismatch | diff=-215; opening=785 | MEDIUM | AC-P941-333 | Exp closing=785 vs stmt closing=1000
R71: EXC-0070 | position_close | Position mismatch | diff=-220; opening=840 | MEDIUM | AC-P964-588000 | Exp closing=840 vs stmt closing=1060
R72: EXC-0071 | position_close | Position mismatch | diff=-225; opening=895 | MEDIUM | AC-P987-159915 | Exp closing=895 vs stmt closing=1120

## Sheet 6: summary
Dimensions: 73 rows x 13 columns
R1: account_id | portfolio_id | lifecycle_ok_count | lifecycle_break_count | confirmation_ok_count | confirmation_break_count | allocation_ok_count | allocation_break_count | position_ok_count | position_break_count | total_exception_count | net_delta_qty | net_cash_impact
R2: AC-3107 | G1 | 2 | 1 | 2 | 0 | 0 | 2 | 0 | 1 | 0 | 2200 | -93295
R3: AC-3927 | G1 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0
R4: AC-4820 | G2 | 1 | 1 | 0 | 2 | 0 | 1 | 0 | 1 | 0 | -500 | 756000
R5: AC-5178 | G2 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0
R6: AC-6684 | G2 | 2 | 0 | 1 | 2 | 1 | 1 | 0 | 2 | 0 | 3000 | 21199.4
R7: AC-6891 | G2 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0
R8: AC-7436 | G2 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0
R9: AC-7712 | G2 | 1 | 2 | 1 | 0 | 1 | 0 | 1 | 0 | 0 | 1500 | -86700
R10: AC-8266 | G3 | 2 | 2 | 2 | 0 | 1 | 1 | 0 | 1 | 0 | -1550 | 331353
R11: AC-9055 | G3 | 1 | 1 | 1 | 0 | 1 | 0 | 1 | 0 | 0 | 5000 | -20640
R12: AC-A659 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R13: AC-A678 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R14: AC-A697 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R15: AC-A716 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R16: AC-A735 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R17: AC-A754 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R18: AC-A773 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R19: AC-A792 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R20: AC-A811 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R21: AC-A830 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R22: AC-A849 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R23: AC-A868 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R24: AC-A887 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R25: AC-A906 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R26: AC-A925 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R27: AC-A944 | GX | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0
R28: AC-C1009 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R29: AC-C1020 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R30: AC-C1031 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R31: AC-C1042 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R32: AC-C1053 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R33: AC-C1064 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R34: AC-C1075 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R35: AC-C1086 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R36: AC-C921 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R37: AC-C932 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R38: AC-C943 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R39: AC-C954 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R40: AC-C965 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R41: AC-C976 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R42: AC-C987 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R43: AC-C998 | GX | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R44: AC-E1002 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R45: AC-E1015 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R46: AC-E1028 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R47: AC-E1041 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R48: AC-E1054 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R49: AC-E833 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R50: AC-E846 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R51: AC-E859 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R52: AC-E872 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R53: AC-E885 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R54: AC-E898 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R55: AC-E911 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R56: AC-E924 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R57: AC-E937 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R58: AC-E950 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R59: AC-E963 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R60: AC-E976 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R61: AC-E989 | GX | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0
R62: AC-P1010 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R63: AC-P1033 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R64: AC-P1056 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R65: AC-P803 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R66: AC-P826 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R67: AC-P849 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R68: AC-P872 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R69: AC-P895 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R70: AC-P918 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R71: AC-P941 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R72: AC-P964 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
R73: AC-P987 | GX | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0
