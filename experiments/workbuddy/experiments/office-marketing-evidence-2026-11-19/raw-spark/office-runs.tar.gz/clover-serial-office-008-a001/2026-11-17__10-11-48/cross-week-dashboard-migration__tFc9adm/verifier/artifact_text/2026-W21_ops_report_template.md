# Week 21 Ops Plan Draft / 第21周运营草稿

Week window: {{CURRENT_WEEK_WINDOW_FROM_CONFIG}}
Calendar flags: {{HOLIDAY_OR_SHIFT_NOTES}}
Draft owner note: This file still has Week 20 fragments, old-export hints, and a few copied reminder lines; the date/window line was not filled in before handoff.

## 1. Historical completions kept for context / 历史完成项

- Context inbox: old sent reminder still mentions a FAQ refresh line; newer Week 20 notes use a close-note tone.
- Draft fragment: dashboard label cleanup already happened? [likely only explains why some labels already look edited]
- Draft fragment: facilities chair/plant notes are mixed into the folder but may just be background clutter.

## 2. Carry-forward queue / 跨周待处理队列

| Current fragment | Draft wording from notes | Where this came from | Owner/comment margin note | Dashboard/reminder loose end |
| --- | --- | --- | --- | --- |
| OPS-214 | old export says resolved?; Friday note still mentions import timeout | Week 20 narrative + scratch export conflict | larger-sample evidence was mentioned in a Friday owner comment | dashboard card may still show old export wording |
| OPS-219 | roster note says waiting; Wednesday is mentioned | roster note + calendar side note | calendar rest-day note may affect this line | roster card/list label looks provisional |
| OPS-224 | access approval queue had no Friday reply | Week 20 narrative | owner sits outside the internal team | access card text is shorter than the report note |
| OPS-230 | EN one-pager schedule section requested | Week 20 late note + draft reminder | partner timing appears in both early and later-week notes | reminder link exists but date line is rough |
| OPS-236 | import watch Monday; no owner | handover note | observation only? no due time in report | watch note area has a loose line |

## 3. Week-boundary and reminder notes / 周界与提醒口径

- Week 21 date line is still blank because the config file has the authoritative week window.
- Wednesday appears in a few draft reminder lines; the calendar notes also mark that day as unusual for meetings.
- Dashboard summary/count/chart placeholders look pre-review and may not match the cleaned report wording yet.
- Old scratch export is marked as lower-confidence clutter in margin notes where it disagrees with the Friday narrative.

## 4. Dashboard sync notes / 看板同步备注

- status_dashboard.html has visible cards, data attributes, and embedded JSON; several labels appear copied from mixed drafts.
- Current dashboard comments mention report/reminder files, but the labels are not necessarily final.
- Do not edit `assets/` for visual styling.

## 5. Reminder and follow-up text / 提醒与跟进口径

- Reminder draft has copied lines from old sent history and the new-week draft; dates and reasons are not fully reconciled.
- A completed/noise line may need to remain only as context rather than send-ready text.
- Partner one-pager, access approval, roster timing, and the FAQ line all appear in different tones across the notes.

## 6. Non-target preservation note / 非目标文件保护

- Do not rewrite archived reports, sent reminders, static dashboard assets, source notes, calendar/config, README, role map, or scratch exports.
- Preserve file tree shape: dashboard/reminder/report changes should not flatten the workspace into one new document.
