# Public Workspace Context Summary

This is a bounded summary of public local files for supplemental WB Judge. It does not include hidden gold, oracle prose, evaluator internals beyond scope status, private trace context, or construction notes.

## Public task contract summary
- Update exactly three target artifacts: Week 21 Markdown report, text-first HTML dashboard, and Week 21 reminder draft.
- Preserve calendar/config, source notes, archive, static assets, sent reminders, scratch export, README, and role map.
- Carry forward unresolved/deferred/blocked/follow-up/watch-only Week 20 state into Week 21 without reopening completed history.
- Apply local calendar/source priority: Week 21 is 2026-05-18..2026-05-24; Wed 2026-05-20 is no-meeting day so Wednesday reminders move to Tue 2026-05-19 morning; Fri 2026-05-22 before 17:30 is partner check-in timing, not completion evidence.
- Treat scratch_old_export.csv and sent/archive history as lower-priority context that cannot override newer Week 20 narrative/config.

## Public source excerpts
### README_先读我.md
# Week 21 weekly ops migration workspace / 第21周运营迁移工作区

这是一个 Week 21 运营迁移资料包。请只使用本目录内的工作区导出材料，把 Week 20 的状态迁移到 Week 21 的 report、状态看板片段和 reminder draft。不要访问网络、浏览器、外部 API、私有服务或任何工作区外在线系统。

## 快速路径

先读：

- `file_roles_and_preservation.md`
- `00_calendar/week_rules.config.txt`
- `00_calendar/team_calendar_notes.txt`

主要来源：

- `01_reports/2026-W20_ops_report.md`
- `04_notes/oncall_handover.txt`
- `04_notes/vendor_window_note.txt`
- `03_reminders/week21_followups_draft.txt`
- `02_dashboard/status_dashboard.html`

三个可编辑目标：

- `01_reports/2026-W21_ops_report_template.md`
- `02_dashboard/status_dashboard.html`
- `03_reminders/week21_followups_draft.txt`

## 工作口径

- Week 21 range 来自 `week_rules.config.txt`，不要从文件名或旧报告标题猜日期。
- 已完成事项可以作为 compact historical context，但不要被重新打开。
- 未解决、延后、阻塞、待追问、watch-only 事项要按来源和日历规则处理。
- `tmp/scratch_old_export.csv` 是低优先级旧导出，只用于识别冲突，不用于覆盖 Week 20 narrative。
- HTML 状态看板片段只要求 text/DOM/data-binding 同步，不需要截图或样式设计判断。

### file_roles_and_preservation.md
# File roles and preservation map / 文件角色与保护边界

## Editable targets / 可编辑目标

| Path | Role | Notes |
| --- | --- | --- |
| `01_reports/2026-W21_ops_report_template.md` | current-week report target | 需要迁移 Week 20 状态并清理模板残留。 |
| `02_dashboard/status_dashboard.html` | dashboard target | 同步 visible DOM text、data attributes 和 embedded JSON。 |
| `03_reminders/week21_followups_draft.txt` | reminder target | 和 report/dashboard 状态保持一致。 |

## Read-only sources / 只读来源

| Path | Role | Notes |
| --- | --- | --- |
| `00_calendar/week_rules.config.txt` | calendar/config source | 定义 week range、source priority、status aliases 和 reminder rules。 |
| `00_calendar/team_calendar_notes.txt` | calendar note source | 补充 no-meeting day、partner check-in 和提醒 wording。 |
| `01_reports/2026-W20_ops_report.md` | previous-week narrative source | Week 20 narrative 高于 stale export。 |
| `04_notes/oncall_handover.txt` | handover source | 含 watch-only、alias、周一注意事项。 |
| `04_notes/vendor_window_note.txt` | timing source | partner/vendor timing 和 reminder wording 限制。 |

## Protected non-targets / 必须保持不变

| Path | Preservation reason |
| --- | --- |
| `01_reports/archive/2026-W19_ops_report.md` | older history; not part of Week 21 migration target |
| `02_dashboard/assets/dashboard.css` | static styling asset; not part of the status-text handoff |
| `02_dashboard/assets/status-icons.svg` | static icon asset; no OCR/VLM/pixel task |
| `03_reminders/sent/week20_sent_followups.txt` | historical sent communication record |
| `tmp/scratch_old_export.csv` | 低优先级旧导出冲突来源; do not rewrite or treat as priority source |
| `README_先读我.md` and this file | orientation and boundary documents |

不要创建新的额外周报模板、独立核对台账、外部调用记录、PPT/deck/image 或临时脚本/配置。

### week_rules.config.txt
[workspace]
project_label = community_training_ops
language_mix = zh_status_content + en_file_and_dashboard_terms
local_only = true

[week]
previous_week_id = 2026-W20
previous_week_range = 2026-05-11..2026-05-17
current_week_id = 2026-W21
current_week_range = 2026-05-18..2026-05-24
week_start = Monday
timezone_label = offline_local

[source_priority]
1 = week_rules.config.txt for week ranges, no-meeting day, and reminder shift policy
2 = 2026-W20_ops_report.md narrative and tables for source status
3 = team_calendar_notes.txt and vendor_window_note.txt for timing windows
4 = oncall_handover.txt for watch-only and Monday handoff context
5 = week21_followups_draft.txt for existing reminder wording that must be reconciled
6 = sent/week20_sent_followups.txt for historical background only
7 = archive/* and tmp/scratch_old_export.csv for low-priority clutter only

[calendar_notes]
2026-05-19 = business_day; label = Tuesday reminder slot; default_reminder_window = morning_before_11_30
2026-05-20 = no_meeting_day; label = 社区培训休息日; reminder_policy = move_to_previous_business_day
2026-05-22 = partner_checkin; window = afternoon_before_17_30; note = EN one-pager can be mentioned here

[status_language_aliases]
completed = Done, 已完成, closed, 发布完成, complete
open = Open, 未解决, still reproduces, 处理中, needs owner touch
blocked = Blocked, 卡住, waiting external approval, 无法继续
deferred = Deferred, 延后, waiting roster, 等名单确认, schedule pending
follow_up = Follow-up, 待追问, reminder needed, 需要提醒
watch_only = Watch-only, 观察, 下周观察, no owner assignment yet
stale = stale, 旧导出, outdated, lower priority

[reminder_rules]
no_meeting_day_shift = If target reminder date is 2026-05-20, move to Tue 2026-05-19 morning.
partner_follow_up = Mention Friday partner check-in as timing context, not completion evidence.
blocked_items = Keep blocker text visible and do not mark as completed.
deferred_items = Keep deferred reason/date condition instead of converting to generic open state.
completed_items = Keep as historical context; do not create active reminders.
watch_only_items = May appear as next-week watch note, not as confirmed active task unless another higher-priority source assigns it.

[dashboard_rules]
sync_visible_text = true
sync_data_attributes = true
sync_embedded_json = true
render_or_pixel_scoring = false
static_assets = preserve_even_if_dashboard_html_changes

### team_calendar_notes.txt
# Team calendar notes / 团队日历备注

- Week 21 is Mon 2026-05-18 through Sun 2026-05-24. 周报窗口以 config 为准。
- Wed 2026-05-20 is a no-meeting day. 如果跟进提醒原本落在周三，提前到 Tue 2026-05-19 morning。
- Friday partner check-in is a timing constraint; it does not mark OPS-230 as completed.
- Week 20 archived notes are reference-only. Do not edit archive files while migrating Week 21 state.
- For dashboard wording, use short bilingual labels: 未解决 / Open, 延后 / Deferred, 卡住 / Blocked, 待追问 / Follow-up, 观察 / Watch-only.
- If a line is only from old export or sent reminder history, keep it as context or conflict note rather than promoted Week 21 state.

### 2026-W20_ops_report.md
# Week 20 Ops Snapshot / 第20周运营状态

Week window: Mon 2026-05-11 to Sun 2026-05-17
Workspace note: 本周记录保留为历史来源；周五收尾时有些旁注还没整理进新周材料，正式 close note、owner margin note 和旧导出文本的口径还不完全一致。

## A. Completed / 已完成，保留历史

- OPS-201 FAQ refresh: FAQ v2 已发布到 offline handbook，owner role: Docs. Week 20 close note says no new action was logged unless handbook feedback reopens it.
- OPS-207 Dashboard label cleanup: English status labels reviewed and merged into the Week 20 HTML status board during Week 20; this explains why some dashboard labels already look edited.
- OPS-212 Training room chairs: 已完成 32 张椅子盘点; facilities side note, not tied to the status-dashboard thread.

## B. Handoff-adjacent notes / 可能还会被问到的旁注

| Item | Source fragment | Evidence excerpt | Owner / handoff comment |
| --- | --- | --- | --- |
| OPS-214 | Friday import note versus old export label | CSV import timeout still reproduces on Friday sample import file; 中文备注: 先不要关闭 | Friday owner asked for larger-sample evidence; an older export line has a different "resolved?" label. |
| OPS-219 | Roster timing note | Volunteer roster waiting for Wednesday confirmation; 等名单确认后再排班 | Roster owner mentioned Wednesday timing; calendar team had not confirmed whether that day is usable. |
| OPS-224 | Door access queue note | Door access approval not returned by Friday; approval owner sits outside the internal team | External queue owner; no internal workaround was written into the Friday close notes. |
| OPS-230 | Partner one-pager note | Partner asked for EN one-pager by next Tue; 需要 reminder | Partner note mentions a schedule section; timing is also discussed around a later check-in window. |
| OPS-236 | On-call observation | Monday morning import watch requested by on-call; no owner assigned yet | Handoff observation only; no named owner or due time in this weekly report. |

## C. Late notes from Friday / 周五晚到线索

- OPS-214: one small retry passed, but the 80-row training file still timed out twice. Friday owner left a question mark around broader sample evidence.
- OPS-219: roster list owner said "可能周三中午前给名单" in chat recap, while the calendar has a Wednesday no-meeting note; exact execution time remained unsettled.
- OPS-224: external approval queue sent no reply by Friday 16:40; the last note is a waiting-thread note rather than an internal action record.
- OPS-230: partner prefers EN one-pager with a short schedule section; the reminder draft has a related line but its timing was not settled he

[TRUNCATED to 2600 chars by verifier before WB Judge extraction; deterministic artifacts remain available separately.]


### week20_sent_followups.txt
Subject: Week 20 sent follow-ups / 第20周已发送提醒

Sent on 2026-05-13:
- OPS-201 FAQ refresh was still open at send time. Later Week 20 report marks it complete.
- OPS-214 import timeout asked for retry evidence.
- OPS-230 partner one-pager was mentioned as early heads-up only.

This file is historical sent communication. Do not edit it during Week 21 migration.

### oncall_handover.txt
# On-call handover / 值班交接

Date: Sun 2026-05-17 evening

- Monday morning watch: data import path for training CSV has been flaky. Relates to OPS-214 but handover does not close it.
- If dashboard card still says OPS-214 resolved from export, prefer Week 20 narrative until a larger sample passes.
- OPS-236 is an observation note: watch data imports Monday morning. No owner or due time assigned yet.
- Avoid reopening OPS-207 label cleanup. That was completed; only dashboard current state text/data may need sync.
- Volunteer roster wording: keep "deferred / 等名单确认" until actual roster arrives; don't call it blocked.

### vendor_window_note.txt
# Vendor / partner timing note

- Partner check-in window: Fri 2026-05-22 afternoon before 17:30 offline_local.
- OPS-230 EN one-pager reminder should happen before the Friday check-in; Tuesday morning is acceptable if Wednesday is unavailable.
- Do not infer partner approval or completion from the check-in window itself.
- Door access approval for OPS-224 belongs to an external queue; no approval response was received by the end of Week 20.
- If reminder text mentions schedule section for the EN one-pager, keep it concise and do not add made-up partner names.

### scratch_old_export.csv
export_timestamp,item_id,status,comment
2026-05-14T09:20:00,OPS-214,resolved?,old small-sample copy passed once
2026-05-14T09:21:00,OPS-201,open,old sent reminder import
2026-05-16T11:05:00,PLANT-009,done,office plant move
2026-05-16T11:06:00,OPS-219,open,roster pending maybe Wednesday

### local_workspace_notes.md
# Workspace export notes

- This Week 21 operations migration package includes only the files under `input/weekly_ops_workspace/`.
- Work from the files already present in the task directory; do not call external APIs, browse websites, use private services, connect to project-management systems, or rely on live accounts.
- No extra app/server connection, browser automation, screenshot capture, OCR, image/video/audio processing, or extra runtime service is needed.
- The status dashboard is text-first HTML: DOM text, `data-*` attributes, and embedded JSON are meaningful; CSS/SVG styling is not part of the handoff.
- Keep edits limited to these target files:
  - `input/weekly_ops_workspace/01_reports/2026-W21_ops_report_template.md`
  - `input/weekly_ops_workspace/02_dashboard/status_dashboard.html`
  - `input/weekly_ops_workspace/03_reminders/week21_followups_draft.txt`
- Protected files include calendar/config sources, archive reports, static assets, sent reminders, source notes, scratch exports, README, and role-map documents.

## Deterministic-owned boundaries
Exact dates, item IDs, item counts, data attributes, parseability, JSON keys, protected-file preservation, and forbidden extra artifacts are deterministic-owned. Judge may assess only visible semantic/narrative quality where the submitted artifacts explain and operationalize these public constraints.
