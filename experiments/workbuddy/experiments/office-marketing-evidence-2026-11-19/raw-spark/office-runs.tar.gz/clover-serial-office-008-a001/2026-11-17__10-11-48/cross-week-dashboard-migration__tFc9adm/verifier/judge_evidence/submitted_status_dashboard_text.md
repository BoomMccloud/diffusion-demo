<!doctype html>
<html lang="zh-Hans">
<head>
  <meta charset="utf-8">
  <title>Week 21 Operations Dashboard / 第21周状态看板</title>
  <link rel="stylesheet" href="assets/dashboard.css">
</head>
<body data-workspace="community_training_ops" data-week-id="2026-W21" data-source-week="2026-W20">
  <header id="week-banner" data-bind="weekWindow">
    <h1>Week 21 Operations Dashboard / 第21周状态看板</h1>
    <p class="week-window">TODO: fill from week_rules.config.txt</p>
    <p class="calendar-note" data-calendar-anchor="holiday-shift">TODO: compare Wednesday note before reminder text</p>
  </header>

  <main>
    <section id="state-summary" data-bind="summaryByState" aria-label="status summary">
      <h2>Status summary / 状态摘要</h2>
      <dl>
        <dt>Historical completed / 历史完成</dt>
        <dd data-state="historical_done" data-count="0">draft count not reviewed</dd>
        <dt>Carry-forward open / 跨周未解决</dt>
        <dd data-state="carry_forward_open" data-count="0">draft count not reviewed</dd>
        <dt>Deferred / 延后</dt>
        <dd data-state="deferred" data-count="0">draft count not reviewed</dd>
        <dt>Blocked / 卡住</dt>
        <dd data-state="blocked" data-count="0">draft count not reviewed</dd>
        <dt>Follow-up / 待追问</dt>
        <dd data-state="follow_up" data-count="0">draft count not reviewed</dd>
        <dt>Watch-only / 观察</dt>
        <dd data-state="watch_only" data-count="0">draft count not reviewed</dd>
      </dl>
    </section>

    <section id="carry-forward-board" data-bind="itemCards">
      <h2>Carry-forward board / 跨周看板</h2>
      <article class="item-card stale" data-item-id="OPS-214" data-source="scratch_old_export" data-target-section="stale-export-review">
        <h3>OPS-214 import timeout</h3>
        <p class="state-label">resolved? / old export label</p>
        <p class="sync-note">This card was auto-filled from an old export; later Week 20 notes mention a larger-sample timeout.</p>
      </article>
      <article class="item-card" data-item-id="OPS-219" data-source="2026-W20_ops_report" data-target-section="roster-calendar-review" data-calendar-sensitive="true">
        <h3>OPS-219 volunteer roster</h3>
        <p class="state-label">roster timing note / calendar check</p>
        <p class="sync-note">Wednesday roster mention may collide with the calendar side note.</p>
      </article>
      <article class="item-card" data-item-id="OPS-224" data-source="2026-W20_ops_report" data-target-section="approval-review">
        <h3>OPS-224 door access approval</h3>
        <p class="state-label">approval queue note / short card</p>
        <p class="sync-note">Card wording is brief compared with report and reminder draft notes.</p>
      </article>
      <article class="item-card" data-item-id="OPS-230" data-source="week21_followups_draft" data-target-section="partner-note-review" data-reminder-anchor="week21-followups">
        <h3>OPS-230 EN one-pager follow-up</h3>
        <p class="state-label">partner one-pager / timing draft</p>
        <p class="sync-note">Draft timing references both a Wednesday line and a later partner window.</p>
      </article>
    </section>

    <section id="watch-notes" data-bind="watchOnlyNotes">
      <h2>Watch notes / 观察事项</h2>
      <ul>
        <li data-item-id="OPS-236" data-state="watch-candidate">watch data imports Monday morning; owner not listed</li>
      </ul>
    </section>

    <section id="reminder-sync" data-bind="reminderQueue">
      <h2>Draft reminder cross-check / 提醒草稿核对</h2>
      <ul>
        <li data-item-id="OPS-230" data-reminder-file="03_reminders/week21_followups_draft.txt">partner reminder topic exists; timing still draft</li>
        <li data-item-id="OPS-224" data-reminder-file="03_reminders/week21_followups_draft.txt">approval line exists; report wording may be longer</li>
        <li data-item-id="OPS-201" data-reminder-file="03_reminders/week21_followups_draft.txt">old sent reminder had FAQ refresh; newer report wording may differ</li>
      </ul>
    </section>
  </main>

  <script type="application/json" id="chart-spec-status-mix" data-bind="chartSpec.statusMix">
  {
    "chartType": "bar",
    "description": "Parseable status chart spec for the Week 21 status dashboard片段; pixels and visual styling are not part of this text update.",
    "source": "week21_dashboard_draft_before_review",
    "series": [
      {"state": "historical_done", "label": "历史完成", "count": 0},
      {"state": "carry_forward_open", "label": "未解决", "count": 0},
      {"state": "deferred", "label": "延后", "count": 0},
      {"state": "blocked", "label": "卡住", "count": 0},
      {"state": "follow_up", "label": "待追问", "count": 0},
      {"state": "watch_only", "label": "观察", "count": 0}
    ]
  }
  </script>

  <script type="application/json" id="data-binding-map">
  {
    "weekBanner": ["00_calendar/week_rules.config.txt", "01_reports/2026-W21_ops_report_template.md"],
    "itemCards": ["01_reports/2026-W20_ops_report.md", "01_reports/2026-W21_ops_report_template.md"],
    "reminderQueue": ["03_reminders/week21_followups_draft.txt"],
    "preserveAssets": ["02_dashboard/assets/dashboard.css", "02_dashboard/assets/status-icons.svg"],
    "needsReview": ["tmp/scratch_old_export.csv"]
  }
  </script>
</body>
</html>
