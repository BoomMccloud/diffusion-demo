Subject: Week 21 follow-up / 第21周待跟进提醒
Audience: internal offline project roles
Week: 2026-W21
Calendar note: Wednesday line copied from an earlier draft; compare with calendar note and Friday partner window before sending.

Draft reminder lines; some copied from old context and still need report/dashboard review:

1. [OPS-230] Partner EN one-pager follow-up
   - Reminder timing: Wed 2026-05-20 afternoon? [calendar note questions this; partner window appears later in week]
   - 中文备注: 请确认英文 one-pager 是否需要补充 schedule section。
   - Draft margin note: same one-pager topic appears in report notes and dashboard card, but the send date is still rough.

2. [OPS-224] Door access approval note
   - Reminder timing: Mon 2026-05-18 after standup.
   - 中文备注: 外部审批队列还没有回音；不要写成已经批准。
   - Draft margin note: report has a longer queue/no-reply comment than the dashboard card.

3. [OPS-219] Volunteer roster item
   - Reminder timing: Wed 2026-05-20 morning? [calendar says this may be invalid]
   - 中文备注: 等名单确认后再排班；这个 line 可能只是 roster/calendar 协调。
   - Draft margin note: source wording alternates between roster wait and schedule timing.

4. [OPS-201] FAQ refresh
   - Reminder timing: copied from old sent reminder.
   - 中文备注: 可能已经完成，迁移前核对 Week 20 report。
   - Draft margin note: appears because the old sent reminder had it; latest status needs checking.

Notes not to send until verified:

- OPS-236 import watch: handover says Monday watch, no owner assigned.
- Office plant move: completed noise item, not operational follow-up.
- tmp/scratch_old_export.csv status text: 低优先级旧导出, not reminder source.
