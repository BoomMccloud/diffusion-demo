# Workbook: signal_workbook.xlsx

## Sheet 1: indicator_snapshot
Dimensions: 9 rows x 15 columns
R1: ts_code | display_name | trade_date | close | ret_5d | ret_20d | ret_ytd | limit_up_price | limit_down_price | pe_ttm | pb | turnover_rate | volume_ratio | quote_status | basic_status
R2: 600519.SH | 贵州茅台 | 20260619 | 1488.6 | 0.045 | 0.08 | 0.12 | 1616.01 | 1322.19 | 27.42 | 8.76 | 0.3124 | 1.18 | normal | normal
R3: 300750.SZ | 宁德时代 | 20260619 | 208.4 | 0.0838 | 0.18 | 0.2784 | 245.1 | 163.4 | 24.15 | 4.58 | 0.9061 | 1.31 | normal | normal
R4: 688981.SH | 中芯国际 | 20260619 | 90.72 | 0.081 | 0.3646 | 0.6345 | 105.78 | 70.52 | 54.22 | 3.12 | 1.852 | 1.43 | normal | normal
R5: 002475.SZ | 立讯精密 | 20260619 | 38.96 | 0.0521 | 0.11 | 0.147 | 42.28 | 34.6 | 31.08 | 3.87 | 2.4428 | 0.96 | daily_basic_lag | daily_basic_lag
R6: 000001.SZ | 平安银行 | 20260619 | 11.82 | -0.015 | 0.0252 | 0.0601 | 13.16 | 10.76 | 5.63 | 0.58 | 0.2841 | 0.71 | normal | normal
R7: 600777.SH | 新潮能源 | 20260619 | 6.39 | 0.0794 | 0.0625 | -0.1 | 6.74 | 6.1 | 18.4 | 1.02 | 1.1 | 1.25 | normal | normal
R8: 601012.SH | 隆基绿能 | 20260619 |  |  |  |  |  |  |  |  |  |  | data_exception | no_ref_day_data
R9: 603882.SH | 海岚装备 | 20260619 | 18.36 | 0.0223 | 0.06 | 0.0903 | 19.71 | 16.13 |  |  |  |  | missing_daily_basic | missing_daily_basic

## Sheet 2: signal_flags
Dimensions: 9 rows x 7 columns
R1: ts_code | display_name | watch_group | primary_flag | secondary_flags | flag_reason | data_quality_status
R2: 600519.SH | 贵州茅台 | 核心持仓 | neutral_track |  | neutral_track; 5d=0.0450; 20d=0.0800; YTD=0.1200; PE_TTM=27.42; PB=8.76 | ok
R3: 300750.SZ | 宁德时代 | 新能源观察 | momentum_watch | 5日涨幅≥6%;量比≥1.20;换手率≥0.80% | momentum_watch; 5d=0.0838; 20d=0.1800; YTD=0.2784; PE_TTM=24.15; PB=4.58 | ok
R4: 688981.SH | 中芯国际 | 科技成长 | risk_watch | PE_TTM=54.22>50; 20d涨幅=0.3646>25% | risk_watch; 5d=0.0810; 20d=0.3646; YTD=0.6345; PE_TTM=54.22; PB=3.12 | ok
R5: 002475.SZ | 立讯精密 | 消费电子 | neutral_track |  | neutral_track; 5d=0.0521; 20d=0.1100; YTD=0.1470; PE_TTM=31.08; PB=3.87 | daily_basic_lag
R6: 000001.SZ | 平安银行 | 红利低估 | valuation_watch | PE≤12;PB≤1.20;20d涨幅在[-8%,8%] | valuation_watch; 5d=-0.0150; 20d=0.0252; YTD=0.0601; PE_TTM=5.63; PB=0.58 | ok
R7: 600777.SH | 新潮能源 | 风险观察 | risk_watch | ST/风险警示 | risk_watch; 5d=0.0794; 20d=0.0625; YTD=-0.1000; PE_TTM=18.40; PB=1.02 | ok
R8: 601012.SH | 隆基绿能 | 新能源观察 | neutral_track |  | neutral_track | no_ref_day_data
R9: 603882.SH | 海岚装备 | 制造观察 | neutral_track |  | neutral_track; 5d=0.0223; 20d=0.0600; YTD=0.0903 | missing_daily_basic

## Sheet 3: risk_notes
Dimensions: 8 rows x 5 columns
R1: ts_code | risk_type | risk_evidence | source_field | source_trade_date
R2: 688981.SH | high_pe_ttm | PE_TTM=54.22 > 50 | 每日指标 | 20260619
R3: 688981.SH | high_20d_return | 20-day return=0.3646 (>25%) | 行情快照+复权因子 | 20260619
R4: 688981.SH | rule_priority_overlap | multiple rules triggered; primary=risk_watch | 策略规则卡 | 20260619
R5: 002475.SZ | stale_daily_basic | daily basic only available from prior trading day (20260619) | 每日指标 | 20260619
R6: 600777.SH | risk_warning_security | ST/risk warning security (market_board=主板, industry=石油石化) | 股票基础信息 | 20260619
R7: 600777.SH | rule_priority_overlap | multiple rules triggered; primary=risk_watch | 策略规则卡 | 20260619
R8: 601012.SH | missing_current_quote | 601012.SH missing on 20260619 | 行情快照 | 20260619

## Sheet 4: summary
Dimensions: 39 rows x 4 columns
R1: summary_key | summary_group | metric_name | metric_value
R2: report_date | 全局 | 报告日期 | 2026-06-22
R3: as_of_trade_date | 全局 | 行情基准日 | 20260619
R4: watchlist_total | 全局 | 有效观察池标的数 | 8
R5: data_quality_issue_count | 全局 | 数据质量异常标的数 | 2
R6: non_watchlist_current_quote_rows | 全局 | 非观察池行情行数量 | 2
R7: inactive_watchlist_rows | 全局 | 未生效或已失效观察池行数 | 2
R8: adjustment_preview_rows_ignored | 全局 | 被final覆盖的preview复权因子行数 | 9
R9: flag_count_data_exception | 信号分布 | data_exception 标的数 | 0
R10: flag_count_risk_watch | 信号分布 | risk_watch 标的数 | 2
R11: flag_count_momentum_watch | 信号分布 | momentum_watch 标的数 | 1
R12: flag_count_valuation_watch | 信号分布 | valuation_watch 标的数 | 1
R13: flag_count_neutral_track | 信号分布 | neutral_track 标的数 | 4
R14: group_count_核心持仓 | 按观察组 | 核心持仓 标的数 | 1
R15: group_count_新能源观察 | 按观察组 | 新能源观察 标的数 | 2
R16: group_count_科技成长 | 按观察组 | 科技成长 标的数 | 1
R17: group_count_消费电子 | 按观察组 | 消费电子 标的数 | 1
R18: group_count_红利低估 | 按观察组 | 红利低估 标的数 | 1
R19: group_count_风险观察 | 按观察组 | 风险观察 标的数 | 1
R20: group_count_制造观察 | 按观察组 | 制造观察 标的数 | 1
R21: data_quality_count_ok | 数据质量 | ok | 5
R22: data_quality_count_daily_basic_lag | 数据质量 | daily_basic_lag | 1
R23: data_quality_count_no_ref_day_data | 数据质量 | no_ref_day_data | 1
R24: data_quality_count_missing_daily_basic | 数据质量 | missing_daily_basic | 1
R25: risk_type_count_missing_current_quote | 风险类型 | missing_current_quote | 1
R26: risk_type_count_missing_daily_basic | 风险类型 | missing_daily_basic | 0
R27: risk_type_count_stale_daily_basic | 风险类型 | stale_daily_basic | 1
R28: risk_type_count_risk_warning_security | 风险类型 | risk_warning_security | 1
R29: risk_type_count_high_pe_ttm | 风险类型 | high_pe_ttm | 1
R30: risk_type_count_high_20d_return | 风险类型 | high_20d_return | 1
R31: risk_type_count_rule_priority_overlap | 风险类型 | rule_priority_overlap | 2
R32: group_flag_count_核心持仓__neutral_track | 分组×标志 | neutral_track | 1
R33: group_flag_count_新能源观察__momentum_watch | 分组×标志 | momentum_watch | 1
R34: group_flag_count_科技成长__risk_watch | 分组×标志 | risk_watch | 1
R35: group_flag_count_消费电子__neutral_track | 分组×标志 | neutral_track | 1
R36: group_flag_count_红利低估__valuation_watch | 分组×标志 | valuation_watch | 1
R37: group_flag_count_风险观察__risk_watch | 分组×标志 | risk_watch | 1
R38: group_flag_count_新能源观察__neutral_track | 分组×标志 | neutral_track | 1
R39: group_flag_count_制造观察__neutral_track | 分组×标志 | neutral_track | 1
