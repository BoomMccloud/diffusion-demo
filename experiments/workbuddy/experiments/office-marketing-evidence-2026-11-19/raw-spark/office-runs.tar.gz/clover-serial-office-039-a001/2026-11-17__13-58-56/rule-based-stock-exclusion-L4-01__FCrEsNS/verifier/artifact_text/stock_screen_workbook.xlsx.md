# Workbook: stock_screen_workbook.xlsx

## Sheet 1: selected_symbols
Dimensions: 31 rows x 13 columns
R1: symbol | name | board | theme_code | theme_name | selection_score | valuation_score | liquidity_score | momentum_score | theme_weight | turnover_rate_pct | sort_rank | source_trace
R2: SH.68Y205 | 翼棱精测 | 科创板 | THM-AUTO | 智能传动 | 90.5 | 28 | 27.5 | 28 | 7 | 8.12 | 1 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R3: SZ.30J574 | 煦舟电驱 | 创业板 | THM-ROBO | 工业机器人 | 87.5 | 26.5 | 25 | 29 | 7 | 10.32 | 2 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R4: SZ.00J612 | 南棱仪表 | 深市主板 | THM-QXAI | 端侧智能 | 85 | 26.5 | 27 | 23.5 | 8 | 9.44 | 3 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R5: SZ.00L648 | 槿川模组 | 深市主板 | THM-QXAI | 端侧智能 | 83 | 27.5 | 24.5 | 23 | 8 | 11.2 | 4 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R6: SZ.00H500 | 峦微晶工 | 深市主板 | THM-AUTO | 智能传动 | 79.5 | 25.5 | 26 | 21 | 7 | 9.44 | 5 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R7: SH.60Y167 | 砾川材料 | 沪市主板 | THM-GRID | 新型电网 | 79 | 27.5 | 25 | 20.5 | 6 | 9 | 6 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R8: SZ.30H538 | 黎澈微能 | 创业板 | THM-ROBO | 工业机器人 | 79 | 25.5 | 17.5 | 29 | 7 | 8.56 | 7 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R9: SZ.00V056 | 青棱模组 | 深市主板 | THM-ROBO | 工业机器人 | 76.5 | 19.5 | 21 | 29 | 7 | 11.2 | 8 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R10: SH.60M723 | 朗枢数控 | 沪市主板 | THM-AUTO | 智能传动 | 76.5 | 21.5 | 20 | 28 | 7 | 10.76 | 9 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R11: SZ.00L724 | 炬微晶工 | 深市主板 | THM-PHOT | 光储控制 | 75.5 | 27.5 | 17 | 25 | 6 | 9.44 | 10 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R12: SZ.00H576 | 岚序电气 | 深市主板 | THM-QXAI | 端侧智能 | 75 | 20 | 22 | 25 | 8 | 10.35 | 11 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R13: SZ.00X168 | 泽矩电气 | 深市主板 | THM-QXAI | 端侧智能 | 75 | 21 | 21 | 25 | 8 | 10.35 | 12 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R14: SH.60O835 | 铂岚智造 | 沪市主板 | THM-QXAI | 端侧智能 | 75 | 19 | 23 | 25 | 8 | 9.4 | 13 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R15: SH.68A317 | 星澜智控 | 科创板 | THM-QXAI | 端侧智能 | 75 | 18 | 24 | 25 | 8 | 9.4 | 14 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R16: SH.68U057 | 麦衡传动 | 科创板 | THM-RAIL | 轨交控制 | 74.5 | 26 | 18 | 26.5 | 4 | 9.88 | 15 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R17: SH.60E427 | 锦栈智造 | 沪市主板 | THM-QXAI | 端侧智能 | 74 | 20 | 23 | 23 | 8 | 9.1 | 16 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R18: SZ.30L686 | 维沐光联 | 创业板 | THM-QXAI | 端侧智能 | 74 | 22 | 20 | 24 | 8 | 8.85 | 17 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R19: SH.60U019 | 珩谷智造 | 沪市主板 | THM-QXAI | 端侧智能 | 74 | 21 | 22 | 23 | 8 | 8.6 | 18 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R20: SZ.30B278 | 湘岚光联 | 创业板 | THM-QXAI | 端侧智能 | 74 | 23 | 21 | 22 | 8 | 8.35 | 19 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R21: SZ.00N760 | 元岚电气 | 深市主板 | THM-PHOT | 光储控制 | 72 | 15.5 | 25.5 | 25 | 6 | 11.2 | 20 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R22: SH.60I575 | 卓砺材料 | 沪市主板 | THM-RAIL | 轨交控制 | 71.5 | 19.5 | 22 | 26 | 4 | 9 | 21 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R23: SZ.30X130 | 观炬微能 | 创业板 | THM-QXAI | 端侧智能 | 71.5 | 20.5 | 20 | 23 | 8 | 8.56 | 22 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R24: SH.60K611 | 朗衡智造 | 沪市主板 | THM-RAIL | 轨交控制 | 69.5 | 20.5 | 19 | 26 | 4 | 10.76 | 23 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R25: SH.60C315 | 云澈数控 | 沪市主板 | THM-ROBO | 工业机器人 | 69 | 16.5 | 23.5 | 22 | 7 | 10.76 | 24 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R26: SH.68C353 | 启舫航控 | 科创板 | THM-QXAI | 端侧智能 | 66 | 17 | 25 | 16 | 8 | 9.88 | 25 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R27: SZ.00B316 | 纤景晶工 | 深市主板 | THM-RAIL | 轨交控制 | 66 | 22.5 | 20.5 | 19 | 4 | 9.44 | 26 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R28: SH.68I537 | 海序航控 | 科创板 | THM-PHOT | 光储控制 | 65 | 20 | 20.5 | 18.5 | 6 | 9.88 | 27 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R29: SH.68E389 | 锦垣精测 | 科创板 | THM-QXAI | 端侧智能 | 64 | 18 | 22 | 16 | 8 | 8.12 | 28 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R30: SZ.30P834 | 霖曜光储 | 创业板 | THM-RAIL | 轨交控制 | 63.5 | 16.5 | 24 | 19 | 4 | 8.56 | 29 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R31: SZ.00Z204 | 苇澜仪表 | 深市主板 | THM-MAT2 | 高端材料 | 63 | 21.5 | 19.5 | 17 | 5 | 9.44 | 30 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38

## Sheet 2: excluded_symbols
Dimensions: 35 rows x 7 columns
R1: symbol | name | board | primary_exclusion_reason | triggered_rule_codes | priority_rank | source_trace
R2: SH.60C391 | 北辰材料 | 沪市主板 | st_or_halt | st_or_halt;market_cap_out_of_range | 1 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R3: SH.60S983 | 渭图材料 | 沪市主板 | st_or_halt | st_or_halt | 1 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R4: SZ.30F502 | 景安光联 | 创业板 | st_or_halt | st_or_halt;turnover_below_min | 1 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R5: BJ.83D390 | 艾珩电驱 | 北交所 | scoped_regime_block | scoped_regime_block | 2 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R6: BJ.83E465 | 润启传动 | 北交所 | scoped_regime_block | theme_not_allowed;scoped_regime_block | 2 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R7: BJ.83Q909 | 麟珩智控 | 北交所 | scoped_regime_block | scoped_regime_block | 2 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R8: BJ.83R908 | 墨序晶工 | 北交所 | scoped_regime_block | scoped_regime_block | 2 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R9: SH.60A279 | 云陌云服 | 沪市主板 | scoped_regime_block | theme_not_allowed;scoped_regime_block | 2 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R10: SH.60K687 | 砺舟云服 | 沪市主板 | scoped_regime_block | theme_not_allowed;stale_required_metric;scoped_regime_block | 2 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R11: SH.68A241 | 微棠传动 | 科创板 | scoped_regime_block | theme_not_allowed;scoped_regime_block | 2 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R12: SH.60G539 | 云栈数控 | 沪市主板 | market_cap_out_of_range | market_cap_out_of_range;pct_change_out_of_range | 3 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R13: SH.68M761 | 皓枢航控 | 科创板 | market_cap_out_of_range | market_cap_out_of_range | 3 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R14: SH.68O797 | 砚桥精测 | 科创板 | market_cap_out_of_range | market_cap_out_of_range | 3 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R15: SZ.00P872 | 昭联模组 | 深市主板 | pct_change_out_of_range | pct_change_out_of_range;turnover_below_min | 4 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R16: SZ.30B354 | 禾川微能 | 创业板 | pct_change_out_of_range | pct_change_out_of_range | 4 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R17: SZ.30T982 | 睿岚电驱 | 创业板 | pct_change_out_of_range | pct_change_out_of_range | 4 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R18: SH.60W131 | 筑曜数控 | 沪市主板 | turnover_below_min | turnover_below_min | 5 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R19: SH.68I613 | 谷曜精测 | 科创板 | turnover_below_min | turnover_below_min | 5 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R20: SH.60Q871 | 佑衡云服 | 沪市主板 | theme_not_allowed | theme_not_allowed | 6 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R21: SH.68K649 | 颂峦传动 | 科创板 | theme_not_allowed | theme_not_allowed | 6 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R22: SZ.00D428 | 辰谷仪表 | 深市主板 | theme_not_allowed | theme_not_allowed | 6 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R23: SZ.30V094 | 棠芯光联 | 创业板 | theme_not_allowed | theme_not_allowed | 6 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R24: SH.68S945 | 星垣航控 | 科创板 | missing_required_metric | missing_required_metric | 7 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R25: SZ.00F464 | 璟联模组 | 深市主板 | missing_required_metric | missing_required_metric | 7 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R26: SZ.30F426 | 沐栈光储 | 创业板 | missing_required_metric | missing_required_metric | 7 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R27: SZ.30J650 | 沐衡光储 | 创业板 | missing_required_metric | missing_required_metric | 7 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:38
R28: SH.60G463 | 玄智云服 | 沪市主板 | stale_required_metric | stale_required_metric | 8 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R29: SH.68G501 | 暄谷智控 | 科创板 | stale_required_metric | stale_required_metric | 8 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R30: SH.68W093 | 宸皓智控 | 科创板 | stale_required_metric | stale_required_metric | 8 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:38
R31: SZ.30N798 | 霁川电驱 | 创业板 | stale_required_metric | stale_required_metric | 8 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R32: SZ.30R946 | 玄浦微能 | 创业板 | stale_required_metric | stale_required_metric | 8 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R33: SZ.30Z242 | 澄佑光储 | 创业板 | stale_required_metric | stale_required_metric | 8 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45
R34: SZ.00D352 | 昭曜电气 | 深市主板 | no_market_snapshot |  | 99 | cu_batch=CU-20260616-B;cu_time=2026-06-16 14:45
R35: SZ.00T020 | 观澜仪表 | 深市主板 | no_market_snapshot |  | 99 | cu_batch=CU-20260616-A;cu_time=2026-06-16 14:45

## Sheet 3: reason_summary
Dimensions: 19 rows x 5 columns
R1: summary_group | reason_or_theme_bucket | count | affected_boards | note
R2: primary_exclusion_reason | market_cap_out_of_range | 3 | 沪市主板, 科创板 | 
R3: primary_exclusion_reason | missing_required_metric | 4 | 创业板, 深市主板, 科创板 | 
R4: primary_exclusion_reason | no_market_snapshot | 2 | 深市主板 | 
R5: primary_exclusion_reason | pct_change_out_of_range | 3 | 创业板, 深市主板 | 
R6: primary_exclusion_reason | scoped_regime_block | 7 | 北交所, 沪市主板, 科创板 | 
R7: primary_exclusion_reason | st_or_halt | 3 | 创业板, 沪市主板 | 
R8: primary_exclusion_reason | stale_required_metric | 6 | 创业板, 沪市主板, 科创板 | 
R9: primary_exclusion_reason | theme_not_allowed | 4 | 创业板, 沪市主板, 深市主板, 科创板 | 
R10: primary_exclusion_reason | turnover_below_min | 2 | 沪市主板, 科创板 | 
R11: selected_theme_group | 光储控制 | 3 | 深市主板, 科创板 | 
R12: selected_theme_group | 工业机器人 | 4 | 创业板, 沪市主板, 深市主板 | 
R13: selected_theme_group | 新型电网 | 1 | 沪市主板 | 
R14: selected_theme_group | 智能传动 | 3 | 沪市主板, 深市主板, 科创板 | 
R15: selected_theme_group | 端侧智能 | 13 | 创业板, 沪市主板, 深市主板, 科创板 | 
R16: selected_theme_group | 轨交控制 | 5 | 创业板, 沪市主板, 深市主板, 科创板 | 
R17: selected_theme_group | 高端材料 | 1 | 深市主板 | 
R18: scoped_regime_affected | 北交所(board) | 4 | 北交所 | Board-level observation pool; do not enter selected_symbols.
R19: scoped_regime_affected | watch_only(theme) | 4 | all | Theme-level observation pool; do not enter selected_symbols.

## Sheet 4: rule_audit
Dimensions: 11 rows x 6 columns
R1: rule_code | rule_description | evaluated_count | triggered_count | examples_symbol_list | note
R2: st_or_halt | Not ST and not halted | 64 | 5 | SH.60C391;SZ.00D352;SZ.00T020;SZ.30F502;SH.60S983 | 
R3: market_cap_out_of_range | Market cap between 50B and 500B CNY inclusive | 64 | 6 | SH.68O797;SH.60G539;SH.60C391;SZ.00D352;SZ.00T020;SH.68M761 | 
R4: pct_change_out_of_range | Price change % between 3.00% and 8.00% inclusive | 64 | 6 | SZ.30B354;SH.60G539;SZ.00P872;SZ.00D352;SZ.00T020;SZ.30T982 | 
R5: turnover_below_min | Turnover rate >= 8.00% | 64 | 6 | SH.68I613;SZ.00P872;SZ.00D352;SZ.00T020;SZ.30F502;SH.60W131 | 
R6: theme_not_allowed | Theme code must have allow_status = allow | 64 | 8 | BJ.83E465;SH.68A241;SH.60K687;SZ.30V094;SH.60Q871;SZ.00D428 | 
R7: missing_required_metric | Valuation, liquidity, momentum scores must be non-empty | 64 | 4 | SZ.00F464;SZ.30F426;SH.68S945;SZ.30J650 | 
R8: stale_required_metric | Required factor as_of_date >= 2026-06-14 | 64 | 7 | SZ.30R946;SH.60K687;SZ.30N798;SH.68W093;SZ.30Z242;SH.60G463 | 
R9: scoped_regime_block | BSE board or watch_only theme → observation pool only | 64 | 7 | BJ.83E465;SH.68A241;SH.60K687;BJ.83D390;BJ.83Q909;SH.60A279 | 
R10: selection_score_formula | selection_score = valuation_score + liquidity_score + momentum_score + theme_weight | 30 | 30 | SH.68Y205;SZ.30J574;SZ.00J612;SZ.00L648;SZ.00H500;SH.60Y167 | Applied to all selected_symbols.
R11: selected_sort_order | Sort by selection_score desc, then turnover_rate_pct desc, then symbol asc | 30 | 30 | SH.68Y205;SZ.30J574;SZ.00J612;SZ.00L648;SZ.00H500;SH.60Y167 | Applied to all selected_symbols.
