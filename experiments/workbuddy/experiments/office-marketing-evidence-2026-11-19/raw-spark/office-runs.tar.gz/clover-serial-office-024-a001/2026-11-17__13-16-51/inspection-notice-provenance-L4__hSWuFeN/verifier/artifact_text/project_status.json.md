{
  "metadata": {
    "case_id": "2026-5月工程质量安全抽查",
    "as_of_date": "2026-06-14",
    "source_root": "/workspace/input",
    "source_files_count": 13,
    "output_path": "/workspace/output/project_status.json",
    "resolution_rules": [
      "formal目录下的正式复查意见书明确引用某份正式整改通知书时，决定项目最新状态和复查结论；处罚金额和整改期限沿用被引用的正式整改通知，除非复查意见书显式改写。",
      "没有正式复查意见书的项目，以最新正式整改通知书作为有效来源，状态为等待复查或限期整改中。",
      "archive下的归档旧件、草稿、历史问题不能覆盖更新的正式通知或正式复查意见。",
      "supplement下的补充说明只能作为冲突解释材料；除非正式复查意见书明确引用并采纳，否则不能覆盖正式复查结论、处罚金额或整改期限。",
      "金额统一格式化为¥X,XXX.XX；日期统一为ISO YYYY-MM-DD；不予罚款记为¥0.00。"
    ]
  },
  "projects": [
    {
      "project_id": "PRJ-A17",
      "项目名称": "青岚湾二期 3#楼幕墙工程",
      "建设单位": "青岚置业有限公司",
      "施工单位": "澄筑幕墙工程有限公司",
      "违规类型": "临边防护缺失",
      "处罚金额": "¥18,000.00",
      "整改期限": "2026-06-06",
      "最新状态": "复查通过，完成整改",
      "复查结论": "合格，可转入闭环归档",
      "effective_source_file": "projects/PRJ-A17/formal/recheck_opinion_RO-2026-041.md",
      "superseded_source_files": [
        "projects/PRJ-A17/formal/rectification_notice_RN-2026-077.md",
        "projects/PRJ-A17/archive/2026-05-21_rectification_notice_RN-2026-077_draft.md",
        "projects/PRJ-A17/supplement/site_note_SN-2026-077A.md"
      ],
      "conflict_notes": "补充说明SN-2026-077A提出将整改期限延至2026-06-10，但该申请未获监督站签发的延期确认，且未被正式复查意见书RO-2026-041引用或采纳，故不改变原期限2026-06-06。归档草稿RN-2026-077_draft（金额¥12,000、期限2026-06-03）已被同项目同期正式签发版本取代，不得作为当前依据。"
    },
    {
      "project_id": "PRJ-B24",
      "项目名称": "北辰仓储园冷链库消防改造",
      "建设单位": "北辰供应链管理有限公司",
      "施工单位": "衡远机电安装有限公司",
      "违规类型": "消防喷淋管网试压记录缺失",
      "处罚金额": "¥26,500.00",
      "整改期限": "2026-06-12",
      "最新状态": "复查不合格，继续整改",
      "复查结论": "不合格，须补交第三方试压报告并重新申请复查",
      "effective_source_file": "projects/PRJ-B24/formal/recheck_opinion_RO-2026-052.md",
      "superseded_source_files": [
        "projects/PRJ-B24/formal/rectification_notice_RN-2026-083.md",
        "projects/PRJ-B24/archive/2026-05-18_recheck_opinion_RO-2026-049_archived.md",
        "projects/PRJ-B24/supplement/payment_note_SN-2026-083B.md"
      ],
      "conflict_notes": "补充说明SN-2026-083B建议暂按¥15,000办理预缴，但文书明确声明'不改变处罚决定金额，不改变整改期限，不构成复查结论'，且未被正式复查意见书RO-2026-052引用或采纳，故不影响原金额¥26,500.00和期限2026-06-12。归档旧件RO-2026-049对应5月上旬旧问题（关联RN-2026-071），与RN-2026-083不属于同一整改事项，已归档不可覆盖当前有效文书。"
    },
    {
      "project_id": "PRJ-C31",
      "项目名称": "星桥学校综合楼加固项目",
      "建设单位": "星桥教育资产运营中心",
      "施工单位": "陆衡建设集团有限公司",
      "违规类型": "脚手架连墙件设置不符合方案",
      "处罚金额": "¥0.00",
      "整改期限": "2026-06-04",
      "最新状态": "等待复查",
      "复查结论": null,
      "effective_source_file": "projects/PRJ-C31/formal/rectification_notice_RN-2026-091.md",
      "superseded_source_files": [
        "projects/PRJ-C31/archive/2026-05-27_rectification_notice_RN-2026-088_old.md",
        "projects/PRJ-C31/supplement/material_note_SN-2026-091C.md"
      ],
      "conflict_notes": "本项目无正式复查意见书，以正式整改通知RN-2026-091为唯一有效来源。补充说明SN-2026-091C提及材料到场及计划复核时间，但明确声明'本说明不是复查意见书，不得据此将项目状态标记为复查通过'，故不能作为复查结论依据。归档旧件RN-2026-088_old针对另一独立问题（材料堆放堵塞通道，金额¥5,000，期限2026-06-01），该问题已另案闭环，不得覆盖RN-2026-091所述连墙件问题。"
    }
  ],
  "unmatched_files": [
    {
      "path": "projects/UNMATCHED/formal/rectification_notice_RN-2026-099.md",
      "reason": "文书编号RN-2026-099对应的工程项目ID为PRJ-X00（未入台账的临时围挡工程），不在inspection_register.md列出的三个有效项目范围内，无法归入任何台账项目。"
    }
  ],
  "summary": {
    "project_count": 3,
    "completed_count": 1,
    "continued_rectification_count": 1,
    "pending_recheck_count": 1,
    "unmatched_file_count": 1,
    "conflict_project_count": 3,
    "effective_recheck_count": 2,
    "effective_notice_count": 1
  }
}
