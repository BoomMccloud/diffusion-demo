# Workbook: factor_workbook.xlsx

## Sheet 1: research_points
Dimensions: 4 rows x 10 columns
R1: point_id | canonical_company_id | canonical_company_name | canonical_sector_name | point_type | effective_source_time | summary_text | source_document | section_or_table | superseded_source
R2: P1 | C001 | 星河电子股份有限公司 | 智能终端零部件 | 核心观点 | 2026-04-18 19:45 | 订单能见度维持正向判断，观察期限由早间简报的1-2Q调整为2Q；海外库存压力维持负向。 | research_report_evening.html | 一、更新后的核心观点 | M-T1-R1（早间简报：订单能见度观察期限1-2Q）
R3: P2 | C002 | 云澜设备控股 | 云计算设备 | 核心观点 | 2026-04-18 19:45 | 云计算资本开支节奏扰动较大，盈利质量在早间口径下暂评为中性；晚间新增费用率改善线索，方向为positive，观察期限为FY2026H2。 | research_report_evening.html | 一、更新后的核心观点 | M-T1-R3（早间简报：盈利质量中性，FY2026），作为背景保留但不替代新因子
R4: P3 | C003 | 海柏材料集团 | 上游电子材料 | 核心观点 | 2026-04-18 19:45 | 采购价格波动仍在传导，原料成本因子从早间负向修订为neutral，观察期限仍为2Q。 | research_report_evening.html | 一、更新后的核心观点 | M-T1-R4（早间简报：原料成本偏负向）

## Sheet 2: factor_mentions
Dimensions: 8 rows x 11 columns
R1: factor_row_id | canonical_company_id | factor_id | factor_name | direction | horizon | evidence_text | effective_source_time | source_document | section_or_table | superseded_source
R2: FM-001 | C001 | F_INVENTORY | 库存压力 | negative | 1Q | 海外库存去化仍是后续观察变量；晚间确认海外库存压力维持负向。 | 2026-04-18 08:35 | research_report_morning.pdf | 摘要 / 表1：因子暴露摘要 | 
R3: FM-002 | C001 | F_ORDER_VIS | 订单能见度 | positive | 2Q | 订单能见度仍维持正向判断，但观察期限由早间简报中的1-2Q调整为2Q。 | 2026-04-18 19:45 | research_report_evening.html | 一、更新后的核心观点 / 表A：晚间因子修订表 | M-T1-R1（早间简报：订单能见度观察期限1-2Q）
R4: FM-003 | C001 | F_ORDER_VIS | 订单能见度 | positive | 1-2Q | 订单能见度改善，短周期景气因子偏正向。 | 2026-04-18 08:35 | research_report_morning.pdf | 二、表1：因子暴露摘要 | 
R5: FM-004 | C002 | F_EXPENSE_RATIO | 费用率改善 | positive | FY2026H2 | 云澜设备新增费用率改善线索，方向记录为positive，观察期限为FY2026H2。 | 2026-04-18 19:45 | research_report_evening.html | 一、更新后的核心观点 / 表A：晚间因子修订表 | 
R6: FM-005 | C002 | F_PROFIT_QUALITY | 盈利质量 | neutral | FY2026 | 云计算资本开支节奏扰动较大，盈利质量在早间口径下暂评为中性。 | 2026-04-18 08:35 | research_report_morning.pdf | 二、表1：因子暴露摘要 | 
R7: FM-006 | C003 | F_RAW_MATERIAL | 原料成本 | negative | 2Q | 采购价格波动仍在传导，原料成本因子在早间口径下偏负向。 | 2026-04-18 08:35 | research_report_morning.pdf | 二、表1：因子暴露摘要 | 
R8: FM-007 | C003 | F_RAW_MATERIAL | 原料成本 | neutral | 2Q | 原料成本因子的早间负向口径已被晚间采购锁价覆盖信息修订，当前方向按neutral记录，观察期限仍为2Q。 | 2026-04-18 19:45 | research_report_evening.html | 一、更新后的核心观点 / 表A：晚间因子修订表 | M-T1-R4（早间简报：原料成本偏负向）

## Sheet 3: risk_disclosures
Dimensions: 7 rows x 6 columns
R1: risk_id | canonical_company_id | risk_type | risk_text | source_document | section_or_table
R2: R1 | C001 | inventory | 若海外库存去化低于预期，星河电子订单能见度改善可能延后。 | research_report_morning.pdf | 三、风险提示
R3: R2 | C002 | capex | 若云计算资本开支节奏放缓，云澜设备收入确认与费用率改善可能后移。 | research_report_morning.pdf | 三、风险提示
R4: R3 | C003 | raw_material | 若上游采购价格继续波动，海柏材料毛利率仍可能承压。 | research_report_morning.pdf | 三、风险提示
R5: R4 | C001 | demand | 若终端需求弱于预期，星河电子订单兑现节奏可能放缓。 | research_report_evening.html | 三、风险提示
R6: R5 | C002 | capex | 若云计算资本开支延期，云澜设备费用率改善可能低于预期。 | research_report_evening.html | 三、风险提示
R7: R6 | C003 | raw_material | 若锁价覆盖不足，海柏材料毛利率仍可能承压。 | research_report_evening.html | 三、风险提示
