{
  "research_points": [
    {
      "point_id": "P1",
      "canonical_company_id": "C001",
      "canonical_company_name": "星河电子股份有限公司",
      "canonical_sector_name": "智能终端零部件",
      "point_type": "核心观点",
      "effective_source_time": "2026-04-18 19:45",
      "summary_text": "订单能见度维持正向判断，观察期限由早间简报的1-2Q调整为2Q；海外库存压力维持负向。",
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "superseded_source": "M-T1-R1（早间简报：订单能见度观察期限1-2Q）"
    },
    {
      "point_id": "P2",
      "canonical_company_id": "C002",
      "canonical_company_name": "云澜设备控股",
      "canonical_sector_name": "云计算设备",
      "point_type": "核心观点",
      "effective_source_time": "2026-04-18 19:45",
      "summary_text": "云计算资本开支节奏扰动较大，盈利质量在早间口径下暂评为中性；晚间新增费用率改善线索，方向为positive，观察期限为FY2026H2。",
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "superseded_source": "M-T1-R3（早间简报：盈利质量中性，FY2026），作为背景保留但不替代新因子"
    },
    {
      "point_id": "P3",
      "canonical_company_id": "C003",
      "canonical_company_name": "海柏材料集团",
      "canonical_sector_name": "上游电子材料",
      "point_type": "核心观点",
      "effective_source_time": "2026-04-18 19:45",
      "summary_text": "采购价格波动仍在传导，原料成本因子从早间负向修订为neutral，观察期限仍为2Q。",
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "superseded_source": "M-T1-R4（早间简报：原料成本偏负向）"
    }
  ],
  "factor_mentions": [
    {
      "factor_row_id": "FM-001",
      "canonical_company_id": "C001",
      "factor_id": "F_INVENTORY",
      "factor_name": "库存压力",
      "direction": "negative",
      "horizon": "1Q",
      "evidence_text": "海外库存去化仍是后续观察变量；晚间确认海外库存压力维持负向。",
      "effective_source_time": "2026-04-18 08:35",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "superseded_source": ""
    },
    {
      "factor_row_id": "FM-002",
      "canonical_company_id": "C001",
      "factor_id": "F_ORDER_VIS",
      "factor_name": "订单能见度",
      "direction": "positive",
      "horizon": "2Q",
      "evidence_text": "订单能见度仍维持正向判断，但观察期限由早间简报中的1-2Q调整为2Q。",
      "effective_source_time": "2026-04-18 19:45",
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "superseded_source": "M-T1-R1（早间简报：订单能见度观察期限1-2Q）"
    },
    {
      "factor_row_id": "FM-003",
      "canonical_company_id": "C001",
      "factor_id": "F_ORDER_VIS",
      "factor_name": "订单能见度",
      "direction": "positive",
      "horizon": "1-2Q",
      "evidence_text": "订单能见度改善，短周期景气因子偏正向。",
      "effective_source_time": "2026-04-18 08:35",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "superseded_source": ""
    },
    {
      "factor_row_id": "FM-004",
      "canonical_company_id": "C002",
      "factor_id": "F_EXPENSE_RATIO",
      "factor_name": "费用率改善",
      "direction": "positive",
      "horizon": "FY2026H2",
      "evidence_text": "云澜设备新增费用率改善线索，方向记录为positive，观察期限为FY2026H2。",
      "effective_source_time": "2026-04-18 19:45",
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "superseded_source": ""
    },
    {
      "factor_row_id": "FM-005",
      "canonical_company_id": "C002",
      "factor_id": "F_PROFIT_QUALITY",
      "factor_name": "盈利质量",
      "direction": "neutral",
      "horizon": "FY2026",
      "evidence_text": "云计算资本开支节奏扰动较大，盈利质量在早间口径下暂评为中性。",
      "effective_source_time": "2026-04-18 08:35",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "superseded_source": ""
    },
    {
      "factor_row_id": "FM-006",
      "canonical_company_id": "C003",
      "factor_id": "F_RAW_MATERIAL",
      "factor_name": "原料成本",
      "direction": "negative",
      "horizon": "2Q",
      "evidence_text": "采购价格波动仍在传导，原料成本因子在早间口径下偏负向。",
      "effective_source_time": "2026-04-18 08:35",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "superseded_source": ""
    },
    {
      "factor_row_id": "FM-007",
      "canonical_company_id": "C003",
      "factor_id": "F_RAW_MATERIAL",
      "factor_name": "原料成本",
      "direction": "neutral",
      "horizon": "2Q",
      "evidence_text": "原料成本因子的早间负向口径已被晚间采购锁价覆盖信息修订，当前方向按neutral记录，观察期限仍为2Q。",
      "effective_source_time": "2026-04-18 19:45",
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "superseded_source": "M-T1-R4（早间简报：原料成本偏负向）"
    }
  ],
  "risk_disclosures": [
    {
      "risk_id": "R1",
      "canonical_company_id": "C001",
      "risk_type": "inventory",
      "risk_text": "若海外库存去化低于预期，星河电子订单能见度改善可能延后。",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示"
    },
    {
      "risk_id": "R2",
      "canonical_company_id": "C002",
      "risk_type": "capex",
      "risk_text": "若云计算资本开支节奏放缓，云澜设备收入确认与费用率改善可能后移。",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示"
    },
    {
      "risk_id": "R3",
      "canonical_company_id": "C003",
      "risk_type": "raw_material",
      "risk_text": "若上游采购价格继续波动，海柏材料毛利率仍可能承压。",
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示"
    },
    {
      "risk_id": "R4",
      "canonical_company_id": "C001",
      "risk_type": "demand",
      "risk_text": "若终端需求弱于预期，星河电子订单兑现节奏可能放缓。",
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示"
    },
    {
      "risk_id": "R5",
      "canonical_company_id": "C002",
      "risk_type": "capex",
      "risk_text": "若云计算资本开支延期，云澜设备费用率改善可能低于预期。",
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示"
    },
    {
      "risk_id": "R6",
      "canonical_company_id": "C003",
      "risk_type": "raw_material",
      "risk_text": "若锁价覆盖不足，海柏材料毛利率仍可能承压。",
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示"
    }
  ],
  "citation_map": {
    "research_points:P1:point_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "P1"
    },
    "research_points:P1:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "C001"
    },
    "research_points:P1:canonical_company_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "星河电子股份有限公司"
    },
    "research_points:P1:canonical_sector_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "智能终端零部件"
    },
    "research_points:P1:point_type": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "核心观点"
    },
    "research_points:P1:effective_source_time": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "2026-04-18 19:45"
    },
    "research_points:P1:summary_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "订单能见度维持正向判断，观察期限由早间简"
    },
    "research_points:P1:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "research_report_evening.html"
    },
    "research_points:P1:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "一、更新后的核心观点"
    },
    "research_points:P1:superseded_source": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "M-T1-R1（早间简报：订单能见度观察期限1-2Q）"
    },
    "research_points:P2:point_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "P2"
    },
    "research_points:P2:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "C002"
    },
    "research_points:P2:canonical_company_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "云澜设备控股"
    },
    "research_points:P2:canonical_sector_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "云计算设备"
    },
    "research_points:P2:point_type": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "核心观点"
    },
    "research_points:P2:effective_source_time": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "2026-04-18 19:45"
    },
    "research_points:P2:summary_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "云计算资本开支节奏扰动较大，盈利质量在早"
    },
    "research_points:P2:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "research_report_evening.html"
    },
    "research_points:P2:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "一、更新后的核心观点"
    },
    "research_points:P2:superseded_source": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "M-T1-R3（早间简报：盈利质量中性，FY2026），作为背景保留但不替代新因子"
    },
    "research_points:P3:point_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "P3"
    },
    "research_points:P3:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "C003"
    },
    "research_points:P3:canonical_company_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "海柏材料集团"
    },
    "research_points:P3:canonical_sector_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "上游电子材料"
    },
    "research_points:P3:point_type": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "核心观点"
    },
    "research_points:P3:effective_source_time": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "2026-04-18 19:45"
    },
    "research_points:P3:summary_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "采购价格波动仍在传导，原料成本因子从早间"
    },
    "research_points:P3:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "research_report_evening.html"
    },
    "research_points:P3:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "一、更新后的核心观点"
    },
    "research_points:P3:superseded_source": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点",
      "snippet_anchor": "M-T1-R4（早间简报：原料成本偏负向）"
    },
    "factor_mentions:FM-001:factor_row_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "FM-001"
    },
    "factor_mentions:FM-001:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "C001"
    },
    "factor_mentions:FM-001:factor_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "F_INVENTORY"
    },
    "factor_mentions:FM-001:factor_name": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "库存压力"
    },
    "factor_mentions:FM-001:direction": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "negative"
    },
    "factor_mentions:FM-001:horizon": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "1Q"
    },
    "factor_mentions:FM-001:evidence_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "海外库存去化仍是后续观察变量；晚间确认海"
    },
    "factor_mentions:FM-001:effective_source_time": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "2026-04-18 08:35"
    },
    "factor_mentions:FM-001:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "factor_mentions:FM-001:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "摘要 / 表1：因子暴露摘要",
      "snippet_anchor": "摘要 / 表1：因子暴露摘要"
    },
    "factor_mentions:FM-002:factor_row_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "FM-002"
    },
    "factor_mentions:FM-002:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "C001"
    },
    "factor_mentions:FM-002:factor_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "F_ORDER_VIS"
    },
    "factor_mentions:FM-002:factor_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "订单能见度"
    },
    "factor_mentions:FM-002:direction": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "positive"
    },
    "factor_mentions:FM-002:horizon": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "2Q"
    },
    "factor_mentions:FM-002:evidence_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "订单能见度仍维持正向判断，但观察期限由早"
    },
    "factor_mentions:FM-002:effective_source_time": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "2026-04-18 19:45"
    },
    "factor_mentions:FM-002:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "research_report_evening.html"
    },
    "factor_mentions:FM-002:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "一、更新后的核心观点 / 表A：晚间因子修订表"
    },
    "factor_mentions:FM-002:superseded_source": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "M-T1-R1（早间简报：订单能见度观察期限1-2Q）"
    },
    "factor_mentions:FM-003:factor_row_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "FM-003"
    },
    "factor_mentions:FM-003:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "C001"
    },
    "factor_mentions:FM-003:factor_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "F_ORDER_VIS"
    },
    "factor_mentions:FM-003:factor_name": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "订单能见度"
    },
    "factor_mentions:FM-003:direction": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "positive"
    },
    "factor_mentions:FM-003:horizon": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "1-2Q"
    },
    "factor_mentions:FM-003:evidence_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "订单能见度改善，短周期景气因子偏正向。"
    },
    "factor_mentions:FM-003:effective_source_time": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "2026-04-18 08:35"
    },
    "factor_mentions:FM-003:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "factor_mentions:FM-003:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "二、表1：因子暴露摘要"
    },
    "factor_mentions:FM-004:factor_row_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "FM-004"
    },
    "factor_mentions:FM-004:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "C002"
    },
    "factor_mentions:FM-004:factor_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "F_EXPENSE_RATIO"
    },
    "factor_mentions:FM-004:factor_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "费用率改善"
    },
    "factor_mentions:FM-004:direction": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "positive"
    },
    "factor_mentions:FM-004:horizon": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "FY2026H2"
    },
    "factor_mentions:FM-004:evidence_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "云澜设备新增费用率改善线索，方向记录为p"
    },
    "factor_mentions:FM-004:effective_source_time": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "2026-04-18 19:45"
    },
    "factor_mentions:FM-004:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "research_report_evening.html"
    },
    "factor_mentions:FM-004:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "一、更新后的核心观点 / 表A：晚间因子修订表"
    },
    "factor_mentions:FM-005:factor_row_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "FM-005"
    },
    "factor_mentions:FM-005:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "C002"
    },
    "factor_mentions:FM-005:factor_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "F_PROFIT_QUALITY"
    },
    "factor_mentions:FM-005:factor_name": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "盈利质量"
    },
    "factor_mentions:FM-005:direction": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "neutral"
    },
    "factor_mentions:FM-005:horizon": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "FY2026"
    },
    "factor_mentions:FM-005:evidence_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "云计算资本开支节奏扰动较大，盈利质量在早"
    },
    "factor_mentions:FM-005:effective_source_time": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "2026-04-18 08:35"
    },
    "factor_mentions:FM-005:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "factor_mentions:FM-005:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "二、表1：因子暴露摘要"
    },
    "factor_mentions:FM-006:factor_row_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "FM-006"
    },
    "factor_mentions:FM-006:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "C003"
    },
    "factor_mentions:FM-006:factor_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "F_RAW_MATERIAL"
    },
    "factor_mentions:FM-006:factor_name": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "原料成本"
    },
    "factor_mentions:FM-006:direction": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "negative"
    },
    "factor_mentions:FM-006:horizon": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "2Q"
    },
    "factor_mentions:FM-006:evidence_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "采购价格波动仍在传导，原料成本因子在早间"
    },
    "factor_mentions:FM-006:effective_source_time": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "2026-04-18 08:35"
    },
    "factor_mentions:FM-006:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "factor_mentions:FM-006:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "二、表1：因子暴露摘要",
      "snippet_anchor": "二、表1：因子暴露摘要"
    },
    "factor_mentions:FM-007:factor_row_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "FM-007"
    },
    "factor_mentions:FM-007:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "C003"
    },
    "factor_mentions:FM-007:factor_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "F_RAW_MATERIAL"
    },
    "factor_mentions:FM-007:factor_name": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "原料成本"
    },
    "factor_mentions:FM-007:direction": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "neutral"
    },
    "factor_mentions:FM-007:horizon": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "2Q"
    },
    "factor_mentions:FM-007:evidence_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "原料成本因子的早间负向口径已被晚间采购锁"
    },
    "factor_mentions:FM-007:effective_source_time": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "2026-04-18 19:45"
    },
    "factor_mentions:FM-007:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "research_report_evening.html"
    },
    "factor_mentions:FM-007:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "一、更新后的核心观点 / 表A：晚间因子修订表"
    },
    "factor_mentions:FM-007:superseded_source": {
      "source_document": "research_report_evening.html",
      "section_or_table": "一、更新后的核心观点 / 表A：晚间因子修订表",
      "snippet_anchor": "M-T1-R4（早间简报：原料成本偏负向）"
    },
    "risk_disclosures:R1:risk_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "R1"
    },
    "risk_disclosures:R1:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "C001"
    },
    "risk_disclosures:R1:risk_type": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "inventory"
    },
    "risk_disclosures:R1:risk_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "若海外库存去化低于预期，星河电子订单能见"
    },
    "risk_disclosures:R1:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "risk_disclosures:R1:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "三、风险提示"
    },
    "risk_disclosures:R2:risk_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "R2"
    },
    "risk_disclosures:R2:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "C002"
    },
    "risk_disclosures:R2:risk_type": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "capex"
    },
    "risk_disclosures:R2:risk_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "若云计算资本开支节奏放缓，云澜设备收入确"
    },
    "risk_disclosures:R2:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "risk_disclosures:R2:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "三、风险提示"
    },
    "risk_disclosures:R3:risk_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "R3"
    },
    "risk_disclosures:R3:canonical_company_id": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "C003"
    },
    "risk_disclosures:R3:risk_type": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "raw_material"
    },
    "risk_disclosures:R3:risk_text": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "若上游采购价格继续波动，海柏材料毛利率仍"
    },
    "risk_disclosures:R3:source_document": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "research_report_morning.pdf"
    },
    "risk_disclosures:R3:section_or_table": {
      "source_document": "research_report_morning.pdf",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "三、风险提示"
    },
    "risk_disclosures:R4:risk_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "R4"
    },
    "risk_disclosures:R4:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "C001"
    },
    "risk_disclosures:R4:risk_type": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "demand"
    },
    "risk_disclosures:R4:risk_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "若终端需求弱于预期，星河电子订单兑现节奏"
    },
    "risk_disclosures:R4:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "research_report_evening.html"
    },
    "risk_disclosures:R4:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "三、风险提示"
    },
    "risk_disclosures:R5:risk_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "R5"
    },
    "risk_disclosures:R5:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "C002"
    },
    "risk_disclosures:R5:risk_type": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "capex"
    },
    "risk_disclosures:R5:risk_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "若云计算资本开支延期，云澜设备费用率改善"
    },
    "risk_disclosures:R5:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "research_report_evening.html"
    },
    "risk_disclosures:R5:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "三、风险提示"
    },
    "risk_disclosures:R6:risk_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "R6"
    },
    "risk_disclosures:R6:canonical_company_id": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "C003"
    },
    "risk_disclosures:R6:risk_type": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "raw_material"
    },
    "risk_disclosures:R6:risk_text": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "若锁价覆盖不足，海柏材料毛利率仍可能承压"
    },
    "risk_disclosures:R6:source_document": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "research_report_evening.html"
    },
    "risk_disclosures:R6:section_or_table": {
      "source_document": "research_report_evening.html",
      "section_or_table": "三、风险提示",
      "snippet_anchor": "三、风险提示"
    }
  }
}