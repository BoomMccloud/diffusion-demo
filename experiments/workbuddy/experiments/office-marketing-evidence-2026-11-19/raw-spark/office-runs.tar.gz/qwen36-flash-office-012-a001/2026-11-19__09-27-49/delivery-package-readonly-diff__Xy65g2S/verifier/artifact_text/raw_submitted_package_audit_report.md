# =============================================================================
# Edu Toolkit Release Package — Handoff Audit Report
# Generated: 2026-09-18T14:30Z
# Auditor: read-only automated reconciliation
# =============================================================================

readonly_confirmation:
  confirmed: true
  statement: >
    All source materials under input/workspace/ were read only. No files were
    edited, deleted, renamed, copied-as-repair, or repacked. The candidate
    archive and all analysis notes remain untouched.
  protected_roots:
    - input/workspace/reference_release_manifest/
    - input/workspace/candidate_package_view/
    - input/workspace/analysis_notes/
    - environment/local_readonly_audit/
    - environment/state_diff_manifest.json
  output_written:
    - input/workspace/output/package_audit_report.yaml

evidence_sources_used:
  - path: input/workspace/reference_release_manifest/reference_manifest.csv
    description: "Reference manifest — 79 rows (MF-0001 through MF-0079)"
    role: authoritative expected paths, SHA-256 prefixes, packaging rules
  - path: input/workspace/reference_release_manifest/manifest_notes.md
    description: "Manifest component-count hints and packaging-rule guidance"
    role: context for expected distribution across components
  - path: input/workspace/candidate_package_view/archive_metadata.json
    description: "Archive metadata — label, entry count, container hash"
    role: confirms 82-entry candidate archive; not_to_be_repacked
  - path: input/workspace/candidate_package_view/listings/candidate_archive_listing.csv
    description: "Candidate listing — 82 rows with observed paths, bytes, sha256_prefix"
    role: primary observed-state source for reconciliation
  - path: input/workspace/candidate_package_view/listings/candidate_tree_view.txt
    description: "Tree-formatted candidate listing"
    role: corroborating view of candidate contents
  - path: input/workspace/analysis_notes/hash_checks/hash_compare_scratch.txt
    description: "Current-run hash-prefix scan warnings (10 metadata-review flagged) + absent probes (5) + stale run markers"
    role: corroborates changed/inconclusive classifications; stale lines explicitly excluded
  - path: input/workspace/analysis_notes/listing_checks/path_probe_notes.md
    description: "Near-match path stems flagged for manual alignment"
    role: identifies locale-punctuation, hyphen/underscore, and directory-name variants
  - path: input/workspace/analysis_notes/noisy_logs/partial_compare_run.log
    description: "Aborted comparison log at docs/reference window; partial outputs only"
    role: acknowledged as stale/partial; used only for cross-reference, not as authoritative classification
  - path: input/workspace/environment/local_readonly_audit/README.md
    description: "Offline read-only environment confirmation"
    role: confirms no live service or credential dependencies
  - path: input/workspace/environment/state_diff_manifest.json
    description: "Schema version contract — recommendation policy"
    role: defines ready_to_attach vs revise_before_handoff criteria

summary_counts:
  manifest_rows: 79
  candidate_entries: 82
  matching: 55
  changed: 13
  missing: 8
  extra: 11
  inconclusive: 3
  total_accounted: 79
  unaccounted: 0

findings:
  matching:
    - manifest_id: MF-0001
      expected_path: edu_toolkit/docs/guides/getting_started.md
      expected_sha256_prefix: sha256:0089d69316ecea7a
      observed_sha256_prefix: sha256:0089d69316ecea7a
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0002
      expected_path: edu_toolkit/docs/guides/teacher_quickstart.md
      expected_sha256_prefix: sha256:52d8f7f0b5cdc2bb
      observed_sha256_prefix: sha256:52d8f7f0b5cdc2bb
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0004
      expected_path: edu_toolkit/docs/guides/offline_mode.md
      expected_sha256_prefix: sha256:294b0e8b2b6c88ae
      observed_sha256_prefix: sha256:294b0e8b2b6c88ae
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0005
      expected_path: edu_toolkit/docs/guides/accessibility_notes.md
      expected_sha256_prefix: sha256:c965b5c0431d39ad
      observed_sha256_prefix: sha256:c965b5c0431d39ad
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0006
      expected_path: edu_toolkit/docs/guides/localization/en_US/overview.md
      expected_sha256_prefix: sha256:4cedb066ab77181d
      observed_sha256_prefix: sha256:4cedb066ab77181d
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0008
      expected_path: edu_toolkit/docs/guides/localization/es_ES/overview.md
      expected_sha256_prefix: sha256:0e10704776ba55ad
      observed_sha256_prefix: sha256:0e10704776ba55ad
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0009
      expected_path: edu_toolkit/docs/guides/troubleshooting/install_errors.md
      expected_sha256_prefix: sha256:2cce75153a0d7e78
      observed_sha256_prefix: sha256:2cce75153a0d7e78
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0011
      expected_path: edu_toolkit/docs/guides/changelog_highlights.md
      expected_sha256_prefix: sha256:5fcdc19204d0c21d
      observed_sha256_prefix: sha256:5fcdc19204d0c21d
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0012
      expected_path: edu_toolkit/docs/reference/api/v1_4/endpoints.md
      expected_sha256_prefix: sha256:7f75b43a4965916c
      observed_sha256_prefix: sha256:7f75b43a4965916c
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0013
      expected_path: edu_toolkit/docs/reference/api/v1_4/errors.md
      expected_sha256_prefix: sha256:db275191825f94eb
      observed_sha256_prefix: sha256:db275191825f94eb
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0014
      expected_path: edu_toolkit/docs/reference/api/v1_4/auth_notes.md
      expected_sha256_prefix: sha256:fe310e33b81df742
      observed_sha256_prefix: sha256:fe310e33b81df742
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0016
      expected_path: edu_toolkit/docs/reference/api/v1_4/schema/classroom_event.yaml
      expected_sha256_prefix: sha256:8acd3a4fabac711e
      observed_sha256_prefix: sha256:8acd3a4fabac711e
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0017
      expected_path: edu_toolkit/docs/reference/api/v1_4/schema/assessment_result.yaml
      expected_sha256_prefix: sha256:101e57f7609ca69f
      observed_sha256_prefix: sha256:101e57f7609ca69f
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0019
      expected_path: edu_toolkit/docs/reference/api/v1_4/examples/error_payload.json
      expected_sha256_prefix: sha256:dad5ba13c4552a57
      observed_sha256_prefix: sha256:dad5ba13c4552a57
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0020
      expected_path: edu_toolkit/docs/reference/cli/command_index.md
      expected_sha256_prefix: sha256:333d3898009826c8
      observed_sha256_prefix: sha256:333d3898009826c8
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0021
      expected_path: edu_toolkit/data/samples/classroom/roster_alpha.csv
      expected_sha256_prefix: sha256:95ca9389b8f67249
      observed_sha256_prefix: sha256:95ca9389b8f67249
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0023
      expected_path: edu_toolkit/data/samples/classroom/roster_gamma.csv
      expected_sha256_prefix: sha256:0fca27af953129ce
      observed_sha256_prefix: sha256:0fca27af953129ce
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0024
      expected_path: edu_toolkit/data/samples/events/2026-09-week01.jsonl
      expected_sha256_prefix: sha256:a04cc94675a7f03d
      observed_sha256_prefix: sha256:a04cc94675a7f03d
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0026
      expected_path: edu_toolkit/data/samples/events/2026-09-week03.jsonl
      expected_sha256_prefix: sha256:b48bbe52dff6cb45
      observed_sha256_prefix: sha256:b48bbe52dff6cb45
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0028
      expected_path: edu_toolkit/data/samples/templates/student_import_template.csv
      expected_sha256_prefix: sha256:cebd6874bb981e94
      observed_sha256_prefix: sha256:cebd6874bb981e94
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0029
      expected_path: edu_toolkit/data/samples/templates/assessment_import_template.csv
      expected_sha256_prefix: sha256:efbf7d15a712c4eb
      observed_sha256_prefix: sha256:efbf7d15a712c4eb
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0031
      expected_path: edu_toolkit/data/samples/media_manifest.csv
      expected_sha256_prefix: sha256:c063e32677b3df3f
      observed_sha256_prefix: sha256:c063e32677b3df3f
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0032
      expected_path: edu_toolkit/data/samples/README.md
      expected_sha256_prefix: sha256:69a7858079ae18ba
      observed_sha256_prefix: sha256:69a7858079ae18ba
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0033
      expected_path: edu_toolkit/config/templates/course_defaults.yaml
      expected_sha256_prefix: sha256:05ad12fc1bf2cd88
      observed_sha256_prefix: sha256:05ad12fc1bf2cd88
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0034
      expected_path: edu_toolkit/config/templates/grading_scale.yaml
      expected_sha256_prefix: sha256:8dad203677d27e9c
      observed_sha256_prefix: sha256:8dad203677d27e9c
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0036
      expected_path: edu_toolkit/config/templates/export_profile_public.yaml
      expected_sha256_prefix: sha256:87ca7d4634b3baaa
      observed_sha256_prefix: sha256:87ca7d4634b3baaa
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0038
      expected_path: edu_toolkit/config/templates/local_run/checks.yaml
      expected_sha256_prefix: sha256:40cc9357c15e7704
      observed_sha256_prefix: sha256:40cc9357c15e7704
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0040
      expected_path: edu_toolkit/config/templates/local_run/logging.yaml
      expected_sha256_prefix: sha256:b60505461174547a
      observed_sha256_prefix: sha256:b60505461174547a
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0041
      expected_path: edu_toolkit/config/templates/archive/package_notes.txt
      expected_sha256_prefix: sha256:7a306e51ec30cb7a
      observed_sha256_prefix: sha256:7a306e51ec30cb7a
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0042
      expected_path: edu_toolkit/config/templates/archive/include_patterns.txt
      expected_sha256_prefix: sha256:88a2c4f13fdee46c
      observed_sha256_prefix: sha256:88a2c4f13fdee46c
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0043
      expected_path: edu_toolkit/src/validation/__init__.py
      expected_sha256_prefix: sha256:275ddd74fb170959
      observed_sha256_prefix: sha256:275ddd74fb170959
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0044
      expected_path: edu_toolkit/src/validation/check_manifest.py
      expected_sha256_prefix: sha256:21034b3c72424cf6
      observed_sha256_prefix: sha256:21034b3c72424cf6
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0045
      expected_path: edu_toolkit/src/validation/check_paths.py
      expected_sha256_prefix: sha256:8fba564f4c4b6bfc
      observed_sha256_prefix: sha256:8fba564f4c4b6bfc
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0047
      expected_path: edu_toolkit/src/validation/rules/schema_rules.py
      expected_sha256_prefix: sha256:31a7bca9b543cddf
      observed_sha256_prefix: sha256:31a7bca9b543cddf
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0048
      expected_path: edu_toolkit/src/validation/rules/path_rules.py
      expected_sha256_prefix: sha256:642b7f3926350a12
      observed_sha256_prefix: sha256:642b7f3926350a12
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0051
      expected_path: edu_toolkit/src/validation/fixtures/valid_manifest_case.json
      expected_sha256_prefix: sha256:e88244c1be3dce23
      observed_sha256_prefix: sha256:e88244c1be3dce23
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0052
      expected_path: edu_toolkit/src/validation/fixtures/path_case_mixed_locale.json
      expected_sha256_prefix: sha256:e220e8fd7ed1ed66
      observed_sha256_prefix: sha256:e220e8fd7ed1ed66
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0053
      expected_path: edu_toolkit/tests/fixtures/manifest/minimal_manifest.json
      expected_sha256_prefix: sha256:39bc5112cc342beb
      observed_sha256_prefix: sha256:39bc5112cc342beb
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0054
      expected_path: edu_toolkit/tests/fixtures/manifest/full_manifest.json
      expected_sha256_prefix: sha256:c8de3b5ae5eef1a3
      observed_sha256_prefix: sha256:c8de3b5ae5eef1a3
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0055
      expected_path: edu_toolkit/tests/fixtures/archive/expected_tree_snapshot.txt
      expected_sha256_prefix: sha256:9a72ec8505edeb7a
      observed_sha256_prefix: sha256:9a72ec8505edeb7a
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0059
      expected_path: edu_toolkit/tests/fixtures/reports/report_success.md
      expected_sha256_prefix: sha256:6234da8221ca76c9
      observed_sha256_prefix: sha256:6234da8221ca76c9
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0060
      expected_path: edu_toolkit/tests/fixtures/reports/report_with_warnings.md
      expected_sha256_prefix: sha256:9beaec247ea686c8
      observed_sha256_prefix: sha256:9beaec247ea686c8
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0062
      expected_path: edu_toolkit/tests/fixtures/README.md
      expected_sha256_prefix: sha256:a5ff94eb02dd88ff
      observed_sha256_prefix: sha256:a5ff94eb02dd88ff
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0063
      expected_path: edu_toolkit/release/checksums/SHA256SUMS.txt
      expected_sha256_prefix: sha256:e17d293f9ca8d4f8
      observed_sha256_prefix: sha256:e17d293f9ca8d4f8
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0065
      expected_path: edu_toolkit/release/checksums/archive_manifest.json
      expected_sha256_prefix: sha256:330ca22083597d37
      observed_sha256_prefix: sha256:330ca22083597d37
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0067
      expected_path: edu_toolkit/release/checksums/generated_at.txt
      expected_sha256_prefix: sha256:303b224725226e3d
      observed_sha256_prefix: sha256:303b224725226e3d
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0068
      expected_path: edu_toolkit/release/checksums/README.md
      expected_sha256_prefix: sha256:9e123dd75782c9bd
      observed_sha256_prefix: sha256:9e123dd75782c9bd
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0069
      expected_path: edu_toolkit/release/checksums/draft_compare_notes.txt
      expected_sha256_prefix: sha256:63664185b8f7ab4e
      observed_sha256_prefix: sha256:63664185b8f7ab4e
      packaging_rule: include_if_present
      required: optional
    - manifest_id: MF-0070
      expected_path: edu_toolkit/README.md
      expected_sha256_prefix: sha256:6ecfed6369ccda52
      observed_sha256_prefix: sha256:6ecfed6369ccda52
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0071
      expected_path: edu_toolkit/LICENSE.txt
      expected_sha256_prefix: sha256:ddaf384463090ff4
      observed_sha256_prefix: sha256:ddaf384463090ff4
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0072
      expected_path: edu_toolkit/NOTICE.txt
      expected_sha256_prefix: sha256:9af6d45e8c13bac9
      observed_sha256_prefix: sha256:9af6d45e8c13bac9
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0073
      expected_path: edu_toolkit/CHANGELOG.md
      expected_sha256_prefix: sha256:03d181707bb50075
      observed_sha256_prefix: sha256:03d181707bb50075
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0075
      expected_path: edu_toolkit/pyproject.toml
      expected_sha256_prefix: sha256:00b9ee1239743767
      observed_sha256_prefix: sha256:00b9ee1239743767
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0076
      expected_path: edu_toolkit/requirements.txt
      expected_sha256_prefix: sha256:4e81e5cc507bfb84
      observed_sha256_prefix: sha256:4e81e5cc507bfb84
      packaging_rule: include_in_zip
      required: required
    - manifest_id: MF-0077
      expected_path: edu_toolkit/scripts/package_release.py
      expected_sha256_prefix: sha256:529b0c2ba32084d2
      observed_sha256_prefix: sha256:529b0c2ba32084d2
      packaging_rule: include_in_zip
      required: required

  changed:
    - manifest_id: MF-0003
      expected_path: edu_toolkit/docs/guides/student_lab_setup.md
      expected_sha256_prefix: sha256:611bffc884b9a95e
      observed_sha256_prefix: sha256:fc150e907a6357d3
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0010
      expected_path: edu_toolkit/docs/guides/troubleshooting/data_import.md
      expected_sha256_prefix: sha256:700562d82e29dc6a
      observed_sha256_prefix: sha256:337d45c4cb79a819
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0015
      expected_path: edu_toolkit/docs/reference/api/v1_4/schema/student_record.yaml
      expected_sha256_prefix: sha256:2a7d771f160e7998
      observed_sha256_prefix: sha256:b5108caa6fee85a8
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0022
      expected_path: edu_toolkit/data/samples/classroom/roster_beta.csv
      expected_sha256_prefix: sha256:98849d521e12bb98
      observed_sha256_prefix: sha256:921ca6a027501e4a
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0025
      expected_path: edu_toolkit/data/samples/events/2026-09-week02.jsonl
      expected_sha256_prefix: sha256:1bb96aa36b8cc088
      observed_sha256_prefix: sha256:73df06451d0fce8b
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0030
      expected_path: edu_toolkit/data/samples/templates/event_import_template.csv
      expected_sha256_prefix: sha256:356906694b1fe1ea
      observed_sha256_prefix: sha256:1917142012139ad4
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0035
      expected_path: edu_toolkit/config/templates/privacy_flags.yaml
      expected_sha256_prefix: sha256:00efba959ba49160
      observed_sha256_prefix: sha256:374ac707cc0d2fc3
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0046
      expected_path: edu_toolkit/src/validation/check_hashes.py
      expected_sha256_prefix: sha256:420673ec947ef0a8
      observed_sha256_prefix: sha256:6807ccde8501ad92
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0050
      expected_path: edu_toolkit/src/validation/rules/report_rules.py
      expected_sha256_prefix: sha256:80ac53be89318a45
      observed_sha256_prefix: sha256:b085edef99cec710
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — metadata review flagged in hash_compare_scratch.txt"
    - manifest_id: MF-0056
      expected_path: edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot.txt
      expected_sha256_prefix: sha256:56a5b6d605e0d099
      observed_sha256_prefix: sha256:cfc98729a974f14d
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — candidate tree snapshot differs from expected fixture"
    - manifest_id: MF-0057
      expected_path: edu_toolkit/tests/fixtures/hash/sample_hashes.json
      expected_sha256_prefix: sha256:0160a95d69171042
      observed_sha256_prefix: sha256:131635e7fccc2af7
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — test fixture hash differs from expected"
    - manifest_id: MF-0066
      expected_path: edu_toolkit/release/checksums/package_size_index.csv
      expected_sha256_prefix: sha256:6b315b5c7ef5da70
      observed_sha256_prefix: sha256:5c6f9c570da94b8d
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — size index content differs from expected"
    - manifest_id: MF-0078
      expected_path: edu_toolkit/scripts/verify_release.py
      expected_sha256_prefix: sha256:d45f281abb557081
      observed_sha256_prefix: sha256:23aae70ca6677902
      packaging_rule: include_in_zip
      required: required
      note: "Hash mismatch — verification helper content differs from expected"

  missing:
    - manifest_id: MF-0027
      expected_path: edu_toolkit/data/samples/events/2026-09-week04.jsonl
      expected_sha256_prefix: sha256:e528084f4865af1e
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0037
      expected_path: edu_toolkit/config/templates/export_profile_minimal.yaml
      expected_sha256_prefix: sha256:f382d0fdf4a03a90
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0049
      expected_path: edu_toolkit/src/validation/rules/locale_rules.py
      expected_sha256_prefix: sha256:3cc36a6c4d8f8d54
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0058
      expected_path: edu_toolkit/tests/fixtures/hash/sample_hashes_legacy.json
      expected_sha256_prefix: sha256:60b17f086ce2d8eb
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0061
      expected_path: edu_toolkit/tests/fixtures/reports/report_incomplete.md
      expected_sha256_prefix: sha256:84ebdbcf568b5c36
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0064
      expected_path: edu_toolkit/release/checksums/SHA256SUMS.txt.sig-note
      expected_sha256_prefix: sha256:76cebf6436de8984
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0074
      expected_path: edu_toolkit/CONTRIBUTING.md
      expected_sha256_prefix: sha256:40b83cfe3fd4b4cd
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"
    - manifest_id: MF-0079
      expected_path: edu_toolkit/scripts/README.md
      expected_sha256_prefix: sha256:a5279795d6118f68
      packaging_rule: include_if_present
      required: optional
      note: "Absent from candidate listing; no near-match path observed"

  extra:
    - observed_path: edu_toolkit/config/templates/archive/include-patterns.txt
      sha256_prefix: sha256:26ec38e136a48743
      note: "Hyphenated variant alongside manifest-expected include_patterns.txt (MF-0042); not automatically equivalent per path_probe_notes"
    - observed_path: edu_toolkit/data/samples/classroom/roster_beta_old.csv
      sha256_prefix: sha256:cb399e047103aa22
      note: "Old roster variant; no manifest row references _old suffix"
    - observed_path: edu_toolkit/data/samples/events/2026-09-week02.tmp.jsonl
      sha256_prefix: sha256:80e35df7421409c7
      note: "Temporary file alongside required week02.jsonl (MF-0025); likely staging artifact"
    - observed_path: edu_toolkit/docs/references/api/v1_4/endpoints_draft.md
      sha256_prefix: sha256:de61a109f9e3b936
      note: "Stem 'references/' (plural) vs manifest 'reference/' (singular); draft endpoint doc with no manifest row"
    - observed_path: edu_toolkit/release/checksums/SHA256SUMS.old.txt
      sha256_prefix: sha256:b45880bb0365f33a
      note: "Old checksum file; no manifest row references .old.txt suffix"
    - observed_path: edu_toolkit/release/checksums/local-compare-work.tmp
      sha256_prefix: sha256:6b8b74ff58c9e301
      note: "Temporary comparison work file; not a release artifact"
    - observed_path: edu_toolkit/scripts/package_release_local_notes.md
      sha256_prefix: sha256:3162853269ec1642
      note: "Local notes file; no manifest row references this path"
    - observed_path: edu_toolkit/src/validation/__pycache__/check_paths.cpython-311.pyc
      sha256_prefix: sha256:d10488f1f419f51b
      note: "Python bytecode cache; not a source artifact, should not be in release zip"
    - observed_path: edu_toolkit/src/validation/rules/report_rules.old.py
      sha256_prefix: sha256:cc2657fa39486569
      note: "Old rule file; no manifest row references .old.py suffix"
    - observed_path: edu_toolkit/tests/fixtures/archive/candidate_tree_snapshot_draft.txt
      sha256_prefix: sha256:143810e2cf6dbfd2
      note: "Draft tree snapshot; no manifest row references _draft suffix"
    - observed_path: edu_toolkit/tmp/export_trace_20260918.log
      sha256_prefix: sha256:edea1cc3c2fc71ab
      note: "Temporary export trace log; not a release artifact"

  inconclusive:
    - manifest_id: MF-0007
      expected_path: edu_toolkit/docs/guides/localization/en_GB/overview.md
      expected_sha256_prefix: sha256:b63a3bfe18149299
      packaging_rule: include_if_present
      required: optional
      near_match_observed: edu_toolkit/docs/guides/localization/en-GB/overview.md
      near_match_sha256_prefix: sha256:eb6d72bc17d48ee3
      note: >
        Locale folder naming difference: underscore (en_GB) vs hyphen (en-GB).
        Manifest notes state locale folders are case- and punctuation-sensitive.
        Hash also differs (b63a3bfe vs eb6d72bc), suggesting different content.
        Requires manual alignment to determine if this is a naming convention change
        or a genuinely missing British English locale file.
    - manifest_id: MF-0018
      expected_path: edu_toolkit/docs/reference/api/v1_4/examples/paged_query.json
      expected_sha256_prefix: sha256:086f20b46f7d7b60
      packaging_rule: include_if_present
      required: optional
      near_match_observed: edu_toolkit/docs/reference/api/v1_4/examples/paged-query.json
      near_match_sha256_prefix: sha256:c896ff33271cba58
      note: >
        Underscore vs hyphen in filename: paged_query.json vs paged-query.json.
        Hash differs (086f20b4 vs c896ff33), suggesting different content.
        Path-probe notes flag this as a potential rename during current export.
        Requires manual alignment to confirm whether this is an intentional rename.
    - manifest_id: MF-0039
      expected_path: edu_toolkit/config/templates/local_run/paths.yaml
      expected_sha256_prefix: sha256:4869f936fc098b9f
      packaging_rule: include_in_zip
      required: required
      near_match_observed: edu_toolkit/config/template/local_run/paths.yaml
      near_match_sha256_prefix: sha256:984deffe1272763a
      note: >
        Directory name difference: templates (plural) vs template (singular).
        Hash differs (4869f936 vs 984deffe), suggesting different content.
        This is a required file with include_in_zip rule.
        Requires manual alignment to determine if the archive tool normalized
        the path or if the file was placed in the wrong directory.

recommendation:
  status: revise_before_handoff
  rationale: >
    Three categories of blocking issues prevent ready_to_attach:

    1. Changed files (13 items): Multiple required files have SHA-256 prefix
       mismatches between the reference manifest and candidate listing. These
       include critical validation helpers (check_hashes.py, report_rules.py),
       test fixtures (sample_hashes.json, candidate_tree_snapshot.txt), and
       data samples (roster_beta.csv, week02.jsonl). Hash drift on required
       files indicates either unintended content changes or manifest staleness.

    2. Inconclusive near-matches (3 items): Three manifest rows have candidate
       near-matches with differing path spelling (locale separator, filename
       separator, directory name) AND differing hashes. These cannot be resolved
       without manual alignment and potentially inspecting file contents.

    3. Extra non-release artifacts (11 items): The candidate contains temporary
       files (.tmp, .old.*, __pycache__), draft artifacts (_draft suffix), and
       local notes that should not be part of a release package. While these do
       not directly block handoff (they are extra, not missing), their presence
       suggests the candidate was packaged without proper cleanup.

    All 8 missing files are optional (include_if_present), so their absence
    does not independently block handoff. However, combined with the changed
    and inconclusive items, the overall signal is that the candidate requires
    reconciliation before attachment.

  no_repack_performed: >
    Consistent with the read-only audit constraint, no repacking, repair, or
    modification of the candidate archive was performed. All findings are
    observational. A follow-up iteration should address the changed files,
    resolve the inconclusive near-matches, and clean up extra artifacts before
    producing a revised candidate.

assumptions:
  - "SHA-256 prefix matching uses the first 16 hex characters as the comparison unit, consistent with all source files."
  - "Path matching is case-sensitive and punctuation-sensitive (underscore vs hyphen, singular vs plural directory names)."
  - "The reference manifest represents the authoritative expected state for this handoff cycle."
  - "The candidate archive listing (82 rows) is the authoritative observed state."
  - "Stale run markers in hash_compare_scratch.txt and the aborted partial_compare_run.log are excluded from authoritative classification."
  - "Files marked include_if_present are optional; their absence does not independently block ready_to_attach."
  - "Files marked include_in_zip are required; their absence or hash mismatch blocks ready_to_attach."
  - "__pycache__ entries are Python bytecode cache and should not appear in a release package."
  - ".tmp, .old.*, _draft, and local-notes files are development artifacts, not release artifacts."

open_questions:
  - question: "Which of the 13 changed files represent intentional updates vs unintended drift?"
    affected_ids:
      - MF-0003
      - MF-0010
      - MF-0015
      - MF-0022
      - MF-0025
      - MF-0030
      - MF-0035
      - MF-0046
      - MF-0050
      - MF-0056
      - MF-0057
      - MF-0066
      - MF-0078
    next_action: "Compare full file contents (not just prefixes) against the reference release to determine if changes are intentional."
  - question: "Is en_GB → en-GB a deliberate locale naming convention change?"
    affected_ids:
      - MF-0007
    next_action: "Confirm with the release coordinator whether British English locale should use underscore or hyphen separator."
  - question: "Is paged_query.json → paged-query.json an intentional rename?"
    affected_ids:
      - MF-0018
    next_action: "Check git history or release notes for rename documentation."
  - question: "Should config/templates/local_run/paths.yaml be under templates (plural) or template (singular)?"
    affected_ids:
      - MF-0039
    next_action: "Verify the correct directory structure against the project's config layout conventions."
  - question: "Should the 11 extra artifacts be cleaned from the candidate before final handoff?"
    next_action: "Remove .tmp, .old.*, __pycache__, _draft, and local-notes files from the candidate archive in a follow-up iteration."

ordering_policy: >
  Findings within each bucket are sorted canonically by manifest_id (ascending)
  for matching/changed/missing/inconclusive, and by observed_path (ascending)
  for extra. This ensures deterministic, reproducible ordering suitable for
  automated downstream processing and human review.

---
# End of package_audit_report.yaml
