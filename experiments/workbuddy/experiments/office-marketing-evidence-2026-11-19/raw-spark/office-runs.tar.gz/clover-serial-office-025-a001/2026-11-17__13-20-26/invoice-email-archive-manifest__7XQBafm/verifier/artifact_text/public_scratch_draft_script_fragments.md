Draft script fragments - not runnable

# These notes were copied from a scratchpad and intentionally omit business decisions.
# They should not be treated as automated decision rules or as a completed archive workflow.

walk mail_export
parse message json if present
keep pdf sidecar text nearby
flag files under stale_outputs as ignored input
write new manifest into archive_out only after source review

TODO left by operator: decide output rows after reading all current files.
