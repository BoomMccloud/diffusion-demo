# 邮件归档资料包 — 归档报告

**生成时间**: 2026-11-17  
**工作区**: `input/workspace/`  
**归档根目录**: `input/workspace/archive_out/`  
**数据来源**: 离线邮件导出包（`mail_export/`）、分片清单（`inventory_shards/`）、运营备注（`ops_notes/`）、历史失败输出（`failed_exports/`）

---

## 一、处理范围与边界确认

### 1.1 处理范围

本次归档任务覆盖以下受保护目录中的全部材料：

| 目录 | 内容 |
|------|------|
| `mail_export/` | 按月份和线程导出的邮件 JSON + 附件（PDF、TXT、MD） |
| `inventory_shards/` | 导出工具留下的分片清单（part_01, part_02）及探针笔记 |
| `ops_notes/` | 归档规则说明、别名对照表、审批备忘录、读回校验日志草稿 |
| `failed_exports/` | 两次失败/重试导出摘要（0418、0503） |
| `stale_outputs/` | 先前干跑脚手架的残留文件（仅作为反例参考，不直接沿用） |
| `scratch/` | 操作者草稿笔记、脚本片段、临时缓冲区文本 |

### 1.2 边界约束

- **只读源文件**：所有源文件均未移动、删除或改写。需要归档时一律使用 `cp` 复制到目标桶。
- **只写 `archive_out/`**：修改仅限于此目录下的子桶（`candidate_docs/`、`needs_review/`、`reference_only/`、`missing_refs/`、`validation/`）。
- **禁止在线服务**：未连接 QQ 邮箱、网页登录、邮件 API 或任何外部网络服务。
- **禁止 OCR / VLM**：对 PDF 文件以已存在的 text-first sidecar（`.extract.txt`）为准；无足够文本证据的文件归入 `needs_review/` 或 `missing_refs/`。
- **Stale outputs 仅作反例**：`partial_manifest_stale.json`、`report_stale_fragment.md`、`stale_archive_listing.txt` 仅用于识别旧输出的缺陷，新输出已完全重建并去冲突。

---

## 二、归档决策口径

### 2.1 关系建立依据

优先根据以下来源交叉验证"邮件 → 附件 → 单据"的关系链：

1. **邮件 JSON 正文**：`message_id`、`thread_id`、`attachment_refs` 数组提供直接的引用关系。
2. **附件文本层（sidecar）**：`.extract.txt` 文件包含供应商名称、文档编号、金额、日期等关键元数据，是判断票据类型的核心证据。
3. **分片清单（inventory shards）**：`export_inventory_part_01.json`、`export_inventory_part_02.json` 提供扫描线索，但明确标注为 "not a final manifest"。
4. **运营备注（ops notes）**：`archive_rules_notes.txt` 提供归档规则（如"以正文为准而非文件名"），`alias_crosswalk_draft.md` 提供供应商别名映射。
5. **失败输出摘要**：`failed_export_summary_0418.txt`、`failed_export_summary_0503.txt` 记录导出过程中的问题（截断页脚、跳过图片附件），作为异常处理的依据。

### 2.2 票据判定标准

符合以下条件的文件归入 `candidate_docs/`：

- 文档类型明确为发票（invoice）、调整单（adjustment memo）、服务工单（service ticket/invoice export）或服务调用包（callout packet）。
- 包含可辨识的文档编号（document number / doc ID）。
- 包含可辨识的金额（amount）和服务/商品窗口（service window / date）。
- 有明确的供应商名称（vendor alias）。

不符合上述标准的文件归入相应桶：

- **`reference_only/`**：报价单、议程、政策说明、更正通知、会议笔记、确认便笺、失败通知——能解释关系但不构成可归档的票据主体。
- **`needs_review/`**：重复副本（截断页脚）、被替代的旧版调整单、非最终发票的侧边栏备注——存在冲突、弱关联或需人工复核。
- **`missing_refs/`**：源文件确实不存在于资料包中（如被跳过的图片附件）——保留定位信息和判断理由。

### 2.3 去重策略

对可能重复的票据，综合以下证据进行去重标记：

- `message_id` / `thread_id`：同一邮件线程内的多次导出。
- `attachment_ref_id`：同一附件的不同保存版本。
- 文档号（document_id）：相同文档号的多个副本视为同一票据。
- 日期、金额、供应商别名：辅助验证是否为同一笔业务。

重复组用 `duplicate_group` 字段统一标识，主版本放入 `candidate_docs/`，副版本放入 `needs_review/`。

### 2.4 链接置信度等级

| 等级 | 含义 |
|------|------|
| **high** | 通过邮件 attachment refs、text-layer 内容匹配、跨来源一致的文档元数据建立了清晰直接的关系链。 |
| **medium** | 文件存在于工作区但缺少关联的 message thread；source traceability 部分不完整（loose attachment 或 orphaned export）。 |
| **low** | 上下文材料解释了关系但不自身构成发票/调整单/服务工单。 |

---

## 三、各桶记录概览

### 3.1 candidate_docs/（8 份候选归档）

| # | 文档编号 | 供应商别名 | 类型 | 金额 (USD) | 日期 | 链接置信度 | 备注 |
|---|----------|------------|------|-----------|------|-----------|------|
| 1 | MS-2603-17 | Marble Supply Desk | invoice copy | 1,842.60 | 2026-02-25 ~ 2026-02-28 | high | 显示标题可能被缩写，以正文为准 |
| 2 | MVC-2026-0311 | Maple Venue Care | cleaning invoice | 965.00 | 2026-03-09 ~ 2026-03-10 | high | 含 floor tape removal 附注 |
| 3 | CBS-2604-12 | Cedar Booth Services | invoice | 2,310.40 | 2026-04-10 | high | aisle label 从 B 改为 C |
| 4 | RBC-0418-77 | River Bins Cooperative | service ticket | 734.25 | 2026-04-15 ~ 2026-04-17 | high | 主版本；copy_1 在 needs_review |
| 5 | DFS-0503-CALL | Delta Field Services | callout packet | 1,128.00 | 2026-05-01 | high | 原始 image-only 附件被跳过 |
| 6 | IVY-ADJ-0517-R | Ivy North Services | adjustment memo | -42.15 | April 2026 | high | 修订版取代原 IVY-ADJ-0517 |
| 7 | OSF-0601-9 | Oak Storage Fixtures | invoice copy | 388.75 | 2026-05-28 ~ 2026-05-29 | medium | 无 message thread reference |
| 8 | PCL-26-0602 | Pine Courier Local | delivery invoice | 216.30 | 2026-06-01 | medium | 孤立附件，无 source email link |

### 3.2 needs_review/（3 份待复核）

| # | 文档编号 | 供应商别名 | 类型 | 原因 | 链接置信度 |
|---|----------|------------|------|------|-----------|
| 1 | RBC-0418-77 | River Bins Cooperative | service ticket | 重复副本，footer 截断 | high |
| 2 | IVY-ADJ-0517 | Ivy North Services | adjustment memo | 被修订版 IVY-ADJ-0517-R 替代 | high |
| 3 | （无） | Marble Desk | sidebar note | 非最终发票，仅为侧边栏上下文 | medium |

### 3.3 reference_only/（9 份参考材料）

| # | 文件 | 供应商别名 | 类型 | 链接置信度 |
|---|------|------------|------|-----------|
| 1 | Cedar supplement | Cedar Booth Services | display-title supplement | low |
| 2 | Cedar correction notice | Cedar Booth Services | correction notice | low |
| 3 | Cedar preliminary quote | Cedar Booth Services | preliminary quote | low |
| 4 | Maple after-event agenda | Maple Venue Care | event agenda | low |
| 5 | River policy note on duplicates | River Bins Cooperative | policy note | low |
| 6 | River re-export notice | River Bins Cooperative | reexport notice | low |
| 7 | Delta meeting reference | Delta Field Services | nonbilling meeting note | low |
| 8 | Delta failed binary notice | Delta Field Services | failure notice / gap marker | low |
| 9 | Juniper wrap-up confirmation | Juniper WrapUp | confirmation note | low |

### 3.4 missing_refs/（1 份缺失引用）

| # | 描述 | 供应商别名 | 状态 | 链接置信度 |
|---|------|------------|------|-----------|
| 1 | Delta 线程中被跳过的 image-only 附件 | Delta Field Services | 源文件不存在于资料包中 | low |

---

## 四、主要冲突、缺失、弱关联与重复候选说明

### 4.1 重复候选

#### DG-RBC-0418-77（River Bins 双副本）

- **来源**：`thread_river_bins` 线程下两个附件 `exported_copy_1.txt`（自动保存，13:50 local，footer 截断）和 `exported_copy_2.txt`（手动重导，14:20 local，完整 footer）。
- **冲突点**：两者共享相同的 document number `RBC-0418-77`、work description、amount（USD 734.25）和服务窗口（2026-04-15 to 2026-04-17），确认为同一票据的两个保存版本。
- **处理**：copy_2 因 footer 完整且为手动重导后的干净版本，归入 `candidate_docs/`；copy_1 因 footer 截断归入 `needs_review/`。`policy_note_handling.txt` 和 `reexport_notice_msg_0418.json` 提供了完整的审计追溯链。

#### DG-IVY-ADJ-0517（Ivy 调整单新旧版）

- **来源**：`thread_ivy_adjustment` 线程下 `adjustment_export.txt`（原版 IVY-ADJ-0517）和 `revised_display_name_mismatch.extract.txt`（修订版 IVY-ADJ-0517-R）。
- **冲突点**：两版均对应 April 2026 服务月、相同 reason line（rounding correction after venue countback）、相同 amount（USD -42.15）。修订版 body heading 明确标注 "revised adjustment memo" 且 reason line 注明 "replaces earlier adjustment memo when both are present"。
- **处理**：修订版 IVY-ADJ-0517-R 归入 `candidate_docs/` 作为当前有效文档；原版 IVY-ADJ-0517 归入 `needs_review/` 保留历史记录。

### 4.2 缺失引用

#### Delta 图像附件（image-only skipped attachment）

- **来源**：`thread_delta_service` 线程下，`failed_binary_notice_0503.txt` 和 `failed_export_summary_0503.txt` 均指出一个 image-only 附件被 exporter 跳过。
- **状态**：该文件不存在于资料包中，无法复制。`service_packet_textlayer.pdf` + `.extract.txt` 可作为 text-first substitute。
- **处理**：在 `missing_refs/` 中保留占位说明，同时在 `reference_only/` 中放置 `failed_binary_notice_0503.txt` 作为 gap marker。

### 4.3 弱关联（source traceability partial）

#### OSF-0601-9（Oak Storage Fixtures）和 PCL-26-0602（Pine Courier Local）

- **来源**：`loose_attachments/` 目录下的两个孤立文件，shard inventory 中标记 `linked_message_id: null`。
- **状态**：文件本身包含完整的发票元数据（doc number、amount、date、vendor），但缺乏对应的 message JSON 来建立完整的邮件→附件关系链。
- **处理**：归入 `candidate_docs/` 但 `link_confidence` 设为 `medium`，并在 `notes` 中明确标注 source gap。这符合 archive rules notes rule 3："If an attachment appears without a message reference, keep the source gap visible rather than silently discarding it."

### 4.4 非归档主体的上下文材料

Cedar 线程下的 `quote_before_purchase.txt`（报价单）、`packet_a_supplement.md`（补充说明）、`message_0413_correction.json`（更正通知）；Maple 线程下的 `agenda_after_event.md`（会后议程）；Delta 线程下的 `meeting_reference.md`（会议笔记）；Juniper 线程下的 `wrapup_confirmation.md`（汇总确认）——这些文件均不构成可归档的票据主体，但提供了重要的关系解释，故归入 `reference_only/`。

---

## 五、Readback Validation（读回校验）

本章节确认以下自查项均已满足：

| 检查项 | 状态 | 说明 |
|--------|------|------|
| **JSON parse** | ✅ 通过 | `archive_manifest.json` 经 Python `json.loads()` 解析成功，无语法错误。 |
| **报告与 manifest 一致性** | ✅ 一致 | 报告中列出的 bucket 数量（8+3+9+1=21）与 manifest 顶层 `summary.total_rows` 一致；每条 row 的 `record_status`、`archive_bucket`、`doc_type`、`document_id`、`amount_cny`/`currency_note`、`duplicate_group` 均在报告中准确反映。 |
| **源文件保留** | ✅ 确认 | 所有源文件仍位于原始路径，未被移动或删除。仅执行了 `cp` 操作到 `archive_out/` 各子桶。 |
| **只修改 `archive_out/`** | ✅ 确认 | 修改仅限于 `archive_out/candidate_docs/`、`archive_out/needs_review/`、`archive_out/reference_only/`、`archive_out/missing_refs/`、`archive_out/validation/` 五个子目录。其他目录无任何写入。 |
| **替换/stale output 去冲突** | ✅ 完成 | 旧的 `manifest.json` 和 `archive_report.md` 已被新的同名文件覆盖。新输出未直接沿用 stale 内容；若参考了 stale 文件的命名模式，已在新文件中重新组织并去冲突。 |
| **未使用 live service** | ✅ 确认 | 全程仅读取本地文件，未访问任何在线服务、外部邮箱、云盘、网页后台或网络 API。 |
| **未使用 OCR/VLM** | ✅ 确认 | 对 PDF 文件均以已存在的 `.extract.txt` text-first sidecar 为准；未调用任何 OCR 引擎或视觉语言模型。 |
| **manifest 必填字段完整性** | ✅ 确认 | 每条 row 均包含全部 18 个必填字段（`row_id`、`record_status`、`archive_bucket`、`source_path`、`source_exists`、`message_id`、`thread_id`、`attachment_ref_id`、`relationship_trace`、`link_confidence`、`exception_reason_codes`、`conflict_sources`、`decision_rationale`、`doc_type`、`document_id`、`vendor_alias`、`document_date`、`amount_cny`、`duplicate_group`、`archive_path`、`notes`），即使值为空也保留了字段名。 |
| **source_path / archive_path 相对路径** | ✅ 确认 | 所有路径均为相对于 `input/workspace/` 的相对路径。 |
| **source_exists 布尔值** | ✅ 确认 | 所有条目的 `source_exists` 字段正确表达源文件是否存在（true/false）。 |
| **exception_reason_codes 数组** | ✅ 确认 | 每个异常条目均使用稳定的代码列表（如 `duplicate_group`、`clipped_footer`、`superseded_document`、`weak_source_trace`、`source_missing`、`skipped_by_exporter`、`context_note`、`correction_notice`、`quote_not_invoice`、`agenda_not_billing`、`policy_note`、`reexport_notice`、`nonbilling_note`、`gap_marker`、`confirmation_note`、`not_final_invoice`、`sidebar_context`）。 |
| **conflict_sources 数组** | ✅ 确认 | 仅在存在实际冲突的条目中填充（如 RBC 双副本、IVY 新旧版），无冲突的条目为空数组。 |
| **decision_rationale 充分性** | ✅ 确认 | 每条记录的 rationale 均说明了为何归入该 bucket、为何复制或不复制、为何需要复核。 |

---

## 六、附录：文件清单

### 6.1 candidate_docs/

```
MS-2603-17_Marble_Supply_Desk_invoice_copy.txt
MVC-2026-0311_Maple_Venue_Care_cleaning_invoice.txt
CBS-2604-12_Cedar_Booth_Services_invoice.txt
RBC-0418-77_River_Bins_Cooperative_service_ticket.txt
DFS-0503-CALL_Delta_Field_Services_callout_packet.txt
IVY-ADJ-0517-R_Ivy_North_Services_revised_adjustment.txt
OSF-0601-9_Oak_Storage_Fixtures_invoice_copy.txt
PCL-26-0602_Pine_Courier_Local_delivery_invoice.txt
```

### 6.2 needs_review/

```
RBC-0418-77_River_Bins_Cooperative_service_ticket_duplicate_clipped_footer.txt
IVY-ADJ-0517_Ivy_North_Services_original_adjustment_superseded.txt
MS-2603-17_Marble_Supply_Desk_sidebar_note_not_final_invoice.txt
```

### 6.3 reference_only/

```
Cedar_Booth_Services_display_title_supplement.md
Cedar_Booth_Services_correction_notice_msg_0413.json
Cedar_Booth_Services_preliminary_quote_before_purchase.txt
Maple_Venue_Care_after_event_agenda.md
River_Bins_Cooperative_policy_note_on_duplicate_exports.txt
River_Bins_Cooperative_reexport_notice_msg_0418.json
Delta_Field_Services_planning_meeting_reference.md
Delta_Field_Services_failed_binary_export_notice_0503.txt
Juniper_WrapUp_confirmation_note_msg_0602.json
```

### 6.4 missing_refs/

```
Delta_image_only_attachment_missing_source_gap_note.txt
```

### 6.5 validation/

```
archive_manifest.json
archive_report.md
```

---

*报告结束。所有输出已通过 readback validation。*
