Plain-text adjustment export

Ivy North Services
Document heading: adjustment memo
Memo number: IVY-ADJ-0517
Related service month: April 2026
Reason line: rounding correction after venue countback
Displayed amount: -42.15 USD

The text export was generated before a revised display name was uploaded. It may not match the later file name exactly.
