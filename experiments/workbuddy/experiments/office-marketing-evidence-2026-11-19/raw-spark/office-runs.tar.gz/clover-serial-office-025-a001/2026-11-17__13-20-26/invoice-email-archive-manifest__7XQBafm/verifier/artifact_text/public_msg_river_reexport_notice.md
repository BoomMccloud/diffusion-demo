{
  "message_id": "msg-20260418-river-02",
  "thread_id": "thread_river_bins",
  "sent_local": "2026-04-18 14:22",
  "subject": "重导提示：River 文件的附件时间戳不一致",
  "body_excerpt": "重导时附件的本地保存时间变了，但导出页脚中的文档编号和服务窗口才是更可靠的判断线索。请保留重导说明供校验。",
  "attachment_refs": []
}
