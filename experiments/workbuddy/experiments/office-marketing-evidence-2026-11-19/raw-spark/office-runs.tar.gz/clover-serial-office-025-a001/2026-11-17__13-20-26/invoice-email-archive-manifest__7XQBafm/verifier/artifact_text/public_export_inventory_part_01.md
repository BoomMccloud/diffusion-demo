{
  "shard_id": "export_inventory_part_01",
  "created_from": "mail-export-scan",
  "scope_note": "First shard covers March and early April thread folders. Field names mirror a noisy export inventory and are not a final manifest.",
  "items": [
    {
      "path": "mail_export/2026-03/thread_marble_supply/message_0301.json",
      "kind": "message_json",
      "thread_id": "thread_marble_supply",
      "attachment_count_observed": 2,
      "inventory_note": "message body says portal filename may be abbreviated"
    },
    {
      "path": "mail_export/2026-03/thread_marble_supply/attachments/export_doc_03a_textlayer.pdf",
      "kind": "pdf_placeholder_text_first",
      "linked_message_id": "msg-20260301-marble-01",
      "sidecar": "mail_export/2026-03/thread_marble_supply/attachments/export_doc_03a_textlayer.extract.txt",
      "inventory_note": "text layer present; display title generic"
    },
    {
      "path": "mail_export/2026-03/thread_maple_cleanup/attachments/agenda_after_event.md",
      "kind": "markdown_note",
      "linked_message_id": "msg-20260311-maple-01",
      "inventory_note": "agenda wording; context attachment"
    },
    {
      "path": "mail_export/2026-04/thread_cedar_booth/message_0413_correction.json",
      "kind": "message_json",
      "thread_id": "thread_cedar_booth",
      "attachment_count_observed": 0,
      "inventory_note": "correction message has no attachment but changes interpretation context"
    },
    {
      "path": "mail_export/2026-04/thread_cedar_booth/attachments/quote_before_purchase.txt",
      "kind": "plain_text",
      "linked_message_id": "msg-20260412-cedar-01",
      "inventory_note": "quote wording; should be checked against source text"
    }
  ]
}
