# Stale report fragment - do not reuse as final output

This fragment was left by an earlier dry run before the hardened workspace was created. It contains prose placeholders and a reminder to re-read the current source tree.

Known problems with this stale fragment:
- It was written before the loose attachment folder was inspected.
- It used display filenames too heavily.
- It did not account for failed export notices.

Regenerate any real report from the current workspace instead of patching this fragment.
