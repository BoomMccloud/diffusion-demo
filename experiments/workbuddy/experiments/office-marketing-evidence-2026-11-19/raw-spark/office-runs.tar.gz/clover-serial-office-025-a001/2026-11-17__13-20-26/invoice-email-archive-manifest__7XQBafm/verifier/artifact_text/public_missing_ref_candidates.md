{
  "file_role": "stale triage scratchpad",
  "authoritative": false,
  "scope": "partial notes from a loose-folder and failed-export cleanup pass only",
  "not_a_manifest": true,
  "notes": "This file is intentionally incomplete and may include distractors. It must not be used to classify final archive membership or source gaps.",
  "items": [
    {
      "note_id": "loose-folder-review-1",
      "fragments": [
        "upload_without_thread_ref_A",
        "manual_export_orphan_B"
      ],
      "state": "unresolved terminal-note fragment",
      "caveat": "Fragment names alone do not decide whether a document belongs in the archive."
    },
    {
      "note_id": "failed-export-reminder",
      "fragments": [
        "failed_export_summary_0503"
      ],
      "state": "export failure reminder, not document content",
      "caveat": "Use only as a reminder that one export attempt failed; it is not a substitute for text artifacts."
    },
    {
      "note_id": "stale-meeting-note",
      "fragments": [
        "agenda_after_event",
        "logo_reference_old"
      ],
      "state": "likely irrelevant or stale",
      "caveat": "Kept as a distractor from an earlier cleanup pass."
    }
  ],
  "known_omissions": "Most threaded attachments are excluded by design, and this file carries no complete vendor/document/source-gap ledger."
}
