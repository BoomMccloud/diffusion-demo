{
  "message_id": "msg-20260418-river-01",
  "thread_id": "thread_river_bins",
  "sent_local": "2026-04-18 13:54",
  "subject": "River bins pickup documents exported twice",
  "body_excerpt": "清运箱收取的文件导出了两次。第一次是自动保存，第二次是手动重导；两个文本文件都保留，后续需要根据正文判断是否可用。",
  "attachment_refs": [
    "attachments/exported_copy_1.txt",
    "attachments/exported_copy_2.txt",
    "attachments/policy_note_handling.txt"
  ]
}
