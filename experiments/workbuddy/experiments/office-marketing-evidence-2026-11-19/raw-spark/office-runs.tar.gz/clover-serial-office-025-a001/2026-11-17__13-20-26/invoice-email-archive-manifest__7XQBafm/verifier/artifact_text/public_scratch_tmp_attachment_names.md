tmp names copied from a terminal buffer during export triage
not sorted; not complete; sidecars and message JSON names were filtered out

packet_a_textlayer.pdf
quote_before_purchase.txt
exported_copy_2.txt
service_packet_textlayer.pdf
revised_display_name_mismatch.pdf
upload_without_thread_ref_A.txt
manual_export_orphan_B_textlayer.pdf
logo_reference_old.png   # stale name from another folder, not found in current pass
marble portal batch 03A  # note fragment, filename not copied

Do not treat this as the attachment inventory. The terminal buffer was clipped before the March thread and after part of the loose-folder listing.