# Draft alias crosswalk

This crosswalk is a helper note, not an authoritative vendor master.

| Seen phrase | Possible normalized wording | Caution |
|---|---|---|
| Marble Desk | Marble Supply Desk | Short name from portal sidebar |
| Maple Venue Care | Maple Venue Care | Agenda uses the place name but is not a charge document |
| Cedar booth | Cedar Booth Services | Quote and invoice share similar wording |
| River Bins | River Bins Cooperative | Exported twice in one afternoon |
| Delta field | Delta Field Services | One image-only attachment excluded |
| Ivy North | Ivy North Services | Revised memo changes heading text |
| Pine Courier | Pine Courier Local | Orphaned from source message in this sample |
| Oak Storage | Oak Storage Fixtures | Loose upload without thread ref |
