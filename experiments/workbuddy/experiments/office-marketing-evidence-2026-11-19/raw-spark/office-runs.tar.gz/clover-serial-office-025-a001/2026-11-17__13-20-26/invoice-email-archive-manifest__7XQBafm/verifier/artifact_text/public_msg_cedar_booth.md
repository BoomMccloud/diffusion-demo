{
  "message_id": "msg-20260412-cedar-01",
  "thread_id": "thread_cedar_booth",
  "sent_local": "2026-04-12 08:07",
  "subject": "Cedar booth packet - initial export bundle",
  "body_excerpt": "展台服务商发来一组导出件。原包里同时有采购前报价和后来上传的说明，归档时需要看文档标题和更正邮件，不要只看文件名。",
  "attachment_refs": [
    "attachments/packet_a_textlayer.pdf",
    "attachments/packet_a_supplement.md",
    "attachments/quote_before_purchase.txt"
  ]
}
