Extracted text layer for packet_a_textlayer.pdf
Body supplier: Cedar Booth Services
Body document heading: invoice for booth reset and late pickup
Document number: CBS-2604-12
Show label: Spring trade table, aisle C
Service date printed: 2026-04-10
Amount printed: 2,310.40 USD
Upload/display title: Cedar quote packet A
Footer export date: 2026-04-12
