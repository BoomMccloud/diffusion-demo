# 票据邮件归档与清单生成

请把这次邮件导出归档资料包当作一次性票据整理任务来处理：目标是从已经导出的邮件、附件清单、运营备注和历史失败输出里，找出可归档的发票/单据，按规则复制到 `input/workspace/archive_out`，并生成一份机器可读的归档 manifest JSON 和一份人工可读的 Markdown 报告。

原始需求的口径是“巡检近 7 天票据邮件、按技能规则搜索电子发票/行程单/酒店水单/打车票据、去重后整理到票据目录并输出清单”。本任务已经把邮箱和附件内容冻结成离线工作区，所以你只需要处理包内材料；不要连接真实 QQ 邮箱、网页登录、邮件 API 或任何在线服务。

## 工作区边界

- 只能读取这些受保护目录：`mail_export/`、`inventory_shards/`、`ops_notes/`、`failed_exports/`、`stale_outputs/`、`scratch/`。
- 只能修改 `archive_out/`。不要在其它目录新增、删除、重命名或改写文件。
- 对源文件一律 copy-not-move：需要归档时复制到 `archive_out/`，不要移动、删除或覆盖原始邮件、附件、清单、备注。
- `stale_outputs/` 和 `failed_exports/` 只能作为历史参考或反例，不能当作权威结果直接沿用；如复用其命名或内容，必须在新输出中去冲突并说明判断依据。
- 这是离线交接材料处理任务：不得访问在线服务、外部邮箱、云盘、网页后台、网络 API 或真实账号。
- 不要做 OCR 或视觉模型识别（no OCR / no VLM）。如遇 PDF，以工作区内已有的 text-first sidecar 或可读取文本为准；没有足够文本证据时放入需要复核或缺失引用类别并说明原因。

## 需要完成的输出

请只在 `input/workspace/archive_out` 下写入或更新结果。至少需要：

1. `input/workspace/archive_out/validation/archive_manifest.json`
2. `input/workspace/archive_out/validation/archive_report.md`
3. 必要时，在 `archive_out/candidate_docs/`、`archive_out/needs_review/`、`archive_out/reference_only/`、`archive_out/missing_refs/` 中放置复制出的文件或占位说明。可使用已有桶名，不要新增受保护目录外的其它结果根目录。

推荐桶含义：

- `candidate_docs/`：证据足够、可作为候选归档的发票/单据文件副本。
- `needs_review/`：存在冲突、弱关联、字段不完整或需要人工复核的文件/记录。
- `reference_only/`：能解释关系但不应作为发票/单据归档主体的邮件、备注或辅助材料。
- `missing_refs/`：邮件或清单提到但资料包中的源文件不存在、无法确认或不能安全复制的引用。
- `validation/`：manifest、报告、读回校验说明等验证输出。

## 归档处理口径

- 优先根据邮件线程、附件引用、inventory shard、ops note 和可读文本建立“邮件/附件/单据”关系；不要只看文件名。
- 对可能重复的票据，按 `message_id`、`attachment_ref_id`、最终文件名、文档号、日期、金额、供应商别名等证据综合去重，并用 `duplicate_group` 标记。
- 对正文链接、附件引用、历史失败缓存、缺失源文件或 base64/sidecar 证据不足的情况，要保留定位信息和判断理由；不能安全复制时不要硬补文件。
- 如果某个附件或记录像票据但证据不够，请放入 `needs_review/` 或 `missing_refs/`，不要为了凑归档结果而编造字段。

## manifest JSON 格式

`archive_manifest.json` 必须是可解析 JSON。顶层建议使用对象，并包含 `rows` 数组；如果增加 `summary` 或 `readback_validation` 等字段，也必须与 `rows` 和报告一致。

`rows` 中每条记录都必须包含以下字段，即使值为空也要保留字段名：

- `row_id`
- `record_status`
- `archive_bucket`
- `source_path`
- `source_exists`
- `message_id`
- `thread_id`
- `attachment_ref_id`
- `relationship_trace`
- `link_confidence`
- `exception_reason_codes`
- `conflict_sources`
- `decision_rationale`
- `doc_type`
- `document_id`
- `vendor_alias`
- `document_date`
- `amount_cny`
- `duplicate_group`
- `archive_path`
- `notes`

字段填写要求：

- `source_path` 和 `archive_path` 使用相对 `input/workspace` 的路径或清楚标注的工作区相对路径。
- `source_exists` 用布尔值表达资料包中的源文件是否存在。
- `relationship_trace` 简要列出你依据了哪些邮件、附件引用、清单 shard、备注或历史失败线索来建立关系。
- `link_confidence` 使用稳定的等级或数值口径，并在报告中解释。
- `exception_reason_codes` 用数组记录异常原因，例如源缺失、弱关联、字段冲突、重复组、历史输出冲突、非归档主体等。
- `conflict_sources` 列出发生冲突的信息来源；没有冲突时使用空数组。
- `decision_rationale` 写清为什么放入该 bucket、为什么复制或不复制、为什么需要复核。
- `duplicate_group` 用于标记你认为属于同一发票/单据或同一重复候选组的记录；无重复可为空。

## Markdown 报告要求

`archive_report.md` 应用中文为主，结构清晰，至少覆盖：

- 处理范围和边界确认。
- 归档决策口径：如何使用邮件线程、附件引用、inventory shard、ops note、失败/陈旧输出。
- 各 bucket 的记录概览，但不要虚构证据。
- 主要冲突、缺失、弱关联和重复候选的说明。
- `readback_validation`：说明你已经读回或复核了新 manifest 与目录状态，包括 JSON parse、报告与 manifest 一致性、源文件保留、只修改 `archive_out`、替换/去冲突 stale output、未使用 live service、未使用 OCR/VLM。

## 完成前自查

- `archive_manifest.json` 可以 JSON parse。
- 报告中的 bucket、异常和记录口径与 manifest 一致。
- 所有源文件仍保留在原位置，没有被移动或删除。
- 修改只发生在 `archive_out/` 下。
- 新输出没有直接沿用旧的 stale output；如果参考了旧输出，已经替换、重建或明确去冲突。
- 全程没有访问 live service，也没有使用 OCR/VLM；只使用归档包内文本、清单和 sidecar 证据。
