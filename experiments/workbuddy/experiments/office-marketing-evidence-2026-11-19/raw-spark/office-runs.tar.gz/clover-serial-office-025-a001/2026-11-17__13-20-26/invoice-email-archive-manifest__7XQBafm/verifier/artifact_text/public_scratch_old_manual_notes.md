Old manual notes - untrusted

The operator typed these notes while switching between mail folders. Some terms are shorthand, and the notes were not reconciled with the current export tree.

- Cedar file name looked like a quote, but body needs re-check.
- River re-export may be cleaner than first save.
- Delta has missing image-only attachment; do not guess.
- Ivy display name mismatch looked confusing.
- Loose uploads need separate source-gap handling.
