{
  "message_id": "msg-20260517-ivy-01",
  "thread_id": "thread_ivy_adjustment",
  "sent_local": "2026-05-17 15:27",
  "subject": "Ivy 调整单：文件名和正文抬头不完全一致",
  "body_excerpt": "请同时看文本导出和修订版 PDF 的正文。文件名里的显示名称来自上传框，正文里的调整说明和修订标记更接近业务含义。",
  "attachment_refs": [
    "attachments/adjustment_export.txt",
    "attachments/revised_display_name_mismatch.pdf"
  ]
}
