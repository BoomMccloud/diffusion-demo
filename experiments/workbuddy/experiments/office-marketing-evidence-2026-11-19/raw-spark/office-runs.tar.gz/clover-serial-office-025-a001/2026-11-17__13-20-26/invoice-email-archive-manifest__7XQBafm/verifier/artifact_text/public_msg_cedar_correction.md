{
  "message_id": "msg-20260413-cedar-02",
  "thread_id": "thread_cedar_booth",
  "sent_local": "2026-04-13 11:35",
  "subject": "更正：Cedar packet 的显示标题和场次备注",
  "body_excerpt": "昨天附件里的显示标题沿用了上一次活动的名称；正文里的供应商抬头和单据编号没有变。补充说明只改场次备注，不代表新增一张单据。",
  "attachment_refs": []
}
