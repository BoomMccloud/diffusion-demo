Manual re-export from River Bins portal

River Bins Cooperative
Document heading: service ticket / invoice export
Document number: RBC-0418-77
Service window: 2026-04-15 through 2026-04-17
Work description: temporary bins, pickup, disposal ticket
Amount printed: USD 734.25
Footer note: manual re-export at 14:20 local after the first saved copy showed a clipped footer.
