Extracted text layer for revised_display_name_mismatch.pdf
Upload display name: revised_display_name_mismatch.pdf
Body supplier: Ivy North Services
Body heading: revised adjustment memo
Memo number: IVY-ADJ-0517-R
Related service month: April 2026
Reason line: rounding correction after venue countback; replaces earlier adjustment memo when both are present.
Displayed amount: -42.15 USD
Footer note: display name uploaded by operations, not accounting.
