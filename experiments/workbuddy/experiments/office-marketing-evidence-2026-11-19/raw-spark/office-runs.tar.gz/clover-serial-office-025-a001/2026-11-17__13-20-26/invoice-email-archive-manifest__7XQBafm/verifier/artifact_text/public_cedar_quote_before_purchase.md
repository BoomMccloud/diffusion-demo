Cedar Booth Services - preliminary quote text

Quote reference: Q-CEDAR-SPRING-04
Prepared before the purchase was approved.
It includes a placeholder amount and a tentative aisle label. The quote was left in the email thread for context and may share words with the later document.

Status line from attachment: quote only, not an invoice.
