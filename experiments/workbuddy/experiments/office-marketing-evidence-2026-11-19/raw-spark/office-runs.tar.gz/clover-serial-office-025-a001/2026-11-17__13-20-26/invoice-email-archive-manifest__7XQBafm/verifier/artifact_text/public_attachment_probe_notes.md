path_fragment	checked_when	probe_result	followup
2026-03 marble portal batch	first-pass text check	sidecar seen; display title was generic	compare with nearby message metadata if needed
2026-04 river exported_copy files	old duplicate check	two text exports looked similar but footer differed	do not infer which copy is final from this note
2026-05 delta service packet	packet skim	text layer looked usable; image-only material was skipped	stay within text extracts
2026-06 loose folder	terminal buffer note	mixed manual uploads; ordering unreliable	use source artifacts, not this scratch row
old logo_reference_old.png	stale probe	name from a previous cleanup folder	ignore unless it appears in current workspace
