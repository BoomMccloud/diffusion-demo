Archive rules notes - draft for archive handoff cleanup

These notes describe how the team usually reads mixed mail exports. They are not a completed archive decision record.

1. Prefer the body text of the document over the upload/display name when they conflict.
2. Treat quotes, agendas, planning notes, and policy notes as context unless the source text itself says it is a payable document or adjustment memo.
3. If an attachment appears without a message reference, keep the source gap visible rather than silently discarding it.
4. When two exports share the same document number and body details, read the re-export notice before deciding how to present them.
5. Do not trust stale manifests, scratch notes, or old script fragments without checking source files.
