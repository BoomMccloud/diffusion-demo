Failed export summary 0503

Thread: thread_delta_service
Observed issue: one image-only attachment skipped by the exporter.
Public-sample handling: the binary was not included. A text-layer service packet and a plain failure notice remain in the workspace.
Action note: keep the gap visible during archive cleanup; do not invent contents for the skipped attachment.
