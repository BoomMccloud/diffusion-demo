Failed/retry export summary 0418

Thread: thread_river_bins
Observed issue: first saved text copy had a clipped footer; a manual re-export was saved later the same afternoon.
Public-sample handling: both text copies and the re-export notice are retained so a reader can reason from source text.
Action note: this file is not a duplicate-resolution decision.
