Extracted text layer for manual_export_orphan_B_textlayer.pdf
Supplier text: Pine Courier Local
Document kind: delivery invoice
Document number: PCL-26-0602
Service date: 2026-06-01
Description: two crate deliveries for month-end archive move
Amount printed: 216.30 USD
Footer note: manually placed in loose attachments; source email link missing from this sample.
