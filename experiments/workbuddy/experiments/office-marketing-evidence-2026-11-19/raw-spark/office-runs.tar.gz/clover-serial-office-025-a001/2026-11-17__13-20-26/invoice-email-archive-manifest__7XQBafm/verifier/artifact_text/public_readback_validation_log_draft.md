Readback validation log - draft, not final

Spot-check entries recorded by the archive operator:
- Marble text layer opens as text and mentions North Hall receiving bay.
- Cedar supplement explains a display-title mismatch.
- River files both contain the same service window phrase, but one footer was clipped in the first save.
- Delta binary failure notice is a gap marker, not a substitute for the missing image-only file.
- Ivy revised memo body should be read before trusting the filename.

The operator did not finish a completed manifest before this handoff bundle was paused.
