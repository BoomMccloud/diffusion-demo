# Month-end cleanup approval memo

The operations lead approved creating a new archive manifest from the mail-export package. The approval covers the cleanup activity only; it does not certify which attachments are final billing documents.

Scope reminders:
- Use the exported text files and available text-layer documents only.
- Keep source gaps visible for orphaned files and failed binary exports.
- Produce new output in `archive_out/` rather than editing mail-export source files.
