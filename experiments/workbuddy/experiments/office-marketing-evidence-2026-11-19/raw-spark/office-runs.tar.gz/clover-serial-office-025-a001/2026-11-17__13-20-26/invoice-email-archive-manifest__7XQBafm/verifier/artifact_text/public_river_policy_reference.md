Archive handling note for River Bins thread

When a portal document is exported twice, keep enough evidence to explain the duplicate-looking files. The policy note does not decide which copy belongs in a manifest; it only says a re-export notice should be available for audit readback if a duplicate-looking attachment appears.
