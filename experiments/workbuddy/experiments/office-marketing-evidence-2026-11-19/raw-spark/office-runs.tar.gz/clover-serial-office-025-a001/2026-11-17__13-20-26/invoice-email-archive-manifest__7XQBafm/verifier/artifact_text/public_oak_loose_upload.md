Loose upload without message thread reference

Oak Storage Fixtures
Document heading: invoice copy
Document number: OSF-0601-9
Service/goods window: 2026-05-28 to 2026-05-29
Short description: temporary shelving rental returned at close of May
Amount printed: USD 388.75

Exporter note: no message JSON pointed to this file in the shard inventory. It was found under loose_attachments during the local scan.
