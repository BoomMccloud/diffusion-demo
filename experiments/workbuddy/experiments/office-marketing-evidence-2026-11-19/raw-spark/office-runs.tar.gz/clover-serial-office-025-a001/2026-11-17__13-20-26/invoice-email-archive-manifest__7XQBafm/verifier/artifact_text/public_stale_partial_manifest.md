{
  "stale": true,
  "authoritative": false,
  "reason_not_to_use": "Abandoned dry-run scaffold created before the hardened workspace was rebuilt. It intentionally contains no final document membership.",
  "old_script_state": {
    "read_mail_export": "partial",
    "read_loose_attachments": "not_done",
    "read_failed_exports": "not_done",
    "used_display_names_too_much": true
  },
  "placeholder_rows": [
    {
      "row_note": "example placeholder from old script, not a classified document",
      "source_path": "mail_export/2026-04/thread_cedar_booth/attachments/packet_a_textlayer.pdf",
      "status": "unreviewed_placeholder"
    },
    {
      "row_note": "example placeholder from old script, not a classified document",
      "source_path": "mail_export/2026-06/loose_attachments/upload_without_thread_ref_A.txt",
      "status": "unreviewed_placeholder"
    }
  ]
}
