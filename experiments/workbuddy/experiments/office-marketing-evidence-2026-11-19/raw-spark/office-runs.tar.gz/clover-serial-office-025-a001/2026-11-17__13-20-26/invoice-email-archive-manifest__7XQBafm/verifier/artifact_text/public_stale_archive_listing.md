Stale archive_out listing from an abandoned dry run

candidate_docs/
needs_review/
reference_only/
missing_refs/
validation/
manifest.json  (old scaffold, not reviewed)
archive_report.md  (old prose fragment, not reviewed)

This listing is retained only to show why stale_outputs should be ignored during final cleanup.
