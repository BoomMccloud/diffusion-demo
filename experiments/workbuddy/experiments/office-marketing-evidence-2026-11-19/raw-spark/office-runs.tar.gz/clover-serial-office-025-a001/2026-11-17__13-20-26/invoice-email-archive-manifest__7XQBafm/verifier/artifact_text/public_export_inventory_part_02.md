{
  "shard_id": "export_inventory_part_02",
  "created_from": "mail-export-scan",
  "scope_note": "Second shard covers late April through June folders plus loose attachments. It is a scan inventory, not an answer.",
  "items": [
    {
      "path": "mail_export/2026-04/thread_river_bins/attachments/exported_copy_1.txt",
      "kind": "plain_text_export",
      "linked_message_id": "msg-20260418-river-01",
      "inventory_note": "automatic save; footer may be clipped"
    },
    {
      "path": "mail_export/2026-04/thread_river_bins/attachments/exported_copy_2.txt",
      "kind": "plain_text_export",
      "linked_message_id": "msg-20260418-river-01",
      "inventory_note": "manual re-export retained next to earlier copy"
    },
    {
      "path": "mail_export/2026-05/thread_delta_service/attachments/service_packet_textlayer.pdf",
      "kind": "pdf_placeholder_text_first",
      "linked_message_id": "msg-20260503-delta-01",
      "sidecar": "mail_export/2026-05/thread_delta_service/attachments/service_packet_textlayer.extract.txt",
      "inventory_note": "text-layer packet remains after image-only attachment exclusion"
    },
    {
      "path": "mail_export/2026-05/thread_ivy_adjustment/attachments/revised_display_name_mismatch.pdf",
      "kind": "pdf_placeholder_text_first",
      "linked_message_id": "msg-20260517-ivy-01",
      "sidecar": "mail_export/2026-05/thread_ivy_adjustment/attachments/revised_display_name_mismatch.extract.txt",
      "inventory_note": "body heading differs from upload name"
    },
    {
      "path": "mail_export/2026-06/loose_attachments/upload_without_thread_ref_A.txt",
      "kind": "plain_text_loose_attachment",
      "linked_message_id": null,
      "inventory_note": "no message JSON pointed to this file in the scan inventory"
    },
    {
      "path": "mail_export/2026-06/loose_attachments/manual_export_orphan_B_textlayer.pdf",
      "kind": "pdf_placeholder_text_first",
      "linked_message_id": null,
      "sidecar": "mail_export/2026-06/loose_attachments/manual_export_orphan_B_textlayer.extract.txt",
      "inventory_note": "manual orphan export; source email missing from sample"
    }
  ]
}
