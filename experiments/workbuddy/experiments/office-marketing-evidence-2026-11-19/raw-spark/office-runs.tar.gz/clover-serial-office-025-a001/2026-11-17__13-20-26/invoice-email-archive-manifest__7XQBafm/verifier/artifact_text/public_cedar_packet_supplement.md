# Supplement from Cedar operations

The portal display title was not updated after the job moved from quote to invoice. The body of the PDF remains the useful text. The aisle label in the old quote said aisle B; the completed service entry says aisle C.

This supplement is a context note, not a standalone charge document.
