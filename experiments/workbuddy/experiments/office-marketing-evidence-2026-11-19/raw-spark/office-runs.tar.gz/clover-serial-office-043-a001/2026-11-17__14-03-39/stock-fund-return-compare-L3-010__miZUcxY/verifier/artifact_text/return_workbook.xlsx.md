# Workbook: return_workbook.xlsx

## Sheet 1: aligned_returns
Dimensions: 73 rows x 12 columns
R1: interval_id | 产品ID | 资产类型 | 展示名称 | 源代码 | start_observation_date | end_observation_date | start_value | end_value | interval_return | rank_in_interval | source_trace
R2: I-2026-05-early | P-LX-209 | 股票 | 朗序仪表A | EQ-S09X | 2026-05-07 | 2026-05-15 | 11.17 | 11.4 | 0.020591 | 5 | stock_prices::EQ-S09X
R3: I-2026-05-early | P-AQ-017 | 股票 | 星桥制造A | EQ-A17Q | 2026-05-06 | 2026-05-13 | 18.75 | 19.5 | 0.04 | 1 | stock_prices::EQ-A17Q
R4: I-2026-05-early | P-DM-011 | 基金 | 远川红利基金 | FD-YC741 |  |  |  |  |  |  | fund_nav::FD-YC741
R5: I-2026-05-early | P-CT-028 | 股票 | 南屿材料A | EQ-N28Y | 2026-05-06 | 2026-05-15 | 13.97 | 14.24 | 0.019327 | 7 | stock_prices::EQ-N28Y
R6: I-2026-05-early | P-RY-618 | 股票 | 润曜控制A | EQ-B18Y | 2026-05-06 | 2026-05-15 | 16.65 | 17.02 | 0.022222 | 3 | stock_prices::EQ-B18Y
R7: I-2026-05-early | P-XW-916 | 股票 | 玄湾观察A | EQ-W16X |  |  |  |  |  |  | stock_prices::EQ-W16X
R8: I-2026-05-early | P-JU-205 | 基金 | 景佑量化基金 | FD-MY642 | 2026-05-06 | 2026-05-14 | 1.1624 | 1.1729 | 0.009033 | 17 | fund_nav::FD-MY642
R9: I-2026-05-early | P-AQ-042 | 股票 | 海岚设备A | EQ-H42L | 2026-05-06 | 2026-05-13 | 11.25 | 11.7 | 0.04 | 1 | stock_prices::EQ-H42L
R10: I-2026-05-early | P-PV-481 | 基金 | 璞维均衡基金 | FD-RT742 | 2026-05-06 | 2026-05-15 | 1.2068 | 1.2196 | 0.010607 | 15 | fund_nav::FD-RT742
R11: I-2026-05-early | P-GL-063 | 股票 | 谷澜精测A | EQ-C63G |  |  |  |  |  |  | stock_prices::EQ-C63G
R12: I-2026-05-early | P-BF-019 | 基金 | 青枢稳健基金 | FD-QS462 | 2026-05-08 | 2026-05-15 | 1.247 | 1.2599 | 0.010345 | 16 | fund_nav::FD-QS462
R13: I-2026-05-early | P-UM-763 | 基金 | 沐岚精选基金 | FD-SM428 | 2026-05-06 | 2026-05-15 | 1.2914 | 1.3118 | 0.015797 | 9 | fund_nav::FD-SM428
R14: I-2026-05-early | P-MN-331 | 股票 | 沐宁材料A | EQ-R31M | 2026-05-06 | 2026-05-15 | 20.85 | 21.26 | 0.019664 | 6 | stock_prices::EQ-R31M
R15: I-2026-05-early | P-SH-702 | 股票 | 森衡光联A | EQ-L02S | 2026-05-06 | 2026-05-15 | 22.13 | 22.6 | 0.021238 | 4 | stock_prices::EQ-L02S
R16: I-2026-05-early | P-EP-044 | 基金 | 峨浦成长基金 | FD-HY519 | 2026-05-06 | 2026-05-14 | 1.3358 | 1.3514 | 0.011678 | 13 | fund_nav::FD-HY519
R17: I-2026-05-early | P-KR-115 | 股票 | 砺川电驱A | EQ-M15K | 2026-05-07 | 2026-05-13 | 23.53 | 23.85 | 0.0136 | 11 | stock_prices::EQ-M15K
R18: I-2026-05-early | P-HN-132 | 基金 | 禾宁稳健基金 | FD-ZH641 | 2026-05-06 | 2026-05-15 | 1.4204 | 1.4389 | 0.013025 | 12 | fund_nav::FD-ZH641
R19: I-2026-05-early | P-QD-574 | 股票 | 青岱设备A | EQ-T74D |  |  |  |  |  |  | stock_prices::EQ-T74D
R20: I-2026-05-early | P-BF-006 | 基金 | 澜石均衡基金 | FD-LS473 | 2026-05-06 | 2026-05-15 | 1.4648 | 1.4809 | 0.010991 | 14 | fund_nav::FD-LS473
R21: I-2026-05-early | P-TK-556 | 基金 | 棠科价值基金 | FD-XC218 | 2026-05-08 | 2026-05-14 | 1.505 | 1.5182 | 0.008771 | 18 | fund_nav::FD-XC218
R22: I-2026-05-early | P-VT-845 | 股票 | 维棠数控A | EQ-D45V | 2026-05-06 | 2026-05-15 | 26.33 | 26.81 | 0.01823 | 8 | stock_prices::EQ-D45V
R23: I-2026-05-early | P-FR-087 | 基金 | 枫润配置基金 | FD-KJ764 | 2026-05-06 | 2026-05-15 | 1.5494 | 1.5736 | 0.015619 | 10 | fund_nav::FD-KJ764
R24: I-2026-05-early | P-NC-337 | 基金 | 南岑收益基金 | FD-BY682 |  |  |  |  |  |  | fund_nav::FD-BY682
R25: I-2026-05-early | P-YA-890 | 基金 | 远岸观察基金 | FD-GL526 |  |  |  |  |  |  | fund_nav::FD-GL526
R26: I-2026-05-late | P-LX-209 | 股票 | 朗序仪表A | EQ-S09X | 2026-05-18 | 2026-05-29 | 11.36 | 11.55 | 0.016725 | 5 | stock_prices::EQ-S09X
R27: I-2026-05-late | P-AQ-017 | 股票 | 星桥制造A | EQ-A17Q | 2026-05-20 | 2026-05-29 | 12.8 | 12.94 | 0.010937 | 13 | stock_prices::EQ-A17Q
R28: I-2026-05-late | P-DM-011 | 基金 | 远川红利基金 | FD-YC741 | 2026-05-18 | 2026-05-29 | 1.118 | 1.1319 | 0.012433 | 11 | fund_nav::FD-YC741
R29: I-2026-05-late | P-CT-028 | 股票 | 南屿材料A | EQ-N28Y |  |  |  |  |  |  | stock_prices::EQ-N28Y
R30: I-2026-05-late | P-RY-618 | 股票 | 润曜控制A | EQ-B18Y | 2026-05-20 | 2026-05-29 | 17.15 | 17.4 | 0.014577 | 8 | stock_prices::EQ-B18Y
R31: I-2026-05-late | P-XW-916 | 股票 | 玄湾观察A | EQ-W16X |  |  |  |  |  |  | stock_prices::EQ-W16X
R32: I-2026-05-late | P-JU-205 | 基金 | 景佑量化基金 | FD-MY642 | 2026-05-19 | 2026-05-29 | 1.1778 | 1.1883 | 0.008915 | 17 | fund_nav::FD-MY642
R33: I-2026-05-late | P-AQ-042 | 股票 | 海岚设备A | EQ-H42L | 2026-05-18 | 2026-05-29 | 18.35 | 18.66 | 0.016894 | 4 | stock_prices::EQ-H42L
R34: I-2026-05-late | P-PV-481 | 基金 | 璞维均衡基金 | FD-RT742 |  |  |  |  |  |  | fund_nav::FD-RT742
R35: I-2026-05-late | P-GL-063 | 股票 | 谷澜精测A | EQ-C63G | 2026-05-18 | 2026-05-26 | 19.45 | 19.69 | 0.012339 | 12 | stock_prices::EQ-C63G
R36: I-2026-05-late | P-BF-019 | 基金 | 青枢稳健基金 | FD-QS462 | 2026-05-18 | 2026-05-29 | 1.2657 | 1.2843 | 0.014695 | 6 | fund_nav::FD-QS462
R37: I-2026-05-late | P-UM-763 | 基金 | 沐岚精选基金 | FD-SM428 | 2026-05-19 | 2026-05-29 | 1.3137 | 1.328 | 0.010885 | 14 | fund_nav::FD-SM428
R38: I-2026-05-late | P-MN-331 | 股票 | 沐宁材料A | EQ-R31M |  |  |  |  |  |  | stock_prices::EQ-R31M
R39: I-2026-05-late | P-SH-702 | 股票 | 森衡光联A | EQ-L02S | 2026-05-18 | 2026-05-29 | 22.74 | 23.21 | 0.020668 | 2 | stock_prices::EQ-L02S
R40: I-2026-05-late | P-EP-044 | 基金 | 峨浦成长基金 | FD-HY519 |  |  |  |  |  |  | fund_nav::FD-HY519
R41: I-2026-05-late | P-KR-115 | 股票 | 砺川电驱A | EQ-M15K | 2026-05-18 | 2026-05-29 | 23.9 | 24.42 | 0.021757 | 1 | stock_prices::EQ-M15K
R42: I-2026-05-late | P-HN-132 | 基金 | 禾宁稳健基金 | FD-ZH641 | 2026-05-19 | 2026-05-29 | 1.4404 | 1.4533 | 0.008956 | 16 | fund_nav::FD-ZH641
R43: I-2026-05-late | P-QD-574 | 股票 | 青岱设备A | EQ-T74D | 2026-05-20 | 2026-05-26 | 24.93 | 25.08 | 0.006017 | 18 | stock_prices::EQ-T74D
R44: I-2026-05-late | P-BF-006 | 基金 | 澜石均衡基金 | FD-LS473 | 2026-05-18 | 2026-05-29 | 1.4871 | 1.5074 | 0.013651 | 10 | fund_nav::FD-LS473
R45: I-2026-05-late | P-TK-556 | 基金 | 棠科价值基金 | FD-XC218 | 2026-05-18 | 2026-05-29 | 1.5206 | 1.5429 | 0.014665 | 7 | fund_nav::FD-XC218
R46: I-2026-05-late | P-VT-845 | 股票 | 维棠数控A | EQ-D45V | 2026-05-18 | 2026-05-29 | 26.84 | 27.32 | 0.017884 | 3 | stock_prices::EQ-D45V
R47: I-2026-05-late | P-FR-087 | 基金 | 枫润配置基金 | FD-KJ764 | 2026-05-19 | 2026-05-25 | 1.5765 | 1.5907 | 0.009007 | 15 | fund_nav::FD-KJ764
R48: I-2026-05-late | P-NC-337 | 基金 | 南岑收益基金 | FD-BY682 | 2026-05-18 | 2026-05-29 | 1.5938 | 1.6158 | 0.013803 | 9 | fund_nav::FD-BY682
R49: I-2026-05-late | P-YA-890 | 基金 | 远岸观察基金 | FD-GL526 |  |  |  |  |  |  | fund_nav::FD-GL526
R50: I-2026-06-window | P-LX-209 | 股票 | 朗序仪表A | EQ-S09X | 2026-06-01 | 2026-06-09 | 11.62 | 11.73 | 0.009466 | 15 | stock_prices::EQ-S09X
R51: I-2026-06-window | P-AQ-017 | 股票 | 星桥制造A | EQ-A17Q | 2026-06-01 | 2026-06-12 | 13.03 | 13.26 | 0.017652 | 3 | stock_prices::EQ-A17Q
R52: I-2026-06-window | P-DM-011 | 基金 | 远川红利基金 | FD-YC741 | 2026-06-01 | 2026-06-08 | 1.1365 | 1.1458 | 0.008183 | 16 | fund_nav::FD-YC741
R53: I-2026-06-window | P-CT-028 | 股票 | 南屿材料A | EQ-N28Y | 2026-06-03 | 2026-06-12 | 14.34 | 14.52 | 0.012552 | 8 | stock_prices::EQ-N28Y
R54: I-2026-06-window | P-RY-618 | 股票 | 润曜控制A | EQ-B18Y |  |  |  |  |  |  | stock_prices::EQ-B18Y
R55: I-2026-06-window | P-XW-916 | 股票 | 玄湾观察A | EQ-W16X |  |  |  |  |  |  | stock_prices::EQ-W16X
R56: I-2026-06-window | P-JU-205 | 基金 | 景佑量化基金 | FD-MY642 | 2026-06-01 | 2026-06-12 | 1.189 | 1.2045 | 0.013036 | 6 | fund_nav::FD-MY642
R57: I-2026-06-window | P-AQ-042 | 股票 | 海岚设备A | EQ-H42L | 2026-06-03 | 2026-06-12 | 18.76 | 18.96 | 0.010661 | 13 | stock_prices::EQ-H42L
R58: I-2026-06-window | P-PV-481 | 基金 | 璞维均衡基金 | FD-RT742 | 2026-06-02 | 2026-06-12 | 1.2249 | 1.2366 | 0.009552 | 14 | fund_nav::FD-RT742
R59: I-2026-06-window | P-GL-063 | 股票 | 谷澜精测A | EQ-C63G | 2026-06-01 | 2026-06-12 | 19.8 | 20.16 | 0.018182 | 2 | stock_prices::EQ-C63G
R60: I-2026-06-window | P-BF-019 | 基金 | 青枢稳健基金 | FD-QS462 | 2026-06-01 | 2026-06-12 | 1.2858 | 1.3045 | 0.014543 | 5 | fund_nav::FD-QS462
R61: I-2026-06-window | P-UM-763 | 基金 | 沐岚精选基金 | FD-SM428 |  |  |  |  |  |  | fund_nav::FD-SM428
R62: I-2026-06-window | P-MN-331 | 股票 | 沐宁材料A | EQ-R31M | 2026-06-01 | 2026-06-12 | 21.27 | 21.68 | 0.019276 | 1 | stock_prices::EQ-R31M
R63: I-2026-06-window | P-SH-702 | 股票 | 森衡光联A | EQ-L02S | 2026-06-03 | 2026-06-09 | 23.35 | 23.53 | 0.007709 | 18 | stock_prices::EQ-L02S
R64: I-2026-06-window | P-EP-044 | 基金 | 峨浦成长基金 | FD-HY519 | 2026-06-02 | 2026-06-12 | 1.3538 | 1.3694 | 0.011523 | 11 | fund_nav::FD-HY519
R65: I-2026-06-window | P-KR-115 | 股票 | 砺川电驱A | EQ-M15K |  |  |  |  |  |  | stock_prices::EQ-M15K
R66: I-2026-06-window | P-HN-132 | 基金 | 禾宁稳健基金 | FD-ZH641 | 2026-06-01 | 2026-06-12 | 1.459 | 1.4775 | 0.01268 | 7 | fund_nav::FD-ZH641
R67: I-2026-06-window | P-QD-574 | 股票 | 青岱设备A | EQ-T74D | 2026-06-01 | 2026-06-12 | 25.21 | 25.63 | 0.01666 | 4 | stock_prices::EQ-T74D
R68: I-2026-06-window | P-BF-006 | 基金 | 澜石均衡基金 | FD-LS473 | 2026-06-02 | 2026-06-08 | 1.5094 | 1.5216 | 0.008083 | 17 | fund_nav::FD-LS473
R69: I-2026-06-window | P-TK-556 | 基金 | 棠科价值基金 | FD-XC218 | 2026-06-01 | 2026-06-12 | 1.5495 | 1.5675 | 0.011617 | 10 | fund_nav::FD-XC218
R70: I-2026-06-window | P-VT-845 | 股票 | 维棠数控A | EQ-D45V | 2026-06-03 | 2026-06-12 | 27.47 | 27.79 | 0.011649 | 9 | stock_prices::EQ-D45V
R71: I-2026-06-window | P-FR-087 | 基金 | 枫润配置基金 | FD-KJ764 |  |  |  |  |  |  | fund_nav::FD-KJ764
R72: I-2026-06-window | P-NC-337 | 基金 | 南岑收益基金 | FD-BY682 | 2026-06-02 | 2026-06-12 | 1.6234 | 1.642 | 0.011457 | 12 | fund_nav::FD-BY682
R73: I-2026-06-window | P-YA-890 | 基金 | 远岸观察基金 | FD-GL526 |  |  |  |  |  |  | fund_nav::FD-GL526

## Sheet 2: missing_date_exceptions
Dimensions: 19 rows x 10 columns
R1: interval_id | 产品ID | 资产类型 | 源代码 | exception_category | interval_start_date | interval_end_date | first_available_date_in_window | last_available_date_in_window | source_trace
R2: I-2026-05-early | P-DM-011 | 基金 | FD-YC741 | missing_end_observation | 2026-05-06 | 2026-05-15 |  |  | fund_nav::FD-YC741
R3: I-2026-05-early | P-XW-916 | 股票 | EQ-W16X | source_code_not_found | 2026-05-06 | 2026-05-15 |  |  | stock_prices::EQ-W16X
R4: I-2026-05-early | P-GL-063 | 股票 | EQ-C63G | missing_end_observation | 2026-05-06 | 2026-05-15 |  |  | stock_prices::EQ-C63G
R5: I-2026-05-early | P-QD-574 | 股票 | EQ-T74D | missing_end_observation | 2026-05-06 | 2026-05-15 |  |  | stock_prices::EQ-T74D
R6: I-2026-05-early | P-NC-337 | 基金 | FD-BY682 | missing_end_observation | 2026-05-06 | 2026-05-15 |  |  | fund_nav::FD-BY682
R7: I-2026-05-early | P-YA-890 | 基金 | FD-GL526 | source_code_not_found | 2026-05-06 | 2026-05-15 |  |  | fund_nav::FD-GL526
R8: I-2026-05-late | P-CT-028 | 股票 | EQ-N28Y | no_usable_observation_in_interval | 2026-05-18 | 2026-05-29 |  |  | stock_prices::EQ-N28Y
R9: I-2026-05-late | P-XW-916 | 股票 | EQ-W16X | source_code_not_found | 2026-05-18 | 2026-05-29 |  |  | stock_prices::EQ-W16X
R10: I-2026-05-late | P-PV-481 | 基金 | FD-RT742 | no_usable_observation_in_interval | 2026-05-18 | 2026-05-29 |  |  | fund_nav::FD-RT742
R11: I-2026-05-late | P-MN-331 | 股票 | EQ-R31M | no_usable_observation_in_interval | 2026-05-18 | 2026-05-29 |  |  | stock_prices::EQ-R31M
R12: I-2026-05-late | P-EP-044 | 基金 | FD-HY519 | no_usable_observation_in_interval | 2026-05-18 | 2026-05-29 |  |  | fund_nav::FD-HY519
R13: I-2026-05-late | P-YA-890 | 基金 | FD-GL526 | source_code_not_found | 2026-05-18 | 2026-05-29 |  |  | fund_nav::FD-GL526
R14: I-2026-06-window | P-RY-618 | 股票 | EQ-B18Y | missing_start_observation | 2026-06-01 | 2026-06-12 |  |  | stock_prices::EQ-B18Y
R15: I-2026-06-window | P-XW-916 | 股票 | EQ-W16X | source_code_not_found | 2026-06-01 | 2026-06-12 |  |  | stock_prices::EQ-W16X
R16: I-2026-06-window | P-UM-763 | 基金 | FD-SM428 | missing_start_observation | 2026-06-01 | 2026-06-12 |  |  | fund_nav::FD-SM428
R17: I-2026-06-window | P-KR-115 | 股票 | EQ-M15K | missing_start_observation | 2026-06-01 | 2026-06-12 |  |  | stock_prices::EQ-M15K
R18: I-2026-06-window | P-FR-087 | 基金 | FD-KJ764 | missing_start_observation | 2026-06-01 | 2026-06-12 |  |  | fund_nav::FD-KJ764
R19: I-2026-06-window | P-YA-890 | 基金 | FD-GL526 | source_code_not_found | 2026-06-01 | 2026-06-12 |  |  | fund_nav::FD-GL526

## Sheet 3: ranked_comparison
Dimensions: 55 rows x 8 columns
R1: interval_id | rank_in_interval | 产品ID | 资产类型 | 展示名称 | interval_return | start_observation_date | end_observation_date
R2: I-2026-05-early | 1 | P-AQ-017 | 股票 | 星桥制造A | 0.04 | 2026-05-06 | 2026-05-13
R3: I-2026-05-early | 1 | P-AQ-042 | 股票 | 海岚设备A | 0.04 | 2026-05-06 | 2026-05-13
R4: I-2026-05-early | 3 | P-RY-618 | 股票 | 润曜控制A | 0.022222 | 2026-05-06 | 2026-05-15
R5: I-2026-05-late | 1 | P-KR-115 | 股票 | 砺川电驱A | 0.021757 | 2026-05-18 | 2026-05-29
R6: I-2026-05-early | 4 | P-SH-702 | 股票 | 森衡光联A | 0.021238 | 2026-05-06 | 2026-05-15
R7: I-2026-05-late | 2 | P-SH-702 | 股票 | 森衡光联A | 0.020668 | 2026-05-18 | 2026-05-29
R8: I-2026-05-early | 5 | P-LX-209 | 股票 | 朗序仪表A | 0.020591 | 2026-05-07 | 2026-05-15
R9: I-2026-05-early | 6 | P-MN-331 | 股票 | 沐宁材料A | 0.019664 | 2026-05-06 | 2026-05-15
R10: I-2026-05-early | 7 | P-CT-028 | 股票 | 南屿材料A | 0.019327 | 2026-05-06 | 2026-05-15
R11: I-2026-06-window | 1 | P-MN-331 | 股票 | 沐宁材料A | 0.019276 | 2026-06-01 | 2026-06-12
R12: I-2026-05-early | 8 | P-VT-845 | 股票 | 维棠数控A | 0.01823 | 2026-05-06 | 2026-05-15
R13: I-2026-06-window | 2 | P-GL-063 | 股票 | 谷澜精测A | 0.018182 | 2026-06-01 | 2026-06-12
R14: I-2026-05-late | 3 | P-VT-845 | 股票 | 维棠数控A | 0.017884 | 2026-05-18 | 2026-05-29
R15: I-2026-06-window | 3 | P-AQ-017 | 股票 | 星桥制造A | 0.017652 | 2026-06-01 | 2026-06-12
R16: I-2026-05-late | 4 | P-AQ-042 | 股票 | 海岚设备A | 0.016894 | 2026-05-18 | 2026-05-29
R17: I-2026-05-late | 5 | P-LX-209 | 股票 | 朗序仪表A | 0.016725 | 2026-05-18 | 2026-05-29
R18: I-2026-06-window | 4 | P-QD-574 | 股票 | 青岱设备A | 0.01666 | 2026-06-01 | 2026-06-12
R19: I-2026-05-early | 9 | P-UM-763 | 基金 | 沐岚精选基金 | 0.015797 | 2026-05-06 | 2026-05-15
R20: I-2026-05-early | 10 | P-FR-087 | 基金 | 枫润配置基金 | 0.015619 | 2026-05-06 | 2026-05-15
R21: I-2026-05-late | 6 | P-BF-019 | 基金 | 青枢稳健基金 | 0.014695 | 2026-05-18 | 2026-05-29
R22: I-2026-05-late | 7 | P-TK-556 | 基金 | 棠科价值基金 | 0.014665 | 2026-05-18 | 2026-05-29
R23: I-2026-05-late | 8 | P-RY-618 | 股票 | 润曜控制A | 0.014577 | 2026-05-20 | 2026-05-29
R24: I-2026-06-window | 5 | P-BF-019 | 基金 | 青枢稳健基金 | 0.014543 | 2026-06-01 | 2026-06-12
R25: I-2026-05-late | 9 | P-NC-337 | 基金 | 南岑收益基金 | 0.013803 | 2026-05-18 | 2026-05-29
R26: I-2026-05-late | 10 | P-BF-006 | 基金 | 澜石均衡基金 | 0.013651 | 2026-05-18 | 2026-05-29
R27: I-2026-05-early | 11 | P-KR-115 | 股票 | 砺川电驱A | 0.0136 | 2026-05-07 | 2026-05-13
R28: I-2026-06-window | 6 | P-JU-205 | 基金 | 景佑量化基金 | 0.013036 | 2026-06-01 | 2026-06-12
R29: I-2026-05-early | 12 | P-HN-132 | 基金 | 禾宁稳健基金 | 0.013025 | 2026-05-06 | 2026-05-15
R30: I-2026-06-window | 7 | P-HN-132 | 基金 | 禾宁稳健基金 | 0.01268 | 2026-06-01 | 2026-06-12
R31: I-2026-06-window | 8 | P-CT-028 | 股票 | 南屿材料A | 0.012552 | 2026-06-03 | 2026-06-12
R32: I-2026-05-late | 11 | P-DM-011 | 基金 | 远川红利基金 | 0.012433 | 2026-05-18 | 2026-05-29
R33: I-2026-05-late | 12 | P-GL-063 | 股票 | 谷澜精测A | 0.012339 | 2026-05-18 | 2026-05-26
R34: I-2026-05-early | 13 | P-EP-044 | 基金 | 峨浦成长基金 | 0.011678 | 2026-05-06 | 2026-05-14
R35: I-2026-06-window | 9 | P-VT-845 | 股票 | 维棠数控A | 0.011649 | 2026-06-03 | 2026-06-12
R36: I-2026-06-window | 10 | P-TK-556 | 基金 | 棠科价值基金 | 0.011617 | 2026-06-01 | 2026-06-12
R37: I-2026-06-window | 11 | P-EP-044 | 基金 | 峨浦成长基金 | 0.011523 | 2026-06-02 | 2026-06-12
R38: I-2026-06-window | 12 | P-NC-337 | 基金 | 南岑收益基金 | 0.011457 | 2026-06-02 | 2026-06-12
R39: I-2026-05-early | 14 | P-BF-006 | 基金 | 澜石均衡基金 | 0.010991 | 2026-05-06 | 2026-05-15
R40: I-2026-05-late | 13 | P-AQ-017 | 股票 | 星桥制造A | 0.010937 | 2026-05-20 | 2026-05-29
R41: I-2026-05-late | 14 | P-UM-763 | 基金 | 沐岚精选基金 | 0.010885 | 2026-05-19 | 2026-05-29
R42: I-2026-06-window | 13 | P-AQ-042 | 股票 | 海岚设备A | 0.010661 | 2026-06-03 | 2026-06-12
R43: I-2026-05-early | 15 | P-PV-481 | 基金 | 璞维均衡基金 | 0.010607 | 2026-05-06 | 2026-05-15
R44: I-2026-05-early | 16 | P-BF-019 | 基金 | 青枢稳健基金 | 0.010345 | 2026-05-08 | 2026-05-15
R45: I-2026-06-window | 14 | P-PV-481 | 基金 | 璞维均衡基金 | 0.009552 | 2026-06-02 | 2026-06-12
R46: I-2026-06-window | 15 | P-LX-209 | 股票 | 朗序仪表A | 0.009466 | 2026-06-01 | 2026-06-09
R47: I-2026-05-early | 17 | P-JU-205 | 基金 | 景佑量化基金 | 0.009033 | 2026-05-06 | 2026-05-14
R48: I-2026-05-late | 15 | P-FR-087 | 基金 | 枫润配置基金 | 0.009007 | 2026-05-19 | 2026-05-25
R49: I-2026-05-late | 16 | P-HN-132 | 基金 | 禾宁稳健基金 | 0.008956 | 2026-05-19 | 2026-05-29
R50: I-2026-05-late | 17 | P-JU-205 | 基金 | 景佑量化基金 | 0.008915 | 2026-05-19 | 2026-05-29
R51: I-2026-05-early | 18 | P-TK-556 | 基金 | 棠科价值基金 | 0.008771 | 2026-05-08 | 2026-05-14
R52: I-2026-06-window | 16 | P-DM-011 | 基金 | 远川红利基金 | 0.008183 | 2026-06-01 | 2026-06-08
R53: I-2026-06-window | 17 | P-BF-006 | 基金 | 澜石均衡基金 | 0.008083 | 2026-06-02 | 2026-06-08
R54: I-2026-06-window | 18 | P-SH-702 | 股票 | 森衡光联A | 0.007709 | 2026-06-03 | 2026-06-09
R55: I-2026-05-late | 18 | P-QD-574 | 股票 | 青岱设备A | 0.006017 | 2026-05-20 | 2026-05-26

## Sheet 4: summary
Dimensions: 10 rows x 8 columns
R1: interval_id | 资产类型 | active_product_count | valid_return_count | exception_count | avg_interval_return | top_product_id | exception_breakdown
R2: I-2026-05-early | 股票 | 12 | 9 | 3 | 0.02387466666666667 | P-AQ-017 | {'missing_end_observation': 2, 'source_code_not_found': 1}
R3: I-2026-05-early | 基金 | 12 | 9 | 3 | 0.01176288888888889 | P-UM-763 | {'missing_end_observation': 2, 'source_code_not_found': 1}
R4: I-2026-05-early | all | 24 | 18 | 6 | 0.01781877777777778 | P-AQ-017 | {'missing_end_observation': 4, 'source_code_not_found': 2}
R5: I-2026-05-late | 股票 | 12 | 9 | 3 | 0.01531088888888889 | P-KR-115 | {'no_usable_observation_in_interval': 2, 'source_code_not_found': 1}
R6: I-2026-05-late | 基金 | 12 | 9 | 3 | 0.01189 | P-BF-019 | {'no_usable_observation_in_interval': 2, 'source_code_not_found': 1}
R7: I-2026-05-late | all | 24 | 18 | 6 | 0.01360044444444444 | P-KR-115 | {'no_usable_observation_in_interval': 4, 'source_code_not_found': 2}
R8: I-2026-06-window | 股票 | 12 | 9 | 3 | 0.01375633333333333 | P-MN-331 | {'missing_start_observation': 2, 'source_code_not_found': 1}
R9: I-2026-06-window | 基金 | 12 | 9 | 3 | 0.011186 | P-BF-019 | {'missing_start_observation': 2, 'source_code_not_found': 1}
R10: I-2026-06-window | all | 24 | 18 | 6 | 0.01247116666666667 | P-MN-331 | {'missing_start_observation': 4, 'source_code_not_found': 2}
