# Judge Scope and Gate Status

This verifier-produced evidence is for the supplemental text-only WB Judge for `market_daily_brief_a_share_recap`.
It is generated only from the submitted `daily_recap.md`, public task requirements, and deterministic result summary.
It contains no hidden gold content, oracle prose, private trace/source context, model logs, external market data, screenshots, OCR, VLM, or pixel-level evidence.

## Deterministic component summary
- submitted artifact path observed by verifier: `/workspace/daily_recap.md`
- submitted artifact exists: True
- deterministic passed_count: 20
- deterministic total_count: 24
- deterministic pass_rate: 0.8333
- deterministic full pass: False
- preflight passed_count: 2
- preflight total_count: 6
- deterministic failed check count: 4
- preflight failed check count: 4

## Failed deterministic checks visible to Judge as non-overridable context
- market_overview_section_covered
- draft_revision_section_covered
- source_decision_ledger_section_covered
- public_expected_state_available_for_scoring

## Failed preflight checks visible to Judge as non-overridable context
- all_p8r4_public_files_present
- public_expected_state_derivable
- case_metadata_judge_enabled_text_only
- text_only_judge_config_present

## WB Judge activation boundary
- deterministic_component_transparency_required: true
- deterministic_partial_pass_allowed: true
- deterministic_full_pass_required: false
- required_evidence_files_must_exist: true
- modality: text_only_non_multimodal
- uses_vlm_judge: false
- deterministic_failure_policy: preserve_failed_checks_and_do_not_mark_objective_failures_passed
- deterministic objective failures remain failed regardless of any LLM Judge rubric result.
- deterministic safety/leakage failure detected: False
- submitted output text withheld from Judge evidence: False

## Judge-owned semantic scope
- The Judge may assess whether the submitted Markdown synthesizes visible source facts into a concise Chinese post-close recap rather than a source/evaluator dump.
- The Judge may assess whether source adoption/replacement/exclusion/background decisions explain affected conclusions, numbers, scope, or material-use boundaries.
- The Judge may assess whether flawed draft overclaims are rewritten into evidence-bounded factual descriptions with visible source/status/scope limits.
- The Judge may assess whether the local synthetic, non-real-time, non-advisory boundary is integrated into framing and source-use language.

## Deterministic-owned scope not to be rescored by Judge
- File existence, filename, root-level output, Markdown parseability, exact source IDs, exact numbers, section/table coverage, banned actionable advice terms, external/private-source leakage, and all objective verifier checks remain deterministic-owned.
- Judge must not infer hidden expected wording, require exact section order, use external facts, or forgive deterministic factual/source/safety failures.
