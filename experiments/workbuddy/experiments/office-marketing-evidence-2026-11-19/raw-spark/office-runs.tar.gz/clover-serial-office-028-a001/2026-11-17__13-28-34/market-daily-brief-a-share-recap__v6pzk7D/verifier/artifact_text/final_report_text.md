# 采菊东篱 · A股收盘复盘｜2026-04-17

## 资料范围与来源取舍

本报告仅基于任务目录内 `input/` 下的冻结示例资料（交易所风格导出、编辑台工作底稿、来源卡、更正卡、交叉表及附录），未调用任何实时行情系统、外部 API 或网络 URL。所有关键数值均绑定 `source_id`，并附采用、替换或排除理由。

| 项目 | 草稿旧值 / 待核项 | 最终取值 | source_id | 取舍说明 |
|---|---|---|---|---|
| 北部样例指数涨跌幅 | +1.84% | +0.62% | SRC-NB-1510 | SRC-NB-0930（早盘快照）已 superseded；以 15:12 收盘行替代 |
| 南部样例指数涨跌幅 | — | −0.18% | SRC-SB-1520 | 同文件 14:30 盘中草稿（excluded）不覆盖；直接取 close_metric 行 |
| 合并宽度分母 | 混合分母（无具体数字） | 558 | WP-004 | SRC-WP-1518 current 行；排除维护池、note_only、旧日摘录 |
| 上涨家数占比 | 71% | 55.91% | WP-005 | SRC-WIDTH-0930 被 SRC-COR-1614 解释为不可用口径；按可交易排除后分母重算 |
| 南部成交额 | 462.1（导出行） | 448.6 | SRC-COR-1608 | SRC-SB-1521 partially_superseded；更正卡只调整 turnover_amount 字段，不改写涨跌和宽度行 |
| 北部成交额 | — | 418.2 | SRC-NB-1511 | current close_metric 行；不含维护池 |
| 领涨风格 | 智能终端、绿能设备 | 见下文行业/风格轮动 | SRC-XWALK-1520 + SRC-COR-1619 | 同名别名需按 segment/source_role 拆分；绿能设备置信度为 low |
| 过强叙事措辞 | "全市场主线明确""资金继续流入" | 描述性局部表述 | SRC-COR-1624 | 缺少本地支撑，改为"局部活跃、确认度有限" |

**排除项：**
- `SRC-NB-MAINT-1515`（北部维护池）、`SRC-SB-MAINT-1525`（南部维护池）：maintenance_note，不进入 active denominator 或成交额汇总。
- `SRC-NB-NOTE-1516`（北部 note_only 评论）：current_context_only，仅作措辞背景，不支持数值。
- `SRC-NB-OLD-0416`（旧交易日干扰项）：stale_prior_date，不支持今日结论。
- `SRC-SB-DRAFT-1430`（南部盘中草稿）：intraday_draft，excluded。
- `SRC-WP-007`（884.6 note_only 旁注）：commentary_only，不是成交额汇总。
- `SRC-THEME-1015`（早盘主题包）：partially_superseded，只能解释草稿旧说法，不能支持收盘领涨判断。
- `archive/20260416/previous_recap_extract_20260416.md`：stale_prior_date，不可支持 2026-04-17 事实。

---

## 一、大盘总览

### 北部样例主板（NB-MAIN）

| 指标 | 数值 | source_id |
|---|---|---|
| 样例指数涨跌幅 | +0.62% | SRC-NB-1510 |
| 成交额 | 418.2 synthetic_billion | SRC-NB-1511 |
| 上涨家数 | 176 | SRC-NB-1512 |
| 下跌家数 | 119 | SRC-NB-1513 |
| 平盘家数 | 15 | SRC-NB-1514 |

北部样例池在 15:12 收盘时收涨，活跃度高于早盘但剔除维护池后幅度收窄（SRC-NB-NOTE-1516）。

### 南部样例成长板（SB-GROWTH）

| 指标 | 数值 | source_id |
|---|---|---|
| 样例指数涨跌幅 | −0.18% | SRC-SB-1520 |
| 成交额（更正后） | 448.6 synthetic_billion | SRC-COR-1608 |
| 上涨家数 | 136 | SRC-SB-1522 |
| 下跌家数 | 107 | SRC-SB-1523 |
| 平盘家数 | 5 | SRC-SB-1524 |

南部指数收跌。其成交额行经 SRC-COR-1608 更晚更正卡调整——剔除一笔维护批次后由原 462.1 修正为 448.6；同文件的涨跌和宽度行未被整体替换，仍可用。

### 合并口径（combined_sample_market）

| 指标 | 数值 | source_id |
|---|---|---|
| 上涨家数 | 312 | WP-001 |
| 下跌家数 | 226 | WP-002 |
| 平盘家数 | 20 | WP-003 |
| 可交易排除后分母 | 558 | WP-004 |
| 上涨家数占比 | 55.91% | WP-005 |
| 下跌家数占比 | 40.50% | WP-006 |

分母 558 = 312 + 226 + 20，按 `tradable_after_exclusions` 口径（排除维护池、note_only、旧日摘录和盘中草稿）。SRC-COR-1614 说明为何不用早盘 71% 旁注。

---

## 二、短线生态指标监测

### 换手分桶（高/低）

| 指标 | 数值 | source_id |
|---|---|---|
| 高换手样本数 | 74 | WP-008 |
| 高换手比例 | 13.26% | WP-009 |
| 低换手比例 | 33.69% | WP-010 |

高换手比例按 74/558 四舍五入；低换手比例为独立统计。注意：synthetic_billion 成交额单位与换手分桶百分比不可混用（NC-03）。

### 活跃度观察

北部样例池活跃度高于早盘，但维护池剔除后幅度收窄（SRC-NB-NOTE-1516）。南部指数收跌，与北部形成方向分化。

---

## 三、行业/风格轮动

以下数据来自 `sector_style_crosswalk_20260417.json`（SRC-XWALK-1520），按 sector_return_pct 降序排列。数值为合成样本，非投资评级。

| 行业/风格 | 收益率 | 成交占比 | 置信度 | source_id |
|---|---|---|---|---|
| 样例硬件链（growth_hardware） | +0.88% | 13.4% | medium | SRC-XWALK-1520-H |
| 云边资源（infrastructure_blend） | +0.33% | 11.7% | medium | SRC-XWALK-1520-C |
| 绿能设备（cyclical_equipment） | +0.21% | 8.2% | low | SRC-XWALK-1520-G |
| 基础修复（defensive_repair） | −0.08% | 7.5% | medium | SRC-XWALK-1520-B |
| 本地服务（domestic_services） | −0.46% | 6.1% | medium | SRC-XWALK-1520-L |

### 别名拆分说明

"智能终端"这一别名在两个不同 segment 中出现：

- **synthetic_hardware_chain**（SEC-HARD-01）：归属 desk_crosswalk（current），对应样例硬件链，+0.88%。
- **synthetic_cloud_edge**（SEC-CLOUD-02）：归属 theme_initial_pack（partially_superseded），对应云边资源，+0.33%。

SRC-COR-1619 要求不得将两者机械合并为一个"智能终端"板块。早盘主题包中"智能终端"的提法仅用于解释草稿旧说法（SRC-THEME-1015），不能作为收盘后的领涨结论依据。

### 绿能设备

早盘主题包称其与智能终端"共同带动"（SRC-THEME-1015）。收盘交叉表显示其收益率为 +0.21%，置信度为 low，且 SRC-CARD-1602 提示应降级为"温和偏强"。SRC-COR-1624 进一步要求把"共同带动"列入修订 ledger，不写成最终领涨结论。

### 本地服务

话题有讨论热度（SRC-CARD-1555），但结构化表现偏弱（−0.46%），不适合写成一致主线。

---

## 四、宽度、换手与技术面简评

### 宽度

合并宽度 55.91%（上涨家数占比）处于中性偏暖区间，但较早盘 71% 明显回落。SRC-COR-1614 指出 71% 的分母为混合口径，当前改用可交易排除后口径。SRC-CARD-1602 提示"局部主题活跃与广度分化并存"。

### 换手

高换手样本占 13.26%，低换手占 33.69%。两部分合计约 46.95%，剩余部分未在工作底稿中提供细分。注意不要将 high_turnover_bucket_count（74）误读为成交额。

### 技术面

本资料柜未提供独立的 K 线、均线或技术指标数据。以下仅为基于现有数据的描述性观察，不构成技术分析结论：

- 北部指数收涨、南部指数收跌，两市场段方向分化。
- 行业层面呈现结构性分化：硬件链与云边资源为正，本地服务为负。
- 广度和换手分桶均未提供跨市场段的统一技术信号。

---

## 五、情绪温度计

| 维度 | 状态 | 证据来源 |
|---|---|---|
| 指数方向 | 北涨南跌，分化 | SRC-NB-1510, SRC-SB-1520 |
| 广度 | 55.91% 上涨占比，较早盘回落 | WP-005, SRC-COR-1614 |
| 行业结构 | 硬件链领先，本地服务拖累 | SRC-XWALK-1520-H, SRC-XWALK-1520-L |
| 换手分布 | 高换手 13.26%，集中度偏低 | WP-008, WP-009 |
| 叙事一致性 | 局部活跃，确认度有限 | SRC-CARD-1555, SRC-CARD-1602, SRC-COR-1624 |

综合判断：市场呈现局部活跃与广度分化并存的格局，缺乏单一方向的全市场共识信号。

---

## 六、明日观察

以下仅为需要继续观察的市场信号，不构成投资建议：

1. **南北方向分化是否延续**：若次日北部维持上涨而南部继续走弱，需关注是否存在风格切换或流动性分层。
2. **硬件链与云边资源的"智能终端"别名争议**：两个 segment 共享同一别名，后续若出现合并报道，需核实其实际对应的 ticker 范围。
3. **绿能设备的持续性**：low confidence 下 +0.21% 的收益能否延续，值得跟踪。
4. **本地服务的反转信号**：−0.46% 的跌幅是否伴随成交量萎缩或扩散至其他消费类风格。
5. **广度的变化**：55.91% 的上涨占比是否向 50% 中枢回归，还是进一步偏离。

---

## 草稿修订要点

| 草稿条目 | 问题类型 | 修订内容 |
|---|---|---|
| "样例宽基指数收涨 1.84%" | 旧值 | 拆分为北部 +0.62%（SRC-NB-1510）和南部 −0.18%（SRC-SB-1520），不再使用 SRC-NB-0930 的早盘快照 |
| "上涨家数占比约 71%" | 分母不明 | 改为 55.91%（WP-005），分母 558 为可交易排除后口径（SRC-COR-1614） |
| "成交较前一日明显放大" | 口径不清 | 改为分别列示北部 418.2 和南部 448.6 synthetic_billion，注明后者经 SRC-COR-1608 更正 |
| "智能终端和绿能设备共同带动" | 别名混用 + 过强叙事 | 拆分为硬件链 +0.88% 和云边资源 +0.33%；绿能设备标注 low confidence 且仅支持温和偏强 |
| "尾盘资金继续流入高弹性成长方向" | 无来源支撑 | 删除；改为描述性观察 |
| "全市场主线明确" | 过强叙事 | 删除；改为"局部活跃、确认度有限"（SRC-COR-1624） |
| 风险与披露 | 披露缺口 | 补充资料边界声明和非建议声明 |

---

## 叙事与结构化数据对照

| 叙事主张 | 结构化数据 | 来源卡备注 |
|---|---|---|
| 智能终端领涨 | 硬件链 +0.88%（medium confidence）；云边资源 +0.33%（medium confidence） | SRC-COR-1619：别名需拆分，不可合并 |
| 绿能设备共同带动 | 绿能设备 +0.21%（low confidence） | SRC-CARD-1602：应降级为温和偏强 |
| 全市场主线明确 | 南北方向分化；55.91% 上涨占比 | SRC-CARD-1555：避免把局部热度写成一致主线 |
| 资金继续流入 | 无独立资金流数据 | SRC-COR-1624：该措辞缺少本地支撑 |

---

## 来源取舍/更正表

| source_id | 角色 | 状态 | 处理 | 理由 |
|---|---|---|---|---|
| SRC-NB-1510 | exchange_close_export | current | **采用** | 北部样例池 15:12 收盘行，替代 SRC-NB-0930 |
| SRC-NB-1511 | exchange_close_export | current | **采用** | 北部成交额，不含维护池 |
| SRC-SB-1520 | exchange_close_export | current | **采用** | 南部指数涨跌幅 |
| SRC-SB-1521 | exchange_close_export | partially_superseded | **部分采用** | 涨跌和宽度行保留；成交额行被 SRC-COR-1608 替换 |
| SRC-COR-1608 | late_correction_card | current | **采用** | 南部成交额更正为 448.6 |
| SRC-WP-1518 | desk_workpaper | current_with_note_rows | **过滤采用** | 仅取 row_status=current 的行（WP-001 ~ WP-006, WP-008 ~ WP-010）；排除 WP-007（note_only）和 WP-012（method_note） |
| SRC-COR-1614 | late_correction_card | current | **采用** | 解释宽度分母政策，替代 SRC-WIDTH-0930 |
| SRC-XWALK-1520 | desk_crosswalk | current | **采用** | 行业/风格方向，别名结合 source_role 拆分 |
| SRC-COR-1619 | late_correction_card | current | **采用** | 别名拆分规则 |
| SRC-CARD-1555 | close_editor_context | current_context_only | **背景采用** | 支持谨慎语气，不支持新增数值 |
| SRC-CARD-1602 | close_editor_context | current_context_only | **背景采用** | 支持叙事降温，不支持改写结构化数据 |
| SRC-COR-1624 | late_correction_card | current | **采用** | 过强叙事措辞修订 |
| SRC-NB-0930 | early_snapshot | superseded | **排除** | 早盘北部快照，已被收盘行替代 |
| SRC-WIDTH-0930 | early_snapshot | superseded | **排除** | 早盘混合分母，被 WP-005 + SRC-COR-1614 替代 |
| SRC-THEME-1015 | theme_initial_pack | partially_superseded | **排除（作为事实）** | 仅用于解释草稿旧说法，不能支持收盘领涨判断 |
| SRC-NB-MAINT-1515 | maintenance_note | excluded | **排除** | 维护池不进入 active denominator |
| SRC-SB-MAINT-1525 | maintenance_note | excluded | **排除** | 维护池不进入 active denominator |
| SRC-NB-NOTE-1516 | note_only | current_context_only | **排除（作为事实）** | 仅作措辞背景 |
| SRC-NB-OLD-0416 | stale_prior_date | stale | **排除** | 旧交易日干扰项 |
| SRC-SB-DRAFT-1430 | intraday_draft | excluded | **排除** | 盘中草稿不支持收盘复盘 |
| archive/20260416/* | prior_day_extract | stale_prior_date | **排除** | 前一交易日材料，不可支持 今日 事实 |

---

## 披露与非建议声明

**资料边界：** 本报告所有数据和判断均来源于任务目录内 `input/` 下的离线示例资料（`_manifest/`、`current/`、`drafts/`、`archive/`）。未使用任何实时行情系统、外部 API、网络 URL、浏览器、私有终端、账号后台、VPN 或 PDF 生成技能。

**非实时声明：** 本复盘基于 2026-04-17 收盘时段（15:12–16:24 CST）的示例数据，不代表真实市场的实时价格或交易情况。所有数值均为合成样本，仅供格式练习。

**非投资建议声明：** 本报告为事实性、描述性复盘，不包含买入、卖出、持有、加仓、减仓、目标价、止损、收益承诺、组合配置或个性化投资建议。读者不应据此做出任何投资决策。

**局限性：** 本资料柜未提供独立的 K 线、均线、技术指标或资金流向数据。行业/风格观察基于合成样本，置信度从 medium 到 low 不等。"智能终端"等别名在不同 segment 中存在歧义，需按 source_role 拆分理解。

---

*报告生成时间：2026-04-17 盘后*
*起草人：采菊东篱（自动化复盘流程）*
