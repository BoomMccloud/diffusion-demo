# Public Recap Requirement Summary

This verifier-produced summary is derived from public task instructions, public task metadata, and public local fixture notes only. It contains no hidden gold, hidden expected answer, model logs, private traces, live market data, or external evidence.

## Output contract anchors
- Required deliverable: a root-level Chinese Markdown file named `daily_recap.md` for synthetic trade date `2026-04-17`.
- The task is Markdown-only: no PDF, HTML, screenshots, or other final delivery artifacts.
- The report must be based only on the local public filing room under `input/_manifest/`, `input/current/`, `input/archive/`, `input/drafts/`, and `environment/local_fixture_notes.md`.

## Source-use and reconciliation anchors
- The recap must distinguish current, archive, and draft roles; archive materials and flawed drafts may explain revisions but do not automatically support current close facts.
- The recap must handle source_id, source_role, source_status/row_state, update_time, scope_tag/scope_note, claim_type, supersession links, row_type/line_kind, row_status, and denominator_scope.
- Old trade-date extracts, morning snapshots, intraday drafts, maintenance pools, note_only rows, context_only sources, superseded sources, old theme packs, and draft margin notes must not be used as final numeric values, rankings, or broad strength evidence.
- The report must include a source decision/correction table or equivalent ledger covering old snapshot replacement, breadth denominator replacement, south turnover correction, morning theme alias split, draft overclaim/tone repair, and disclosure boundary.
- Key numbers, status judgments, conflict explanations, or background judgments should bind to local source_id values and distinguish structured numeric sources, workpapers, source cards, appendices/method notes, archive material, and drafts.

## Market recap semantic anchors for Judge
- A passing semantic recap should integrate market, sector/style, breadth/turnover, and draft-revision interpretation; it should not read mainly as source IDs, filenames, raw rows, evaluator checklist language, or a compliance ledger.
- Source decisions should explain the affected conclusion, number, scope, or material-use boundary, such as field-level south turnover correction scope, breadth denominator replacement, and context-only/note-only limits.
- Flawed draft overclaims should be rewritten as evidence-bounded factual descriptions with visible source/status/scope limits, not preserved as full-market mainline, broad turnover expansion, final ranking, or funds-flow claims unsupported by public local sources.
- The local synthetic, non-real-time, non-advisory boundary should be integrated into source-use and framing language, not only appended as a generic disclaimer.

## Safety and dependency anchors
- No live行情/market/news service, external API, browser, private terminal, account backend, VPN, private URL/path, credentials, account IDs, customer data, real proprietary opinion, or unpublished private asset may be used or cited.
- No buy/sell/hold call, target price, position sizing, portfolio allocation, return promise, trading instruction, or personalized investment advice may be output.
- Deterministic verifier owns objective banned-term/actionable-advice, exact source-id, exact numeric, file-contract, and leakage checks; the supplemental Judge only assesses evidence-visible semantic integration.

## Public instruction excerpt
[public file not available at verifier runtime: instruction.md]

## Public local fixture note excerpt
# 资料柜运行说明

本任务只需要当前工作目录中的资料柜文件。资料位于 `input/`，包括资料清单、来源状态表、优先级口径、当前收盘导出、工作底稿、来源卡、附录、归档材料和待修订工作稿。

运行环境不提供实时行情、外部网页、私有终端、账号后台、浏览器依赖、插件或数据服务。请只读取资料柜文件，并在当前工作目录根路径写出一个 Markdown 文件：`daily_recap.md`。

资料柜中的所有市场段、主题名、ticker_scope、source_id、数值和文字片段均为脱敏样本材料。它们仅用于本次资料柜来源核对和草稿修订，不代表真实市场事实，也不构成投资建议。
