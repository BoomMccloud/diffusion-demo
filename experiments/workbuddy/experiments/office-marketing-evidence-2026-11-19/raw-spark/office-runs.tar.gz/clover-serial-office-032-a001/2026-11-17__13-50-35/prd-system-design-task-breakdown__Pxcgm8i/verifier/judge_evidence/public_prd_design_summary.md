# Public PRD and System Design Summary

This verifier-produced Judge evidence is derived only from the approved public Markdown inputs. It excludes hidden gold rows, private traces, construction notes, private paths, private URLs, credentials, account identifiers, customer data, proprietary code, and unpublished assets.

Exact source-anchor coverage, dependency validation, output schema compliance, deterministic safety/leakage checks, and Mermaid text constraints remain deterministic-only scope.

## PRD source: input/prd_community_ops_console.md

### 1. 背景
Community Ops Console 是一个示例开源社区运营平台。当前社区协作请求分散在讨论串、公开表单和维护者备注中，值班协调员需要人工判断请求类型、合并重复反馈、分派到维护者队列、提醒超时处理并追踪关闭状态。这个流程在小规模社区中可用，但在活动周和版本发布周会出现重复请求、分派不稳定、通知过多、状态关闭不清晰等问题。

本 feature 希望提供一个轻量的请求分流与协作闭环，不引入付费客服系统，也不要求接入真实邮件、短信、CRM 或企业项目管理后台。所有外部触达在本 PRD 中只作为事件占位或配置占位描述。

### 2. 目标与非目标
### 2.1 目标

- 让社区成员能提交结构化协作请求，并在需要时补充上下文。
- 让值班协调员能看到待审核、疑似重复、待分派、超时和待归档请求。
- 让维护者队列能接收分派并更新处理状态。
- 在不自动关闭请求的前提下，提示可能重复项，减少人工查找时间。
- 建立状态流、审计、通知节流和基础指标，支持后续迭代。

### 2.2 非目标摘要

- 本期不做移动端原生推送。
- 本期不做付费 SLA 面板、企业多租户权限或计费系统。
- 本期不要求真实外部通知发送，只需要站内通知和邮件占位事件的内部设计。
- 本期不把导出功能扩展为 BI 集成或 CSV pipeline。

### 2.1 目标
- 让社区成员能提交结构化协作请求，并在需要时补充上下文。
- 让值班协调员能看到待审核、疑似重复、待分派、超时和待归档请求。
- 让维护者队列能接收分派并更新处理状态。
- 在不自动关闭请求的前提下，提示可能重复项，减少人工查找时间。
- 建立状态流、审计、通知节流和基础指标，支持后续迭代。

### 2.2 非目标摘要
- 本期不做移动端原生推送。
- 本期不做付费 SLA 面板、企业多租户权限或计费系统。
- 本期不要求真实外部通知发送，只需要站内通知和邮件占位事件的内部设计。
- 本期不把导出功能扩展为 BI 集成或 CSV pipeline。

### 3. 角色
- Role ID=ROLE-01; 角色=社区成员; 主要诉求=提交请求、补充信息、确认解决或重新打开; 权限边界=不应看到维护者内部备注或其他成员联系方式
- Role ID=ROLE-02; 角色=值班协调员; 主要诉求=审核新请求、合并重复项、分派队列、处理升级; 权限边界=可看到审核所需的提交可见性字段，但不应导出私密联系方式
- Role ID=ROLE-03; 角色=项目维护者; 主要诉求=接收队列分派、更新处理状态、请求补充信息; 权限边界=不应直接看到匿名提交者的私密联系方式
- Role ID=ROLE-04; 角色=社区运营管理员; 主要诉求=配置组件到维护者队列映射、查看运营指标; 权限边界=不参与单个请求的内容处理

### 4. 用户流程
### FLOW-01：提交与初审

成员通过公开入口创建请求。系统校验主题、描述、组件提示和反馈方式，将请求置为 `pending_review` 或 `open_triage`。匿名提交允许进入待审核，但必须限制后续可见字段。

### FLOW-02：重复项提示与人工合并

系统根据主题、组件和描述片段生成 `triageFingerprint`，给协调员展示疑似重复项。协调员可以人工确认合并，但系统不能自动关闭疑似重复请求。合并后需要保留来源、备注、订阅关系和审计记录。

### FLOW-03：分派与升级

协调员根据组件到队列映射分派请求。分派成功后发布 `RequestAssigned`，触发站内通知/邮件占位事件和超时监控。48 小时无人首响时创建升级提醒；已分派请求 72 小时无维护者更新时进入待关注列表。

### FLOW-04：补充信息、解决与归档

维护者可以标记 `needs_info`，成员补充后回到已分派状态。成员确认解决后进入 `resolved_pending_archive`，保留 7 天可重新打开窗口；窗口结束后归档。

### 5. 功能需求
- ID=FR-01; 需求=成员可以通过 `POST /requests` 创建请求，必填主题、描述，选填组件标签和期望反馈方式。; Priority=P0; 说明 / 约束=匿名提交进入 `pending_review`；非匿名提交可直接进入 `open_triage`。
- ID=FR-02; 需求=创建请求后系统生成 `triageFingerprint`，用于提示潜在重复项。; Priority=P0; 说明 / 约束=只能提示，不得自动关闭或自动合并请求；与保守阈值策略相关。
- ID=FR-03; 需求=协调员可以将两个请求合并为一个主请求，并保留被合并请求的来源、备注和订阅关系。; Priority=P0; 说明 / 约束=必须有人工确认原因和审计记录。
- ID=FR-04; 需求=协调员可以把请求分派给一个维护者队列，分派后触发 `RequestAssigned` 事件。; Priority=P0; 说明 / 约束=维护者不可见匿名提交者的私密联系方式。
- ID=FR-05; 需求=维护者可以把请求标记为 `needs_info`，系统生成面向成员的补充信息提示。; Priority=P1; 说明 / 约束=超过 5 天后的归属仍未定，见 `OQ-01`。
- ID=FR-06; 需求=成员确认解决后，请求进入 `resolved_pending_archive`，保留 7 天可重新打开窗口。; Priority=P1; 说明 / 约束=归档任务必须尊重重开窗口。
- ID=FR-07; 需求=社区运营管理员可以配置组件到维护者队列的映射，配置变更不得影响已分派请求。; Priority=P1; 说明 / 约束=需要兼容旧字段 `legacy_label` 和新字段 `componentKey`。
- ID=FR-08; 需求=系统需要展示值班视图，包括新请求、待补充、疑似重复、已分派但超时、待归档。; Priority=P1; 说明 / 约束=不是实时大屏；允许后台刷新重复项提示。
- ID=FR-09; 需求=当请求 48 小时无人首响时，系统应创建升级提醒，而不是直接重新分派。; Priority=P1; 说明 / 约束=与通知节流、维护窗口和首响事件有关。
- ID=FR-10; 需求=成员可以撤回尚未分派的请求；已分派请求只能追加撤回意图并等待协调员处理。; Priority=P2; 说明 / 约束=撤回不能抹掉已有审计或维护者上下文。
- ID=FR-11; 需求=导出功能只需要导出当前筛选结果的 Markdown 摘要。; Priority=P2; 说明 / 约束=不做 CSV、BI、付费 SLA 或外部集成。

### 6. 非功能约束
- ID=NFR-01; 约束=协调员视图 P95 加载时间不超过 900ms。; 说明=允许重复项提示后台刷新，不要求每次打开页面同步完成。
- ID=NFR-02; 约束=通知必须节流，同一请求 24 小时内同类提醒不超过 2 次。; 说明=站内通知和邮件占位事件都受该约束影响。
- ID=NFR-03; 约束=合并、撤销合并、分派和状态变更需要可审计。; 说明=审计内容不得包含成员私密联系方式。
- ID=NFR-04; 约束=`legacy_label` 仍需读取 60 天；新写入只使用 `componentKey`。; 说明=历史数据兼容期结束后再移除读取逻辑。

### 7. 边界情况
- BC-01：匿名请求可以提交，但只有协调员可看到联系方式占位状态；维护者和导出摘要不得包含私密联系方式。
- BC-02：两个请求主题相似但组件不同，只能提示为疑似重复，不可自动合并。
- BC-03：维护窗口期间触发的超时提醒应延后，不计入误分派率或首响违规。
- BC-04：成员撤回已分派请求时，维护者仍需看到上下文和撤回意图，协调员决定是否关闭。
- BC-05：旧标签无法映射到新组件时，请求进入 `needs_manual_mapping`，不得自动分派。
- BC-06：被合并请求重新打开时，需要说明是恢复原请求、拆分订阅，还是在主请求追加新讨论；当前策略未完全确定。

### 8. 成功指标
- ID=M-01; Metric=新请求首响时间中位数; 目标口径=发布后一个月下降 30%。
- ID=M-02; Metric=重复请求人工识别率; 目标口径=协调员确认重复项的识别率达到 80%，误合并率低于 3%。
- ID=M-03; Metric=分派后 72 小时无更新占比; 目标口径=低于 8%，维护窗口内事件单独标记。
- ID=M-04; Metric=成员确认解决率; 目标口径=达到 60%，不把自动归档视为成员确认。

### 9. 运营规则与轻微不一致
- 值班协调员希望先上线可见队列，再逐步增强指纹策略；维护者希望通知节流与分派一起上线，否则活动周会产生提醒风暴。
- 产品草案中“首响”主要指协调员首次响应，运营备注中有时把维护者第一次更新也称为首响；开发任务需要区分这两个事件。
- 旧版表单仍会提交 `legacy_label`，但新的配置界面只接受 `componentKey`。
- 有些历史请求没有 `fingerprint`，不要求批量回填；但协调员打开历史请求时可以懒生成。

### 10. 风险
- ID=RISK-01; 风险=重复项提示过于激进会造成误合并。; 影响=需要保守阈值、人工确认和误合并撤销能力。
- ID=RISK-02; 风险=通知节流如果只按请求维度实现，可能忽略同一维护者的提醒风暴。; 影响=需要按请求和 recipient bucket 同时考虑预算。
- ID=RISK-03; 风险=旧标签迁移不完整会影响组件到队列映射。; 影响=无法映射时必须进入人工映射队列。
- ID=RISK-04; 风险=审计字段过多可能暴露匿名提交者隐私。; 影响=需要最小化审计字段并区分可见性。

### 11. 开放问题
- OQ-01：`needs_info` 超过 5 天后是提醒成员、退回协调员，还是自动转入低优先级待处理？
- OQ-02：匿名请求是否允许成员侧重新打开？如果允许，如何验证同一提交者？
- OQ-03：误合并撤销后，订阅关系和通知历史应如何拆分？
- OQ-04：48 小时无人首响的升级提醒由协调员处理，还是由维护者队列负责人处理？
- OQ-05：Markdown 导出摘要是否需要包含审计时间线，还是只包含当前状态和公开备注？
- OQ-06：如果成员撤回请求但维护者已经给出解决方案，是否仍进入 `resolved_pending_archive`？

### 12. 暂不做 / 干扰项
- ID=OS-01; 暂不做内容=移动端原生推送和设备 token 管理。; 原因=当前只设计站内通知和邮件占位事件。
- ID=OS-02; 暂不做内容=付费 SLA 客户面板、计费系统或合同状态展示。; 原因=本 feature 面向开源社区协作，不做商业 SLA。
- ID=OS-03; 暂不做内容=多租户企业权限、跨组织隔离和企业审计导出。; 原因=当前只支持单社区空间。
- ID=OS-04; 暂不做内容=CSV/BI 数据管道和外部数据仓库同步。; 原因=导出只要求当前筛选结果的 Markdown 摘要。

### 13. 给工程任务拆解的提示
任务拆解需要把 PRD 需求和系统设计联系起来，而不是只列功能点。请特别注意：请求创建、指纹提示、人工合并、分派事件、通知节流、超时监控、旧标签迁移、重开/归档窗口、隐私审计、错误处理、测试和指标之间存在顺序依赖。

## System design source: input/system_design_community_ops_console.md

### 1. 设计原则
- 使用小模块和事件边界，而不是把所有逻辑放进一个单体 handler。
- 所有外部触达仅建模为内部事件或占位任务；不得在本设计中依赖真实邮件、短信、CRM、工单系统或私有账号。
- 重复项识别只提供候选提示，不自动合并、不自动关闭。
- 合并、撤销合并、分派和状态变更必须可审计，但审计字段要遵守匿名和私密联系方式边界。
- 旧字段 `legacy_label` 与新字段 `componentKey` 有 60 天兼容窗口。

### 2. 模块划分
- Module=RequestIntake; 责任=接收创建请求命令、校验字段、初始化状态和可见性; 关键输入=`CreateRequestCommand`; 关键输出=`HelpRequest`, `RequestCreated`; 备注=匿名提交默认 `pending_review`
- Module=FingerprintService; 责任=基于标题、组件提示和描述片段生成重复候选; 关键输入=`HelpRequest`, `ComponentProfile`; 关键输出=`TriageFingerprint`, `DuplicateCandidate[]`; 备注=不负责自动合并
- Module=TriageQueue; 责任=维护协调员队列、筛选视图、待补充/超时/待归档 buckets; 关键输入=`HelpRequest`, `TriageFingerprint`, `EscalationSignal`; 关键输出=queue buckets; 备注=视图允许后台刷新
- Module=AssignmentRouter; 责任=根据 `componentKey` 和 `QueueMapping` 分派维护者队列; 关键输入=`HelpRequest`, `QueueMapping`; 关键输出=`AssignmentRecord`, `RequestAssigned`; 备注=需要处理 `needs_manual_mapping`
- Module=MergeAuditLog; 责任=记录合并、撤销合并、订阅迁移依据和审计字段; 关键输入=merge commands, undo commands; 关键输出=`MergeAuditEntry`, `RequestMerged`; 备注=先写审计再发事件
- Module=NotificationLimiter; 责任=对站内通知和邮件占位事件做节流; 关键输入=event stream, `NotificationBudget`; 关键输出=allowed/suppressed notification intent; 备注=不能回滚核心状态变更

### 3. API / Command 草案
- ID=API-01; API / Command=`POST /requests`; Caller=社区成员或公开表单; 说明=创建请求；匿名提交进入 `pending_review`。
- ID=API-02; API / Command=`PATCH /requests/{id}/triage`; Caller=值班协调员; 说明=更新组件、优先级、重复项判断和公开备注。
- ID=API-03; API / Command=`POST /requests/{id}/assign`; Caller=值班协调员; 说明=分派到维护者队列并写入 `assignmentId`。
- ID=API-04; API / Command=`POST /requests/{id}/merge`; Caller=值班协调员; 说明=把当前请求合并到主请求，必须提供人工确认原因。
- ID=API-05; API / Command=`POST /requests/{id}/merge-undo`; Caller=值班协调员; 说明=撤销最近一次合并，保留原审计链。
- ID=API-06; API / Command=`POST /requests/{id}/reopen`; Caller=成员或协调员; 说明=在允许窗口内重新打开请求；匿名请求策略待定。
- ID=API-07; API / Command=`GET /triage/queues`; Caller=协调员视图; 说明=返回新请求、待补充、疑似重复、超时、待归档 buckets。
- ID=API-08; API / Command=`POST /exports/triage-summary`; Caller=协调员或运营管理员; 说明=生成当前筛选结果 Markdown 摘要，不做 CSV 或 BI。

### 4. Event 草案
- ID=EVT-01; Event=`RequestCreated`; 生产者=RequestIntake; 消费者=FingerprintService, TriageQueue; 注意事项=创建后发布；不包含私密联系方式。
- ID=EVT-02; Event=`FingerprintGenerated`; 生产者=FingerprintService; 消费者=TriageQueue, Observability hooks; 注意事项=可异步到达，视图需显示刷新中状态。
- ID=EVT-03; Event=`RequestAssigned`; 生产者=AssignmentRouter; 消费者=NotificationLimiter, TimeoutMonitor; 注意事项=分派成功后发布。
- ID=EVT-04; Event=`RequestMerged`; 生产者=MergeAuditLog; 消费者=SubscriptionMover, TriageQueue; 注意事项=审计写入成功后发布。
- ID=EVT-05; Event=`RequestNeedsInfo`; 生产者=TriageQueue or maintainer action; 消费者=NotificationLimiter, TimeoutMonitor; 注意事项=5 天后策略未定。
- ID=EVT-06; Event=`RequestResolved`; 生产者=maintainer action or member confirmation; 消费者=ReopenPolicy, ArchiveWorker; 注意事项=成员确认解决与维护者标记解决需要区分。
- ID=EVT-07; Event=`EscalationReminderCreated`; 生产者=TimeoutMonitor; 消费者=NotificationLimiter, TriageQueue; 注意事项=48h 首响和 72h 已分派无更新是不同规则。
- ID=EVT-08; Event=`NotificationSuppressed`; 生产者=NotificationLimiter; 消费者=Observability hooks; 注意事项=用于节流计数，不代表请求失败。

### 5. 数据 / 状态对象
- Object=HelpRequest; 关键字段=`id`, `status`, `componentKey`, `legacyLabel`, `submitterVisibility`, `fingerprintId`, `primaryRequestId`, `assignmentId`, `reopenUntil`; 说明=主请求状态对象，兼容旧标签读取。
- Object=TriageFingerprint; 关键字段=`id`, `requestId`, `normalizedTitle`, `componentHint`, `similarityScore`, `candidateIds`, `createdAt`; 说明=仅用于候选提示；不决定自动合并。
- Object=QueueMapping; 关键字段=`componentKey`, `maintainerQueue`, `effectiveFrom`, `isActive`, `legacyLabelAliases`; 说明=配置变更不能影响已分派请求。
- Object=AssignmentRecord; 关键字段=`assignmentId`, `requestId`, `maintainerQueue`, `assignedAt`, `assignedByRole`, `firstMaintainerUpdateAt`; 说明=支持 72h 无更新监控。
- Object=MergeAuditEntry; 关键字段=`sourceRequestId`, `targetRequestId`, `reason`, `operatorRole`, `subscriptionMoved`, `privateFieldsExcluded`; 说明=不存成员私密联系方式。
- Object=NotificationBudget; 关键字段=`requestId`, `recipientBucket`, `kind`, `windowStart`, `sentCount`, `suppressedCount`; 说明=节流按请求和 recipient bucket 组合计算。
- Object=ReopenWindow; 关键字段=`requestId`, `resolvedAt`, `reopenUntil`, `reopenedByRole`, `archiveEligibleAt`; 说明=支持 7 天重开窗口和归档。

### 6. 状态流
```mermaid
stateDiagram-v2
  [*] --> pending_review
  pending_review --> open_triage: coordinator approves or non-anonymous request
  pending_review --> withdrawn: submitter withdraws before assignment
  open_triage --> assigned: coordinator assigns queue
  open_triage --> merged: coordinator confirms duplicate
  open_triage --> needs_manual_mapping: legacy label cannot map
  assigned --> needs_info: maintainer asks member
  needs_info --> assigned: member provides info
  assigned --> resolved_pending_archive: member confirms or maintainer marks resolved
  resolved_pending_archive --> open_triage: reopen within window
  resolved_pending_archive --> archived: archive worker after reopen window
```

状态备注：`merged` 请求本身不再作为独立队列项处理，但审计和订阅关系仍需可追踪。`withdrawn` 只适用于尚未分派请求；已分派请求的撤回应追加意图并等待协调员处理。

### 7. 依赖边候选
- ID=DEP-01; From=RequestIntake; To=FingerprintService; 理由=请求创建并有基础字段后才能生成指纹。
- ID=DEP-02; From=RequestIntake; To=TriageQueue; 理由=队列视图依赖初始状态和字段校验。
- ID=DEP-03; From=FingerprintService; To=TriageQueue; 理由=协调员需要看到疑似重复候选。
- ID=DEP-04; From=QueueMapping migration; To=AssignmentRouter; 理由=分派必须读取 `componentKey` 和旧标签兼容映射。
- ID=DEP-05; From=AssignmentRouter; To=RequestAssigned event; 理由=分派记录写入后才能发布分派事件。
- ID=DEP-06; From=RequestAssigned event; To=NotificationLimiter; 理由=分派通知需要先通过节流预算。
- ID=DEP-07; From=RequestAssigned event; To=TimeoutMonitor; 理由=分派后才计算 72 小时无维护者更新。
- ID=DEP-08; From=MergeAuditLog; To=RequestMerged event; 理由=审计写入成功后才能发布合并事件。
- ID=DEP-09; From=RequestMerged event; To=SubscriptionMover; 理由=订阅迁移依赖合并事件。
- ID=DEP-10; From=MergeUndoPolicy; To=MergeAuditLog; 理由=撤销合并需要追踪原合并关系和订阅迁移。
- ID=DEP-11; From=ComponentProfile seed; To=FingerprintService; 理由=组件词表有助于降低跨组件误合并。
- ID=DEP-12; From=NotificationLimiter; To=EscalationReminderCreated; 理由=升级提醒也要受节流限制。
- ID=DEP-13; From=ReopenPolicy; To=ArchiveWorker; 理由=7 天重开窗口结束后才能归档。
- ID=DEP-14; From=Observability hooks; To=TimeoutMonitor; 理由=首响、分派后无更新、节流抑制等指标依赖事件埋点。
- ID=DEP-15; From=ManualMappingQueue; To=AssignmentRouter; 理由=无法映射旧标签时不得自动分派。

### 8. 迁移 / 兼容
- MIG-01：`legacy_label` 读取保留 60 天；写路径只接受 `componentKey`。
- MIG-02：历史请求没有 `fingerprint` 时不批量回填，只在被协调员打开时懒生成。
- MIG-03：旧状态 `closed` 映射为 `archived`，但最近 7 天内关闭的请求需要补充 `reopenUntil`。
- MIG-04：旧配置中的队列别名需要导入 `QueueMapping.legacyLabelAliases`，冲突别名进入人工映射清单。

### 9. 可观测性
- ID=OBS-01; 观测点=`request_created`, `fingerprint_generated`, `request_assigned`, `request_merged` counters; 口径=按事件成功发布计数。
- ID=OBS-02; 观测点=coordinator view latency; 口径=P95 需要低于 900ms，重复项后台刷新不计入阻塞加载。
- ID=OBS-03; 观测点=first response latency; 口径=48h 首响规则使用协调员首次公开响应，不等同于维护者第一次更新。
- ID=OBS-04; 观测点=assigned stale ratio; 口径=分派后 72h 无维护者更新占比，维护窗口事件单独 tag。
- ID=OBS-05; 观测点=notification suppressed count; 口径=按 `requestId + recipientBucket + kind` 汇总。
- ID=OBS-06; 观测点=manual mapping queue size; 口径=旧标签无法映射时进入人工映射队列，不能静默丢弃。

### 10. 错误处理
- ERR-01：`POST /requests/{id}/merge` 如果目标请求已归档，应返回可恢复错误并提示先 reopen。
- ERR-02：通知占位事件失败不得回滚分派或合并，但要写入可重试 notification intent。
- ERR-03：`componentKey` 缺失且 `legacy_label` 无法映射时，`AssignmentRouter` 必须拒绝自动分派并写入 `needs_manual_mapping`。
- ERR-04：`POST /requests/{id}/reopen` 如果超过 `reopenUntil`，应返回明确错误，不能重新打开归档请求。
- ERR-05：合并撤销时如果订阅迁移状态不完整，必须保留人工修复任务，不能删除审计链。

### 11. 测试说明
- ID=TEST-01; 测试方向=request creation contract tests; 覆盖点=必填字段、匿名状态、`RequestCreated` 不含私密联系方式。
- ID=TEST-02; 测试方向=duplicate candidate tests; 覆盖点=跨组件相似标题只提示不合并，保守阈值可配置。
- ID=TEST-03; 测试方向=merge and undo audit tests; 覆盖点=合并前后审计、订阅迁移、撤销恢复、私密字段排除。
- ID=TEST-04; 测试方向=assignment routing tests; 覆盖点=`componentKey`、旧标签别名、无法映射进入 `needs_manual_mapping`。
- ID=TEST-05; 测试方向=notification throttling tests; 覆盖点=同请求同类提醒 24h 不超过 2 次，同时考虑 recipient bucket。
- ID=TEST-06; 测试方向=timeout monitor tests; 覆盖点=48h 首响提醒与 72h 已分派无更新监控分开验证。
- ID=TEST-07; 测试方向=reopen/archive tests; 覆盖点=7 天窗口、窗口内 reopen、窗口后 archive、旧 `closed` 迁移。
- ID=TEST-08; 测试方向=coordinator view tests; 覆盖点=buckets 准确、后台刷新状态、P95 加载口径。

### 12. 已知冲突 / 歧义
- ID=CONFLICT-01; Type=privacy/audit tension; 描述=PRD 要求匿名请求可提交且状态变更可审计，但审计不能暴露成员私密联系方式。; 设计处理建议=任务拆解应包含审计最小字段和可见性测试，不应扩大审计字段。
- ID=CONFLICT-02; Type=monitoring-rule mismatch; 描述=PRD 有 48h 无人首响升级，设计还有 72h 已分派无维护者更新；两者容易混淆。; 设计处理建议=应拆成两个监控规则或至少在任务中明确区分。
- ID=CONFLICT-03; Type=resolution semantics; 描述=PRD 把成员确认解决作为关键指标，设计允许维护者标记 resolved。; 设计处理建议=需要区分 `RequestResolved` 来源，指标不能把自动归档当成员确认。
- ID=AMBIG-01; Type=product policy; 描述=`needs_info` 超过 5 天后的处理归属未定。; 设计处理建议=任务应标记为开放问题或 gated policy task。
- ID=AMBIG-02; Type=anonymous reopen; 描述=匿名请求是否允许成员侧重新打开未定。; 设计处理建议=任务应避免直接实现身份校验假设。
- ID=AMBIG-03; Type=export audit scope; 描述=Markdown 导出是否包含审计时间线未定。; 设计处理建议=可先实现当前状态摘要，并把审计时间线列为待确认。

### 13. 设计杂项和干扰备注
- 早期讨论中提过 `MobilePushGateway`，但本期不设计设备 token 或 native push；如果任务表出现相关内容，应列为 non-goal。
- 有志愿者建议把付费 SLA 信息放入队列排序，但 PRD 明确不做付费 SLA 面板或计费系统。
- `RealtimeWallboard` 名称出现在一次白板讨论中，但当前只要求协调员视图，不要求实时大屏。
- Markdown 导出只覆盖当前筛选结果；不要把它扩展成 CSV/BI pipeline。
