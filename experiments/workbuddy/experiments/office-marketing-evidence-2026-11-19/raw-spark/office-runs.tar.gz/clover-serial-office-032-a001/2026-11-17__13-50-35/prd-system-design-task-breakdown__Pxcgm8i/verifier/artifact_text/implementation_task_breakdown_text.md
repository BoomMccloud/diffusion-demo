# Community Ops Console — 开发任务拆解

> 基于 `input/prd_community_ops_console.md`（PRD v0.8）与 `input/system_design_community_ops_console.md`（系统设计 v0.7）交叉整理。
> 所有锚点均回指源文档，任务按 MVP → 第二阶段 → 后续增强顺序排列。

---

## Source Coverage Summary

| 源文档 | 覆盖范围 | 关键锚点 |
|--------|---------|---------|
| **PRD** | 角色、用户流程、功能需求(P0-P2)、非功能约束(NFR-01~04)、边界情况(BC-01~06)、成功指标(M-01~04)、运营规则不一致项、风险(RISK-01~04)、开放问题(OQ-01~06)、暂不做清单(OS-01~04) | FR-01~11, NFR-01~04, BC-01~06, M-01~04, RISK-01~04, OQ-01~06, OS-01~04 |
| **系统设计** | 模块划分(RequestIntake…NotificationLimiter)、API/Command(API-01~08)、Event(EVT-01~08)、数据对象(HelpRequest…ReopenWindow)、状态流、依赖边(DEP-01~15)、迁移兼容(MIG-01~04)、可观测性(OBS-01~06)、错误处理(ERR-01~05)、测试方向(TEST-01~08)、冲突/歧义(CONFLICT-01~03, AMBIG-01~03) | DEP-01~15, MIG-01~04, OBS-01~06, ERR-01~05, TEST-01~08, CONFLICT-01~03, AMBIG-01~03 |

**交叉映射原则：**
- 每个 P0/P1 功能需求至少对应一个 API + Event + Module + Test anchor。
- NFR 约束直接驱动性能、节流、审计类任务的验收标准。
- 边界情况 (BC) 和错误处理 (ERR) 作为独立子任务或内嵌于主任务中验证。
- 开放问题 (OQ) 和歧义 (AMBIG) 标记为 gated / conditional，不拆入正式实施任务除非有决策。

---

## Implementation Task Table

### Phase 1 — MVP（核心分流闭环）

| Task ID | Title | Module/Area | Source Links | Depends On | Priority | Estimate | Acceptance Criteria | Risk/Open Question |
|---------|-------|-------------|--------------|------------|----------|----------|---------------------|-------------------|
| T-01 | Request Intake & Create | RequestIntake | FR-01, API-01, EVT-01, HelpRequest, DEP-01, DEP-02, TEST-01, ERR-01 | — | P0 | 3 days | `POST /requests` 接受必填主题+描述、选填组件标签+反馈方式；匿名提交进入 `pending_review`，非匿名直接进入 `open_triage`；发布 `RequestCreated` 事件且不含私密联系方式；字段校验失败返回明确错误 | 无 |
| T-02 | Fingerprint Generation Service | FingerprintService | FR-02, EVT-02, TriageFingerprint, DEP-01, DEP-03, DEP-11, TEST-02 | T-01 | P0 | 2 days | 基于标题、组件提示、描述片段生成 `triageFingerprint`；跨组件相似只提示不合并；保守阈值可配置；历史请求无 fingerprint 时懒生成（MIG-02）；不自动关闭任何请求 | 阈值策略需产品确认（RISK-01） |
| T-03 | Queue Mapping Config & Legacy Label Migration | AssignmentRouter / Data Layer | FR-07, QueueMapping, DEP-04, DEP-15, MIG-01, MIG-04, ERR-03, TEST-04 | T-01 | P0 | 2 days | 管理员可配置 `componentKey→maintainerQueue` 映射；旧版表单仍写 `legacy_label`，新写入用 `componentKey`；60 天兼容期内读取两者；无法映射的旧标签进入 `needs_manual_mapping` 队列不得自动分派；配置变更不影响已分派请求 | 别名冲突处理策略待确认（CONFLICT-01） |
| T-04 | Coordinator Triage View | TriageQueue | FR-08, API-07, DEP-02, DEP-03, OBS-02, TEST-08 | T-01, T-02 | P0 | 3 days | `GET /triage/queues` 返回新请求、待补充、疑似重复、超时、待归档 buckets；重复项提示允许后台刷新（NFR-01）；P95 ≤ 900ms；视图显示"刷新中"状态 | 后台刷新并发模型未指定 |
| T-05 | Merge Command & Audit Log | MergeAuditLog | FR-03, API-04, EVT-04, MergeAuditEntry, DEP-08, DEP-09, DEP-10, TEST-03, ERR-01, ERR-05 | T-04 | P0 | 2 days | `POST /requests/{id}/merge` 要求人工确认原因；先写审计再发 `RequestMerged`；订阅关系迁移保留来源；目标已归档时返回可恢复错误并提示 reopen；撤销合并保留原审计链 | 误合并撤销后订阅拆分策略未定（OQ-03） |
| T-06 | Assignment Router & Assign Command | AssignmentRouter | FR-04, API-03, EVT-03, AssignmentRecord, DEP-04, DEP-05, DEP-15, TEST-04 | T-03 | P0 | 2 days | `POST /requests/{id}/assign` 根据 `componentKey` 分派到维护者队列；写入 `assignmentId`；发布 `RequestAssigned`；`componentKey` 缺失且旧标签无法映射时拒绝分派并写入 `needs_manual_mapping` | 无 |
| T-07 | Notification Throttling Core | NotificationLimiter | NFR-02, EVT-03, EVT-07, NotificationBudget, DEP-06, DEP-12, TEST-05, OBS-05 | T-06 | P0 | 2 days | 站内通知和邮件占位事件受节流：同一请求 24h 同类提醒 ≤ 2 次；同时考虑 recipient bucket（RISK-02）；通知失败不滚核心状态变更但写入可重试 intent（ERR-02） | 通知渠道实现仅为占位事件，具体通道 TBD |
| T-08 | Timeout Monitor — First Response & Stale Update | TimeoutMonitor | FR-09, EVT-07, DEP-07, DEP-14, OBS-03, OBS-04, TEST-06 | T-06, T-07 | P0 | 2 days | 48h 无人首响创建升级提醒（不是重新分派）；72h 已分派无维护者更新进入待关注列表；两个规则分开验证（CONFLICT-02）；维护窗口期间超时延后不计违规（BC-03） | "首响"定义区分协调员 vs 维护者（PRD §9） |

### Phase 2 — 状态流转与成员交互

| Task ID | Title | Module/Area | Source Links | Depends On | Priority | Estimate | Acceptance Criteria | Risk/Open Question |
|---------|-------|-------------|--------------|------------|----------|----------|---------------------|-------------------|
| T-09 | Needs Info Flow | TriageQueue | FR-05, EVT-05, DEP-07, OBS-03, TEST-06 | T-06 | P1 | 1 day | 维护者可标记 `needs_info`；系统生成面向成员的补充信息提示；超过 5 天后归属未定（OQ-01），当前仅做标记和提示，不自动降级 | OQ-01 未决，条件实现 |
| T-10 | Reopen & Archive Window | ReopenPolicy / ArchiveWorker | FR-06, API-06, EVT-06, ReopenWindow, DEP-13, MIG-03, ERR-04, TEST-07 | T-08 | P1 | 2 days | 成员确认解决后进入 `resolved_pending_archive`；保留 7 天可重新打开窗口；窗口结束后归档；旧 `closed` 状态迁移为 `archived` 并补 `reopenUntil`；超期 reopen 返回明确错误 | 匿名请求是否允许重开未定（OQ-02） |
| T-11 | Withdraw Request | RequestIntake | FR-10, DEP-02, TEST-01 | T-01 | P1 | 1 day | 未分派请求可撤回；已分派请求只能追加撤回意图等待协调员处理；撤回不抹掉已有审计和维护者上下文（BC-04） | 无 |
| T-12 | Export Markdown Summary | Exporter | FR-11, API-08, OBS-01, TEST-08 | T-04 | P1 | 1 day | `POST /exports/triage-summary` 导出当前筛选结果 Markdown 摘要；不包含 CSV/BI/付费 SLA；审计时间线包含范围待定（OQ-05） | OQ-05 未决，默认不含审计时间线 |

### Phase 3 — 增强与治理

| Task ID | Title | Module/Area | Source Links | Depends On | Priority | Estimate | Acceptance Criteria | Risk/Open Question |
|---------|-------|-------------|--------------|------------|----------|----------|---------------------|-------------------|
| T-13 | Escalation Reminder Routing | TriageQueue / NotificationLimiter | FR-09, EVT-07, DEP-12, OBS-03, OBS-04 | T-08 | P2 | 1 day | 升级提醒路由至协调员或队列负责人（OQ-04）；受节流限制（DEP-12） | OQ-04 未决 |
| T-14 | Merge Undo Policy & Subscription Split | MergeAuditLog | FR-03, API-05, EVT-04, DEP-10, ERR-05, TEST-03 | T-05 | P2 | 1 day | 撤销最近一次合并；保留原审计链；订阅拆分策略未定（OQ-03） | OQ-03 未决 |
| T-15 | Component Profile Seed & Threshold Tuning | FingerprintService | DEP-11, TEST-02 | T-02 | P2 | 1 day | 初始化组件词表降低跨组件误合并；阈值参数化暴露给运营配置 | 无 |
| T-16 | Metrics Dashboard Hooks | Observability | M-01~04, OBS-01~06, DEP-14 | T-08, T-07 | P2 | 2 days | 接入首响时间中位数、重复识别率、72h 无更新占比、解决率的埋点采集；支持运营查看 | 指标口径对齐（CONFLICT-03） |

---

## Dependency and Sequencing Notes

### 硬依赖（必须串行）

```
T-01 ──► T-02 ──► T-04 ──► T-05
  │         │          │
  ├────────► T-03 ───► T-06 ──► T-07 ──► T-08
  │                                    │
  └────────► T-09 ──► T-10
```

- **T-01 → T-02/T-03/T-06**：没有请求创建就无法生成指纹、配置映射或执行分派。
- **T-02 → T-04**：协调员视图需要重复候选才能展示。
- **T-03 → T-06**：分派逻辑依赖队列映射可用。
- **T-06 → T-07/T-08**：通知节流和超时监控都消费 `RequestAssigned` 事件。
- **T-04 → T-05**：合并操作在协调员视图中触发。
- **T-08 → T-10**：归档/重开窗口依赖状态流转完成。

### 建议顺序（可并行但有先后偏好）

- **T-07 与 T-08 可并行**：通知节流和超时监控都是事件消费者，但 T-08 的 48h 首响规则需要 T-06 的分派记录作为起点。
- **T-09 可在 T-06 完成后立即开始**：`needs_info` 是独立的维护者动作，不阻塞其他路径。
- **T-12 导出可在 T-04 完成后开始**：导出依赖 triage view 的数据，但不依赖状态流转。

### 可并行组（Phase 1 内部）

- T-01（ intake）→ 可立即启动
- T-02（fingerprint）与 T-03（queue mapping）可并行，各自依赖 T-01
- T-05（merge audit）与 T-06（assign router）可并行，各自依赖 T-04/T-03

---

## Testing / Migration / Observability Coverage

### 测试覆盖矩阵

| 测试 ID | 对应任务 | 覆盖场景 |
|---------|---------|---------|
| TEST-01 | T-01, T-11 | 创建请求必填校验、匿名状态、`RequestCreated` 不含私密联系方式、撤回逻辑 |
| TEST-02 | T-02, T-15 | 跨组件相似标题只提示不合并、保守阈值可配置、组件词表种子 |
| TEST-03 | T-05, T-14 | 合并前后审计、订阅迁移、撤销恢复、私密字段排除 |
| TEST-04 | T-03, T-06 | `componentKey`、旧标签别名、无法映射进入 `needs_manual_mapping` |
| TEST-05 | T-07 | 同请求同类提醒 24h ≤ 2 次、recipient bucket 组合计算 |
| TEST-06 | T-08, T-09 | 48h 首响提醒与 72h 已分派无更新分开验证、`needs_info` 标记 |
| TEST-07 | T-10 | 7 天窗口、窗口内 reopen、窗口后 archive、旧 `closed` 迁移 |
| TEST-08 | T-04, T-12 | buckets 准确、后台刷新状态、P95 加载口径、Markdown 导出 |

### 迁移覆盖

| 迁移 ID | 对应任务 | 说明 |
|---------|---------|------|
| MIG-01 | T-03 | `legacy_label` 读取保留 60 天；写路径只接受 `componentKey` |
| MIG-02 | T-02 | 历史请求无 fingerprint 时懒生成，不批量回填 |
| MIG-03 | T-10 | 旧 `closed` 状态映射为 `archived`，补 `reopenUntil` |
| MIG-04 | T-03 | 旧配置队列别名导入 `QueueMapping.legacyLabelAliases`，冲突进入人工映射清单 |

### 可观测性覆盖

| 观测点 ID | 对应任务 | 说明 |
|-----------|---------|------|
| OBS-01 | T-01, T-05, T-06, T-16 | 事件计数器：request_created, fingerprint_generated, request_assigned, request_merged |
| OBS-02 | T-04 | coordinator view latency P95 ≤ 900ms |
| OBS-03 | T-08, T-09 | first response latency（区分协调员首次响应 vs 维护者第一次更新） |
| OBS-04 | T-08, T-13 | assigned stale ratio（72h 无更新占比，维护窗口 tag） |
| OBS-05 | T-07 | notification suppressed count（requestId + recipientBucket + kind） |
| OBS-06 | T-03, T-06 | manual mapping queue size（旧标签无法映射计数） |

---

## Risks, Open Questions, and Non-goals

### 风险

| Risk ID | 风险描述 | 缓解措施 | 对应任务 |
|---------|---------|---------|---------|
| RISK-01 | 重复项提示过于激进造成误合并 | 保守阈值、人工确认、误合并撤销能力 | T-02, T-05, T-14 |
| RISK-02 | 通知节流忽略同一维护者的提醒风暴 | 按 requestId + recipientBucket 双维度预算 | T-07, T-12 |
| RISK-03 | 旧标签迁移不完整影响组件→队列映射 | 无法映射时必须进入人工映射队列 | T-03, T-06 |
| RISK-04 | 审计字段过多暴露匿名提交者隐私 | 最小化审计字段、区分可见性 | T-05, T-14 |

### 开放问题（Gated / Conditional）

| OQ ID | 问题 | 对任务的影响 | 建议处理方式 |
|-------|------|-------------|-------------|
| OQ-01 | `needs_info` 超过 5 天后的处理归属 | T-09 不能自动降级 | 标记为 gated policy task，先做标记+提示，等决策后再加行为 |
| OQ-02 | 匿名请求是否允许成员侧重新打开 | T-10 的重开逻辑 | 避免直接实现身份校验假设；默认不允许，待确认 |
| OQ-03 | 误合并撤销后订阅关系如何拆分 | T-14 的 undo 逻辑 | 保留人工修复任务入口，不删除审计链 |
| OQ-04 | 48h 升级提醒由谁处理 | T-13 的路由 | 默认路由至协调员，待确认 |
| OQ-05 | Markdown 导出是否包含审计时间线 | T-12 的导出内容 | 默认不含，待确认 |
| OQ-06 | 成员撤回但维护者已给出方案时的状态 | 现有任务未覆盖此场景 | 列为 scope gap，不拆入正式任务 |

### 已知冲突 / 歧义

| Conflict/Ambiguity ID | 类型 | 描述 | 设计处理 |
|----------------------|------|------|---------|
| CONFLICT-01 | privacy/audit tension | 匿名请求可提交且状态变更可审计，但审计不能暴露私密联系方式 | 审计最小字段 + 可见性测试（TEST-03） |
| CONFLICT-02 | monitoring-rule mismatch | 48h 无人首响 vs 72h 已分派无更新容易混淆 | 拆成两个监控规则分别验证（TEST-06） |
| CONFLICT-03 | resolution semantics | 成员确认解决 vs 维护者标记 resolved | 区分 `RequestResolved` 来源，指标不将自动归档当成员确认 |
| AMBIG-01 | product policy | `needs_info` 5 天后的处理归属未定 | Gated task（T-09） |
| AMBIG-02 | anonymous reopen | 匿名请求是否允许重开未定 | 避免身份校验假设（T-10） |
| AMBIG-03 | export audit scope | Markdown 导出是否含审计时间线未定 | 默认不含（T-12） |

### Non-goals / Exclusions

以下 PRD 明确暂不做的内容，不拆入正式实施任务：

| ID | 暂不做内容 | 原因 |
|----|-----------|------|
| OS-01 | 移动端原生推送和设备 token 管理 | 本期只设计站内通知和邮件占位事件 |
| OS-02 | 付费 SLA 客户面板、计费系统或合同状态展示 | feature 面向开源社区协作，不做商业 SLA |
| OS-03 | 多租户企业权限、跨组织隔离和企业审计导出 | 当前只支持单社区空间 |
| OS-04 | CSV/BI 数据管道和外部数据仓库同步 | 导出只要求 Markdown 摘要 |
| OS-05 | RealtimeWallboard 实时大屏 | 只要求协调员视图，允许后台刷新 |
| OS-06 | MobilePushGateway 设备 token 管理 | 早期讨论提及，本期不设计 native push |

---

## Optional Mermaid — 开发阶段依赖图

```mermaid
gantt
    title Community Ops Console — 开发里程碑
    dateFormat YYYY-MM-DD
    section Phase 1 — MVP
    T-01 Request Intake            :milestone, m1, 2026-11-18, 3d
    T-02 Fingerprint Service       :crit, after m1, 2d
    T-03 Queue Mapping & Migration :crit, after m1, 2d
    T-04 Coordinator Triage View   :crit, after m1, m2, 3d
    T-05 Merge Audit               :after m2, 2d
    T-06 Assignment Router         :after m2, 2d
    T-07 Notification Throttling   :after m2, 2d
    T-08 Timeout Monitor           :after m2, 2d
    section Phase 2 — State Flow
    T-09 Needs Info Flow           :after m2, 1d
    T-10 Reopen & Archive Window   :after m2, 2d
    T-11 Withdraw Request          :after m1, 1d
    T-12 Export Markdown Summary   :after m2, 1d
    section Phase 3 — Enhancements
    T-13 Escalation Routing        :after m2, 1d
    T-14 Merge Undo Policy         :after m2, 1d
    T-15 Component Profile Seed    :after m2, 1d
    T-16 Metrics Dashboard Hooks   :after m2, 2d
```

```mermaid
flowchart TD
    subgraph Phase1["Phase 1 — MVP"]
        A[T-01 Request Intake] --> B[T-02 Fingerprint]
        A --> C[T-03 Queue Mapping]
        B --> D[T-04 Triage View]
        C --> E[T-06 Assign Router]
        D --> F[T-05 Merge Audit]
        E --> G[T-07 Notif Throttle]
        E --> H[T-08 Timeout Monitor]
    end

    subgraph Phase2["Phase 2 — State Flow"]
        H --> I[T-09 Needs Info]
        H --> J[T-10 Reopen & Archive]
        A --> K[T-11 Withdraw]
        D --> L[T-12 Export]
    end

    subgraph Phase3["Phase 3 — Enhancements"]
        H --> M[T-13 Escalation Routing]
        F --> N[T-14 Merge Undo]
        B --> O[T-15 Component Profile]
        H --> P[T-16 Metrics Dashboard]
    end

    style Phase1 fill:#e6f3ff
    style Phase2 fill:#fff3e6
    style Phase3 fill:#e6ffe6
```

---

*文档生成日期：2026-11-17*
*源文档版本：PRD v0.8 / System Design v0.7*
