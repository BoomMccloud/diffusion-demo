# Judge Scope and Deterministic Gate Status

This Markdown evidence file is produced by the deterministic verifier for optional text-only WB Judge consumption.

## Deterministic status
- passed_count: 111
- total_count: 153
- pass_rate: 0.7255
- preflight_passed_count: 9
- preflight_total_count: 9
- deterministic_gated_pass: false
- deterministic_safety_or_leakage_failed: false
- llm_judge_activation_allowed: true
- failed_checks: task_row_count_in_expected_band, task_acceptance_criteria_density, task_titles_not_anchor_list_only, source_links_rows_have_valid_anchors, source_anchor_mentions_limited_to_public_inputs, prd_anchor_distinct_count, nonfunctional_coverage, boundary_case_coverage, metric_coverage, hard_dependency_edge_01_ordered, hard_dependency_edge_02_ordered, hard_dependency_edge_03_ordered, hard_dependency_edge_04_ordered, hard_dependency_edge_05_ordered, hard_dependency_edge_06_ordered, hard_dependency_edge_07_ordered, hard_dependency_edge_08_ordered, hard_dependency_edge_09_ordered, hard_dependency_edge_10_ordered, hard_dependency_edge_11_ordered, hard_dependency_edge_12_ordered, member_confirmation_vs_maintainer_resolved, open_question_OQ_01_classified, open_question_OQ_02_classified, open_question_OQ_03_classified, open_question_OQ_04_classified, open_question_OQ_06_classified, conflict_ambiguity_CONFLICT_01_present, conflict_ambiguity_CONFLICT_03_present, conflict_ambiguity_AMBIG_01_present, conflict_ambiguity_AMBIG_03_present, non_goal_OS_01_excluded, non_goal_OS_03_excluded, non_goal_OS_04_excluded, semantic_fact_status_flow_terms, semantic_fact_notification_throttle_terms, semantic_fact_privacy_audit_terms, semantic_fact_manual_merge_terms, semantic_fact_legacy_mapping_terms, semantic_fact_export_scope_terms, mermaid_code_fence_plain_text_terms, local_public_only_boundary_stated
- preflight_failed_checks: none

LLM Judge may run only when required judge_evidence files exist, deterministic safety/leakage checks pass, and deterministic component score, preflight status, failed_checks, and objective failure attribution are preserved separately.

## Judge modality and forbidden behavior
- Text-only semantic/actionability review only.
- No VLM/image/OCR/pixel-level visual scoring.
- No browser/API/Skill/MCP/live-service behavior is required or allowed for Judge evidence.

## Deterministic-owned scope not scored by Judge
- artifact existence, filename, Markdown parseability, required sections/schema, and table formatting
- exact source-anchor validity, coverage counts, public ID matching, and dependency-edge validation
- objective safety/leakage checks, private/source leakage detection, secret detection, and forbidden artifact detection
- Mermaid syntax, text-only rendering constraints, and side-artifact boundaries

## Exclusion boundary
This file excludes hidden gold-only task rows, private trace text, private paths, private URLs, credentials, account identifiers, customer data, proprietary code, and unpublished assets.
