{
  "metadata": {
    "case_id": "ATTR-2026-08-30-DV-SERIES",
    "as_of_date": "2026-08-30",
    "target_product_family": "便携式无线吸尘器 DV 系列",
    "source_root": "input/",
    "output_path": "output/incident_attribution_report.json",
    "source_files_used": [
      "aug_2026_intake_workbook.xlsx",
      "returns_workbook.xlsx",
      "master_serial_index.csv",
      "product_bom_v3.csv",
      "operations_change_log.csv",
      "release_log.csv",
      "notice_2026_08_25.md"
    ],
    "excluded_evidence_categories": [
      "peer_q3_summary.csv (同业聚合汇总，无SN粒度，不构成独立证据)",
      "attribution_faq.md (FAQ说明，不蕴含归因规则)",
      "intake_format.txt (字段命名说明，不蕴含归因规则)",
      "OOS change records (非DV产品线变更记录)"
    ],
    "attribution_inputs_resolved": 21
  },
  "committed_attributions": [
    {
      "incident_id": "INC-E-02",
      "root_canonical_variant": "DV-A2-rev2",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-02",
        "returns_workbook.xlsx:rma_returns:RMA-002",
        "master_serial_index.csv:DV-A2-EARLY-0017",
        "operations_change_log.csv:CR-008"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-E-07",
      "root_canonical_variant": "DV-A1",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 2,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-07",
        "returns_workbook.xlsx:rma_returns:RMA-005",
        "master_serial_index.csv:SN-2026-W08-0034",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-E-11",
      "root_canonical_variant": "DV-A1",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 2,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-11",
        "returns_workbook.xlsx:rma_returns:RMA-008",
        "master_serial_index.csv:SN-2026-W14-0107",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-W-03",
      "root_canonical_variant": "DV-A2",
      "root_component": "MOTOR-G1",
      "root_supplier_lot": "DM1-2026-W24",
      "attribution_confidence": "high",
      "contributing_evidence_count": 2,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-03",
        "returns_workbook.xlsx:rma_returns:RMA-011",
        "master_serial_index.csv:SN-2026-W22-0033",
        "operations_change_log.csv:CR-007"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-W-06",
      "root_canonical_variant": "DV-A2-rev2",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-06",
        "returns_workbook.xlsx:rma_returns:RMA-014",
        "master_serial_index.csv:DV-A2-EARLY-0029",
        "operations_change_log.csv:CR-008"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-W-09",
      "root_canonical_variant": "DV-A1",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 2,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-09",
        "returns_workbook.xlsx:rma_returns:RMA-017",
        "master_serial_index.csv:SN-2026-W18-0123",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    }
  ],
  "review_queue": [
    {
      "incident_id": "INC-E-04",
      "reason_code": "evidence_insufficient_for_attribution",
      "missing_evidence_types": [
        "return_evidence",
        "supplier_change_record"
      ],
      "ambiguity_kind": "single_source_field_report_only",
      "recommended_next_action": "人工补录仲裁记录并获取独立退件拆机或供应商批次证据"
    },
    {
      "incident_id": "INC-E-06",
      "reason_code": "alias_conflict_unresolved",
      "missing_evidence_types": [
        "unique_canonical_variant",
        "arbitration_record"
      ],
      "ambiguity_kind": "no_valid_serial_mapping",
      "recommended_next_action": "人工补录仲裁记录并获取独立退件拆机或供应商批次证据"
    },
    {
      "incident_id": "INC-E-09",
      "reason_code": "alias_conflict_unresolved",
      "missing_evidence_types": [
        "arbitration_record",
        "unique_canonical_variant"
      ],
      "ambiguity_kind": "unresolved_serial_mapping",
      "recommended_next_action": "人工补录仲裁记录并获取独立退件拆机或供应商批次证据"
    }
  ],
  "serial_alias_resolutions": [
    {
      "observed_serial": "DV-A2-EARLY-0017",
      "canonical_variant": "DV-A2-rev2",
      "production_batch": "BATCH-2026-EARLY",
      "resolution_basis": "operations_change_log.csv:CR-008",
      "alternative_mappings_rejected": [
        "DV-A2"
      ],
      "_eff": "2026-07-15",
      "_cr_id": "CR-008"
    },
    {
      "observed_serial": "DV-A2-EARLY-0029",
      "canonical_variant": "DV-A2-rev2",
      "production_batch": "BATCH-2026-EARLY",
      "resolution_basis": "operations_change_log.csv:CR-008",
      "alternative_mappings_rejected": [
        "DV-A2"
      ],
      "_eff": "2026-07-15",
      "_cr_id": "CR-008"
    },
    {
      "observed_serial": "DV-B1-W30-0009",
      "canonical_variant": "DV-B1-rev2",
      "production_batch": "BATCH-2026-W30",
      "resolution_basis": "operations_change_log.csv:CR-011",
      "alternative_mappings_rejected": [
        "DV-B1"
      ],
      "_eff": "2026-08-12",
      "_cr_id": "CR-011"
    },
    {
      "observed_serial": "DV-B1-W30-0044",
      "canonical_variant": "DV-B1-rev2",
      "production_batch": "BATCH-2026-W30",
      "resolution_basis": "operations_change_log.csv:CR-011",
      "alternative_mappings_rejected": [
        "DV-B1"
      ],
      "_eff": "2026-08-12",
      "_cr_id": "CR-011"
    }
  ],
  "retroactive_invalidations": [
    {
      "recall_id": "RCL-2026-MCU-X3-W08",
      "source_doc": "notice_2026_08_25.md",
      "recall_announced_date": "2026-08-25",
      "recall_effective_date": "2026-07-15",
      "affected_lot": "RX3-2026-W08",
      "affected_supplier": "锐芯半导体",
      "affected_incidents": [
        "INC-E-01",
        "INC-E-03",
        "INC-E-05",
        "INC-E-08",
        "INC-E-10",
        "INC-W-01",
        "INC-W-02",
        "INC-W-04",
        "INC-W-05",
        "INC-W-07",
        "INC-W-08",
        "INC-W-10"
      ],
      "original_attribution": [
        {
          "incident_id": "INC-E-01",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-E-03",
          "root_component": "FW-MAIN-B1",
          "supplier_lot": "n/a"
        },
        {
          "incident_id": "INC-E-05",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-E-08",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-E-10",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-W-01",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-W-02",
          "root_component": "BAT-CELL-200",
          "supplier_lot": "J200-2026-W16"
        },
        {
          "incident_id": "INC-W-04",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-W-05",
          "root_component": "FW-MAIN-B1",
          "supplier_lot": "n/a"
        },
        {
          "incident_id": "INC-W-07",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-W-08",
          "root_component": "MCU-X3",
          "supplier_lot": "RX3-2026-W08"
        },
        {
          "incident_id": "INC-W-10",
          "root_component": "HINGE-L",
          "supplier_lot": "HL-2026-W29"
        }
      ],
      "new_attribution": [
        {
          "incident_id": "INC-E-01",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-E-03",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-E-05",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-E-08",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-E-10",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-01",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-02",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-04",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-05",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-07",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-08",
          "disposition": "reattributed_to_lot_supplier_recall"
        },
        {
          "incident_id": "INC-W-10",
          "disposition": "reattributed_to_lot_supplier_recall"
        }
      ]
    }
  ],
  "supplier_summary": [
    {
      "supplier": "江南电芯",
      "supplier_lot": "J100-2026-W02",
      "attributed_incident_count": 5,
      "invalidated_by_recall_count": 0,
      "in_review_incident_count": 0,
      "exposure_unit_count": 5
    },
    {
      "supplier": "锐芯半导体",
      "supplier_lot": "RX1-2026-W06",
      "attributed_incident_count": 0,
      "invalidated_by_recall_count": 0,
      "in_review_incident_count": 3,
      "exposure_unit_count": 3
    },
    {
      "supplier": "锐芯半导体",
      "supplier_lot": "RX3-2026-W08",
      "attributed_incident_count": 0,
      "invalidated_by_recall_count": 12,
      "in_review_incident_count": 0,
      "exposure_unit_count": 12
    },
    {
      "supplier": "鼎鸿电机",
      "supplier_lot": "DM1-2026-W24",
      "attributed_incident_count": 1,
      "invalidated_by_recall_count": 0,
      "in_review_incident_count": 0,
      "exposure_unit_count": 1
    }
  ],
  "evidence_provenance_index": {
    "INC-E-02": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-02",
      "returns_workbook.xlsx:rma_returns:RMA-002",
      "master_serial_index.csv:DV-A2-EARLY-0017",
      "operations_change_log.csv:CR-008"
    ],
    "INC-E-07": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-07",
      "returns_workbook.xlsx:rma_returns:RMA-005",
      "master_serial_index.csv:SN-2026-W08-0034",
      "operations_change_log.csv:CR-001"
    ],
    "INC-E-11": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-11",
      "returns_workbook.xlsx:rma_returns:RMA-008",
      "master_serial_index.csv:SN-2026-W14-0107",
      "operations_change_log.csv:CR-001"
    ],
    "INC-W-03": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-03",
      "returns_workbook.xlsx:rma_returns:RMA-011",
      "master_serial_index.csv:SN-2026-W22-0033",
      "operations_change_log.csv:CR-007"
    ],
    "INC-W-06": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-06",
      "returns_workbook.xlsx:rma_returns:RMA-014",
      "master_serial_index.csv:DV-A2-EARLY-0029",
      "operations_change_log.csv:CR-008"
    ],
    "INC-W-09": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-09",
      "returns_workbook.xlsx:rma_returns:RMA-017",
      "master_serial_index.csv:SN-2026-W18-0123",
      "operations_change_log.csv:CR-001"
    ],
    "INC-E-04": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-04",
      "master_serial_index.csv:SN-2026-W18-0042"
    ],
    "INC-E-06": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-06",
      "master_serial_index.csv:AMBIG-X-001"
    ],
    "INC-E-09": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-09",
      "master_serial_index.csv:AMBIG-X-002"
    ]
  },
  "summary": {
    "committed_count": 6,
    "review_count": 3,
    "retroactive_invalidations_count": 12,
    "affected_incidents_count": 12,
    "distinct_canonical_variants": 3,
    "distinct_supplier_lots": 2,
    "target_window_days": 60,
    "source_documents_used_count": 7
  }
}