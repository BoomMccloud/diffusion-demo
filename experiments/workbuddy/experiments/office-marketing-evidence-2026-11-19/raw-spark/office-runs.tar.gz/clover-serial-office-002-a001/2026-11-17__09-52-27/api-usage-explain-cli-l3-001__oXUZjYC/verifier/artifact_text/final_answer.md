# CitrineCtl 使用手册（中文）

> 本文档基于 `input/sample_workspace/citrinectl/` 仓库的源码、文档、schema、示例和输出样本交叉验证编写。所有路径引用均指向工作区内的实际文件。

---

## 1. 项目概览

`citrinectl` 是一个小型 CLI 工具，用于检查 YAML 格式的 Citrine job 文件并生成面向操作人员的扫描输出。它同时暴露一个 Python API（包名 `citrinekit`）。

- **Python 包名**：`citrinekit`（见 `pyproject.toml:8`）
- **CLI 入口脚本**：`citrinectl`（由 `[project.scripts]` 注册，`pyproject.toml:9`）
- **最低 Python 版本**：≥3.10（`pyproject.toml:5`）
- **唯一外部依赖**：PyYAML ≥6.0（`pyproject.toml:6`）

---

## 2. CLI 命令与选项

### 2.1 可执行入口

安装后直接调用：

```bash
citrinectl scan JOB_FILE [OPTIONS]
citrinectl explain JOB_FILE [OPTIONS]
```

入口函数为 `citrinekit.cli:main`（`src/citrinekit/cli.py:55`），通过 argparse subparsers 分发。

### 2.2 `scan` 命令

检查一个 job YAML 文件并发出扫描结果。

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `job_file`（位置参数） | 路径 | — | Citrine job YAML 文件路径 |
| `--profile NAME` | 字符串 | `None` | 选择命名 profile；加载顺序见 §3 |
| `--format table\|jsonl\|summary` | 枚举 | `None`（回退到配置） | 渲染模式；省略时由已解析的配置决定 |
| `--include-warnings` | flag | `False` | 在支持的格式中保留 warning 记录详情 |

典型调用：

```bash
# 最小用法——仅指定 job 文件
citrinectl scan tests/fixtures/minimal_job.yaml

# 指定 format
citrinectl scan tests/fixtures/minimal_job.yaml --format summary

# 使用 local-dev profile + 开启 warnings
citrinectl scan tests/fixtures/minimal_job.yaml --profile local-dev --include-warnings
```

参考示例脚本：`examples/cli/scan_minimal.sh`、`examples/cli/scan_with_profile.sh`。

### 2.3 `explain` 命令

打印 job 文件的配置与 schema 备注信息，适合人类阅读。

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `job_file`（位置参数） | 路径 | — | Citrine job YAML 文件路径 |
| `--profile NAME` | 字符串 | `None` | 同上 |

注意：**不支持** `--format` 参数（`src/citrinekit/cli.py:31-34`）。

典型调用：

```bash
citrinectl explain tests/fixtures/minimal_job.yaml --profile ci-quiet
```

### 2.4 输出格式对比

| 格式 | 用途 | Warning 行为 |
|------|------|-------------|
| `table` | 终端短表格，人工查看 | 可能只显示 warning 计数，不显示完整消息 |
| `summary` | 紧凑文本摘要（含计数和最终状态） | 折叠进最后一行；需显式包含详情 |
| `jsonl` | 逐行 JSON，供下游工具消费 | 仅在 `include_warnings=true` 时发出独立 warning 记录 |

参考：`docs/output-format.md`、`schemas/scan-result.schema.json`、`examples/output/scan_summary.jsonl`。

---

## 3. Config / Schema 关系

### 3.1 配置解析层级（先 → 后覆盖）

1. **打包默认值**：`config/defaults.yaml`
2. **命名 Profile 值**：`config/profiles.example.yaml`（或环境变量 `CITRINE_PROFILE_FILE` 指定的替代文件）
3. **CLI 标志**：仅对当前命令 parser 暴露的字段生效

合并规则为深合并（`_deep_merge`，`src/citrinekit/config.py:14-21`）——后续层只覆盖其实际提供的字段。

### 3.2 默认 Profile

未提供 `--profile` 且无 `CITRINE_DEFAULT_PROFILE` 环境变量时，使用 `default`（来自 `config/defaults.yaml:1`）。

### 3.3 可用 Profile

| Profile | retry_count | timeout_seconds | output.format | include_warnings |
|---------|------------|-----------------|---------------|------------------|
| `default` | 2 | 45 | summary | false |
| `local-dev` | 0 | 10 | jsonl | true |
| `ci-quiet` | 1 | 20 | summary | false |

来源：`config/profiles.example.yaml`。

### 3.4 Schema 约束

- **Profile 文档**（`schemas/profile.schema.json`）：顶层必须包含 `profiles` key；每个 profile 内仅允许 `scan`（含 `retry_count`、`timeout_seconds`）和 `output`（含 `format`、`include_warnings`）两个子对象，禁止额外属性。
- **ScanResult 记录**（`schemas/scan-result.schema.json`）：每条记录必须包含 `record_type`、`job_id`、`status`；`metric` 类型额外要求 `metrics` 对象；`summary`/`warning` 类型额外要求 `message` 字符串。`additionalProperties=false` 禁止未知字段。

### 3.5 环境变量

| 变量 | 作用 |
|------|------|
| `CITRINE_PROFILE_FILE` | 指向替代的 profile YAML 文件 |
| `CITRINE_DEFAULT_PROFILE` | 未提供 `--profile` 时的默认 profile 名称 |

注意：没有环境变量可以强制设置一次性输出格式；CLI 用 `--format`，Python API 用 `ScanResult` 适配器方法。

来源：`docs/config-resolution.md`、`src/citrinekit/config.py:29-37`。

---

## 4. Python API

### 4.1 主要入口

```python
from citrinekit.client import ScanClient, ScanResult
```

包级导出：`__all__ = ["ScanClient", "ScanResult"]`（`src/citrinekit/__init__.py:3`）。

### 4.2 ScanClient

| 方法 | 签名 | 返回值 | 说明 |
|------|------|--------|------|
| `from_profile(profile_name)` | classmethod | `ScanClient` | 从已解析的配置构建客户端 |
| `scan_job(job_path, include_warnings=False)` | instance method | `ScanResult` | 执行扫描 |

构造方式二（手动传入 settings dict）：

```python
from citrinekit.client import ScanClient
client = ScanClient(settings={"scan": {"retry_count": 0}, "output": {"format": "jsonl"}})
result = client.scan_job("tests/fixtures/minimal_job.yaml")
```

### 4.3 ScanResult

| 方法 | 返回 | 说明 |
|------|------|------|
| `to_records()` | `list[dict[str, Any]]` | JSONL 兼容字典列表 |
| `to_summary()` | `str` | 紧凑 Markdown 友好摘要 |

### 4.4 典型调用

```python
from citrinekit.client import ScanClient

client = ScanClient.from_profile("local-dev")
result = client.scan_job("tests/fixtures/minimal_job.yaml", include_warnings=True)
for record in result.to_records():
    print(record)

print(result.to_summary())
```

参考：`docs/api-client.md`、`examples/python/use_client.py`。

### 4.5 与 CLI 的差异

- API **不暴露** `--format` 作为 `scan_job()` 的参数。渲染选择在获取 `ScanResult` 之后进行——调用方自行选择 `to_records()`（JSONL）或 `to_summary()`（文本摘要）。
- API 不暴露 `--include-warnings` 以外的 CLI 标志；`include_warnings` 是唯一的布尔开关。
- CLI 的 `render_result()` 函数（`src/citrinekit/render.py:8`）处理三种格式；API 使用者通常不需要此函数。

---

## 5. 输出格式确认

### 5.1 JSONL 记录结构

每条 JSONL 行对应一条记录，字段如下（受 `schemas/scan-result.schema.json` 约束）：

| 字段 | 必需 | 类型 | 可选值 |
|------|------|------|--------|
| `record_type` | ✅ | string | `summary`、`metric`、`warning` |
| `job_id` | ✅ | string (minLength 1) | — |
| `status` | ✅ | string | `ok`、`warning`、`blocked` |
| `message` | 条件 | string | `summary`/`warning` 类型必需 |
| `metrics` | 条件 | object (values: number) | `metric` 类型必需 |

### 5.2 示例输出

`examples/output/scan_summary.jsonl`：

```json
{"record_type":"summary","job_id":"minimal_job","status":"ok","message":"2 checks completed"}
{"record_type":"metric","job_id":"minimal_job","status":"ok","metrics":{"duration_seconds":3.7,"checked_items":2}}
{"record_type":"warning","job_id":"minimal_job","status":"warning","message":"optional field owner was not set"}
```

### 5.3 Summary 输出

`to_summary()` 返回格式：`job={id}; warnings={count}; records={len}`。当 `include_warnings` 且存在警告时，CLI 追加 `; warning_details=included`。

### 5.4 Table 输出

固定模板：`JOB ID        STATUS    RECORDS\n{job_id:<13} ok        {len(records)}`。

---

## 6. Caveats & 不支持的功能

以下事项**不能**当作当前支持功能来使用：

### 6.1 已废弃的 CLI 语法

- `--json` 标志：旧版草稿中使用，当前 parser 不再注册。应改用 `--format jsonl`。
  - 证据：`examples/legacy/old_json_flag.txt`、`docs/migration-v1.md`。
- `citrinectl run` 命令：旧版提及，当前仅支持 `scan` 和 `explain`。
  - 证据：`docs/migration-v1.md`。

### 6.2 实验性 / 未接入代码

`src/citrinekit/experimental.py` 中的两个函数均为占位符：

- `stream_scan_events(job_path)`：设计讨论草稿，未接入 CLI 或公共 API，调用即抛 `NotImplementedError`。
- `sync_remote_profile(profile_name)`：roadmap 占位，无服务端点，调用即抛 `NotImplementedError`。

这些函数不应出现在任何用户-facing 文档中，也不应被当作可用功能。

### 6.3 Roadmap 规划项（非当前支持）

`notes/roadmap_draft.txt` 列出的未来方向：

- 远程 profile 同步
- CSV 导出（dashboard 用）
- 流式扫描事件

这些均未在当前 CLI parser 或 API 中注册。**不要**将其写入"已支持功能"章节。

### 6.4 未实现的渲染目标

`docs/output-format.md:20-22` 明确声明：当前 renderer **不**支持 XML、CSV 或远程 webhook 事件推送。

### 6.5 行为不明确之处

- `ScanClient.scan_job()` 内部硬编码了模拟数据（`src/citrinekit/client.py:32-56`），并非真正读取 job YAML 内容。这意味着 API 调用的结果取决于 `include_warnings` 布尔值，而非 job 文件的实际内容。这是 sample 项目的已知限制，生产环境不应假设真实扫描逻辑。
- `explain` 命令的输出仅为单行拼接字符串（`src/citrinekit/cli.py:47-52`），不包含实际的 schema 校验结果或详细的配置注释。
- `broken_optional_fields.yaml` 测试 fixture 标注为"Negative fixture for warning behavior; not a recommended production template"（`tests/fixtures/broken_optional_fields.yaml:7`），不应作为正常 job 模板使用。

### 6.6 配置路径

- `DEFAULTS_PATH` 和 `PROFILES_PATH` 通过 `Path(__file__).resolve().parents[2]` 计算得出（`src/citrinekit/config.py:10-11`），即相对于 `src/citrinekit/` 向上两级到达项目根目录再进入 `config/`。如果以不同方式安装（如 pip install），路径可能偏移。

---

## 7. 关键文件索引

| 类别 | 文件路径 |
|------|----------|
| README | `README.md` |
| Quickstart | `docs/quickstart.md` |
| API Client | `docs/api-client.md` |
| Config Resolution | `docs/config-resolution.md` |
| Output Format | `docs/output-format.md` |
| Migration v1 | `docs/migration-v1.md` |
| Glossary | `docs/glossary.md` |
| CLI Parser | `src/citrinekit/cli.py` |
| Client API | `src/citrinekit/client.py` |
| Config Loader | `src/citrinekit/config.py` |
| Renderer | `src/citrinekit/render.py` |
| Experimental | `src/citrinekit/experimental.py` |
| Package Init | `src/citrinekit/__init__.py` |
| Defaults | `config/defaults.yaml` |
| Profiles Example | `config/profiles.example.yaml` |
| Profile Schema | `schemas/profile.schema.json` |
| Result Schema | `schemas/scan-result.schema.json` |
| PyProject | `pyproject.toml` |
| Scan Minimal Script | `examples/cli/scan_minimal.sh` |
| Scan With Profile Script | `examples/cli/scan_with_profile.sh` |
| JSONL Sample Output | `examples/output/scan_summary.jsonl` |
| Python Example | `examples/python/use_client.py` |
| Legacy Flag Note | `examples/legacy/old_json_flag.txt` |
| Job Fixture | `tests/fixtures/minimal_job.yaml` |
| Broken Fixture | `tests/fixtures/broken_optional_fields.yaml` |
| Roadmap Notes | `notes/roadmap_draft.txt` |

---

*本手册仅反映 `input/sample_workspace/citrinectl/` 仓库在读取时刻的状态。若源码或文档有更新，请以实际文件为准。*
