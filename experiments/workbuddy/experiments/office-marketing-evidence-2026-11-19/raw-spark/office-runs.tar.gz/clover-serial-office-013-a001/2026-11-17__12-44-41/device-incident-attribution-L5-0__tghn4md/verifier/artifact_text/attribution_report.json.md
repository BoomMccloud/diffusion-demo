{
  "metadata": {
    "case_id": "CASE-DV-ATTRIBUTION-2026",
    "as_of_date": "2026-08-30",
    "target_product_family": "便携式无线吸尘器 DV 系列",
    "source_root": "input/",
    "output_path": "output/incident_attribution_report.json",
    "source_files_used": [
      "aug_2026_intake_workbook.xlsx",
      "returns_workbook.xlsx",
      "operations_change_log.csv",
      "release_log.csv",
      "master_serial_index.csv",
      "product_bom_v3.csv",
      "notice_2026_08_25.md"
    ],
    "excluded_evidence_categories": [
      "peer_q3_summary.csv",
      "attribution_faq.md",
      "intake_format.txt"
    ],
    "attribution_inputs_resolved": true
  },
  "committed_attributions": [
    {
      "incident_id": "INC-E-02",
      "root_canonical_variant": "DV-A2-rev2",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-02",
        "returns_workbook.xlsx:rma_returns:RMA-002",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-E-07",
      "root_canonical_variant": "DV-A1",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-07",
        "returns_workbook.xlsx:rma_returns:RMA-005",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-E-11",
      "root_canonical_variant": "DV-A1",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-11",
        "returns_workbook.xlsx:rma_returns:RMA-008",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-W-03",
      "root_canonical_variant": "DV-A2",
      "root_component": "MOTOR-G1",
      "root_supplier_lot": "DM1-2026-W24",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-03",
        "returns_workbook.xlsx:rma_returns:RMA-011",
        "operations_change_log.csv:CR-007"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-W-06",
      "root_canonical_variant": "DV-A2-rev2",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "J100-2026-W02",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-06",
        "returns_workbook.xlsx:rma_returns:RMA-014",
        "operations_change_log.csv:CR-001"
      ],
      "retroactive_invalidations_applied": false
    },
    {
      "incident_id": "INC-W-09",
      "root_canonical_variant": "DV-A1",
      "root_component": "BAT-CELL-100",
      "root_supplier_lot": "Y100-2026-W31",
      "attribution_confidence": "high",
      "contributing_evidence_count": 3,
      "evidence_keys": [
        "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-09",
        "returns_workbook.xlsx:rma_returns:RMA-017",
        "operations_change_log.csv:CR-X3"
      ],
      "retroactive_invalidations_applied": false
    }
  ],
  "review_queue": [
    {
      "incident_id": "INC-E-04",
      "reason_code": "evidence_insufficient_for_attribution",
      "missing_evidence_types": [
        "return_evidence",
        "supplier_change_record",
        "unique_canonical_variant"
      ],
      "ambiguity_kind": "insufficient_evidence_sources",
      "recommended_next_action": "补充退件拆机证据或运营变更日志以完成归因"
    },
    {
      "incident_id": "INC-E-06",
      "reason_code": "alias_conflict_unresolved",
      "missing_evidence_types": [
        "unique_canonical_variant",
        "return_evidence"
      ],
      "ambiguity_kind": "dual_registration_no_arbitration",
      "recommended_next_action": "通过运营变更日志或人工复核确定唯一 canonical_variant"
    },
    {
      "incident_id": "INC-E-09",
      "reason_code": "alias_conflict_unresolved",
      "missing_evidence_types": [
        "unique_canonical_variant",
        "return_evidence"
      ],
      "ambiguity_kind": "serial_contamination_revoked_mapping",
      "recommended_next_action": "人工补录新的仲裁记录以确认 observed_serial 的 canonical_variant"
    }
  ],
  "serial_alias_resolutions": [
    {
      "observed_serial": "DV-A2-EARLY-0017",
      "canonical_variant": "DV-A2-rev2",
      "production_batch": "BATCH-2026-EARLY",
      "resolution_basis": "operations_change_log.csv:CR-008",
      "alternative_mappings_rejected": [
        "DV-A2"
      ]
    },
    {
      "observed_serial": "DV-B1-W30-0009",
      "canonical_variant": "DV-B1-rev2",
      "production_batch": "BATCH-2026-W30",
      "resolution_basis": "operations_change_log.csv:CR-011",
      "alternative_mappings_rejected": [
        "DV-B1"
      ]
    },
    {
      "observed_serial": "DV-B1-W30-0044",
      "canonical_variant": "DV-B1-rev2",
      "production_batch": "BATCH-2026-W30",
      "resolution_basis": "operations_change_log.csv:CR-011",
      "alternative_mappings_rejected": [
        "DV-B1"
      ]
    },
    {
      "observed_serial": "DV-A2-EARLY-0029",
      "canonical_variant": "DV-A2-rev2",
      "production_batch": "BATCH-2026-EARLY",
      "resolution_basis": "operations_change_log.csv:CR-008",
      "alternative_mappings_rejected": [
        "DV-A2"
      ]
    }
  ],
  "retroactive_invalidations": [
    {
      "recall_id": "RCL-2026-MCU-X3-W08",
      "source_doc": "notice_2026_08_25.md",
      "recall_announced_date": "2026-08-25",
      "recall_effective_date": "2026-07-15",
      "affected_lot": "RX3-2026-W08",
      "affected_supplier": "锐芯半导体",
      "affected_incidents": [
        {
          "incident_id": "INC-E-01",
          "original_attribution": {
            "incident_id": "INC-E-01",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-E-01",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-E-03",
          "original_attribution": {
            "incident_id": "INC-E-03",
            "root_component": "FW-MAIN-B1",
            "supplier_lot": "n/a"
          },
          "new_attribution": {
            "incident_id": "INC-E-03",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-E-05",
          "original_attribution": {
            "incident_id": "INC-E-05",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-E-05",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-E-08",
          "original_attribution": {
            "incident_id": "INC-E-08",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-E-08",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-E-10",
          "original_attribution": {
            "incident_id": "INC-E-10",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-E-10",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-01",
          "original_attribution": {
            "incident_id": "INC-W-01",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-W-01",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-02",
          "original_attribution": {
            "incident_id": "INC-W-02",
            "root_component": "BAT-CELL-200",
            "supplier_lot": "J200-2026-W16"
          },
          "new_attribution": {
            "incident_id": "INC-W-02",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-04",
          "original_attribution": {
            "incident_id": "INC-W-04",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-W-04",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-05",
          "original_attribution": {
            "incident_id": "INC-W-05",
            "root_component": "FW-MAIN-B1",
            "supplier_lot": "n/a"
          },
          "new_attribution": {
            "incident_id": "INC-W-05",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-07",
          "original_attribution": {
            "incident_id": "INC-W-07",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-W-07",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-08",
          "original_attribution": {
            "incident_id": "INC-W-08",
            "root_component": "MCU-X3",
            "supplier_lot": "RX3-2026-W08"
          },
          "new_attribution": {
            "incident_id": "INC-W-08",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        },
        {
          "incident_id": "INC-W-10",
          "original_attribution": {
            "incident_id": "INC-W-10",
            "root_component": "HINGE-L",
            "supplier_lot": "HL-X-2026-W32"
          },
          "new_attribution": {
            "incident_id": "INC-W-10",
            "disposition": "reattributed_to_lot_supplier_recall"
          }
        }
      ]
    }
  ],
  "supplier_summary": [
    {
      "supplier": "另岸电源",
      "supplier_lot": "Y100-2026-W31",
      "attributed_incident_count": 1,
      "invalidated_by_recall_count": 0,
      "in_review_incident_count": 3,
      "exposure_unit_count": 4
    },
    {
      "supplier": "江南电芯",
      "supplier_lot": "J100-2026-W02",
      "attributed_incident_count": 4,
      "invalidated_by_recall_count": 0,
      "in_review_incident_count": 0,
      "exposure_unit_count": 4
    },
    {
      "supplier": "江南电芯",
      "supplier_lot": "J200-2026-W16",
      "attributed_incident_count": 0,
      "invalidated_by_recall_count": 1,
      "in_review_incident_count": 0,
      "exposure_unit_count": 1
    },
    {
      "supplier": "翔达机械",
      "supplier_lot": "HL-X-2026-W32",
      "attributed_incident_count": 0,
      "invalidated_by_recall_count": 1,
      "in_review_incident_count": 0,
      "exposure_unit_count": 1
    },
    {
      "supplier": "锐芯半导体",
      "supplier_lot": "RX3-2026-W08",
      "attributed_incident_count": 0,
      "invalidated_by_recall_count": 8,
      "in_review_incident_count": 0,
      "exposure_unit_count": 8
    },
    {
      "supplier": "鼎鸿电机",
      "supplier_lot": "DM1-2026-W24",
      "attributed_incident_count": 1,
      "invalidated_by_recall_count": 0,
      "in_review_incident_count": 0,
      "exposure_unit_count": 1
    }
  ],
  "evidence_provenance_index": {
    "INC-E-01": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-01",
      "returns_workbook.xlsx:rma_returns:RMA-001",
      "operations_change_log.csv:CR-003"
    ],
    "INC-E-02": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-02",
      "returns_workbook.xlsx:rma_returns:RMA-002",
      "operations_change_log.csv:CR-001"
    ],
    "INC-E-03": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-03",
      "returns_workbook.xlsx:rma_returns:RMA-003"
    ],
    "INC-E-04": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-04"
    ],
    "INC-E-05": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-05",
      "returns_workbook.xlsx:rma_returns:RMA-004",
      "operations_change_log.csv:CR-003",
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-06"
    ],
    "INC-E-06": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-05",
      "returns_workbook.xlsx:rma_returns:RMA-004",
      "operations_change_log.csv:CR-003",
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-06"
    ],
    "INC-E-07": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-07",
      "returns_workbook.xlsx:rma_returns:RMA-005",
      "operations_change_log.csv:CR-001"
    ],
    "INC-E-08": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-08",
      "returns_workbook.xlsx:rma_returns:RMA-006",
      "operations_change_log.csv:CR-003",
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-09"
    ],
    "INC-E-09": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-08",
      "returns_workbook.xlsx:rma_returns:RMA-006",
      "operations_change_log.csv:CR-003",
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-09"
    ],
    "INC-E-10": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-10",
      "returns_workbook.xlsx:rma_returns:RMA-007",
      "operations_change_log.csv:CR-003"
    ],
    "INC-E-11": [
      "aug_2026_intake_workbook.xlsx:incidents_east:INC-E-11",
      "returns_workbook.xlsx:rma_returns:RMA-008",
      "operations_change_log.csv:CR-001"
    ],
    "INC-W-01": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-01",
      "returns_workbook.xlsx:rma_returns:RMA-009",
      "operations_change_log.csv:CR-003"
    ],
    "INC-W-02": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-02",
      "returns_workbook.xlsx:rma_returns:RMA-010",
      "operations_change_log.csv:CR-X3"
    ],
    "INC-W-03": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-03",
      "returns_workbook.xlsx:rma_returns:RMA-011",
      "operations_change_log.csv:CR-007"
    ],
    "INC-W-04": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-04",
      "returns_workbook.xlsx:rma_returns:RMA-012",
      "operations_change_log.csv:CR-003"
    ],
    "INC-W-05": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-05",
      "returns_workbook.xlsx:rma_returns:RMA-013"
    ],
    "INC-W-06": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-06",
      "returns_workbook.xlsx:rma_returns:RMA-014",
      "operations_change_log.csv:CR-001"
    ],
    "INC-W-07": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-07",
      "returns_workbook.xlsx:rma_returns:RMA-015",
      "operations_change_log.csv:CR-003"
    ],
    "INC-W-08": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-08",
      "returns_workbook.xlsx:rma_returns:RMA-016",
      "operations_change_log.csv:CR-003"
    ],
    "INC-W-09": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-09",
      "returns_workbook.xlsx:rma_returns:RMA-017",
      "operations_change_log.csv:CR-X3"
    ],
    "INC-W-10": [
      "aug_2026_intake_workbook.xlsx:incidents_west:INC-W-10",
      "returns_workbook.xlsx:rma_returns:RMA-018",
      "operations_change_log.csv:CR-X4"
    ]
  },
  "summary": {
    "committed_count": 6,
    "review_count": 3,
    "retroactive_invalidations_count": 1,
    "affected_incidents_count": 12,
    "distinct_canonical_variants": 3,
    "distinct_supplier_lots": 3,
    "target_window_days": 60,
    "source_documents_used_count": 7
  }
}