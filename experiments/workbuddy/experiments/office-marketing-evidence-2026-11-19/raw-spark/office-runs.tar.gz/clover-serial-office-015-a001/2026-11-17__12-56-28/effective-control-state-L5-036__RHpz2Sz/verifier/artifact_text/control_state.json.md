{
  "metadata": {
    "case_id": "PROC-CC-036",
    "as_of_date": "2026-08-20",
    "target_site": "华南冷链库",
    "target_role": "夜班QA复核员",
    "source_root": "/workspace/input",
    "output_path": "output/effective_control_state.json",
    "authority_order": [
      "regulatory_notice",
      "incident_triggered_control",
      "signed_site_appendix",
      "training_gate",
      "base_sop",
      "faq"
    ],
    "excluded_statuses": [
      "archived",
      "unsigned_draft",
      "future_training",
      "superseded_notice",
      "training_pending_target_role"
    ],
    "source_docs_used": [
      "controlled/base_PROC-CC-036_rev3.md",
      "site/signed_site_appendix_SC-2026-07.md",
      "notices/regulatory_notice_RC-2026-17.md",
      "notices/regulatory_notice_RC-2026-22.md",
      "notices/regulatory_notice_RC-2026-22A.md",
      "notices/regulatory_notice_RC-2026-23.md",
      "training/training_release_matrix.csv",
      "incidents/incident_digest_august.csv",
      "register/document_register.csv",
      "appendix/appendix_A_role_matrix.csv",
      "appendix/appendix_B_hold_codes.csv",
      "appendix/appendix_C_record_retention.csv",
      "archive/base_PROC-CC-036_rev2_archived.md",
      "archive/base_PROC-CC-036_rev1_archived.md",
      "draft/unsigned_site_appendix_SC-2026-08.md",
      "faq/FAQ_PROC-CC-036.md"
    ]
  },
  "control_states": [
    {
      "control_id": "C1",
      "title": "到货温控接收",
      "effective_steps": [
        {
          "step_id": "BASE-C1.1",
          "text": "接收前核对预约号、采购批号、运输温区和设备编号。",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md",
          "authority_level": "base_sop",
          "applies_to": ["夜班QA复核员", "仓储收货员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "SITE-C1.2",
          "text": "华南冷链库夜班到货必须由仓储收货员和夜班QA复核员双签接收，替代BASE-C1.2。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix",
          "applies_to": ["夜班QA复核员", "仓储收货员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C1-SITE",
          "text": "双签要求只在华南冷链库夜班接收场景生效。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-A",
          "binding_controls": ["C1"],
          "required_rows": ["ROLE-WH-RECV", "ROLE-NIGHT-QA"]
        },
        {
          "appendix_id": "APP-B",
          "binding_controls": ["C1"],
          "required_rows": ["DOC-INCOMPLETE", "DOC-COMPLETE", "RECV-PENDING", "RECV-COMPLETED"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "BASE-C1.2",
          "reason": "被SIGN-A appended by SITE-C1.2取代",
          "replaced_by": "SITE-C1.2",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md",
          "status": "superseded"
        }
      ],
      "source_doc": "controlled/base_PROC-CC-036_rev3.md + site/signed_site_appendix_SC-2026-07.md",
      "authority_level": "signed_site_appendix > base_sop",
      "site_scope": "华南冷链库（主仓+中转区+待复核区+隔离区）",
      "role_scope": "夜班QA复核员、仓储收货员"
    },
    {
      "control_id": "C2",
      "title": "温控断点与隔离判定",
      "effective_steps": [
        {
          "step_id": "NOTICE22-C2.1",
          "text": "任一温度记录断点超过12分钟或探头低于2°C/高于8°C时，批次立即转入QA隔离。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": ["夜班QA复核员", "仓储收货员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "NOTICE22A-C2.4",
          "text": "自2026-08-01起，同一站点同一承运商7天内重复温控断点立即升级为H2，覆盖原INC-C2.3的14天口径。",
          "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
          "authority_level": "regulatory_notice",
          "applies_to": ["夜班QA复核员", "仓储收货员"],
          "training_gate": "追溯生效不依赖培训完成，已签署即生效"
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C2-NOTICE22",
          "text": "不得沿用20分钟或30分钟断点。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice"
        },
        {
          "warning_id": "WARN-C2-RETRO22A",
          "text": "追溯生效自2026-08-01；2026-08-01至颁发日之间发生的事件需按本附件重新分类。",
          "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
          "authority_level": "regulatory_notice"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-B",
          "binding_controls": ["C2"],
          "required_rows": ["TEMP-BREAK-12", "H2", "H3", "TEMP-RISK-WARN"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "BASE-C2.1",
          "reason": "被RC-2026-17(20分钟)→RC-2026-22(12分钟)→RC-2026-23(10分钟)逐步收紧取代",
          "replaced_by": "NOTICE22-C2.1",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md",
          "status": "superseded"
        },
        {
          "ref_id": "NOTICE17-C2.1",
          "reason": "被RC-2026-22取代",
          "replaced_by": "NOTICE22-C2.1",
          "source_doc": "notices/regulatory_notice_RC-2026-17.md",
          "status": "superseded"
        },
        {
          "ref_id": "NOTICE23-C2.1",
          "reason": "目标角色培训未完成(TR-036-NQ-23 future_training, release_date 2026-08-30)",
          "replaced_by": "NOTICE22-C2.1 (12分钟口径作为过渡)",
          "source_doc": "notices/regulatory_notice_RC-2026-23.md",
          "status": "training_pending_target_role"
        }
      ],
      "source_doc": "notices/regulatory_notice_RC-2026-22.md + notices/regulatory_notice_RC-2026-22A.md",
      "authority_level": "regulatory_notice > signed_site_appendix > base_sop",
      "site_scope": "全国冷链仓（华南冷链库适用RC-2026-22A追溯条款）",
      "role_scope": "夜班QA复核员、仓储收货员"
    },
    {
      "control_id": "C3",
      "title": "复核权限与放行门禁",
      "effective_steps": [
        {
          "step_id": "BASE-C3.1",
          "text": "夜班QA复核员可以登记记录完整性复核。",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md",
          "authority_level": "base_sop",
          "applies_to": ["夜班QA复核员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "NOTICE22-C2.2",
          "text": "隔离批次不得由夜班单人放行，必须等待QA负责人和法规联络人双批准。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": ["夜班QA复核员", "QA负责人", "法规联络人"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "NOTICE22-C3.3",
          "text": "H2/H3放行门禁以RC-2026-22为准，不得采用RC-2026-17的单主管口径。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": ["QA负责人", "法规联络人"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "SITE-C3.1",
          "text": "夜班QA复核员可完成记录完整性复核，但不得单独解除QA隔离。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix",
          "applies_to": ["夜班QA复核员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C3-GATE",
          "text": "H2/H3禁止夜班单人解除隔离。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-A",
          "binding_controls": ["C3"],
          "required_rows": ["ROLE-NIGHT-QA", "ROLE-QA-LEAD"]
        },
        {
          "appendix_id": "APP-B",
          "binding_controls": ["C3"],
          "required_rows": ["H2", "H3", "RECV-PENDING", "ARCHIVE-LOCKED"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "NOTICE17-C3.1",
          "reason": "被RC-2026-22 NOTICE22-C3.3取代",
          "replaced_by": "NOTICE22-C3.3",
          "source_doc": "notices/regulatory_notice_RC-2026-17.md",
          "status": "superseded"
        }
      ],
      "source_doc": "controlled/base_PROC-CC-036_rev3.md + notices/regulatory_notice_RC-2026-22.md + site/signed_site_appendix_SC-2026-07.md",
      "authority_level": "regulatory_notice > signed_site_appendix > base_sop",
      "site_scope": "华南冷链库",
      "role_scope": "夜班QA复核员、QA负责人、法规联络人"
    },
    {
      "control_id": "C4",
      "title": "记录保留与追溯包",
      "effective_steps": [
        {
          "step_id": "BASE-C4.1",
          "text": "接收、隔离、复核和放行记录必须按批次号归档，保留原始温度曲线和操作签名。",
          "source_doc": "controlled/base_PROC-CC-036_rev3.md",
          "authority_level": "base_sop",
          "applies_to": ["夜班QA复核员", "仓储收货员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "NOTICE22-C4.2",
          "text": "H2/H3事件追溯包保留540天，并附法规联络确认。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice",
          "applies_to": ["夜班QA复核员", "QA负责人", "法规联络人"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        },
        {
          "step_id": "SITE-C4.3",
          "text": "华南冷链库夜班交接记录需绑定班次、设备编号和QA复核员工号。",
          "source_doc": "site/signed_site_appendix_SC-2026-07.md",
          "authority_level": "signed_site_appendix",
          "applies_to": ["夜班QA复核员", "仓储收货员"],
          "training_gate": "TR-036-NQ (released 2026-08-12)"
        }
      ],
      "active_warnings": [
        {
          "warning_id": "WARN-C4-RETENTION",
          "text": "追溯包保留期以540天为准。",
          "source_doc": "notices/regulatory_notice_RC-2026-22.md",
          "authority_level": "regulatory_notice"
        }
      ],
      "bound_appendices": [
        {
          "appendix_id": "APP-C",
          "binding_controls": ["C4"],
          "required_rows": ["RET-H2H3-540", "TRACE-PACK", "RET-H1-365", "RET-OBS-90", "RET-INFO-90"]
        }
      ],
      "inactive_refs": [
        {
          "ref_id": "ARCH-C4.1",
          "reason": "rev2归档版，追溯包保留180天，已被rev3及RC-2026-22取代",
          "replaced_by": "NOTICE22-C4.2",
          "source_doc": "archive/base_PROC-CC-036_rev2_archived.md",
          "status": "archived"
        }
      ],
      "source_doc": "controlled/base_PROC-CC-036_rev3.md + notices/regulatory_notice_RC-2026-22.md + site/signed_site_appendix_SC-2026-07.md",
      "authority_level": "regulatory_notice > signed_site_appendix > base_sop",
      "site_scope": "华南冷链库",
      "role_scope": "夜班QA复核员、仓储收货员、QA负责人、法规联络人"
    }
  ],
  "inactive_controls": [
    {
      "ref_id": "BASE-C1.2",
      "inactive_reason": "被SIGN-A appended by SITE-C1.2取代：华南冷链库夜班到货必须由仓储收货员和夜班QA复核员双签接收",
      "replaced_by": "SITE-C1.2",
      "source_doc": "controlled/base_PROC-CC-036_rev3.md",
      "status": "superseded"
    },
    {
      "ref_id": "BASE-C2.1",
      "inactive_reason": "被RC-2026-17(20分钟)→RC-2026-22(12分钟)→RC-2026-23(10分钟)逐步收紧取代",
      "replaced_by": "NOTICE22-C2.1",
      "source_doc": "controlled/base_PROC-CC-036_rev3.md",
      "status": "superseded"
    },
    {
      "ref_id": "NOTICE17-C2.1",
      "inactive_reason": "被RC-2026-22取代：温度记录断点超过20分钟时进入QA隔离",
      "replaced_by": "NOTICE22-C2.1",
      "source_doc": "notices/regulatory_notice_RC-2026-17.md",
      "status": "superseded"
    },
    {
      "ref_id": "NOTICE23-C2.1",
      "inactive_reason": "目标角色培训未完成：TR-036-NQ-23为future_training(release_date 2026-08-30)，截至as_of_date尚未释放",
      "replaced_by": "NOTICE22-C2.1 (12分钟口径作为过渡执行)",
      "source_doc": "notices/regulatory_notice_RC-2026-23.md",
      "status": "training_pending_target_role"
    },
    {
      "ref_id": "NOTICE17-C3.1",
      "inactive_reason": "被RC-2026-22 NOTICE22-C3.3取代：H2/H3放行可由QA主管单独批准的单口径不再适用",
      "replaced_by": "NOTICE22-C3.3",
      "source_doc": "notices/regulatory_notice_RC-2026-17.md",
      "status": "superseded"
    },
    {
      "ref_id": "ARCH-C4.1",
      "inactive_reason": "rev2归档版，追溯包保留180天，已被rev3及RC-2026-22扩展至540天取代",
      "replaced_by": "NOTICE22-C4.2",
      "source_doc": "archive/base_PROC-CC-036_rev2_archived.md",
      "status": "archived"
    },
    {
      "ref_id": "DRAFT-C1.4",
      "inactive_reason": "未签署草案：建议夜班高峰时取消QA双签，违反监管通知硬性阈值",
      "replaced_by": null,
      "source_doc": "draft/unsigned_site_appendix_SC-2026-08.md",
      "status": "unsigned_draft"
    },
    {
      "ref_id": "DRAFT-C2.5",
      "inactive_reason": "未签署草案：建议夜班主管可口头批准温控隔离放行，违反RC-2026-22双批准要求",
      "replaced_by": null,
      "source_doc": "draft/unsigned_site_appendix_SC-2026-08.md",
      "status": "unsigned_draft"
    },
    {
      "ref_id": "DRAFT-C3.4",
      "inactive_reason": "未签署草案：建议夜班QA复核员可单独解除H2隔离，违反RC-2026-22 NOTICE22-C2.2",
      "replaced_by": null,
      "source_doc": "draft/unsigned_site_appendix_SC-2026-08.md",
      "status": "unsigned_draft"
    },
    {
      "ref_id": "LEGACY-rev1-C2",
      "inactive_reason": "rev1归档版，温度记录断点超过60分钟时进入QA隔离，已被后续版本多次收紧",
      "replaced_by": "NOTICE22-C2.1",
      "source_doc": "archive/base_PROC-CC-036_rev1_archived.md",
      "status": "archived"
    },
    {
      "ref_id": "LEGACY-rev1-C4",
      "inactive_reason": "rev1归档版，追溯包保留90天，已被后续版本扩展",
      "replaced_by": "NOTICE22-C4.2",
      "source_doc": "archive/base_PROC-CC-036_rev1_archived.md",
      "status": "archived"
    },
    {
      "ref_id": "LEGACY-rev2-C2",
      "inactive_reason": "rev2归档版，温度记录断点超过45分钟时进入QA隔离，已被RC-2026系列通知收紧",
      "replaced_by": "NOTICE22-C2.1",
      "source_doc": "archive/base_PROC-CC-036_rev2_archived.md",
      "status": "archived"
    },
    {
      "ref_id": "LEGACY-rev2-C3",
      "inactive_reason": "rev2归档版，H2/H3放行可由QA主管单独批准，已被RC-2026-22双批准机制取代",
      "replaced_by": "NOTICE22-C3.3",
      "source_doc": "archive/base_PROC-CC-036_rev2_archived.md",
      "status": "archived"
    },
    {
      "ref_id": "LEGACY-rev2-C4",
      "inactive_reason": "rev2归档版，追溯包保留180天，已被RC-2026-22扩展至540天取代",
      "replaced_by": "NOTICE22-C4.2",
      "source_doc": "archive/base_PROC-CC-036_rev2_archived.md",
      "status": "archived"
    },
    {
      "ref_id": "FAQ-C2.4",
      "inactive_reason": "FAQ-only：旧培训样例中曾出现45分钟断点，仅为历史示例，不得覆盖监管通知",
      "replaced_by": null,
      "source_doc": "faq/FAQ_PROC-CC-036.md",
      "status": "faq_only"
    }
  ],
  "conflict_register": [
    {
      "conflict_id": "CONF-C2-THRESHOLD",
      "object": "C2温控断点判定阈值",
      "losing_source": "controlled/base_PROC-CC-036_rev3.md BASE-C2.1 (30分钟)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C2.1 (12分钟)",
      "active_winner": "NOTICE22-C2.1 (12分钟)",
      "resolution": "按authority_order: regulatory_notice > base_sop，RC-2026-22取代BASE-C2.1的30分钟阈值",
      "requires_human_note": false
    },
    {
      "conflict_id": "CONF-C2-THRESHOLD-RC17",
      "object": "C2温控断点判定阈值(RC-2026-17 vs RC-2026-22)",
      "losing_source": "notices/regulatory_notice_RC-2026-17.md NOTICE17-C2.1 (20分钟)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C2.1 (12分钟)",
      "active_winner": "NOTICE22-C2.1 (12分钟)",
      "resolution": "RC-2026-22明确标注替代RC-2026-17中温控断点，document_register标记RC-2026-17状态为superseded_notice",
      "requires_human_note": false
    },
    {
      "conflict_id": "CONF-C2-THRESHOLD-RC23",
      "object": "C2温控断点判定阈值(RC-2026-23 vs RC-2026-22)",
      "losing_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C2.1 (12分钟)",
      "winning_source": "notices/regulatory_notice_RC-2026-23.md NOTICE23-C2.1 (10分钟)",
      "active_winner": "NOTICE22-C2.1 (12分钟) - 目标角色培训pending",
      "resolution": "RC-2026-23 NOTICE23-C2.1有角色培训前提条件，目标角色培训未完成故仍按RC-2026-22执行。非目标角色已完成培训者按10分钟执行。",
      "requires_human_note": true,
      "human_note": "需跟踪TR-036-NQ-23培训释放日期(2026-08-30)，完成后切换至10分钟阈值"
    },
    {
      "conflict_id": "CONF-C2-CARRIER-REPEAT",
      "object": "C2同承运商重复断点升级窗口(INC-C2.3 vs RC-2026-22A)",
      "losing_source": "incidents/incident_digest_august.csv RULE-RPT-CARRIER-14D (14天)",
      "winning_source": "notices/regulatory_notice_RC-2026-22A.md NOTICE22A-C2.4 (7天)",
      "active_winner": "NOTICE22A-C2.4 (7天)",
      "resolution": "RC-2026-22A明确覆盖原INC-C2.3的14天口径，追溯生效自2026-08-01",
      "requires_human_note": false
    },
    {
      "conflict_id": "CONF-C3-RELEASE-AUTHORITY",
      "object": "C3夜班QA复核员隔离放行权限(BASE-C3.1 vs RC-2026-22 vs SITE-C3.1)",
      "losing_source": "controlled/base_PROC-CC-036_rev3.md BASE-C3.1 (夜班QA可登记记录完整性复核，隐含可单独放行)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C2.2 + site/signed_site_appendix_SC-2026-07.md SITE-C3.1",
      "active_winner": "NOTICE22-C2.2 + SITE-C3.1 (双批准)",
      "resolution": "按authority_order: regulatory_notice > signed_site_appendix > base_sop，RC-2026-22 NOTICE22-C2.2禁止夜班单人放行，SITE-C3.1进一步确认不得单独解除隔离",
      "requires_human_note": false
    },
    {
      "conflict_id": "CONF-C3-RELEASE-AUTHORITY-RC17",
      "object": "C3 H2/H3放行审批权限(RC-2026-17单主管 vs RC-2026-22双批准)",
      "losing_source": "notices/regulatory_notice_RC-2026-17.md NOTICE17-C3.1 (H2/H3放行可由QA主管单独批准)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C3.3 (H2/H3放行门禁以RC-2026-22为准)",
      "active_winner": "NOTICE22-C3.3 (双批准)",
      "resolution": "RC-2026-22明确标注替代RC-2026-17中H2/H3门禁，NOTICE22-C3.3禁止采用RC-2026-17的单主管口径",
      "requires_human_note": false
    },
    {
      "conflict_id": "CONF-C4-RETENTION",
      "object": "C4 H2/H3追溯包保留期(BASE-C4.1 vs RC-2026-22)",
      "losing_source": "controlled/base_PROC-CC-036_rev3.md BASE-C4.1 (一般保留期)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C4.2 (540天)",
      "active_winner": "NOTICE22-C4.2 (540天)",
      "resolution": "按authority_order: regulatory_notice > base_sop，RC-2026-22 NOTICE22-C4.2将H2/H3追溯包保留期扩展至540天",
      "requires_human_note": false
    },
    {
      "conflict_id": "CONF-C4-RETENTION-REV2",
      "object": "C4追溯包保留期(rev2归档180天 vs RC-2026-22 540天)",
      "losing_source": "archive/base_PROC-CC-036_rev2_archived.md ARCH-C4.1 (180天)",
      "winning_source": "notices/regulatory_notice_RC-2026-22.md NOTICE22-C4.2 (540天)",
      "active_winner": "NOTICE22-C4.2 (540天)",
      "resolution": "rev2已归档，document_register标记为archived，仅用于追溯审计",
      "requires_human_note": false
    }
  ],
  "appendix_bindings": [
    {
      "appendix_id": "APP-A",
      "appendix_name": "角色矩阵",
      "source_file": "appendix/appendix_A_role_matrix.csv",
      "bindings": [
        {
          "control_id": "C1",
          "binding_description": "到货接收双签需要仓储收货员和夜班QA复核员工号绑定",
          "required_rows": ["ROLE-WH-RECV", "ROLE-NIGHT-QA"]
        },
        {
          "control_id": "C3",
          "binding_description": "H2/H3放行门禁需要QA负责人和法规联络人工号绑定",
          "required_rows": ["ROLE-NIGHT-QA", "ROLE-QA-LEAD"]
        }
      ]
    },
    {
      "appendix_id": "APP-B",
      "appendix_name": "冻结代码",
      "source_file": "appendix/appendix_B_hold_codes.csv",
      "bindings": [
        {
          "control_id": "C1",
          "binding_description": "接收流程状态流转使用DOC-INCOMPLETE/DOC-COMPLETE/RECV-PENDING/RECV-COMPLETED",
          "required_rows": ["DOC-INCOMPLETE", "DOC-COMPLETE", "RECV-PENDING", "RECV-COMPLETED"]
        },
        {
          "control_id": "C2",
          "binding_description": "温控断点和偏差等级使用TEMP-BREAK-12/H2/H3/TEMP-RISK-WARN",
          "required_rows": ["TEMP-BREAK-12", "H2", "H3", "TEMP-RISK-WARN"]
        },
        {
          "control_id": "C3",
          "binding_description": "隔离状态和放行决策使用H2/H3/RECV-PENDING/ARCHIVE-LOCKED",
          "required_rows": ["H2", "H3", "RECV-PENDING", "ARCHIVE-LOCKED"]
        }
      ]
    },
    {
      "appendix_id": "APP-C",
      "appendix_name": "记录保留期",
      "source_file": "appendix/appendix_C_record_retention.csv",
      "bindings": [
        {
          "control_id": "C4",
          "binding_description": "各类记录的保留期限定义",
          "required_rows": ["RET-H2H3-540", "TRACE-PACK", "RET-H1-365", "RET-OBS-90", "RET-INFO-90"]
        }
      ]
    }
  ],
  "role_specific_overrides": [
    {
      "role": "仓储收货员",
      "site": "华南冷链库",
      "control_id": "C2",
      "base_step_id": "NOTICE22-C2.1",
      "overriding_step_id": "NOTICE23-C2.1",
      "training_evidence_id": "TR-036-WH-23",
      "training_release_date": "2026-08-15",
      "notice_effective_date": "2026-08-18",
      "effective_for_role_from": "2026-08-18",
      "reason": "仓储收货员已完成TR-036-WH-23培训(released)，可执行RC-2026-23 NOTICE23-C2.1的10分钟断点阈值，比目标角色的12分钟更严格"
    }
  ],
  "retroactive_actions": [
    {
      "action_id": "RET-ACT-001",
      "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
      "issue_date": "2026-08-19",
      "retroactive_effective_date": "2026-08-01",
      "as_of_date": "2026-08-20",
      "affected_record": "IR-036-001",
      "affected_record_event_date": "2026-08-02",
      "original_severity": "H1",
      "new_severity": "H2",
      "trigger_rule": "RULE-RPT-CARRIER-14D → NOTICE22A-C2.4 (同一站点同一承运商7天内重复温控断点立即升级为H2)",
      "paired_with": "IR-036-002",
      "paired_with_event_date": "2026-08-08",
      "rationale": "IR-036-001(冷捷承运,13分钟断点)与IR-036-002(冷捷承运,14分钟断点)发生在同一站点华南冷链库且间隔6天(<7天)，按RC-2026-22A NOTICE22A-C2.4追溯规则，应升级为H2。原H1分类基于RPT-CARRIER-14D(14天窗口)不适用。"
    },
    {
      "action_id": "RET-ACT-002",
      "source_doc": "notices/regulatory_notice_RC-2026-22A.md",
      "issue_date": "2026-08-19",
      "retroactive_effective_date": "2026-08-01",
      "as_of_date": "2026-08-20",
      "affected_record": "IR-036-002",
      "affected_record_event_date": "2026-08-08",
      "original_severity": "H1",
      "new_severity": "H2",
      "trigger_rule": "RULE-RPT-CARRIER-14D → NOTICE22A-C2.4 (同一站点同一承运商7天内重复温控断点立即升级为H2)",
      "paired_with": "IR-036-001",
      "paired_with_event_date": "2026-08-02",
      "rationale": "IR-036-002(冷捷承运,14分钟断点)与IR-036-001(冷捷承运,13分钟断点)发生在同一站点华南冷链库且间隔6天(<7天)，按RC-2026-22A NOTICE22A-C2.4追溯规则，应升级为H2。原H1分类基于RPT-CARRIER-14D(14天窗口)不适用。"
    }
  ],
  "summary": {
    "total_controls": 4,
    "controls_with_active_steps": 4,
    "total_inactive_entries": 15,
    "total_conflicts_resolved": 8,
    "total_appendix_bindings": 3,
    "total_role_overrides": 1,
    "total_retroactive_actions": 2,
    "key_findings": [
      "C1: BASE-C1.2被SITE-C1.2取代，华南冷链库夜班到货实行双签接收",
      "C2: NOTICE22-C2.1(12分钟)为当前有效阈值；NOTICE23-C2.1(10分钟)因目标角色培训pending而暂不生效；NOTICE22A-C2.4(7天重复断点升级H2)追溯生效",
      "C3: NOTICE22-C2.2禁止夜班单人放行隔离，SITE-C3.1确认夜班QA复核员不得单独解除隔离",
      "C4: NOTICE22-C4.2将H2/H3追溯包保留期扩展至540天；SITE-C4.3增加夜班交接记录字段绑定要求",
      "非目标角色(仓储收货员)因已完成TR-036-WH-23培训，可执行NOTICE23-C2.1的10分钟阈值，形成role_specific_override",
      "目标角色(夜班QA复核员)的TR-036-NQ-23培训为future_training(release_date 2026-08-30)，不在role_specific_overrides中列出",
      "两笔追溯重分类行动(RT-ACT-001/RT-ACT-002)将IR-036-001和IR-036-002从H1升级为H2，配对依据为同一承运商冷捷在7天内两次断点",
      "未签署草案(DRAFT-C1.4/C2.5/C3.4)均被排除，因其建议违反监管通知硬性阈值",
      "FAQ仅用于解释格式或历史示例，不能覆盖硬性阈值(C2.4关于45分钟断点的历史示例)"
    ],
    "pending_items": [
      "TR-036-NQ-23培训预计2026-08-30释放，届时NOTICE23-C2.1(10分钟阈值)将对目标角色生效",
      "TR-036-H2培训预计2026-09-01释放，涉及H2相关操作权限"
    ],
    "audit_trail": {
      "determination_method": "按authority_order逐层判定：regulatory_notice > incident_triggered_control > signed_site_appendix > training_gate > base_sop > FAQ",
      "training_validation": "通过training_release_matrix.csv验证各角色培训状态",
      "retroactive_window": "RC-2026-22A retroactive_effective_date 2026-08-01至as_of_date 2026-08-20期间发生的SC站点同承运商断点对",
      "conflict_resolution_principle": "高优先级文件取代低优先级文件；培训前置条件未满足时维持上一版本步骤"
    }
  }
}
