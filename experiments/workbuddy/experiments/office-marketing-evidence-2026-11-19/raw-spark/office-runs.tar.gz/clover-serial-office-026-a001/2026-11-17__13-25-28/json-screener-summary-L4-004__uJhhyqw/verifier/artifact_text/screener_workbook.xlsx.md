# Workbook: screener_workbook.xlsx

## Sheet 1: screened_universe
Dimensions: 8 rows x 9 columns
R1: stock_code | display_name | exchange | leaf_industry | concept_match | score | rank | selected_reasons | source_pages
R2: 839215 | 北辰传感 | BJ | 传感器件 | 低空经济 | 99.0083 | 1 | Leaf industry '传感器件' in scope; All typed filters passed | page_002.json
R3: 000731 | 南岭材料 | SZ | 专用设备 | 低空经济 | 98.2583 | 2 | Leaf industry '专用设备' in scope; Concept group match via taxonomy; Vendor concept tag matches allowed concept; All typed filters passed | page_001.json
R4: 601245 | 东域控制 | SH | 通用电子 | 低空经济 | 97.3117 | 3 | Concept group match via taxonomy; Vendor concept tag matches allowed concept; All typed filters passed | page_001.json
R5: 600777 | 华电配套 | SH | 电力设备 | 低空经济 | 92.1 | 4 | Leaf industry '电力设备' in scope; All typed filters passed | page_002.json
R6: 300808 | 盛云微联 | SZ | 专用设备 | 低空经济 | 85.925 | 5 | Leaf industry '专用设备' in scope; Concept group match via taxonomy; Vendor concept tag matches allowed concept; All typed filters passed | page_002.json
R7: 301777 | 云岭智造 | SZ | 电力设备 | 低空经济 | 80.8 | 6 | Leaf industry '电力设备' in scope; All typed filters passed | page_001.json
R8: 920118 | 京北材料 | BJ | 专用设备 | 低空经济 | 70.255 | 7 | Leaf industry '专用设备' in scope; All typed filters passed | page_002.json

## Sheet 2: factor_detail
Dimensions: 85 rows x 6 columns
R1: stock_code | field_name | raw_value | normalized_value | component_score | source_artifact
R2: 000731 | CHANGE_RATE | 5.18 | 0.09 | 16.38 | page_001.json
R3: 000731 | VOLUME_RATIO | 1.84 | 0.6133 | 9.8133 | page_001.json
R4: 000731 | PE_TTM | 36.2 | 0.181 | 8.19 | page_001.json
R5: 000731 | TURNOVER_RATE | 3.1 | 0.3875 | 3.875 | page_001.json
R6: 000731 | leaf_industry_match | True | 1 | 6 | page_001.json
R7: 000731 | concept_group_match | True | 1 | 4 | page_001.json
R8: 600418 | CHANGE_RATE | 6.02 | 0.51 |  | page_001.json
R9: 600418 | VOLUME_RATIO |  |  |  | page_001.json
R10: 600418 | PE_TTM | 48.5 | 0.2425 |  | page_001.json
R11: 600418 | TURNOVER_RATE | 2.7 | 0.3375 |  | page_001.json
R12: 600418 | leaf_industry_match | False | 0 |  | page_001.json
R13: 600418 | concept_group_match | False | 0 |  | page_001.json
R14: 430215 | CHANGE_RATE | 4.23 | 0.385 |  | page_001.json
R15: 430215 | VOLUME_RATIO | 1.67 | 0.5567 |  | page_001.json
R16: 430215 | PE_TTM | 28.1 | 0.1405 |  | page_001.json
R17: 430215 | TURNOVER_RATE | 6.4 | 0.8 |  | page_001.json
R18: 430215 | leaf_industry_match | False | 0 |  | page_001.json
R19: 430215 | concept_group_match | False | 0 |  | page_001.json
R20: 003018 | CHANGE_RATE | 4.92 | 0.04 |  | page_001.json
R21: 003018 | VOLUME_RATIO | 2.21 | 0.7367 |  | page_001.json
R22: 003018 | PE_TTM | 22.4 | 0.112 |  | page_001.json
R23: 003018 | TURNOVER_RATE | 4.4 | 0.55 |  | page_001.json
R24: 003018 | leaf_industry_match | False | 0 |  | page_001.json
R25: 003018 | concept_group_match | False | 0 |  | page_001.json
R26: 301777 | CHANGE_RATE | 7 | 1 | 0 | page_001.json
R27: 301777 | VOLUME_RATIO | 1.5 | 0.5 | 8 | page_001.json
R28: 301777 | PE_TTM | 84 | 0.42 | 5.8 | page_001.json
R29: 301777 | TURNOVER_RATE | 5.6 | 0.7 | 7 | page_001.json
R30: 301777 | leaf_industry_match | True | 1 | 6 | page_001.json
R31: 301777 | concept_group_match | True | 1 | 4 | page_001.json
R32: 601245 | CHANGE_RATE | 4.8 | 0.1 | 16.2 | page_001.json
R33: 601245 | VOLUME_RATIO | 1.91 | 0.6367 | 10.1867 | page_001.json
R34: 601245 | PE_TTM | 54 | 0.27 | 7.3 | page_001.json
R35: 601245 | TURNOVER_RATE | 2.9 | 0.3625 | 3.625 | page_001.json
R36: 601245 | leaf_industry_match | True | 1 | 6 | page_001.json
R37: 601245 | concept_group_match | True | 1 | 4 | page_001.json
R38: 300642 | CHANGE_RATE | 2.95 | 1.025 |  | page_001.json
R39: 300642 | VOLUME_RATIO | 2.8 | 0.9333 |  | page_001.json
R40: 300642 | PE_TTM | 65 | 0.325 |  | page_001.json
R41: 300642 | TURNOVER_RATE | 6.2 | 0.775 |  | page_001.json
R42: 300642 | leaf_industry_match | False | 0 |  | page_001.json
R43: 300642 | concept_group_match | False | 0 |  | page_001.json
R44: 688909 | CHANGE_RATE | 3.6 | 0.7 |  | page_002.json
R45: 688909 | VOLUME_RATIO | 2.4 | 0.8 |  | page_002.json
R46: 688909 | PE_TTM | -4 |  |  | page_002.json
R47: 688909 | TURNOVER_RATE | 3.8 | 0.475 |  | page_002.json
R48: 688909 | leaf_industry_match | False | 0 |  | page_002.json
R49: 688909 | concept_group_match | False | 0 |  | page_002.json
R50: 839215 | CHANGE_RATE | 4.7 | 0.15 | 15.3 | page_002.json
R51: 839215 | VOLUME_RATIO | 2.05 | 0.6833 | 10.9333 | page_002.json
R52: 839215 | PE_TTM | 72 | 0.36 | 6.4 | page_002.json
R53: 839215 | TURNOVER_RATE | 5.1 | 0.6375 | 6.375 | page_002.json
R54: 839215 | leaf_industry_match | True | 1 | 6 | page_002.json
R55: 839215 | concept_group_match | True | 1 | 4 | page_002.json
R56: 002804 | CHANGE_RATE | 5.75 | 0.375 |  | page_002.json
R57: 002804 | VOLUME_RATIO | 1.88 | 0.6267 |  | page_002.json
R58: 002804 | PE_TTM | 42 | 0.21 |  | page_002.json
R59: 002804 | TURNOVER_RATE | 3.6 | 0.45 |  | page_002.json
R60: 002804 | leaf_industry_match | False | 0 |  | page_002.json
R61: 002804 | concept_group_match | False | 0 |  | page_002.json
R62: 920118 | CHANGE_RATE | 3 | 1 | 0 | page_002.json
R63: 920118 | VOLUME_RATIO | 1.5 | 0.5 | 8 | page_002.json
R64: 920118 | PE_TTM | 199.9 | 0.9995 | 0.005 | page_002.json
R65: 920118 | TURNOVER_RATE | 1.8 | 0.225 | 2.25 | page_002.json
R66: 920118 | leaf_industry_match | True | 1 | 6 | page_002.json
R67: 920118 | concept_group_match | True | 1 | 4 | page_002.json
R68: 300808 | CHANGE_RATE | 6.9 | 0.95 | 0.9 | page_002.json
R69: 300808 | VOLUME_RATIO | 2.7 | 0.9 | 14.4 | page_002.json
R70: 300808 | PE_TTM | 110 | 0.55 | 4.5 | page_002.json
R71: 300808 | TURNOVER_RATE | 4.9 | 0.6125 | 6.125 | page_002.json
R72: 300808 | leaf_industry_match | True | 1 | 6 | page_002.json
R73: 300808 | concept_group_match | True | 1 | 4 | page_002.json
R74: 600777 | CHANGE_RATE | 6.55 | 0.775 | 4.05 | page_002.json
R75: 600777 | VOLUME_RATIO | 3 | 1 | 16 | page_002.json
R76: 600777 | PE_TTM | 39 | 0.195 | 8.05 | page_002.json
R77: 600777 | TURNOVER_RATE | 3.2 | 0.4 | 4 | page_002.json
R78: 600777 | leaf_industry_match | True | 1 | 6 | page_002.json
R79: 600777 | concept_group_match | True | 1 | 4 | page_002.json
R80: 002222 | CHANGE_RATE | 5.44 | 0.22 |  | page_002.json
R81: 002222 | VOLUME_RATIO | 2.1 | 0.7 |  | page_002.json
R82: 002222 | PE_TTM | 38 | 0.19 |  | page_002.json
R83: 002222 | TURNOVER_RATE | 3 | 0.375 |  | page_002.json
R84: 002222 | leaf_industry_match | False | 0 |  | page_002.json
R85: 002222 | concept_group_match | False | 0 |  | page_002.json

## Sheet 3: review_or_excluded
Dimensions: 8 rows x 6 columns
R1: stock_code | display_name | status | primary_reason | visible_rule_id | source_artifact
R2: 003018 | 岭南精机 | excluded_risk_warning | stock_master risk_warning_flag=Y | E02_risk_warning | page_001.json
R3: 002222 | 浙安科技 | excluded_snapshot_mismatch | Snapshot trade date (2026-06-17) does not match as_of_trade_date (2026-06-18) | E01_snapshot_date | page_002.json
R4: 300642 | 瀚科新能 | excluded_filter_fail | CHANGE_RATE=2.95 outside [3.0,7.0] | E04_typed_filters | page_001.json
R5: 688909 | 星港电芯 | excluded_filter_fail | PE_TTM=-4.0 outside [0.0,200.0] | E04_typed_filters | page_002.json
R6: 430215 | 北证智控 | excluded_scope_mismatch | Industry not in scope and no concept match | E05_scope_match | page_001.json
R7: 600418 | 华东电装 | review_missing_required_metric | VOLUME_RATIO is missing | E04_typed_filters | page_001.json
R8: 002804 | 江南微驱 | review_exchange_mismatch | Exchange conflict: snapshot=SZ, master=SH | E06_exchange_authority | page_002.json

## Sheet 4: selection_summary
Dimensions: 17 rows x 3 columns
R1: metric | value | notes
R2: Total rows processed | 14 | All stocks from valid snapshot pages (pages in expected_pages with matching dates)
R3: Selected candidates | 7 | Final candidates passing all eligibility checks
R4: Under review | 2 | Stocks requiring manual review before selection
R5: Excluded | 5 | Stocks failing eligibility checks outright
R6: Ignored pages | 1 | Pages whose number is not in expected_pages
R7: Excluded – CHANGE_RATE=2.95 outside [3.0,7.0] | 1 | Count of exclusions by reason
R8: Excluded – Industry not in scope and no concept match | 1 | Count of exclusions by reason
R9: Excluded – PE_TTM=-4.0 outside [0.0,200.0] | 1 | Count of exclusions by reason
R10: Excluded – Snapshot trade date (2026-06-17) does not match as_of_trade_date (2026-06-18) | 1 | Count of exclusions by reason
R11: Excluded – stock_master risk_warning_flag=Y | 1 | Count of exclusions by reason
R12: Review – Exchange conflict: snapshot=SZ, master=SH | 1 | Count of reviews by reason
R13: Review – VOLUME_RATIO is missing | 1 | Count of reviews by reason
R14: Supplier industry conflicts | 1 | Stocks where snapshot EXCHANGE differs from master exchange_marker
R15: Concept-hit selected | 7 | Selected stocks with at least one concept group match
R16: Sum of scores (selected) | 623.6583 | Sum of total scores across all selected candidates
R17: Top-ranked code | 839215 | First stock after sorting by score desc, CHANGE_RATE desc, code asc
