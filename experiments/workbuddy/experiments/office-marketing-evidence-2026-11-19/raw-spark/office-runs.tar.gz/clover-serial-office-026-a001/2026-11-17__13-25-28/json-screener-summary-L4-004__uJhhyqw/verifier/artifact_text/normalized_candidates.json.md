{
  "request_id": "SR-20260618-CN-04",
  "as_of_trade_date": "2026-06-18",
  "total_processed": 14,
  "n_selected": 7,
  "n_review": 2,
  "n_excluded": 5,
  "ignored_pages": 1,
  "candidates": [
    {
      "stock_code": "839215",
      "display_name": "北辰传感",
      "exchange": "BJ",
      "leaf_industry": "传感器件",
      "concept_match": [
        "低空经济"
      ],
      "score": 99.0083,
      "rank": 1,
      "status": "selected",
      "primary_reason": "Leaf industry '传感器件' in scope; All typed filters passed",
      "source_files": [
        "page_002.json"
      ]
    },
    {
      "stock_code": "000731",
      "display_name": "南岭材料",
      "exchange": "SZ",
      "leaf_industry": "专用设备",
      "concept_match": [
        "低空经济"
      ],
      "score": 98.2583,
      "rank": 2,
      "status": "selected",
      "primary_reason": "Leaf industry '专用设备' in scope; Concept group match via taxonomy; Vendor concept tag matches allowed concept; All typed filters passed",
      "source_files": [
        "page_001.json"
      ]
    },
    {
      "stock_code": "601245",
      "display_name": "东域控制",
      "exchange": "SH",
      "leaf_industry": "通用电子",
      "concept_match": [
        "低空经济"
      ],
      "score": 97.3117,
      "rank": 3,
      "status": "selected",
      "primary_reason": "Concept group match via taxonomy; Vendor concept tag matches allowed concept; All typed filters passed",
      "source_files": [
        "page_001.json"
      ]
    },
    {
      "stock_code": "600777",
      "display_name": "华电配套",
      "exchange": "SH",
      "leaf_industry": "电力设备",
      "concept_match": [
        "低空经济"
      ],
      "score": 92.1,
      "rank": 4,
      "status": "selected",
      "primary_reason": "Leaf industry '电力设备' in scope; All typed filters passed",
      "source_files": [
        "page_002.json"
      ]
    },
    {
      "stock_code": "300808",
      "display_name": "盛云微联",
      "exchange": "SZ",
      "leaf_industry": "专用设备",
      "concept_match": [
        "低空经济"
      ],
      "score": 85.925,
      "rank": 5,
      "status": "selected",
      "primary_reason": "Leaf industry '专用设备' in scope; Concept group match via taxonomy; Vendor concept tag matches allowed concept; All typed filters passed",
      "source_files": [
        "page_002.json"
      ]
    },
    {
      "stock_code": "301777",
      "display_name": "云岭智造",
      "exchange": "SZ",
      "leaf_industry": "电力设备",
      "concept_match": [
        "低空经济"
      ],
      "score": 80.8,
      "rank": 6,
      "status": "selected",
      "primary_reason": "Leaf industry '电力设备' in scope; All typed filters passed",
      "source_files": [
        "page_001.json"
      ]
    },
    {
      "stock_code": "920118",
      "display_name": "京北材料",
      "exchange": "BJ",
      "leaf_industry": "专用设备",
      "concept_match": [
        "低空经济"
      ],
      "score": 70.255,
      "rank": 7,
      "status": "selected",
      "primary_reason": "Leaf industry '专用设备' in scope; All typed filters passed",
      "source_files": [
        "page_002.json"
      ]
    }
  ]
}