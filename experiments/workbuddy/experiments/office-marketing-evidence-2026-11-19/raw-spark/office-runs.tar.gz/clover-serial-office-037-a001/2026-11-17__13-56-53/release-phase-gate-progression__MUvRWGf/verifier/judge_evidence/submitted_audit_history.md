# Submitted Artifact Evidence Withheld

The text for `submitted_audit_history` is withheld because deterministic safety, leakage, or forbidden external-service checks failed on submitted mutable artifacts. Use deterministic failed_check names in deterministic_scope_summary.md for attribution. Do not run WB Judge on unsafe submitted text.
