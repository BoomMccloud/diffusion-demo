
# quillship-cli local release board

> Maintainer-facing release board for a command-line utility and documentation bundle for a command-line utility and documentation bundle. This Markdown board is maintainer-facing and can lag behind JSON state.

## Current banner, copied from maintainer board

- release label: `qs-local-2026-08-rc3`
- visible lane text: `repair_alignment in progress`
- board checkbox copied from previous evening: `[ ] validation pending repair`
- maintainer caution: “不要只看这一行；如果 JSON state 或 validation category 不一致，以本地 state/validation/audit 同步结果为准。”

## Phase tracker

| order | phase_key | board_status | owner_role | note |
|---:|---|---|---|---|
| 1 | `draft_intake` | done | release coordinator | scope file and seed manifest were readable yesterday |
| 2 | `scope_freeze` | done | release coordinator | component list was frozen after docs bundle update |
| 3 | `local_validation` | done | validation maintainer | all blocking checks resolved; adjacent phase advanced |
| 4 | `repair_alignment` | in_progress | release coordinator | currently being processed after local_validation admission |
| 5 | `handoff_ready` | copied ready label | docs maintainer | stale board label; do not treat as admitted without state and audit support |
| 6 | `release_wrap` | not started | maintainer | out of scope unless previous gates are truly admitted |

## Artifact status notes

- CLI manifest and Linux packaging notes remain stable in the local records.
- Docs bundle patch (10:18Z) has been reconciled; active cache now reflects current-scope digest from local_lookup_records.json#record.docs.current.
- Audit history includes reconciliation entry AUD-QS-042 appended after repair; no premature handoff wording remains.
- Archived board copy (`notes/old_release_board_copy.md`) retains prior scope label only for reference; not authoritative for current release.

## Mutable status panel

The panel below is intentionally lightweight; update it after reconciling JSON state, validation categories, lookup/cache, and audit timing.

```yaml
board_panel_version: panel-rc3-2026-08-05
current_gate_label: repair_alignment
board_phase_wording: in_progress
blocking_category_summary: []
last_public_sync_note: "Board aligned with workflow_state.json (repair_alignment phase); all prior blockers resolved."
```

## Human handoff reminders

- 不要删除旧 audit；要追加纠偏记录。
- 不要把 passed 子项汇总成整体 complete。
- 如果只能本地修复一部分 blocker，宁可保持 blocked，也不要跳到 handoff。
