# Public Workspace Boundary Context

This evidence summarizes only public local/mock workspace boundary files for supplemental WB Judge. It includes no hidden gold, hidden expected state, oracle prose, construction notes, private trace context, model logs, final-agent replies, external web evidence, or live-service evidence.

## Public README excerpt
# 专用同步工作区：日历到待办/提醒

这是一个专用同步工作区，所有材料均在任务目录内。请不要连接、登录或调用任何真实日历、待办、提醒、外部服务、网络 URL 或 live service。

## 本轮同步

- 同步运行时间：`2026-07-14T18:20:00+08:00`
- 时区：`Asia/Shanghai`
- 同步窗口：`2026-07-15T00:00:00+08:00` 到 `2026-07-21T23:59:59+08:00`
- 日历来源：`input/workspace/calendar/calendar_export_2026-07-14.json`
- 待办目标：`input/workspace/tasks/task_state.json`
- 稳定匹配记录：`input/workspace/sync/sync_history.json`
- 同步规则：`input/workspace/rules/sync_policy.md`
- 人工备注：`input/workspace/notes/operator_notes.txt`

## 只允许更新

- `input/workspace/tasks/task_state.json`
- `input/workspace/sync/sync_history.json`
- `input/workspace/reports/sync_summary.md`

其他文件都按只读处理。

## 处理口径

请以 `sync_key` 和 active sync history 为主键做稳定匹配。标题相似、时间接近、备注里写着“已同步/不用处理”等自然语言，只能作为辅助线索，不能覆盖同步规则。手工任务、无同步键任务、已有同 `sync_key` 的手机端/缓存同步项、只读日历记录、窗口外记录和重复导出记录都要谨慎保留或排除，不能产生外部副作用。

## Public local mock environment excerpt
# Sync Environment

This environment is a file-backed sync workspace for the calendar-to-task synchronization task.

- There is no live external service, browser session, identity material, or network dependency.
- The calendar source, task/reminder state, stable sync history, policy, notes, and summary are represented by files under `input/workspace/`.
- Read the listed JSON/Markdown/text files and update only the mutable files named by the instruction and policy.
- Any behavior that would require external service access must be treated as out of scope.

Mutable public files for the task:

- `input/workspace/tasks/task_state.json`
- `input/workspace/sync/sync_history.json`
- `input/workspace/reports/sync_summary.md`

Read-only public files for the task:

- `input/workspace/README_先读我.md`
- `input/workspace/calendar/calendar_export_2026-07-14.json`
- `input/workspace/rules/sync_policy.md`
- `input/workspace/notes/operator_notes.txt`
- `environment/local_mock_sync/README.md`
- `environment/state_diff_manifest.json`

## Public state-diff manifest excerpt
{
  "manifest_id": "calendar_dida_sync_state-public-state-contract",
  "visibility": "public_environment",
  "manifest_version": "public-state-contract-2026-07-14",
  "workspace_root": "input/workspace",
  "runtime_boundary": {
    "mode": "local_static_files_only",
    "network_required": false,
    "live_services_allowed": false,
    "auth_material_required": false,
    "mcp_required": false,
    "skill_required": false,
    "external_identity_required": false
  },
  "read_only_paths": [
    "input/workspace/README_先读我.md",
    "input/workspace/calendar/calendar_export_2026-07-14.json",
    "input/workspace/rules/sync_policy.md",
    "input/workspace/notes/operator_notes.txt",
    "environment/local_mock_sync/README.md",
    "environment/state_diff_manifest.json"
  ],
  "mutable_paths": [
    "input/workspace/tasks/task_state.json",
    "input/workspace/sync/sync_history.json",
    "input/workspace/reports/sync_summary.md"
  ],
  "source_files": {
    "calendar_export": "input/workspace/calendar/calendar_export_2026-07-14.json",
    "task_state": "input/workspace/tasks/task_state.json",
    "sync_history": "input/workspace/sync/sync_history.json",
    "sync_policy": "input/workspace/rules/sync_policy.md",
    "operator_notes": "input/workspace/notes/operator_notes.txt",
    "summary": "input/workspace/reports/sync_summary.md"
  },
  "time_contract": {
    "timezone": "Asia/Shanghai",
    "sync_run_time_local": "2026-07-14T18:20:00+08:00",
    "sync_window_start": "2026-07-15T00:00:00+08:00",
    "sync_window_end": "2026-07-21T23:59:59+08:00",
    "timestamp_format": "ISO-8601 with timezone offset"
  },
  "status_vocabulary": {
    "calendar_event_status": [
      "confirmed",
      "tentative",
      "cancelled"
    ],
    "task_status": [
      "active",
      "inactive"
    ],
    "mapping_state": [
      "active",
      "inactive",
      "excluded"
    ],
    "inactive_reason": [
      "calendar_event_cancelled",
      "source_missing_current_export",
      "historical_archive",
      "superseded_local_archive",
      null
    ]
  },
  "matching_contract": {
    "primary_match_key": "sync_key",
    "history_active_state": "active",
    "title_similarity_is_authoritative": false,
    "one_active_task_per_sync_key": true,
    "manual_task_protection_fields": [
      "source.kind",
      "source.sync_key",
      "manual_lock",
      "manual_note",
      "manual_tags"
    ]
  },
  "summary_contract": {
    "path": "input/workspace/reports/sync_summary.md",
    "language": "zh",
    "required_headings": [
      "## 本轮同步结论",
      "## 新建待办",
      "## 更新已有同步项",
      "## 置为 inactive",
      "## 保持不变",
      "## 重复或排除",
      "## 手工/无关任务保留",
      "## 边界确认"
    ],
    "item_reference_fields": [
      "event_id",
      "sync_key",
      "task_id",
      "mapping_id"
    ],
    "must_match_actual_json_state": true
  },
  "non_contract_notes": [
    "This manifest exposes only public runtime and file-boundary requirements.",
    "It describes the initial workspace state and runtime boundaries only; no preset synchronization results or external checking materials are included."
  ]
}

## Boundary anchors for Judge
- The workspace is local mock JSON/Markdown state, not a real calendar/task/reminder service.
- Approved mutable outputs are only `input/workspace/tasks/task_state.json`, `input/workspace/sync/sync_history.json`, and `input/workspace/reports/sync_summary.md`.
- Calendar source, rules, notes, README, environment files, and other public inputs are protected context and must not be treated as submitted output changes for Judge scoring.
- No real external calendar, Dida/TickTick account, browser, network, API, MCP, Skill, notification, or live side effect is part of the task or Judge evidence.
- Deterministic checks own exact file-boundary, protected-hash, forbidden extra-artifact, URL, secret, private-marker, and live-service-claim facts.
