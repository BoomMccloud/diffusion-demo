# Submitted Sync History Semantic Summary

This evidence summarizes only the submitted final `input/workspace/sync/sync_history.json` artifact. It does not compare against hidden gold, hidden expected state, oracle prose, construction notes, private trace context, model logs, or final-agent replies. Exact mapping IDs, counts, timestamps, source-binding facts, duplicate records, schema compliance, and correctness remain deterministic-owned.

## Top-level context
- history_meta keys: current_export_fingerprint, exported_at, history_kind, notes, sync_run_id, timezone, workspace
- sync_window: {'start': '2026-07-15T00:00:00+08:00', 'end': '2026-07-21T23:59:59+08:00'}
- submitted mappings total: 17 (context only; deterministic-owned)
- mapping state families: {'active': 10, 'inactive': 6, 'excluded': 1}
- last_action families: {'updated_from_calendar': 3, 'calendar_event_cancelled': 2, 'source_missing_current_export': 2, 'no_change': 1, 'unchanged_outside_window': 1, 'created_task': 5, 'archived_historical': 1, 'superseded_local_archive': 1, 'ignored_read_only_calendar': 1}
- missing_in_current_export families: {'missing_true': 4, 'missing_false': 13, 'missing_other': 0}
- suppressed duplicate records: 4 (context only; deterministic-owned)

## Mapping families
- mapping_id=map-local-1007; state=active; last_action=created_task; sync_key=cal::uid-after-window-20260724::2026-07-24; task_id=task-local-2009; event_id_last_seen=evt-20260724-after-window-old; missing_in_current_export=False; last_seen_in_export_at=2026-07-12T13:30:00+08:00; last_synced_at=2026-07-12T13:35:00+08:00
- mapping_id=map-local-1012; state=active; last_action=unchanged_outside_window; sync_key=cal::uid-local-after-window-missing-20260722::2026-07-22; task_id=task-local-2018; event_id_last_seen=evt-20260722-after-window-missing-old; missing_in_current_export=True; last_seen_in_export_at=2026-07-12T18:00:00+08:00; last_synced_at=2026-07-12T18:10:00+08:00
- mapping_id=map-local-2020; state=active; last_action=created_task; sync_key=cal::uid-local-briefing-20260715::2026-07-15; task_id=task-local-2020; event_id_last_seen=evt-20260715-briefing-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T17:42:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1006; state=active; last_action=no_change; sync_key=cal::uid-local-briefing-shift-20260716::2026-07-16; task_id=task-local-2006; event_id_last_seen=evt-20260716-briefing-shift-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T17:50:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1001; state=active; last_action=updated_from_calendar; sync_key=cal::uid-local-budget-20260716::2026-07-16; task_id=task-local-2001; event_id_last_seen=evt-20260716-budget-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T12:10:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-2023; state=active; last_action=created_task; sync_key=cal::uid-local-contract-renewal-20260717-v2::2026-07-17; task_id=task-local-2023; event_id_last_seen=evt-20260717-contract-new-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T17:25:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-2022; state=active; last_action=created_task; sync_key=cal::uid-local-onsite-20260717::2026-07-17; task_id=task-local-2022; event_id_last_seen=evt-20260717-onsite-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T15:18:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1002; state=active; last_action=updated_from_calendar; sync_key=cal::uid-local-review-moved-20260719::2026-07-19; task_id=task-local-2002; event_id_last_seen=evt-20260719-review-moved-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T17:08:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1011; state=active; last_action=updated_from_calendar; sync_key=cal::uid-local-training-20260718::2026-07-18; task_id=task-local-2017; event_id_last_seen=evt-20260718-training-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-13T19:22:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-2021; state=active; last_action=created_task; sync_key=cal::uid-local-vendor-review-20260715::2026-07-15; task_id=task-local-2021; event_id_last_seen=evt-20260715-vendor-review-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T16:55:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1010; state=excluded; last_action=ignored_read_only_calendar; sync_key=cal::uid-readonly-lunch-20260716::2026-07-16; task_id=None; event_id_last_seen=evt-20260716-readonly-lunch-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-13T21:00:00+08:00; last_synced_at=None
- mapping_id=map-local-1008; state=inactive; last_action=archived_historical; sync_key=cal::uid-archive-20260630::2026-06-30; task_id=task-local-2014; event_id_last_seen=evt-archive-20260630-old; missing_in_current_export=False; last_seen_in_export_at=2026-06-29T10:00:00+08:00; last_synced_at=2026-06-29T10:05:00+08:00
- mapping_id=map-local-1009; state=inactive; last_action=superseded_local_archive; sync_key=cal::uid-local-briefing-old-20260715::2026-07-15; task_id=task-local-2015; event_id_last_seen=evt-old-briefing-archive; missing_in_current_export=True; last_seen_in_export_at=2026-07-10T08:00:00+08:00; last_synced_at=2026-07-10T08:05:00+08:00
- mapping_id=map-local-1004; state=inactive; last_action=calendar_event_cancelled; sync_key=cal::uid-local-checkout-cancelled-20260721::2026-07-21; task_id=task-local-2004; event_id_last_seen=evt-20260721-checkout-cancelled-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T08:30:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1013; state=inactive; last_action=source_missing_current_export; sync_key=cal::uid-local-contract-renewal-20260717-v1::2026-07-17; task_id=task-local-2019; event_id_last_seen=evt-20260717-contract-old; missing_in_current_export=True; last_seen_in_export_at=2026-07-12T16:00:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1003; state=inactive; last_action=calendar_event_cancelled; sync_key=cal::uid-local-demo-cancelled-20260720::2026-07-20; task_id=task-local-2003; event_id_last_seen=evt-20260720-demo-cancelled-A; missing_in_current_export=False; last_seen_in_export_at=2026-07-14T09:40:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00
- mapping_id=map-local-1005; state=inactive; last_action=source_missing_current_export; sync_key=cal::uid-local-doc-freeze-20260718::2026-07-18; task_id=task-local-2005; event_id_last_seen=evt-20260718-doc-freeze-old; missing_in_current_export=True; last_seen_in_export_at=2026-07-10T10:00:00+08:00; last_synced_at=2026-07-14T18:20:00+08:00

## Suppressed duplicate families
- source_event_id=evt-20260715-briefing-duplicate-B; sync_key=cal::uid-local-briefing-20260715::2026-07-15; reason=same_sync_key_repeated_export_row; source_updated_at=None
- source_event_id=evt-20260716-budget-shadow-B; sync_key=cal::uid-local-budget-20260716::2026-07-16; reason=same_sync_key_backup_snapshot; source_updated_at=None
- source_event_id=evt-20260719-review-duplicate-B; sync_key=cal::uid-local-review-moved-20260719::2026-07-19; reason=same_sync_key_repeated_export_row; source_updated_at=None
- source_event_id=evt-20260719-review-near-window-shadow-C; sync_key=cal::uid-local-review-moved-20260719::2026-07-19; reason=same_sync_key_device_cache_snapshot; source_updated_at=None

## Semantic-use boundary
Judge may use this summary only to compare the submitted human report against the model's own submitted final history at a semantic category level. Deterministic checks own parseability, schema, exact mapping/source-binding facts, duplicate uniqueness, exact duplicate records, timestamps, and correctness against expected state.
