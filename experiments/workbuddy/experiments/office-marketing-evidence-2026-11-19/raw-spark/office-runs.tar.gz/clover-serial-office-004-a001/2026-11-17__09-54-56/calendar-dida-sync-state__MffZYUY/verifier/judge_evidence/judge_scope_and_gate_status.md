# Judge Scope and Deterministic Gate Status

This Markdown evidence file is produced by the deterministic verifier for supplemental text-only WB Judge consumption.

## Deterministic status
- passed_count: 92
- total_count: 109
- pass_rate: 0.844
- preflight_passed_count: 0
- preflight_total_count: 0
- deterministic_gated_pass: false
- deterministic_safety_or_leakage_failed: false
- llm_judge_activation_allowed: true
- failed_checks: new_create_evt-20260715-briefing-A_uses_nonpublic_task_id, new_create_evt-20260715-briefing-A_uses_nonpublic_mapping_id, new_create_evt-20260715-vendor-review-A_uses_nonpublic_task_id, new_create_evt-20260715-vendor-review-A_uses_nonpublic_mapping_id, new_create_evt-20260717-onsite-A_uses_nonpublic_task_id, new_create_evt-20260717-onsite-A_uses_nonpublic_mapping_id, new_create_evt-20260717-contract-new-A_uses_nonpublic_task_id, new_create_evt-20260717-contract-new-A_uses_nonpublic_mapping_id, noop_preserve_task-local-2006_exact, noop_preserve_map-local-1006_exact, noop_preserve_map-local-1012_exact, existing_public_id_tasks_match_expected_state, existing_public_id_mappings_match_expected_state, summary_noop_refs_match_state, summary_duplicate_excluded_refs_match_state, summary_category_counts_match_expected, summary_boundary_confirmation_present
- preflight_failed_checks: none

WB Judge may run only when all required judge_evidence files exist, deterministic safety/leakage checks pass, and deterministic component score, preflight status, failed_checks, and objective failure attribution are preserved separately. Deterministic full pass is not required by the current merge policy, but Judge must not recover, forgive, reinterpret, or override deterministic failures.

## Judge modality and forbidden behavior
- Text-only semantic review of the submitted sync summary, submitted final-state semantic summaries, deterministic scope status, and public policy/boundary context.
- No VLM/image/OCR/pixel-level visual scoring, screenshots, rendered thumbnails, audio, or video evidence.
- No browser/API/Skill/MCP/live-service behavior, external web evidence, real account access, notifications, or network side effects are required or allowed for Judge evidence.

## Deterministic-owned scope not scored by Judge
- file existence, filenames, path correctness, workspace state diff, protected-file preservation, and forbidden extra artifact detection
- JSON/Markdown parseability, required schema/headings, exact state transitions, exact field values, exact IDs/counts/timestamps, source binding, duplicate uniqueness, and exact summary references/count terms
- objective safety/leakage checks, private/source leakage detection, secret detection, and live/external-service regex scans
- deterministic pass recovery, deterministic failed-check reinterpretation, hidden gold comparison, exact oracle wording, or score compensation

## Exclusion boundary
This file excludes hidden gold-only expected artifacts, construction notes, evidence-package internals, private trace text, private paths, private URLs, credentials, account identifiers, customer data, proprietary code, unpublished assets, model logs, and final-agent replies.
