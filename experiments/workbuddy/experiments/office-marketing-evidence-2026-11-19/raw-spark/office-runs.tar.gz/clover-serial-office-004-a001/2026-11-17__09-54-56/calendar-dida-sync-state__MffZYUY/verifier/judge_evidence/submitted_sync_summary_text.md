# 日历到待办/提醒同步摘要

同步运行：`run-20260714-1820-local`  
工作区：`input/workspace`  
状态：本轮已完成。完成同步后，请在下列稳定标题下写入与 JSON 实际状态一致的 item reference 和处理原因。

## 本轮同步结论

本轮同步共处理了 18 个日历事件（含重复和排除项），其中：
- **新建** 4 个工作区待办/提醒
- **更新** 4 个已有同步项的字段
- **置为 inactive** 4 个任务（2个因日历取消，2个因来源缺失）
- **保持不变** 5 个活跃映射和 7 个手工任务
- **抑制重复** 4 条导出行
- **排除** 4 条记录（只读日历、窗口外等）

## 新建待办

以下新事件在本轮无 active mapping，已创建新的工作区待办：

1. **task-local-2020** - `sync_key: cal::uid-local-briefing-20260715::2026-07-15`
   - 对应事件：`evt-20260715-briefing-A`（晨间同步材料整理）
   - due_time: 2026-07-15T08:40:00+08:00
   - 原因：该 sync_key 在本轮无历史匹配，且为 confirmed 状态的合格日历事件

2. **task-local-2021** - `sync_key: cal::uid-local-vendor-review-20260715::2026-07-15`
   - 对应事件：`evt-20260715-vendor-review-A`（供应商方案复盘）
   - due_time: 2026-07-15T14:15:00+08:00
   - 原因：该 sync_key 在本轮无历史匹配，且为 confirmed 状态的合格日历事件

3. **task-local-2022** - `sync_key: cal::uid-local-onsite-20260717::2026-07-17`
   - 对应事件：`evt-20260717-onsite-A`（现场物料点检）
   - due_time: 2026-07-17T12:30:00+08:00
   - 原因：该 sync_key 在本轮无历史匹配，且为 confirmed 状态的合格日历事件

4. **task-local-2023** - `sync_key: cal::uid-local-contract-renewal-20260717-v2::2026-07-17`
   - 对应事件：`evt-20260717-contract-new-A`（合同归档提醒 v2）
   - due_time: 2026-07-17T15:30:00+08:00
   - 原因：v2 版本的 sync_key 与旧 v1 不同，无 active mapping；旧 v1 已在下方置为 inactive

## 更新已有同步项

以下事件有 active mapping 且字段发生变化，已更新同步相关字段：

1. **task-local-2001** / `map-local-1001` - `sync_key: cal::uid-local-budget-20260716::2026-07-16`
   - 对应事件：`evt-20260716-budget-A`（预算口径确认会）
   - 更新内容：source.event_id, source.last_source_updated_at, source.last_synced_at, sync_fields.source_start_time/end_time/location, due_time, reminder_time, updated_at
   - 注意：保留了 manual_tags=["财务口径"] 和 manual_note="会前带上上周版本，不要覆盖这条备注。"

2. **task-local-2002** / `map-local-1002` - `sync_key: cal::uid-local-review-moved-20260719::2026-07-19`
   - 对应事件：`evt-20260719-review-moved-A`（周报数据复核）
   - 更新内容：source.event_id, source.last_source_updated_at, source.last_synced_at, sync_fields.source_start_time/end_time/location, due_time, reminder_time, updated_at
   - 注意：保留了 manual_note="保留上次手工写的检查范围说明。"

3. **task-local-2006** / `map-local-1006` - `sync_key: cal::uid-local-briefing-shift-20260716::2026-07-16`
   - 对应事件：`evt-20260716-briefing-shift-A`（晨间同步材料整理）
   - 更新内容：仅刷新 source.last_synced_at 和 updated_at
   - 注意：其他字段已与当前导出一致，未做不必要的时间戳修改

4. **task-local-2017** / `map-local-1011` - `sync_key: cal::uid-local-training-20260718::2026-07-18`
   - 对应事件：`evt-20260718-training-A`（周末演练报名截止提醒）
   - 更新内容：source.event_id, source.last_source_updated_at, source.last_synced_at, sync_fields.source_start_time/end_time/location, due_time, reminder_time, updated_at
   - 注意：保留了 manual_tags=["报名"] 和 manual_note="手机端先建过的同步提醒；本轮只刷新同步字段，别覆盖这条备注。"

## 置为 inactive

### 因日历事件取消（status=cancelled）

1. **task-local-2003** / `map-local-1003` - `sync_key: cal::uid-local-demo-cancelled-20260720::2026-07-20`
   - 对应事件：`evt-20260720-demo-cancelled-A`（样机演示预演）
   - 操作：status="inactive", archived=true, inactive_reason="calendar_event_cancelled"
   - 更新内容：source.event_id, source.last_source_updated_at, source.last_synced_at, mapping.state, mapping.last_action
   - 注意：保留了 manual_tags=["预演"] 和 manual_note="原本需要准备演示线缆，取消时也不要删记录。"

2. **task-local-2004** / `map-local-1004` - `sync_key: cal::uid-local-checkout-cancelled-20260721::2026-07-21`
   - 对应事件：`evt-20260721-checkout-cancelled-A`（临时设备归还确认）
   - 操作：status="inactive", archived=true, inactive_reason="calendar_event_cancelled"
   - 更新内容：source.event_id, source.last_source_updated_at, source.last_synced_at, mapping.state, mapping.last_action

### 因来源缺失且在当前窗口内

3. **task-local-2005** / `map-local-1005` - `sync_key: cal::uid-local-doc-freeze-20260718::2026-07-18`
   - 对应事件：无（mapping.marked as missing_in_current_export=true）
   - 目标 due_time: 2026-07-18T17:30:00+08:00（在当前窗口内）
   - 操作：status="inactive", archived=true, inactive_reason="source_missing_current_export"
   - 更新内容：mapping.state="inactive", mapping.last_action="source_missing_current_export"
   - 注意：保留了 manual_tags=["版本"] 和 manual_note="历史同步项；如果本轮来源缺失且仍在窗口内，按规则置 inactive。"

4. **task-local-2019** / `map-local-1013` - `sync_key: cal::uid-local-contract-renewal-20260717-v1::2026-07-17`
   - 对应事件：无（旧 v1 源不在当前导出中）
   - 目标 due_time: 2026-07-17T15:20:00+08:00（在当前窗口内）
   - 操作：status="inactive", archived=true, inactive_reason="source_missing_current_export"
   - 更新内容：mapping.state="inactive", mapping.last_action="source_missing_current_export"
   - 注意：保留了 manual_tags=["法务"] 和 manual_note="旧本地端同步项；同名记录要先看 sync_key 和历史状态，不要和同名新 UID 混成一条。"
   - 补充：该 sync_key 对应的旧实例已失效，但同名的 v2 实例（`cal::uid-local-contract-renewal-20260717-v2::2026-07-17`）已在上方作为 task-local-2023 新建

## 保持不变

以下项目在本轮无需变更：

### 活跃映射（字段已匹配或无需更新）

1. **map-local-1007** - `sync_key: cal::uid-after-window-20260724::2026-07-24`
   - 关联任务：task-local-2009
   - 状态：active，last_action="created_task"
   - 原因：该事件在导出中属于窗口外参考记录，不参与本轮同步

2. **map-local-1012** - `sync_key: cal::uid-local-after-window-missing-20260722::2026-07-22`
   - 关联任务：task-local-2018
   - 状态：active，missing_in_current_export=true
   - 原因：虽然标记为来源缺失，但目标 due_time (2026-07-22) 在当前窗口之外，根据规则保持 active 不变

### 历史 inactive/excluded 映射

3. **map-local-1008** - `sync_key: cal::uid-archive-20260630::2026-06-30`
   - 状态：inactive，last_action="archived_historical"
   - 原因：历史归档记录，不属于本轮窗口

4. **map-local-1009** - `sync_key: cal::uid-local-briefing-old-20260715::2026-07-15`
   - 状态：inactive，last_action="superseded_local_archive"
   - 原因：旧实例已归档，current rows may share a similar title

5. **map-local-1010** - `sync_key: cal::uid-readonly-lunch-20260716::2026-07-16`
   - 状态：excluded，last_action="ignored_read_only_calendar"
   - 原因：只读参考日历，sync_allowed=false

### 手工/无关任务（source.kind=manual 或 sync_key=null）

6. **task-local-2007** - "手工：供应商方案复盘补充问题"
   - manual_lock=true，无 sync_key
   - 原因：人工清单，不能作为同步目标覆盖

7. **task-local-2008** - "手工：预算口径确认会发言稿"
   - manual_lock=true，无 sync_key
   - 原因：不要因标题相似改成日历同步任务

8. **task-local-2010** - "手工：午间散步"
   - manual_lock=true，无 sync_key
   - 原因：与只读日历午间提醒相近，但没有同步键

9. **task-local-2011** - "手工：整理周末演练报名表"
   - manual_lock=true，无 sync_key
   - 原因：这是报名表整理，不是日历提醒本身

10. **task-local-2012** - "手工：仓库样板间门禁申请"
    - manual_lock=true，无 sync_key
    - 原因：与现场物料点检相关但不是日历同步项

11. **task-local-2013** - "手工：补登记发票抬头"
    - manual_lock=false，无 sync_key
    - 原因：无关任务，不能被本轮同步修改

12. **task-local-2016** - "手工：本周待办清理"
    - manual_lock=false，无 sync_key
    - 原因：普通清理项，不参与日历同步

## 重复或排除

以下记录被识别为重复或不应进入同步范围：

### 重复导出行（same sync_key）

1. **evt-20260715-briefing-duplicate-B** - `sync_key: cal::uid-local-briefing-20260715::2026-07-15`
   - 原因：same_sync_key_repeated_export_row
   - 首选事件：evt-20260715-briefing-A
   - 处理：写入 suppressed_duplicates，不生成第二个 active 任务

2. **evt-20260716-budget-shadow-B** - `sync_key: cal::uid-local-budget-20260716::2026-07-16`
   - 原因：same_sync_key_backup_snapshot
   - 首选事件：evt-20260716-budget-A
   - 处理：写入 suppressed_duplicates，不生成第二个 active 任务

3. **evt-20260719-review-near-window-shadow-C** - `sync_key: cal::uid-local-review-moved-20260719::2026-07-19`
   - 原因：same_sync_key_device_cache_snapshot
   - 首选事件：evt-20260719-review-moved-A
   - 处理：写入 suppressed_duplicates，不生成第二个 active 任务

4. **evt-20260719-review-duplicate-B** - `sync_key: cal::uid-local-review-moved-20260719::2026-07-19`
   - 原因：same_sync_key_repeated_export_row
   - 首选事件：evt-20260719-review-moved-A
   - 处理：写入 suppressed_duplicates，不生成第二个 active 任务

### 排除的记录

5. **evt-20260716-readonly-lunch-A** - `calendar_id: cal_mock_personal_readonly`
   - 原因：sync_allowed=false（只读参考日历）
   - 处理：不创建任务，不更新手工任务

6. **evt-20260724-after-window-A** - start_time: 2026-07-24T10:00:00+08:00
   - 原因：outside_current_window（超出同步窗口）
   - 处理：不创建任务

7. **evt-20260714-before-window-A** - start_time: 2026-07-14T18:00:00+08:00
   - 原因：outside_current_window（早于同步窗口）
   - 处理：不创建任务

8. **evt-archive-20260630-A** - `calendar_id: cal_mock_archive`
   - 原因：sync_allowed=false（归档观察日历）
   - 处理：不创建任务

## 手工/无关任务保留

以下任务均包含 `manual_lock=true` 或 `source.sync_key=null`，在本轮保持不变：

- task-local-2007: "手工：供应商方案复盘补充问题"（manual_lock=true）
- task-local-2008: "手工：预算口径确认会发言稿"（manual_lock=true）
- task-local-2010: "手工：午间散步"（manual_lock=true）
- task-local-2011: "手工：整理周末演练报名表"（manual_lock=true）
- task-local-2012: "手工：仓库样板间门禁申请"（manual_lock=true）
- task-local-2013: "手工：补登记发票抬头"（manual_lock=false, no sync_key）
- task-local-2016: "手工：本周待办清理"（manual_lock=false, no sync_key）

这些任务均未被任何日历事件覆盖或修改。

## 边界确认

- **同步窗口**: 2026-07-15T00:00:00+08:00 至 2026-07-21T23:59:59+08:00
- **有效日历**: 仅 `cal_mock_work_ops`（sync_allowed=true）
- **无效日历**: `cal_mock_personal_readonly`（sync_allowed=false）、`cal_mock_archive`（sync_allowed=false）
- **时间边界**: 
  - 窗口外的记录（如 evt-20260724-after-window-A、evt-20260714-before-window-A）被排除
  - 窗口边界的缓存行（如 evt-20260719-review-near-window-shadow-C）被抑制为重复
- **手动保护**: 所有 manual_lock=true 的任务均未修改
- **外部服务**: 本轮未访问任何真实日历、待办、提醒、通知、外部服务、网络 URL 或 live service
