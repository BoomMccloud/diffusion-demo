# Workbook: trade_pnl_workbook.xlsx

## Sheet 1: position_reconciliation
Dimensions: 10 rows x 26 columns
R1: as_of_date | internal_unit | account_short_code | broker_fund_account | shareholder_account | market | symbol | name | opening_qty | record_date_qty | trade_buy_qty | trade_sell_qty | bonus_share_qty | transfer_in_qty | transfer_out_qty | pending_settlement_qty | settled_ending_qty | reportable_qty | opening_cost_amount | trade_buy_cost_amount | trade_sell_cost_amount | corporate_action_cost_adjustment | ending_cost_amount | adjusted_avg_cost_price | balance_source_ids | source_trace
R2: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | A462108391 | 深A | 002M08 | 明澈医药 | 900 | 900 | 0 | 300 | 0 | 0 | 0 | 0 | 600 | 600 | 11574 | 0 | 3858 | 0 | 7716 | 12.86 | BAL-0318-A7-M08;SB260317-002M08-01;SB260318-002M08-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv
R3: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | A462108391 | 深A | 300Q17 | 昱航智能 | 1200 | 1200 | 500 | 0 | 0 | 0 | 0 | 500 | 1200 | 1700 | 22014 | 9310.89 | 0 | 0 | 31324.89 | 18.4264 | BAL-0317-A7-Q17;SB260317-300Q17-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv
R4: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | A462108391 | 深A | 300Z88 | 泽川软件 | 400 | 400 | 0 | 150 | 0 | 0 | 0 | -150 | 400 | 250 | 10872 | 0 | 4077 | 0 | 6795 | 27.18 | BAL-0317-A7-Z88;SB260317-300Z88-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv
R5: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | B730029184 | 沪A | 600R42 | 瑞岭材料 | 600 | 600 | 200 | 0 | 0 | 0 | 0 | 200 | 600 | 800 | 5652 | 1948.6 | 0 | 0 | 7600.6 | 9.5008 | BAL-0317-B2-R42;SB260317-600R42-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv
R6: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | B730029184 | 沪A | 603Y21 | 云湾机械 | 500 | 500 | 0 | 0 | 0 | 0 | 0 | 0 | 500 | 500 | 8210 | 0 | 0 | 0 | 8210 | 16.42 | BAL-0317-B2-Y21;SB260317-603Y21-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; closing_prices.csv
R7: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | B730029184 | 科创板 | 688T66 | 凌川电子 | 300 | 300 | 0 | 0 | 0 | 0 | 0 | 0 | 180 | 180 | 13446 | 0 | 0 | 0 | 13446 | 74.7 | BAL-0318-B2-T66;SB260317-688T66-01;SB260318-688T66-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv
R8: 2026-03-17 | 资产单元-C | acct-C5 | 55288013 | A119006237 | 沪A | 601V03 | 南谷电气 | 400 | 400 | 0 | 0 | 0 | 0 | 0 | 0 | 400 | 400 | 6420 | 0 | 0 | 0 | 6420 | 16.05 | BAL-0317-C5-V03;SB260317-601V03-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; closing_prices.csv
R9: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | C920184375 | 深A | 002D31 | 东环电气 | 1000 | 1000 | 400 | 0 | 200 | 0 | 0 | 0 | 1600 | 1600 | 10800 | 4073.26 | 0 | 0 | 14873.26 | 9.2958 | BAL-0317-D4;SB260316-002D31-01;SB260316-002D31-02;SB260317-002D31-01 | account_aliases.csv; initial_positions.xlsx; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv
R10: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | C920184375 | 深A | 002N55 | 北岚食品 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | BAL-0317-D4-N55;SB260317-002N55-01 | account_aliases.csv; security_balance_changes.xlsx; trade_fills.xlsx; closing_prices.csv

## Sheet 2: realized_pnl
Dimensions: 10 rows x 19 columns
R1: trade_date | settlement_date | internal_unit | market | symbol | name | side | executed_qty | gross_amount | cost_basis | commission | stamp_tax | transfer_fee | realized_pnl | settlement_amount | cash_status | fill_ids | statement_contract_id | source_trace
R2: 2026-03-17 | 2026-03-18 | 资产单元-A | 深A | 002M08 | 明澈医药 | 卖出 | 300 | 3993 | 3858 | 1.2 | 3.99 | 0.04 | 129.77 | 3987.77 | 已记账 | 77K450031 | HT8801-0317-014 | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R3: 2026-03-17 | 2026-03-18 | 资产单元-A | 深A | 300Q17 | 昱航智能 | 买入 | 300 | 9308 | 9308 | 2.79 | 0 | 0.1 | -2.89 | 9310.89 | 已记账 | 45A019883 | HT8801-0317-006 | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R4: 2026-03-17 | 2026-03-18 | 资产单元-A | 深A | 300Q17 | 昱航智能 | 买入 | 200 | 3728 | 3728 | 1.12 | 0 | 0.04 | -1.16 | 3729.16 | 已记账 | 45A019914 |  | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R5: 2026-03-17 | 2026-03-18 | 资产单元-A | 深A | 300Z88 | 泽川软件 | 卖出 | 150 | 4188 | 4077 | 1.26 | 4.19 | 0.04 | 105.51 | 4182.51 | 已记账 | 88Z120044 | HT8801-0317-018 | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R6: 2026-03-17 | 2026-03-18 | 资产单元-B | 沪A | 600R42 | 瑞岭材料 | 买入 | 200 | 1948 | 1948 | 0.58 | 0 | 0.02 | -0.6 | 1948.6 | 已记账 | 601-884210 |  | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R7: 2026-03-17 | 2026-03-18 | 资产单元-B | 科创板 | 688T66 | 凌川电子 | 卖出 | -120 | -5404.8 | -5378.4 | -1.62 | -5.4 | -0.05 | -19.33 | -5397.73 | 已记账 | 90D7110R1 |  | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R8: 2026-03-17 | 2026-03-18 | 资产单元-B | 科创板 | 688T66 | 凌川电子 | 卖出 | 120 | 5409.6 | 5378.4 | 1.62 | 5.41 | 0.05 | 24.12 | 5402.52 | 已记账 | 90D711104 | HT7716-0317-021 | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R9: 2026-03-16 | 2026-03-17 | 资产单元-D | 深A | 002D31 | 东环电气 | 买入 | 400 | 4072 | 4072 | 1.22 | 0 | 0.04 | -1.26 | 4073.26 | 已记账 | 16D310044 | HT6632-0317-011 | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; initial_positions.xlsx
R10: 2026-03-17 | 2026-03-18 | 资产单元-D | 深A | 002N55 | 北岚食品 | 买入 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 已记账 | D4-TRAIL-01 |  | trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv

## Sheet 3: unrealized_pnl
Dimensions: 10 rows x 14 columns
R1: valuation_date | internal_unit | market | symbol | name | reportable_qty | adjusted_avg_cost_price | cost_amount | closing_price | price_status | market_value | unrealized_pnl | valuation_status | source_trace
R2: 2026-03-17 | 资产单元-A | 深A | 002M08 | 明澈医药 | 600 | 12.86 | 7716 | 13.05 | 有效 | 7830 | 114 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx; trade_fills.xlsx
R3: 2026-03-17 | 资产单元-A | 深A | 300Q17 | 昱航智能 | 1700 | 18.4264 | 31324.89 | 18.92 | 除权有效 | 32164 | 839.11 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx; trade_fills.xlsx
R4: 2026-03-17 | 资产单元-A | 深A | 300Z88 | 泽川软件 | 250 | 27.18 | 6795 | 27.44 | 有效 | 6860 | 65 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx; trade_fills.xlsx
R5: 2026-03-17 | 资产单元-B | 沪A | 600R42 | 瑞岭材料 | 800 | 9.5008 | 7600.6 | 9.68 | 有效 | 7744 | 143.4 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx; trade_fills.xlsx
R6: 2026-03-17 | 资产单元-B | 沪A | 603Y21 | 云湾机械 | 500 | 16.42 | 8210 | 16.73 | 停牌 | 8365 | 155 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx
R7: 2026-03-17 | 资产单元-B | 科创板 | 688T66 | 凌川电子 | 180 | 74.7 | 13446 | 45.22 | 有效 | 8139.6 | -5306.4 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx; trade_fills.xlsx
R8: 2026-03-17 | 资产单元-C | 沪A | 601V03 | 南谷电气 | 400 | 16.05 | 6420 |  | 缺失 |  |  | blank_price | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx
R9: 2026-03-17 | 资产单元-D | 深A | 002D31 | 东环电气 | 1600 | 9.2958 | 14873.26 | 8.58 | 除权有效 | 13728 | -1145.26 | valued | security_balance_changes.xlsx; closing_prices.csv; initial_positions.xlsx; trade_fills.xlsx
R10: 2026-03-17 | 资产单元-D | 深A | 002N55 | 北岚食品 | 0 | 0 | 0 | 7.33 | 有效 |  |  | valued | security_balance_changes.xlsx; closing_prices.csv; trade_fills.xlsx

## Sheet 4: cash_reconciliation
Dimensions: 20 rows x 14 columns
R1: as_of_date | internal_unit | account_short_code | broker_fund_account | amount_type | market | symbol | gross_cash_amount | fee_amount | tax_amount | net_cash_amount | settlement_status | related_ids | source_trace
R2: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 买入清算 | 深A | 300Q17 | -9308 | 0 | 0 | -9308 | pending | 45A019883;45A019914 | cash_ledger.csv
R3: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 佣金 | 深A | 002M08 | -1.2 | 1.2 | 0 | 0 | pending | 77K450031 | cash_ledger.csv
R4: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 卖出清算 | 深A | 002M08 | 3993 | 0 | 0 | 3993 | pending | 77K450031 | cash_ledger.csv
R5: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 卖出清算 | 深A | 300Z88 | 4188 | 0 | 0 | 4188 | pending | 88Z120044 | cash_ledger.csv
R6: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 印花税 | 深A | 002M08 | -3.99 | 0 | 3.99 | 0 | pending | 77K450031 | cash_ledger.csv
R7: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 过户费 | 深A | 002M08 | -0.04 | 0.04 | 0 | 0 | pending | 77K450031 | cash_ledger.csv
R8: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 买入清算 | 沪A | 600R42 | -1948 | 0 | 0 | -1948 | pending | 601-884210 | cash_ledger.csv
R9: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 佣金 | 沪A | 600R42 | -0.58 | 0.58 | 0 | 0 | pending | 601-884210 | cash_ledger.csv
R10: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 佣金 | 科创板 | 688T66 | -1.62 | 1.62 | 0 | 0 | pending | 90D711104 | cash_ledger.csv
R11: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 卖出清算 | 科创板 | 688T66 | 5409.6 | 0 | 0 | 5409.6 | pending | 90D711104 | cash_ledger.csv
R12: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 印花税 | 科创板 | 688T66 | -5.41 | 0 | 5.41 | 0 | pending | 90D711104 | cash_ledger.csv
R13: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 过户费 | 沪A | 600R42 | -0.02 | 0.02 | 0 | 0 | pending | 601-884210 | cash_ledger.csv
R14: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 过户费 | 科创板 | 688T66 | -0.05 | 0.05 | 0 | 0 | pending | 90D711104 | cash_ledger.csv
R15: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | 买入清算 | 深A | 002D31 | -4072 | 0 | 0 | -4072 | settled | 16D310044 | cash_ledger.csv
R16: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | 佣金 | 深A | 002D31 | -1.22 | 1.22 | 0 | 0 | settled | 16D310044 | cash_ledger.csv
R17: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | 现金红利 | 深A | 002D31 | 150 | 0 | 0 | 150 | settled | CA-0316-SZ-02 | cash_ledger.csv
R18: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | 红利税 | 深A | 002D31 | -15 | 0 | 15 | 0 | settled | CA-0316-SZ-02 | cash_ledger.csv
R19: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | 过户费 | 深A | 002D31 | -0.04 | 0.04 | 0 | 0 | settled | 16D310044 | cash_ledger.csv
R20: 2026-03-18 | 资产单元-B | acct-B2 | 77160425 | 红利税 | 沪A | 603Y21 | 0 | 0 | 0 | 0 | pending | DIV7716-0317-603Y21 | cash_ledger.csv

## Sheet 5: account_summary
Dimensions: 5 rows x 18 columns
R1: as_of_date | internal_unit | account_short_code | broker_fund_account | beginning_cost_amount | trade_buy_cost_amount | trade_sell_cost_amount | corporate_action_qty_delta | dividend_cash | withholding_tax | net_trade_cash | pending_cash_amount | ending_cost_amount | market_value | unrealized_pnl | realized_pnl | exception_count | source_trace
R2: 2026-03-17 | 资产单元-A | acct-A7 | 88001976 | 44460 | 9310.89 | 7935 | 0 | 0 | 0 | -1127 | 17489 | 45835.89 | 46854 | 1018.11 | 231.23 | 13 | initial_positions.xlsx; trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; corporate_actions.xlsx; security_balance_changes.xlsx; closing_prices.csv
R3: 2026-03-17 | 资产单元-B | acct-B2 | 77160425 | 27308 | 1948.6 | 0 | 0 | 0 | 0 | 3461.6 | 7357.6 | 29256.6 | 24248.6 | -5008 | 4.19 | 12 | initial_positions.xlsx; trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; corporate_actions.xlsx; security_balance_changes.xlsx; closing_prices.csv
R4: 2026-03-17 | 资产单元-C | acct-C5 | 55288013 | 6420 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 6420 | 0 | 0 | 0 | 2 | initial_positions.xlsx; trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; corporate_actions.xlsx; security_balance_changes.xlsx; closing_prices.csv
R5: 2026-03-17 | 资产单元-D | acct-D4 | 66321048 | 10800 | 4073.26 | 0 | 200 | 150 | 0 | -4072 | 0 | 14873.26 | 13728 | -1145.26 | -1.26 | 3 | initial_positions.xlsx; trade_fills.xlsx; broker_statement.xlsx; cash_ledger.csv; corporate_actions.xlsx; security_balance_changes.xlsx; closing_prices.csv

## Sheet 6: exceptions
Dimensions: 31 rows x 11 columns
R1: as_of_date | internal_unit | account_short_code | market | symbol | name | review_type | review_detail | severity | related_ids | source_trace
R2: 2026-03-17 | 资产单元-B | acct-B2 | 沪A | 603Y21 | 云湾机械 | cash_dividend_missing | Expected cash dividend 40.00 CNY for 500 shares at record date, but no cash receipt line in cash_ledger | high | CA-CA-0316-SH-05; DIV7716-0317-603Y21 | corporate_actions.xlsx; cash_ledger.csv; broker_statement.xlsx
R3: 2026-03-17 | 资产单元-C | acct-C5 | 沪A | 601V03 |  | price_missing | No closing price available for 601V03; market value and unrealized P&L left blank | high |  | closing_prices.csv; security_balance_changes.xlsx
R4: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Q17 | 昱航智能 | post_record_date_trade_no_entitlement | Trade on 2026-03-17 (after record date 2026-03-13, ex-right date 2026-03-16) does not qualify for corporate action CA-0316-SZ-09 | review | 45A019883 | trade_fills.xlsx; corporate_actions.xlsx
R5: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Q17 | 昱航智能 | post_record_date_trade_no_entitlement | Trade on 2026-03-17 (after record date 2026-03-13, ex-right date 2026-03-16) does not qualify for corporate action CA-0316-SZ-09 | review | 45A019914 | trade_fills.xlsx; corporate_actions.xlsx
R6: 2026-03-17 | 资产单元-B | acct-B2 | 沪A | 600R42 | 瑞岭材料 | rejected_order_no_fill | Order 2198770045 rejected/not submitted: 废单 | review | 2198770045 | order_history.csv
R7: 2026-03-17 | 资产单元-C | acct-C5 | 沪A | 601V03 | 南谷电气 | rejected_order_no_fill | Order 3142609901 rejected/not submitted: 未报成功 | review | 3142609901 | order_history.csv
R8: 2026-03-17 | 资产单元-D | acct-D4 | 深A | 002D31 | 东环电气 | post_record_date_trade_no_entitlement | Trade on 2026-03-16 (after record date 2026-03-14, ex-right date 2026-03-16) does not qualify for corporate action CA-0316-SZ-02 | review | 16D310044 | trade_fills.xlsx; corporate_actions.xlsx
R9: 2026-03-17 | 资产单元-D | acct-D4 | 深A | 002N55 | 北岚食品 | post_record_date_trade_no_entitlement | Trade on 2026-03-17 (after record date 2026-03-12, ex-right date 2026-03-17) does not qualify for corporate action CA-0317-SZ-18 | review | D4-TRAIL-01 | trade_fills.xlsx; corporate_actions.xlsx
R10: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 002M08 | 明澈医药 | order_partial_cancel | Order 7724003188 partially filled (300) and remaining cancelled (200) | info | 7724003188 | order_history.csv
R11: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 002M08 |  | pending_settlement_cash | 卖出清算: 3993.00 CNY pending settlement | info | 77K450031 | cash_ledger.csv
R12: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 002M08 |  | pending_settlement_cash | 佣金: 1.20 CNY pending settlement | info | 77K450031 | cash_ledger.csv
R13: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 002M08 |  | pending_settlement_cash | 印花税: 3.99 CNY pending settlement | info | 77K450031 | cash_ledger.csv
R14: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 002M08 |  | pending_settlement_cash | 过户费: 0.04 CNY pending settlement | info | 77K450031 | cash_ledger.csv
R15: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Q17 | 昱航智能 | order_partial_cancel | Order 5300198421 partially filled (500) and remaining cancelled (150) | info | 5300198421 | order_history.csv
R16: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Q17 |  | pending_settlement_cash | 买入清算: 9308.00 CNY pending settlement | info | 45A019883;45A019914 | cash_ledger.csv
R17: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Q17 | 昱航智能 | pending_settlement_security | Pending settlement quantity: 500 shares | info | BAL-0317-A7-Q17 | security_balance_changes.xlsx
R18: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Z88 | 泽川软件 | order_partial_cancel | Order 4400276198 partially filled (150) and remaining cancelled (50) | info | 4400276198 | order_history.csv
R19: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Z88 |  | pending_settlement_cash | 卖出清算: 4188.00 CNY pending settlement | info | 88Z120044 | cash_ledger.csv
R20: 2026-03-17 | 资产单元-A | acct-A7 | 深A | 300Z88 | 泽川软件 | pending_settlement_security | Pending settlement quantity: -150 shares | info | BAL-0317-A7-Z88 | security_balance_changes.xlsx
R21: 2026-03-17 | 资产单元-B | acct-B2 | 沪A | 600R42 |  | pending_settlement_cash | 买入清算: 1948.00 CNY pending settlement | info | 601-884210 | cash_ledger.csv
R22: 2026-03-17 | 资产单元-B | acct-B2 | 沪A | 600R42 |  | pending_settlement_cash | 佣金: 0.58 CNY pending settlement | info | 601-884210 | cash_ledger.csv
R23: 2026-03-17 | 资产单元-B | acct-B2 | 沪A | 600R42 |  | pending_settlement_cash | 过户费: 0.02 CNY pending settlement | info | 601-884210 | cash_ledger.csv
R24: 2026-03-17 | 资产单元-B | acct-B2 | 沪A | 600R42 | 瑞岭材料 | pending_settlement_security | Pending settlement quantity: 200 shares | info | BAL-0317-B2-R42 | security_balance_changes.xlsx
R25: 2026-03-17 | 资产单元-B | acct-B2 | 科创板 | 688T66 | 凌川电子 | corrected_fill_applied | Original fill 90D711028 cancelled, replaced by fill 90D7110R1 | info | 90D711028; 90D7110R1 | trade_fills.xlsx
R26: 2026-03-17 | 资产单元-B | acct-B2 | 科创板 | 688T66 | 凌川电子 | corrected_fill_applied | Original fill 90D711028 cancelled, replaced by fill 90D711104 | info | 90D711028; 90D711104 | trade_fills.xlsx
R27: 2026-03-17 | 资产单元-B | acct-B2 | 科创板 | 688T66 |  | pending_settlement_cash | 卖出清算: 5409.60 CNY pending settlement | info | 90D711104 | cash_ledger.csv
R28: 2026-03-17 | 资产单元-B | acct-B2 | 科创板 | 688T66 |  | pending_settlement_cash | 佣金: 1.62 CNY pending settlement | info | 90D711104 | cash_ledger.csv
R29: 2026-03-17 | 资产单元-B | acct-B2 | 科创板 | 688T66 |  | pending_settlement_cash | 印花税: 5.41 CNY pending settlement | info | 90D711104 | cash_ledger.csv
R30: 2026-03-17 | 资产单元-B | acct-B2 | 科创板 | 688T66 |  | pending_settlement_cash | 过户费: 0.05 CNY pending settlement | info | 90D711104 | cash_ledger.csv
R31: 2026-03-17 | 资产单元-D | acct-D4 | 深A | 002D31 |  | bonus_share_applied | Bonus shares applied correctly: 200 shares | info | CA-CA-0316-SZ-02; SB-SB260316-002D31-01 | corporate_actions.xlsx; security_balance_changes.xlsx
