# Workbook: indicator_workbook.xlsx

## Sheet 1: indicator_by_date
Dimensions: 161 rows x 14 columns
R1: ts_code | trade_date | review_time | close | ma20 | prev_trade_date | prev_ma20 | ma20_slope | tr | atr14 | close_vs_ma | history_status | session_label | base_signal
R2: FQ1001.SZ | 2026-04-17 | 15:00 | 20.56 | 19.397 | 2026-04-16 | 19.277 | 0.12 | 0.55 | 0.5471 | >= MA20 | sufficient | PM_EOD | qualified_signal
R3: FQ1002.SH | 2026-04-17 | 15:00 | 41.18 | 41.652 | 2026-04-16 | 41.705 | -0.053 | 0.73 | 0.7579 | < MA20 | sufficient | PM_EOD | no_signal
R4: FQ1003.SZ | 2026-04-17 | 15:00 | 11.03 | 10.312 | 2026-04-16 | 10.239 | 0.073 | 0.42 | 0.42 | >= MA20 | sufficient | PM_EOD | qualified_signal
R5: FQ1004.SH | 2026-04-17 | 15:00 | 27.25 | 27.25 | 2026-04-16 | 27.25 | 0 | 0.41 | 0.4157 | >= MA20 | sufficient | PM_EOD | watch_only
R6: FQ1005.SZ | 2026-04-17 | 15:00 | 13.81 |  | 2026-04-16 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R7: FQ1006.SH | 2026-04-17 | 15:00 | 31.61 |  | 2026-04-16 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R8: FQ1007.SZ | 2026-04-17 | 15:00 | 23.53 | 22.712 | 2026-04-16 | 22.6285 | 0.0835 | 0.45 | 0.4486 | >= MA20 | sufficient | PM_EOD | qualified_signal
R9: FQ1008.SH | 2026-04-17 | 15:00 | 35.41 | 35.6635 | 2026-04-16 | 35.6935 | -0.03 | 0.48 | 0.5071 | < MA20 | sufficient | PM_EOD | no_signal
R10: FQ1001.SZ | 2026-04-20 | 15:00 | 20.59 | 19.5115 | 2026-04-17 | 19.397 | 0.1145 | 0.57 | 0.5421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R11: FQ1002.SH | 2026-04-20 | 15:00 | 41.03 | 41.593 | 2026-04-17 | 41.652 | -0.059 | 0.75 | 0.7621 | < MA20 | sufficient | PM_EOD | no_signal
R12: FQ1003.SZ | 2026-04-20 | 15:00 | 11.09 | 10.3835 | 2026-04-17 | 10.312 | 0.0715 | 0.44 | 0.4179 | >= MA20 | sufficient | PM_EOD | qualified_signal
R13: FQ1004.SH | 2026-04-20 | 15:00 | 27.25 | 27.25 | 2026-04-17 | 27.25 | 0 | 0.43 | 0.415 | >= MA20 | sufficient | PM_EOD | watch_only
R14: FQ1005.SZ | 2026-04-20 | 15:00 | 13.89 |  | 2026-04-17 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R15: FQ1006.SH | 2026-04-20 | 15:00 | 31.73 |  | 2026-04-17 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R16: FQ1007.SZ | 2026-04-20 | 15:00 | 23.52 | 22.79 | 2026-04-17 | 22.712 | 0.078 | 0.47 | 0.4443 | >= MA20 | sufficient | PM_EOD | qualified_signal
R17: FQ1008.SH | 2026-04-20 | 15:00 | 35.29 | 35.628 | 2026-04-17 | 35.6635 | -0.0355 | 0.5 | 0.5107 | < MA20 | sufficient | PM_EOD | no_signal
R18: FQ1001.SZ | 2026-04-21 | 15:00 | 20.72 | 19.6255 | 2026-04-20 | 19.5115 | 0.114 | 0.48 | 0.5414 | >= MA20 | sufficient | PM_EOD | qualified_signal
R19: FQ1002.SH | 2026-04-21 | 15:00 | 41 | 41.5345 | 2026-04-20 | 41.593 | -0.0585 | 0.78 | 0.7614 | < MA20 | sufficient | PM_EOD | no_signal
R20: FQ1003.SZ | 2026-04-21 | 15:00 | 11.1 | 10.451 | 2026-04-20 | 10.3835 | 0.0675 | 0.37 | 0.4143 | >= MA20 | sufficient | PM_EOD | qualified_signal
R21: FQ1004.SH | 2026-04-21 | 15:00 | 27.25 | 27.25 | 2026-04-20 | 27.25 | 0 | 0.4 | 0.4143 | >= MA20 | sufficient | PM_EOD | watch_only
R22: FQ1005.SZ | 2026-04-21 | 15:00 | 14.02 | 13.381 | 2026-04-20 | 13.3155 | 0.0655 | 0.45 | 0.4429 | >= MA20 | sufficient | PM_EOD | qualified_signal
R23: FQ1006.SH | 2026-04-21 | 15:00 | 31.73 |  | 2026-04-20 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R24: FQ1007.SZ | 2026-04-21 | 15:00 | 23.62 | 22.868 | 2026-04-20 | 22.79 | 0.078 | 0.39 | 0.4436 | >= MA20 | sufficient | PM_EOD | qualified_signal
R25: FQ1008.SH | 2026-04-21 | 15:00 | 35.27 | 35.592 | 2026-04-20 | 35.628 | -0.036 | 0.53 | 0.51 | < MA20 | sufficient | PM_EOD | no_signal
R26: FQ1001.SZ | 2026-04-22 | 15:00 | 20.86 | 19.7455 | 2026-04-21 | 19.6255 | 0.12 | 0.56 | 0.5471 | >= MA20 | sufficient | PM_EOD | qualified_signal
R27: FQ1002.SH | 2026-04-22 | 15:00 | 40.96 | 41.4815 | 2026-04-21 | 41.5345 | -0.053 | 0.74 | 0.8214 | < MA20 | sufficient | PM_EOD | no_signal
R28: FQ1003.SZ | 2026-04-22 | 15:00 | 11.19 | 10.524 | 2026-04-21 | 10.451 | 0.073 | 0.43 | 0.4186 | >= MA20 | sufficient | PM_EOD | qualified_signal
R29: FQ1004.SH | 2026-04-22 | 15:00 | 27.25 | 27.25 | 2026-04-21 | 27.25 | 0 | 0.42 | 0.4157 | >= MA20 | sufficient | PM_EOD | watch_only
R30: FQ1005.SZ | 2026-04-22 | 15:00 | 14.05 | 13.4465 | 2026-04-21 | 13.381 | 0.0655 | 0.45 | 0.44 | >= MA20 | sufficient | PM_EOD | qualified_signal
R31: FQ1006.SH | 2026-04-22 | 15:00 | 31.84 |  | 2026-04-21 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R32: FQ1007.SZ | 2026-04-22 | 15:00 | 23.72 | 22.9515 | 2026-04-21 | 22.868 | 0.0835 | 0.46 | 0.4486 | >= MA20 | sufficient | PM_EOD | qualified_signal
R33: FQ1008.SH | 2026-04-22 | 15:00 | 35.26 | 35.562 | 2026-04-21 | 35.592 | -0.03 | 0.49 | 0.5071 | < MA20 | sufficient | PM_EOD | no_signal
R34: FQ1001.SZ | 2026-04-23 | 15:00 | 21 | 19.8655 | 2026-04-22 | 19.7455 | 0.12 | 0.56 | 0.5464 | >= MA20 | sufficient | PM_EOD | qualified_signal
R35: FQ1002.SH | 2026-04-23 | 15:00 | 40.92 | 41.428 | 2026-04-22 | 41.4815 | -0.0535 | 0.74 | 0.8843 | < MA20 | sufficient | PM_EOD | no_signal
R36: FQ1003.SZ | 2026-04-23 | 15:00 | 11.28 | 10.597 | 2026-04-22 | 10.524 | 0.073 | 0.43 | 0.4179 | >= MA20 | sufficient | PM_EOD | qualified_signal
R37: FQ1004.SH | 2026-04-23 | 15:00 | 27.25 | 27.25 | 2026-04-22 | 27.25 | 0 | 0.42 | 0.415 | >= MA20 | sufficient | PM_EOD | watch_only
R38: FQ1005.SZ | 2026-04-23 | 15:00 | 14.13 | 13.512 | 2026-04-22 | 13.4465 | 0.0655 | 0.44 | 0.4393 | >= MA20 | sufficient | PM_EOD | qualified_signal
R39: FQ1006.SH | 2026-04-23 | 15:00 | 31.96 |  | 2026-04-22 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R40: FQ1007.SZ | 2026-04-23 | 15:00 | 23.82 | 23.035 | 2026-04-22 | 22.9515 | 0.0835 | 0.46 | 0.4479 | >= MA20 | sufficient | PM_EOD | qualified_signal
R41: FQ1008.SH | 2026-04-23 | 15:00 | 35.25 | 35.532 | 2026-04-22 | 35.562 | -0.03 | 0.49 | 0.5064 | < MA20 | sufficient | PM_EOD | no_signal
R42: FQ1001.SZ | 2026-04-24 | 15:00 | 21.13 | 19.9815 | 2026-04-23 | 19.8655 | 0.116 | 0.55 | 0.5421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R43: FQ1001.SZ | 2026-04-24 | 11:30 | 21.05 | 19.9815 | 2026-04-23 | 19.8655 | 0.116 | 0.55 | 0.5421 | >= MA20 | sufficient | AM_MID | qualified_signal
R44: FQ1002.SH | 2026-04-24 | 15:00 | 40.71 | 41.3695 | 2026-04-23 | 41.428 | -0.0585 | 0.73 | 0.8879 | < MA20 | sufficient | PM_EOD | no_signal
R45: FQ1002.SH | 2026-04-24 | 11:30 | 40.78 | 41.3695 | 2026-04-23 | 41.428 | -0.0585 | 0.73 | 0.8879 | < MA20 | sufficient | AM_MID | no_signal
R46: FQ1003.SZ | 2026-04-24 | 15:00 | 11.36 | 10.6655 | 2026-04-23 | 10.597 | 0.0685 | 0.42 | 0.4136 | >= MA20 | sufficient | PM_EOD | qualified_signal
R47: FQ1003.SZ | 2026-04-24 | 11:30 | 11.28 | 10.6655 | 2026-04-23 | 10.597 | 0.0685 | 0.42 | 0.4136 | >= MA20 | sufficient | AM_MID | qualified_signal
R48: FQ1004.SH | 2026-04-24 | 15:00 | 27.25 | 27.2535 | 2026-04-23 | 27.25 | 0.0035 | 0.41 | 0.4171 | < MA20 | sufficient | PM_EOD | no_signal
R49: FQ1004.SH | 2026-04-24 | 11:30 | 27.32 | 27.2535 | 2026-04-23 | 27.25 | 0.0035 | 0.41 | 0.4171 | >= MA20 | sufficient | AM_MID | qualified_signal
R50: FQ1005.SZ | 2026-04-24 | 15:00 | 14.22 | 13.574 | 2026-04-23 | 13.512 | 0.062 | 0.47 | 0.4379 | >= MA20 | sufficient | PM_EOD | qualified_signal
R51: FQ1005.SZ | 2026-04-24 | 11:30 | 14.14 | 13.574 | 2026-04-23 | 13.512 | 0.062 | 0.47 | 0.4379 | >= MA20 | sufficient | AM_MID | qualified_signal
R52: FQ1006.SH | 2026-04-24 | 15:00 | 32.07 |  | 2026-04-23 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R53: FQ1006.SH | 2026-04-24 | 11:30 | 32.14 |  | 2026-04-23 |  |  |  |  |  | insufficient_history | AM_MID | insufficient_history
R54: FQ1007.SZ | 2026-04-24 | 15:00 | 23.92 | 23.1145 | 2026-04-23 | 23.035 | 0.0795 | 0.45 | 0.4436 | >= MA20 | sufficient | PM_EOD | qualified_signal
R55: FQ1007.SZ | 2026-04-24 | 11:30 | 23.84 | 23.1145 | 2026-04-23 | 23.035 | 0.0795 | 0.45 | 0.4436 | >= MA20 | sufficient | AM_MID | qualified_signal
R56: FQ1008.SH | 2026-04-24 | 15:00 | 35.05 | 35.496 | 2026-04-23 | 35.532 | -0.036 | 0.48 | 0.5107 | < MA20 | sufficient | PM_EOD | no_signal
R57: FQ1008.SH | 2026-04-24 | 11:30 | 35.12 | 35.496 | 2026-04-23 | 35.532 | -0.036 | 0.48 | 0.5107 | < MA20 | sufficient | AM_MID | no_signal
R58: FQ1001.SZ | 2026-04-27 | 15:00 | 21.27 | 20.2075 | 2026-04-24 | 19.9815 | 0.226 | 0.57 | 0.5436 | >= MA20 | sufficient | PM_EOD | qualified_signal
R59: FQ1002.SH | 2026-04-27 | 15:00 | 40.85 | 41.258 | 2026-04-24 | 41.3695 | -0.1115 | 0.75 | 0.9007 | < MA20 | sufficient | PM_EOD | no_signal
R60: FQ1003.SZ | 2026-04-27 | 15:00 | 11.53 | 10.8055 | 2026-04-24 | 10.6655 | 0.14 | 0.44 | 0.4186 | >= MA20 | sufficient | PM_EOD | qualified_signal
R61: FQ1004.SH | 2026-04-27 | 15:00 | 27.25 | 27.2535 | 2026-04-24 | 27.2535 | 0 | 0.43 | 0.4186 | < MA20 | sufficient | PM_EOD | no_signal
R62: FQ1005.SZ | 2026-04-27 | 15:00 | 14.19 | 13.6895 | 2026-04-24 | 13.574 | 0.1155 | 0.4 | 0.435 | >= MA20 | sufficient | PM_EOD | qualified_signal
R63: FQ1006.SH | 2026-04-27 | 15:00 | 32.19 |  | 2026-04-24 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R64: FQ1007.SZ | 2026-04-27 | 15:00 | 24.02 | 23.2715 | 2026-04-24 | 23.1145 | 0.157 | 0.47 | 0.445 | >= MA20 | sufficient | PM_EOD | qualified_signal
R65: FQ1008.SH | 2026-04-27 | 15:00 | 35.22 | 35.428 | 2026-04-24 | 35.496 | -0.068 | 0.5 | 0.5264 | < MA20 | sufficient | PM_EOD | no_signal
R66: FQ1001.SZ | 2026-04-28 | 15:00 | 21.29 | 20.315 | 2026-04-27 | 20.2075 | 0.1075 | 0.48 | 0.5364 | >= MA20 | sufficient | PM_EOD | qualified_signal
R67: FQ1002.SH | 2026-04-28 | 15:00 | 40.7 | 41.201 | 2026-04-27 | 41.258 | -0.057 | 0.79 | 0.9036 | < MA20 | sufficient | PM_EOD | no_signal
R68: FQ1003.SZ | 2026-04-28 | 15:00 | 11.44 | 10.8685 | 2026-04-27 | 10.8055 | 0.063 | 0.37 | 0.4164 | >= MA20 | sufficient | PM_EOD | qualified_signal
R69: FQ1004.SH | 2026-04-28 | 15:00 | 27.25 | 27.2535 | 2026-04-27 | 27.2535 | 0 | 0.4 | 0.4164 | < MA20 | sufficient | PM_EOD | no_signal
R70: FQ1005.SZ | 2026-04-28 | 15:00 | 14.32 | 13.7535 | 2026-04-27 | 13.6895 | 0.064 | 0.45 | 0.4407 | >= MA20 | sufficient | PM_EOD | qualified_signal
R71: FQ1006.SH | 2026-04-28 | 15:00 | 32.3 |  | 2026-04-27 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R72: FQ1007.SZ | 2026-04-28 | 15:00 | 24.02 | 23.345 | 2026-04-27 | 23.2715 | 0.0735 | 0.39 | 0.4386 | >= MA20 | sufficient | PM_EOD | qualified_signal
R73: FQ1008.SH | 2026-04-28 | 15:00 | 35.09 | 35.393 | 2026-04-27 | 35.428 | -0.035 | 0.53 | 0.5293 | < MA20 | sufficient | PM_EOD | no_signal
R74: FQ1001.SZ | 2026-04-29 | 15:00 | 21.43 | 20.428 | 2026-04-28 | 20.315 | 0.113 | 0.56 | 0.5421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R75: FQ1002.SH | 2026-04-29 | 15:00 | 40.67 | 41.1495 | 2026-04-28 | 41.201 | -0.0515 | 0.74 | 0.9 | < MA20 | sufficient | PM_EOD | no_signal
R76: FQ1003.SZ | 2026-04-29 | 15:00 | 11.52 | 10.9365 | 2026-04-28 | 10.8685 | 0.068 | 0.43 | 0.4207 | >= MA20 | sufficient | PM_EOD | qualified_signal
R77: FQ1004.SH | 2026-04-29 | 15:00 | 27.25 | 27.2535 | 2026-04-28 | 27.2535 | 0 | 0.42 | 0.4179 | < MA20 | sufficient | PM_EOD | no_signal
R78: FQ1005.SZ | 2026-04-29 | 15:00 | 14.35 | 13.815 | 2026-04-28 | 13.7535 | 0.0615 | 0.45 | 0.4386 | >= MA20 | sufficient | PM_EOD | qualified_signal
R79: FQ1006.SH | 2026-04-29 | 15:00 | 32.31 |  | 2026-04-28 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R80: FQ1007.SZ | 2026-04-29 | 15:00 | 24.12 | 23.424 | 2026-04-28 | 23.345 | 0.079 | 0.46 | 0.4436 | >= MA20 | sufficient | PM_EOD | qualified_signal
R81: FQ1008.SH | 2026-04-29 | 15:00 | 35.08 | 35.3635 | 2026-04-28 | 35.393 | -0.0295 | 0.49 | 0.5264 | < MA20 | sufficient | PM_EOD | no_signal
R82: FQ1001.SZ | 2026-04-30 | 15:00 | 21.57 | 20.541 | 2026-04-29 | 20.428 | 0.113 | 0.56 | 0.5421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R83: FQ1002.SH | 2026-04-30 | 15:00 | 40.63 | 41.098 | 2026-04-29 | 41.1495 | -0.0515 | 0.74 | 0.9 | < MA20 | sufficient | PM_EOD | no_signal
R84: FQ1003.SZ | 2026-04-30 | 15:00 | 11.61 | 11.0045 | 2026-04-29 | 10.9365 | 0.068 | 0.43 | 0.4207 | >= MA20 | sufficient | PM_EOD | qualified_signal
R85: FQ1004.SH | 2026-04-30 | 15:00 | 27.25 | 27.2535 | 2026-04-29 | 27.2535 | 0 | 0.42 | 0.4179 | < MA20 | sufficient | PM_EOD | no_signal
R86: FQ1005.SZ | 2026-04-30 | 15:00 | 14.44 | 13.877 | 2026-04-29 | 13.815 | 0.062 | 0.47 | 0.4379 | >= MA20 | sufficient | PM_EOD | qualified_signal
R87: FQ1006.SH | 2026-04-30 | 15:00 | 32.42 |  | 2026-04-29 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R88: FQ1007.SZ | 2026-04-30 | 15:00 | 24.21 | 23.5025 | 2026-04-29 | 23.424 | 0.0785 | 0.46 | 0.4429 | >= MA20 | sufficient | PM_EOD | qualified_signal
R89: FQ1008.SH | 2026-04-30 | 15:00 | 35.07 | 35.334 | 2026-04-29 | 35.3635 | -0.0295 | 0.49 | 0.5264 | < MA20 | sufficient | PM_EOD | no_signal
R90: FQ1001.SZ | 2026-05-05 | 15:00 | 21.7 | 20.654 | 2026-04-30 | 20.541 | 0.113 | 0.55 | 0.5414 | >= MA20 | sufficient | PM_EOD | qualified_signal
R91: FQ1002.SH | 2026-05-05 | 15:00 | 40.59 | 41.0465 | 2026-04-30 | 41.098 | -0.0515 | 0.84 | 0.8993 | < MA20 | sufficient | PM_EOD | no_signal
R92: FQ1003.SZ | 2026-05-05 | 15:00 | 11.78 | 11.077 | 2026-04-30 | 11.0045 | 0.0725 | 0.42 | 0.4236 | >= MA20 | sufficient | PM_EOD | qualified_signal
R93: FQ1004.SH | 2026-05-05 | 15:00 | 27.25 | 27.2535 | 2026-04-30 | 27.2535 | 0 | 0.41 | 0.4171 | < MA20 | sufficient | PM_EOD | no_signal
R94: FQ1005.SZ | 2026-05-05 | 15:00 | 14.52 | 13.9385 | 2026-04-30 | 13.877 | 0.0615 | 0.41 | 0.4357 | >= MA20 | sufficient | PM_EOD | qualified_signal
R95: FQ1006.SH | 2026-05-05 | 15:00 | 32.53 |  | 2026-04-30 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R96: FQ1007.SZ | 2026-05-05 | 15:00 | 24.32 | 23.5815 | 2026-04-30 | 23.5025 | 0.079 | 0.45 | 0.4421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R97: FQ1008.SH | 2026-05-05 | 15:00 | 35.05 | 35.3045 | 2026-04-30 | 35.334 | -0.0295 | 0.58 | 0.5257 | < MA20 | sufficient | PM_EOD | no_signal
R98: FQ1001.SZ | 2026-05-06 | 15:00 | 21.84 | 20.767 | 2026-05-05 | 20.654 | 0.113 | 0.55 | 0.5414 | >= MA20 | sufficient | PM_EOD | qualified_signal
R99: FQ1002.SH | 2026-05-06 | 15:00 | 40.56 | 40.9955 | 2026-05-05 | 41.0465 | -0.051 | 0.8 | 0.8914 | < MA20 | sufficient | PM_EOD | no_signal
R100: FQ1003.SZ | 2026-05-06 | 15:00 | 11.79 | 11.1455 | 2026-05-05 | 11.077 | 0.0685 | 0.42 | 0.4207 | >= MA20 | sufficient | PM_EOD | qualified_signal
R101: FQ1004.SH | 2026-05-06 | 15:00 | 27.25 | 27.2535 | 2026-05-05 | 27.2535 | 0 | 0.41 | 0.4171 | < MA20 | sufficient | PM_EOD | no_signal
R102: FQ1005.SZ | 2026-05-06 | 15:00 | 14.6 | 13.9975 | 2026-05-05 | 13.9385 | 0.059 | 0.46 | 0.4393 | >= MA20 | sufficient | PM_EOD | qualified_signal
R103: FQ1006.SH | 2026-05-06 | 15:00 | 32.65 |  | 2026-05-05 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R104: FQ1007.SZ | 2026-05-06 | 15:00 | 24.42 | 23.6605 | 2026-05-05 | 23.5815 | 0.079 | 0.45 | 0.4421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R105: FQ1008.SH | 2026-05-06 | 15:00 | 35.04 | 35.275 | 2026-05-05 | 35.3045 | -0.0295 | 0.56 | 0.5186 | < MA20 | sufficient | PM_EOD | no_signal
R106: FQ1001.SZ | 2026-05-07 | 15:00 | 21.98 | 20.88 | 2026-05-06 | 20.767 | 0.113 | 0.57 | 0.5429 | >= MA20 | sufficient | PM_EOD | qualified_signal
R107: FQ1002.SH | 2026-05-07 | 15:00 | 40.34 | 40.935 | 2026-05-06 | 40.9955 | -0.0605 | 0.75 | 0.8957 | < MA20 | sufficient | PM_EOD | no_signal
R108: FQ1003.SZ | 2026-05-07 | 15:00 | 11.88 | 11.214 | 2026-05-06 | 11.1455 | 0.0685 | 0.44 | 0.4221 | >= MA20 | sufficient | PM_EOD | qualified_signal
R109: FQ1004.SH | 2026-05-07 | 15:00 | 27.25 | 27.2535 | 2026-05-06 | 27.2535 | 0 | 0.43 | 0.4186 | < MA20 | sufficient | PM_EOD | no_signal
R110: FQ1005.SZ | 2026-05-07 | 15:00 | 14.62 | 14.056 | 2026-05-06 | 13.9975 | 0.0585 | 0.39 | 0.4343 | >= MA20 | sufficient | PM_EOD | qualified_signal
R111: FQ1006.SH | 2026-05-07 | 15:00 | 32.76 |  | 2026-05-06 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R112: FQ1007.SZ | 2026-05-07 | 15:00 | 24.52 | 23.7395 | 2026-05-06 | 23.6605 | 0.079 | 0.47 | 0.4436 | >= MA20 | sufficient | PM_EOD | qualified_signal
R113: FQ1008.SH | 2026-05-07 | 15:00 | 34.85 | 35.2365 | 2026-05-06 | 35.275 | -0.0385 | 0.5 | 0.5214 | < MA20 | sufficient | PM_EOD | no_signal
R114: FQ1001.SZ | 2026-05-08 | 15:00 | 22 | 20.9875 | 2026-05-07 | 20.88 | 0.1075 | 0.48 | 0.5357 | >= MA20 | sufficient | PM_EOD | qualified_signal
R115: FQ1002.SH | 2026-05-08 | 15:00 | 40.38 | 40.8785 | 2026-05-07 | 40.935 | -0.0565 | 0.79 | 0.8936 | < MA20 | sufficient | PM_EOD | no_signal
R116: FQ1003.SZ | 2026-05-08 | 15:00 | 11.86 | 11.277 | 2026-05-07 | 11.214 | 0.063 | 0.39 | 0.4171 | >= MA20 | sufficient | PM_EOD | qualified_signal
R117: FQ1004.SH | 2026-05-08 | 15:00 | 27.25 | 27.2535 | 2026-05-07 | 27.2535 | 0 | 0.4 | 0.4164 | < MA20 | sufficient | PM_EOD | no_signal
R118: FQ1005.SZ | 2026-05-08 | 15:00 | 14.66 | 14.118 | 2026-05-07 | 14.056 | 0.062 | 0.45 | 0.4971 | >= MA20 | sufficient | PM_EOD | qualified_signal
R119: FQ1006.SH | 2026-05-08 | 15:00 | 32.88 |  | 2026-05-07 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R120: FQ1007.SZ | 2026-05-08 | 15:00 | 24.51 | 23.813 | 2026-05-07 | 23.7395 | 0.0735 | 0.39 | 0.4379 | >= MA20 | sufficient | PM_EOD | qualified_signal
R121: FQ1008.SH | 2026-05-08 | 15:00 | 34.9 | 35.2015 | 2026-05-07 | 35.2365 | -0.035 | 0.53 | 0.5207 | < MA20 | sufficient | PM_EOD | no_signal
R122: FQ1001.SZ | 2026-05-11 | 15:00 | 22.14 | 21.1005 | 2026-05-08 | 20.9875 | 0.113 | 0.56 | 0.5414 | >= MA20 | sufficient | PM_EOD | qualified_signal
R123: FQ1002.SH | 2026-05-11 | 15:00 | 40.34 | 40.8275 | 2026-05-08 | 40.8785 | -0.051 | 0.74 | 0.89 | < MA20 | sufficient | PM_EOD | no_signal
R124: FQ1003.SZ | 2026-05-11 | 15:00 | 11.95 | 11.3455 | 2026-05-08 | 11.277 | 0.0685 | 0.39 | 0.42 | >= MA20 | sufficient | PM_EOD | qualified_signal
R125: FQ1004.SH | 2026-05-11 | 15:00 | 27.25 | 27.2535 | 2026-05-08 | 27.2535 | 0 | 0.42 | 0.4179 | < MA20 | sufficient | PM_EOD | no_signal
R126: FQ1005.SZ | 2026-05-11 | 15:00 | 14.74 | 14.1795 | 2026-05-08 | 14.118 | 0.0615 | 0.48 | 0.5579 | >= MA20 | sufficient | PM_EOD | qualified_signal
R127: FQ1006.SH | 2026-05-11 | 15:00 | 32.88 |  | 2026-05-08 |  |  |  |  |  | insufficient_history | PM_EOD | insufficient_history
R128: FQ1007.SZ | 2026-05-11 | 15:00 | 24.61 | 23.892 | 2026-05-08 | 23.813 | 0.079 | 0.46 | 0.4429 | >= MA20 | sufficient | PM_EOD | qualified_signal
R129: FQ1008.SH | 2026-05-11 | 15:00 | 34.89 | 35.172 | 2026-05-08 | 35.2015 | -0.0295 | 0.49 | 0.5179 | < MA20 | sufficient | PM_EOD | no_signal
R130: FQ1001.SZ | 2026-05-12 | 15:00 | 22.27 | 21.213 | 2026-05-11 | 21.1005 | 0.1125 | 0.56 | 0.5414 | >= MA20 | sufficient | PM_EOD | qualified_signal
R131: FQ1002.SH | 2026-05-12 | 15:00 | 40.3 | 40.776 | 2026-05-11 | 40.8275 | -0.0515 | 1.62 | 0.89 | < MA20 | sufficient | PM_EOD | no_signal
R132: FQ1003.SZ | 2026-05-12 | 15:00 | 12.04 | 11.414 | 2026-05-11 | 11.3455 | 0.0685 | 0.43 | 0.4229 | >= MA20 | sufficient | PM_EOD | qualified_signal
R133: FQ1004.SH | 2026-05-12 | 15:00 | 27.25 | 27.2535 | 2026-05-11 | 27.2535 | 0 | 0.42 | 0.4179 | < MA20 | sufficient | PM_EOD | no_signal
R134: FQ1005.SZ | 2026-05-12 | 15:00 | 14.82 | 14.241 | 2026-05-11 | 14.1795 | 0.0615 | 0.41 | 0.555 | >= MA20 | sufficient | PM_EOD | qualified_signal
R135: FQ1006.SH | 2026-05-12 | 15:00 | 33 | 32.1575 | 2026-05-11 | 32.065 | 0.0925 | 0.66 | 0.6536 | >= MA20 | sufficient | PM_EOD | qualified_signal
R136: FQ1007.SZ | 2026-05-12 | 15:00 | 24.71 | 23.971 | 2026-05-11 | 23.892 | 0.079 | 0.46 | 0.4429 | >= MA20 | sufficient | PM_EOD | qualified_signal
R137: FQ1008.SH | 2026-05-12 | 15:00 | 34.88 | 35.1425 | 2026-05-11 | 35.172 | -0.0295 | 0.49 | 0.5179 | < MA20 | sufficient | PM_EOD | no_signal
R138: FQ1001.SZ | 2026-05-13 | 15:00 | 22.41 | 21.326 | 2026-05-12 | 21.213 | 0.113 | 0.55 | 0.5407 | >= MA20 | sufficient | PM_EOD | qualified_signal
R139: FQ1002.SH | 2026-05-13 | 15:00 | 40.26 | 40.7245 | 2026-05-12 | 40.776 | -0.0515 | 1.62 | 0.8264 | < MA20 | sufficient | PM_EOD | no_signal
R140: FQ1003.SZ | 2026-05-13 | 15:00 | 12.13 | 11.4825 | 2026-05-12 | 11.414 | 0.0685 | 0.42 | 0.4221 | >= MA20 | sufficient | PM_EOD | qualified_signal
R141: FQ1004.SH | 2026-05-13 | 15:00 | 27.25 | 27.2535 | 2026-05-12 | 27.2535 | 0 | 0.41 | 0.4171 | < MA20 | sufficient | PM_EOD | no_signal
R142: FQ1005.SZ | 2026-05-13 | 15:00 | 14.9 | 14.3 | 2026-05-12 | 14.241 | 0.059 | 0.44 | 0.5571 | >= MA20 | sufficient | PM_EOD | qualified_signal
R143: FQ1006.SH | 2026-05-13 | 15:00 | 33.11 | 32.2495 | 2026-05-12 | 32.1575 | 0.092 | 0.67 | 0.6536 | >= MA20 | sufficient | PM_EOD | qualified_signal
R144: FQ1007.SZ | 2026-05-13 | 15:00 | 24.81 | 24.05 | 2026-05-12 | 23.971 | 0.079 | 0.45 | 0.4421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R145: FQ1008.SH | 2026-05-13 | 15:00 | 34.86 | 35.113 | 2026-05-12 | 35.1425 | -0.0295 | 0.48 | 0.5171 | < MA20 | sufficient | PM_EOD | no_signal
R146: FQ1001.SZ | 2026-05-14 | 15:00 | 22.55 | 21.439 | 2026-05-13 | 21.326 | 0.113 | 0.5 | 0.5407 | >= MA20 | sufficient | PM_EOD | qualified_signal
R147: FQ1002.SH | 2026-05-14 | 15:00 | 40.23 | 40.6825 | 2026-05-13 | 40.7245 | -0.042 | 0.79 | 0.7629 | < MA20 | sufficient | PM_EOD | no_signal
R148: FQ1003.SZ | 2026-05-14 | 15:00 | 12.22 | 11.551 | 2026-05-13 | 11.4825 | 0.0685 | 0.37 | 0.4221 | >= MA20 | sufficient | PM_EOD | qualified_signal
R149: FQ1004.SH | 2026-05-14 | 15:00 | 27.25 | 27.2535 | 2026-05-13 | 27.2535 | 0 | 0.45 | 0.4171 | < MA20 | sufficient | PM_EOD | no_signal
R150: FQ1005.SZ | 2026-05-14 | 15:00 | 15.04 | 14.3645 | 2026-05-13 | 14.3 | 0.0645 | 0.42 | 0.5607 | >= MA20 | sufficient | PM_EOD | qualified_signal
R151: FQ1006.SH | 2026-05-14 | 15:00 | 33.23 | 32.342 | 2026-05-13 | 32.2495 | 0.0925 | 0.69 | 0.6529 | >= MA20 | sufficient | PM_EOD | qualified_signal
R152: FQ1007.SZ | 2026-05-14 | 15:00 | 24.91 | 24.129 | 2026-05-13 | 24.05 | 0.079 | 0.4 | 0.4421 | >= MA20 | sufficient | PM_EOD | qualified_signal
R153: FQ1008.SH | 2026-05-14 | 15:00 | 34.85 | 35.0925 | 2026-05-13 | 35.113 | -0.0205 | 0.55 | 0.5171 | < MA20 | sufficient | PM_EOD | no_signal
R154: FQ1001.SZ | 2026-05-15 | 15:00 | 22.68 | 21.552 | 2026-05-14 | 21.439 | 0.113 | 0.55 | 0.5457 | >= MA20 | sufficient | PM_EOD | qualified_signal
R155: FQ1002.SH | 2026-05-15 | 15:00 | 40.19 | 40.631 | 2026-05-14 | 40.6825 | -0.0515 | 0.83 | 0.76 | < MA20 | sufficient | PM_EOD | no_signal
R156: FQ1003.SZ | 2026-05-15 | 15:00 | 12.31 | 11.6195 | 2026-05-14 | 11.551 | 0.0685 | 0.42 | 0.4271 | >= MA20 | sufficient | PM_EOD | qualified_signal
R157: FQ1004.SH | 2026-05-15 | 15:00 | 27.25 | 27.2535 | 2026-05-14 | 27.2535 | 0 | 0.41 | 0.4157 | < MA20 | sufficient | PM_EOD | no_signal
R158: FQ1005.SZ | 2026-05-15 | 15:00 | 14.96 | 14.421 | 2026-05-14 | 14.3645 | 0.0565 | 0.46 | 0.5614 | >= MA20 | sufficient | PM_EOD | qualified_signal
R159: FQ1006.SH | 2026-05-15 | 15:00 | 33.34 | 32.434 | 2026-05-14 | 32.342 | 0.092 | 0.65 | 0.65 | >= MA20 | sufficient | PM_EOD | qualified_signal
R160: FQ1007.SZ | 2026-05-15 | 15:00 | 25.01 | 24.208 | 2026-05-14 | 24.129 | 0.079 | 0.45 | 0.4471 | >= MA20 | sufficient | PM_EOD | qualified_signal
R161: FQ1008.SH | 2026-05-15 | 15:00 | 34.83 | 35.063 | 2026-05-14 | 35.0925 | -0.0295 | 0.59 | 0.5136 | < MA20 | sufficient | PM_EOD | no_signal

## Sheet 2: signals
Dimensions: 161 rows x 6 columns
R1: ts_code | trade_date | review_time | base_signal | signal_reason | threshold_case
R2: FQ1001.SZ | 2026-04-17 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R3: FQ1002.SH | 2026-04-17 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R4: FQ1003.SZ | 2026-04-17 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R5: FQ1004.SH | 2026-04-17 | 15:00 | watch_only | 收盘价不低于MA20但MA20未较上一交易日上行 | close >= MA20 and MA20 <= prev_MA20
R6: FQ1005.SZ | 2026-04-17 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R7: FQ1006.SH | 2026-04-17 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R8: FQ1007.SZ | 2026-04-17 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R9: FQ1008.SH | 2026-04-17 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R10: FQ1001.SZ | 2026-04-20 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R11: FQ1002.SH | 2026-04-20 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R12: FQ1003.SZ | 2026-04-20 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R13: FQ1004.SH | 2026-04-20 | 15:00 | watch_only | 收盘价不低于MA20但MA20未较上一交易日上行 | close >= MA20 and MA20 <= prev_MA20
R14: FQ1005.SZ | 2026-04-20 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R15: FQ1006.SH | 2026-04-20 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R16: FQ1007.SZ | 2026-04-20 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R17: FQ1008.SH | 2026-04-20 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R18: FQ1001.SZ | 2026-04-21 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R19: FQ1002.SH | 2026-04-21 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R20: FQ1003.SZ | 2026-04-21 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R21: FQ1004.SH | 2026-04-21 | 15:00 | watch_only | 收盘价不低于MA20但MA20未较上一交易日上行 | close >= MA20 and MA20 <= prev_MA20
R22: FQ1005.SZ | 2026-04-21 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R23: FQ1006.SH | 2026-04-21 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R24: FQ1007.SZ | 2026-04-21 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R25: FQ1008.SH | 2026-04-21 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R26: FQ1001.SZ | 2026-04-22 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R27: FQ1002.SH | 2026-04-22 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R28: FQ1003.SZ | 2026-04-22 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R29: FQ1004.SH | 2026-04-22 | 15:00 | watch_only | 收盘价不低于MA20但MA20未较上一交易日上行 | close >= MA20 and MA20 <= prev_MA20
R30: FQ1005.SZ | 2026-04-22 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R31: FQ1006.SH | 2026-04-22 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R32: FQ1007.SZ | 2026-04-22 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R33: FQ1008.SH | 2026-04-22 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R34: FQ1001.SZ | 2026-04-23 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R35: FQ1002.SH | 2026-04-23 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R36: FQ1003.SZ | 2026-04-23 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R37: FQ1004.SH | 2026-04-23 | 15:00 | watch_only | 收盘价不低于MA20但MA20未较上一交易日上行 | close >= MA20 and MA20 <= prev_MA20
R38: FQ1005.SZ | 2026-04-23 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R39: FQ1006.SH | 2026-04-23 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R40: FQ1007.SZ | 2026-04-23 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R41: FQ1008.SH | 2026-04-23 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R42: FQ1001.SZ | 2026-04-24 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R43: FQ1001.SZ | 2026-04-24 | 11:30 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R44: FQ1002.SH | 2026-04-24 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R45: FQ1002.SH | 2026-04-24 | 11:30 | no_signal | 收盘价低于MA20 | close < MA20
R46: FQ1003.SZ | 2026-04-24 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R47: FQ1003.SZ | 2026-04-24 | 11:30 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R48: FQ1004.SH | 2026-04-24 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R49: FQ1004.SH | 2026-04-24 | 11:30 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R50: FQ1005.SZ | 2026-04-24 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R51: FQ1005.SZ | 2026-04-24 | 11:30 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R52: FQ1006.SH | 2026-04-24 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R53: FQ1006.SH | 2026-04-24 | 11:30 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R54: FQ1007.SZ | 2026-04-24 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R55: FQ1007.SZ | 2026-04-24 | 11:30 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R56: FQ1008.SH | 2026-04-24 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R57: FQ1008.SH | 2026-04-24 | 11:30 | no_signal | 收盘价低于MA20 | close < MA20
R58: FQ1001.SZ | 2026-04-27 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R59: FQ1002.SH | 2026-04-27 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R60: FQ1003.SZ | 2026-04-27 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R61: FQ1004.SH | 2026-04-27 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R62: FQ1005.SZ | 2026-04-27 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R63: FQ1006.SH | 2026-04-27 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R64: FQ1007.SZ | 2026-04-27 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R65: FQ1008.SH | 2026-04-27 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R66: FQ1001.SZ | 2026-04-28 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R67: FQ1002.SH | 2026-04-28 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R68: FQ1003.SZ | 2026-04-28 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R69: FQ1004.SH | 2026-04-28 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R70: FQ1005.SZ | 2026-04-28 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R71: FQ1006.SH | 2026-04-28 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R72: FQ1007.SZ | 2026-04-28 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R73: FQ1008.SH | 2026-04-28 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R74: FQ1001.SZ | 2026-04-29 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R75: FQ1002.SH | 2026-04-29 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R76: FQ1003.SZ | 2026-04-29 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R77: FQ1004.SH | 2026-04-29 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R78: FQ1005.SZ | 2026-04-29 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R79: FQ1006.SH | 2026-04-29 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R80: FQ1007.SZ | 2026-04-29 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R81: FQ1008.SH | 2026-04-29 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R82: FQ1001.SZ | 2026-04-30 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R83: FQ1002.SH | 2026-04-30 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R84: FQ1003.SZ | 2026-04-30 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R85: FQ1004.SH | 2026-04-30 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R86: FQ1005.SZ | 2026-04-30 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R87: FQ1006.SH | 2026-04-30 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R88: FQ1007.SZ | 2026-04-30 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R89: FQ1008.SH | 2026-04-30 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R90: FQ1001.SZ | 2026-05-05 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R91: FQ1002.SH | 2026-05-05 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R92: FQ1003.SZ | 2026-05-05 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R93: FQ1004.SH | 2026-05-05 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R94: FQ1005.SZ | 2026-05-05 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R95: FQ1006.SH | 2026-05-05 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R96: FQ1007.SZ | 2026-05-05 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R97: FQ1008.SH | 2026-05-05 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R98: FQ1001.SZ | 2026-05-06 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R99: FQ1002.SH | 2026-05-06 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R100: FQ1003.SZ | 2026-05-06 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R101: FQ1004.SH | 2026-05-06 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R102: FQ1005.SZ | 2026-05-06 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R103: FQ1006.SH | 2026-05-06 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R104: FQ1007.SZ | 2026-05-06 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R105: FQ1008.SH | 2026-05-06 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R106: FQ1001.SZ | 2026-05-07 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R107: FQ1002.SH | 2026-05-07 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R108: FQ1003.SZ | 2026-05-07 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R109: FQ1004.SH | 2026-05-07 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R110: FQ1005.SZ | 2026-05-07 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R111: FQ1006.SH | 2026-05-07 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R112: FQ1007.SZ | 2026-05-07 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R113: FQ1008.SH | 2026-05-07 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R114: FQ1001.SZ | 2026-05-08 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R115: FQ1002.SH | 2026-05-08 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R116: FQ1003.SZ | 2026-05-08 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R117: FQ1004.SH | 2026-05-08 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R118: FQ1005.SZ | 2026-05-08 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R119: FQ1006.SH | 2026-05-08 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R120: FQ1007.SZ | 2026-05-08 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R121: FQ1008.SH | 2026-05-08 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R122: FQ1001.SZ | 2026-05-11 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R123: FQ1002.SH | 2026-05-11 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R124: FQ1003.SZ | 2026-05-11 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R125: FQ1004.SH | 2026-05-11 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R126: FQ1005.SZ | 2026-05-11 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R127: FQ1006.SH | 2026-05-11 | 15:00 | insufficient_history | 历史数据不足，无法计算完整指标 | 
R128: FQ1007.SZ | 2026-05-11 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R129: FQ1008.SH | 2026-05-11 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R130: FQ1001.SZ | 2026-05-12 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R131: FQ1002.SH | 2026-05-12 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R132: FQ1003.SZ | 2026-05-12 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R133: FQ1004.SH | 2026-05-12 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R134: FQ1005.SZ | 2026-05-12 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R135: FQ1006.SH | 2026-05-12 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R136: FQ1007.SZ | 2026-05-12 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R137: FQ1008.SH | 2026-05-12 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R138: FQ1001.SZ | 2026-05-13 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R139: FQ1002.SH | 2026-05-13 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R140: FQ1003.SZ | 2026-05-13 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R141: FQ1004.SH | 2026-05-13 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R142: FQ1005.SZ | 2026-05-13 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R143: FQ1006.SH | 2026-05-13 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R144: FQ1007.SZ | 2026-05-13 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R145: FQ1008.SH | 2026-05-13 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R146: FQ1001.SZ | 2026-05-14 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R147: FQ1002.SH | 2026-05-14 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R148: FQ1003.SZ | 2026-05-14 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R149: FQ1004.SH | 2026-05-14 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R150: FQ1005.SZ | 2026-05-14 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R151: FQ1006.SH | 2026-05-14 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R152: FQ1007.SZ | 2026-05-14 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R153: FQ1008.SH | 2026-05-14 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R154: FQ1001.SZ | 2026-05-15 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R155: FQ1002.SH | 2026-05-15 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R156: FQ1003.SZ | 2026-05-15 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R157: FQ1004.SH | 2026-05-15 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20
R158: FQ1005.SZ | 2026-05-15 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R159: FQ1006.SH | 2026-05-15 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R160: FQ1007.SZ | 2026-05-15 | 15:00 | qualified_signal | 收盘价不低于MA20且MA20较上一交易日上行 | close >= MA20 and MA20 > prev_MA20
R161: FQ1008.SH | 2026-05-15 | 15:00 | no_signal | 收盘价低于MA20 | close < MA20

## Sheet 3: risk_overrides
Dimensions: 161 rows x 8 columns
R1: ts_code | trade_date | review_time | pre_override_signal | halt_status | risk_status | final_label | override_reason
R2: FQ1001.SZ | 2026-04-17 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R3: FQ1002.SH | 2026-04-17 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R4: FQ1003.SZ | 2026-04-17 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R5: FQ1004.SH | 2026-04-17 | 15:00 | watch_only |  | False | watch_only | 无市场状态覆盖
R6: FQ1005.SZ | 2026-04-17 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R7: FQ1006.SH | 2026-04-17 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R8: FQ1007.SZ | 2026-04-17 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R9: FQ1008.SH | 2026-04-17 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R10: FQ1001.SZ | 2026-04-20 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R11: FQ1002.SH | 2026-04-20 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R12: FQ1003.SZ | 2026-04-20 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R13: FQ1004.SH | 2026-04-20 | 15:00 | watch_only |  | False | watch_only | 无市场状态覆盖
R14: FQ1005.SZ | 2026-04-20 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R15: FQ1006.SH | 2026-04-20 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R16: FQ1007.SZ | 2026-04-20 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R17: FQ1008.SH | 2026-04-20 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R18: FQ1001.SZ | 2026-04-21 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R19: FQ1002.SH | 2026-04-21 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R20: FQ1003.SZ | 2026-04-21 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R21: FQ1004.SH | 2026-04-21 | 15:00 | watch_only |  | False | watch_only | 无市场状态覆盖
R22: FQ1005.SZ | 2026-04-21 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R23: FQ1006.SH | 2026-04-21 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R24: FQ1007.SZ | 2026-04-21 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R25: FQ1008.SH | 2026-04-21 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R26: FQ1001.SZ | 2026-04-22 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R27: FQ1002.SH | 2026-04-22 | 15:00 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R28: FQ1003.SZ | 2026-04-22 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R29: FQ1004.SH | 2026-04-22 | 15:00 | watch_only |  | False | watch_only | 无市场状态覆盖
R30: FQ1005.SZ | 2026-04-22 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R31: FQ1006.SH | 2026-04-22 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R32: FQ1007.SZ | 2026-04-22 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R33: FQ1008.SH | 2026-04-22 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R34: FQ1001.SZ | 2026-04-23 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R35: FQ1002.SH | 2026-04-23 | 15:00 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R36: FQ1003.SZ | 2026-04-23 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R37: FQ1004.SH | 2026-04-23 | 15:00 | watch_only |  | False | watch_only | 无市场状态覆盖
R38: FQ1005.SZ | 2026-04-23 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R39: FQ1006.SH | 2026-04-23 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R40: FQ1007.SZ | 2026-04-23 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R41: FQ1008.SH | 2026-04-23 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R42: FQ1001.SZ | 2026-04-24 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R43: FQ1001.SZ | 2026-04-24 | 11:30 | qualified_signal | False | True | blocked_by_market_risk_off | 风险警示有效
R44: FQ1002.SH | 2026-04-24 | 15:00 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R45: FQ1002.SH | 2026-04-24 | 11:30 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R46: FQ1003.SZ | 2026-04-24 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R47: FQ1003.SZ | 2026-04-24 | 11:30 | qualified_signal | False | True | blocked_by_market_risk_off | 风险警示有效
R48: FQ1004.SH | 2026-04-24 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R49: FQ1004.SH | 2026-04-24 | 11:30 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R50: FQ1005.SZ | 2026-04-24 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R51: FQ1005.SZ | 2026-04-24 | 11:30 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R52: FQ1006.SH | 2026-04-24 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R53: FQ1006.SH | 2026-04-24 | 11:30 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R54: FQ1007.SZ | 2026-04-24 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R55: FQ1007.SZ | 2026-04-24 | 11:30 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R56: FQ1008.SH | 2026-04-24 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R57: FQ1008.SH | 2026-04-24 | 11:30 | no_signal |  | False | no_signal | 无市场状态覆盖
R58: FQ1001.SZ | 2026-04-27 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R59: FQ1002.SH | 2026-04-27 | 15:00 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R60: FQ1003.SZ | 2026-04-27 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R61: FQ1004.SH | 2026-04-27 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R62: FQ1005.SZ | 2026-04-27 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R63: FQ1006.SH | 2026-04-27 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R64: FQ1007.SZ | 2026-04-27 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R65: FQ1008.SH | 2026-04-27 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R66: FQ1001.SZ | 2026-04-28 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R67: FQ1002.SH | 2026-04-28 | 15:00 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R68: FQ1003.SZ | 2026-04-28 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R69: FQ1004.SH | 2026-04-28 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R70: FQ1005.SZ | 2026-04-28 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R71: FQ1006.SH | 2026-04-28 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R72: FQ1007.SZ | 2026-04-28 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R73: FQ1008.SH | 2026-04-28 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R74: FQ1001.SZ | 2026-04-29 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R75: FQ1002.SH | 2026-04-29 | 15:00 | no_signal | True | True | blocked_by_halt | 停牌状态：True
R76: FQ1003.SZ | 2026-04-29 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R77: FQ1004.SH | 2026-04-29 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R78: FQ1005.SZ | 2026-04-29 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R79: FQ1006.SH | 2026-04-29 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R80: FQ1007.SZ | 2026-04-29 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R81: FQ1008.SH | 2026-04-29 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R82: FQ1001.SZ | 2026-04-30 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R83: FQ1002.SH | 2026-04-30 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R84: FQ1003.SZ | 2026-04-30 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R85: FQ1004.SH | 2026-04-30 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R86: FQ1005.SZ | 2026-04-30 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R87: FQ1006.SH | 2026-04-30 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R88: FQ1007.SZ | 2026-04-30 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R89: FQ1008.SH | 2026-04-30 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R90: FQ1001.SZ | 2026-05-05 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R91: FQ1002.SH | 2026-05-05 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R92: FQ1003.SZ | 2026-05-05 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R93: FQ1004.SH | 2026-05-05 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R94: FQ1005.SZ | 2026-05-05 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R95: FQ1006.SH | 2026-05-05 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R96: FQ1007.SZ | 2026-05-05 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R97: FQ1008.SH | 2026-05-05 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R98: FQ1001.SZ | 2026-05-06 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R99: FQ1002.SH | 2026-05-06 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R100: FQ1003.SZ | 2026-05-06 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R101: FQ1004.SH | 2026-05-06 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R102: FQ1005.SZ | 2026-05-06 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R103: FQ1006.SH | 2026-05-06 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R104: FQ1007.SZ | 2026-05-06 | 15:00 | qualified_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R105: FQ1008.SH | 2026-05-06 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R106: FQ1001.SZ | 2026-05-07 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R107: FQ1002.SH | 2026-05-07 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R108: FQ1003.SZ | 2026-05-07 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R109: FQ1004.SH | 2026-05-07 | 15:00 | no_signal | True | False | blocked_by_halt | 停牌状态：True
R110: FQ1005.SZ | 2026-05-07 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R111: FQ1006.SH | 2026-05-07 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R112: FQ1007.SZ | 2026-05-07 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R113: FQ1008.SH | 2026-05-07 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R114: FQ1001.SZ | 2026-05-08 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R115: FQ1002.SH | 2026-05-08 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R116: FQ1003.SZ | 2026-05-08 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R117: FQ1004.SH | 2026-05-08 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R118: FQ1005.SZ | 2026-05-08 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R119: FQ1006.SH | 2026-05-08 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R120: FQ1007.SZ | 2026-05-08 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R121: FQ1008.SH | 2026-05-08 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R122: FQ1001.SZ | 2026-05-11 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R123: FQ1002.SH | 2026-05-11 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R124: FQ1003.SZ | 2026-05-11 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R125: FQ1004.SH | 2026-05-11 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R126: FQ1005.SZ | 2026-05-11 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R127: FQ1006.SH | 2026-05-11 | 15:00 | insufficient_history |  | False | insufficient_history | 无市场状态覆盖
R128: FQ1007.SZ | 2026-05-11 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R129: FQ1008.SH | 2026-05-11 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R130: FQ1001.SZ | 2026-05-12 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R131: FQ1002.SH | 2026-05-12 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R132: FQ1003.SZ | 2026-05-12 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R133: FQ1004.SH | 2026-05-12 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R134: FQ1005.SZ | 2026-05-12 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R135: FQ1006.SH | 2026-05-12 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R136: FQ1007.SZ | 2026-05-12 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R137: FQ1008.SH | 2026-05-12 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R138: FQ1001.SZ | 2026-05-13 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R139: FQ1002.SH | 2026-05-13 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R140: FQ1003.SZ | 2026-05-13 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R141: FQ1004.SH | 2026-05-13 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R142: FQ1005.SZ | 2026-05-13 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R143: FQ1006.SH | 2026-05-13 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R144: FQ1007.SZ | 2026-05-13 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R145: FQ1008.SH | 2026-05-13 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R146: FQ1001.SZ | 2026-05-14 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R147: FQ1002.SH | 2026-05-14 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R148: FQ1003.SZ | 2026-05-14 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R149: FQ1004.SH | 2026-05-14 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R150: FQ1005.SZ | 2026-05-14 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R151: FQ1006.SH | 2026-05-14 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R152: FQ1007.SZ | 2026-05-14 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R153: FQ1008.SH | 2026-05-14 | 15:00 | no_signal |  | True | blocked_by_market_risk_off | 风险警示有效
R154: FQ1001.SZ | 2026-05-15 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R155: FQ1002.SH | 2026-05-15 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R156: FQ1003.SZ | 2026-05-15 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R157: FQ1004.SH | 2026-05-15 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖
R158: FQ1005.SZ | 2026-05-15 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R159: FQ1006.SH | 2026-05-15 | 15:00 | qualified_signal | True | True | blocked_by_halt | 停牌状态：True
R160: FQ1007.SZ | 2026-05-15 | 15:00 | qualified_signal |  | False | qualified_signal | 无市场状态覆盖
R161: FQ1008.SH | 2026-05-15 | 15:00 | no_signal |  | False | no_signal | 无市场状态覆盖

## Sheet 4: summary
Dimensions: 16 rows x 3 columns
R1: summary_key | summary_value | note
R2: review_row_count | 160 | 复核明细总行数
R3: ready_row_count | 142 | 历史充足的复核行数
R4: insufficient_history_count | 18 | 历史不足行数
R5: base_qualified_signal_count | 83 | 基础标签为qualified_signal的行数
R6: base_watch_only_count | 5 | 基础标签为watch_only的行数
R7: base_no_signal_count | 54 | 基础标签为no_signal的行数
R8: override_row_count | 67 | 最终标签不同于基础标签的行数
R9: blocked_by_halt_count | 40 | 因停牌被覆盖的行数
R10: blocked_by_market_risk_off_count | 2 | 因风险警示被覆盖的行数
R11: final_qualified_signal_count | 34 | 覆盖后final_label为qualified_signal的行数
R12: final_watch_only_count | 5 | 覆盖后final_label为watch_only的行数
R13: final_no_signal_count | 36 | 覆盖后final_label为no_signal的行数
R14: final_insufficient_history_count | 18 | 覆盖后final_label为insufficient_history的行数
R15: half_session_row_count | 8 | 午间复核快照行数
R16: risk_and_halt_overlap_count | 39 | 同时处于停牌覆盖和风险警示有效期的行数
