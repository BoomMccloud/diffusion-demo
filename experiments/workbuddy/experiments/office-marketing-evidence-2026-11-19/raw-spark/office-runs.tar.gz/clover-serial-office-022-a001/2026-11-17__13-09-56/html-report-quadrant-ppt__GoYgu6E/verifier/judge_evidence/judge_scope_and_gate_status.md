# Judge evidence: scope and gate status

## Deterministic verifier status
- case_slug: html_report_quadrant_ppt
- candidate label: output/qingsui_q2_quadrant_board.pptx
- deterministic passed_count: 61
- deterministic total_count: 78
- deterministic pass_rate: 0.7821
- deterministic gated_pass: False
- failed checks, if any, are preserved and must not be hidden, forgiven, or reinterpreted by Judge: ['quadrant_budget_terms_present', 'anchor_H-117_visible_or_metadata', 'anchor_H-205_visible_or_metadata', 'anchor_H-402-a_visible_or_metadata', 'anchor_H-402-b_visible_or_metadata', 'quadrant_service_has_two_binding_classes', 'quadrant_flow_has_two_binding_classes', 'chart_CH-01_visible_or_metadata', 'chart_CH-03_visible_or_metadata', 'metric_M_COVER_VISITS_Q2_present', 'metric_M_COVER_REPEAT_Q2_present', 'metric_M_FLOW_MEDIAN_DAYS_Q2_present', 'metric_M_FLOW_BACKLOG_Q2_present', 'metric_M_FLOW_COMPLEX_SPLIT_Q2_present', 'metric_M_BUDGET_FORECAST_Q3_annotation_present', 'metric_M_RISK_BUDGET_REVIEW_Q3_present', 'provenance_summary_available_per_quadrant']

## P6/Judge gate IDs
- public surface gate: G-P6R-001
- fixed reviewer verdict: RV-P6R-006
- Judge mode: text-first WB Judge evidence only

## Activation readiness
- verifier-log judge evidence directory emitted: judge_evidence/
- required evidence files declared by tests/judge.yaml and judge/evidence_manifest.yaml: judge_evidence/judge_scope_and_gate_status.md, judge_evidence/public_context_summary.md, judge_evidence/normalized_workbook_chart_summary.md, judge_evidence/revision_conflict_inventory.md, judge_evidence/submitted_pptx_quadrant_text.md, judge_evidence/visible_text_summary.md, judge_evidence/notes_metadata_provenance_summary.md, judge_evidence/raw_dump_debug_density_summary.md, judge_evidence/parse_leakage_prerequisite_facts.md
- candidate parse/text readiness for Judge evidence: True
- deterministic full pass required before Judge activation: false
- deterministic component transparency required: true

## Evidence boundary
Allowed evidence is restricted to public inputs, submitted PPTX OOXML-visible text, speaker notes, shape/document metadata, and deterministic parse/leakage facts. Forbidden evidence includes hidden gold/oracle expected prose as an answer key, screenshots, OCR, VLM, rendered thumbnails, pixel-level visual scoring, private paths or URLs, private emails/accounts, tokens/credentials/secrets, real customer/person data, model logs, tool traces, live services, and external web evidence.
