# Judge evidence: parse and leakage prerequisite facts

## Boundary
These facts are deterministic prerequisites for trusting text evidence. They are not a deterministic-full-pass gate for WB Judge activation, and they must not be used to forgive or override objective verifier failures. Hidden gold/oracle expected wording, model logs, screenshots, OCR, VLM, rendered thumbnails, private services, and external web evidence were not used to build these facts.

## Candidate and parse status
- candidate label: output/qingsui_q2_quadrant_board.pptx
- PPTX parseable for OOXML extraction: True
- slide count parsed: 1
- slide size EMU: 12191695 x 6858000
- visible/notes/metadata separation succeeded: True
- parse errors: []

## Deterministic score transparency
- deterministic passed_count: 61
- deterministic total_count: 78
- deterministic gated_pass: False
- failed checks remain preserved separately: ['quadrant_budget_terms_present', 'anchor_H-117_visible_or_metadata', 'anchor_H-205_visible_or_metadata', 'anchor_H-402-a_visible_or_metadata', 'anchor_H-402-b_visible_or_metadata', 'quadrant_service_has_two_binding_classes', 'quadrant_flow_has_two_binding_classes', 'chart_CH-01_visible_or_metadata', 'chart_CH-03_visible_or_metadata', 'metric_M_COVER_VISITS_Q2_present', 'metric_M_COVER_REPEAT_Q2_present', 'metric_M_FLOW_MEDIAN_DAYS_Q2_present', 'metric_M_FLOW_BACKLOG_Q2_present', 'metric_M_FLOW_COMPLEX_SPLIT_Q2_present', 'metric_M_BUDGET_FORECAST_Q3_annotation_present', 'metric_M_RISK_BUDGET_REVIEW_Q3_present', 'provenance_summary_available_per_quadrant']

## Public-safety leakage facts
- external relationships count: 0
- external URL/file URI hits: []
- private path/source-locator hits: []
- email hits: []
- secret-like hits: []
- positive OCR/VLM/pixel/network/private-service dependency claim: False
- allowed relationship namespace note: standard OOXML schema URIs are ignored by the deterministic URL check.
