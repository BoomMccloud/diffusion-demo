# Judge evidence: revision conflict inventory

## Boundary
Derived only from public draft preview, public two-round revision notes, and public chart bindings. This inventory lists chronology and conflict surfaces; it does not prescribe hidden final wording or compare with an oracle PPTX.

## Public label semantics and chronology
- - `SUPERSEDED`：旧稿或第一轮之前的表述，只可作为错位/冲突背景，不应作为当前结论直接入页。
- - `FINAL`：第二轮后仍保留的制作口径，需要结合 HTML、工作簿和图表绑定核对；标签本身不是最终文案。
- - `CONTEXT_ONLY`：可放入旁注、speaker notes 或解释背景，不应替代主叙事。
- - `FORECAST_ONLY`：下季或滚动预测，只能作为风险/动作注记，不能改写为本季实绩。
- - CN-R1-01（版式方向｜FINAL）：保留一页四象限结构，但把旧稿 `SUPERSEDED` 的“总览 / 图表 / 建议 / 附录”改为四个业务角色标题。标题用于分区，不等同于每区最终正文。
- - CN-R1-02（左上绑定｜SUPERSEDED → FINAL）：左上图表旧稿仍绑到 `M_COVER_VISITS_Q1`（`SUPERSEDED`）；本轮要求改查本季 `M_COVER_VISITS_Q2`，并让 `H-117` 成为可读来源标记。`M_COVER_REPEAT_Q2` 可作为同图副轴或旁注，但具体一句话结论需另行综合。
- - CN-R1-03（效率象限取舍｜CONTEXT_ONLY）：右上象限重点是办理时长和积压关系；`M_FLOW_AUTO_RATE_Q2` 只能作背景，因为 `H-205` 已说明人工复核量同步上升。不要把“自动化率”写成主成效标题。
- - CN-R1-04（草稿标题｜FINAL）：草稿标题仍带“v0.3”旧稿感，可改成季度看板标题，但不要引入真实机构、网址、外部 logo 或不可追溯来源。
- - CN-R1-05（来源可见性｜FINAL）：每个象限至少保留一个 source chip、speaker notes 或 shape alt text 绑定；格式可类似“来源 H-117 / metric M_COVER_VISITS_Q2 / chart CH-01”。来源标记是审计线索，不要求全部显示在正文大字中。
- - CN-R2-01（预算图表口径｜FORECAST_ONLY 冲突）：预算象限请把 `H-304`、`CH-02`、`M_BUDGET_SPEND_Q2` 和 `M_BUDGET_COMMIT_Q2` 作为同一图表关系核对；`M_BUDGET_FORECAST_Q3` 是下季预测风险，不能写成本季执行率或本季已完成成果。
- - CN-R2-02（风险措辞修订｜SUPERSEDED → FINAL）：旧稿“试点名单全部稳定扩围”为 `SUPERSEDED`；风险象限需要保留两处服务点人手缺口和预算复核动作的来源线索，来源锚点使用 `H-402`，但不要整段复制源文。
- - CN-R2-03（第四象限表面｜FINAL）：如果右下角空间不足，可用 `CH-04` 风险动作表或三行状态表承载风险/动作/来源，不要把 `H-402` 原段落直接堆入页面。

## Public correction-note excerpts
- - CN-R1-02（左上绑定｜SUPERSEDED → FINAL）：左上图表旧稿仍绑到 `M_COVER_VISITS_Q1`（`SUPERSEDED`）；本轮要求改查本季 `M_COVER_VISITS_Q2`，并让 `H-117` 成为可读来源标记。`M_COVER_REPEAT_Q2` 可作为同图副轴或旁注，但具体一句话结论需另行综合。
- - CN-R1-03（效率象限取舍｜CONTEXT_ONLY）：右上象限重点是办理时长和积压关系；`M_FLOW_AUTO_RATE_Q2` 只能作背景，因为 `H-205` 已说明人工复核量同步上升。不要把“自动化率”写成主成效标题。
- - CN-R2-01（预算图表口径｜FORECAST_ONLY 冲突）：预算象限请把 `H-304`、`CH-02`、`M_BUDGET_SPEND_Q2` 和 `M_BUDGET_COMMIT_Q2` 作为同一图表关系核对；`M_BUDGET_FORECAST_Q3` 是下季预测风险，不能写成本季执行率或本季已完成成果。
- - CN-R2-02（风险措辞修订｜SUPERSEDED → FINAL）：旧稿“试点名单全部稳定扩围”为 `SUPERSEDED`；风险象限需要保留两处服务点人手缺口和预算复核动作的来源线索，来源锚点使用 `H-402`，但不要整段复制源文。
- - CN-R2-03（第四象限表面｜FINAL）：如果右下角空间不足，可用 `CH-04` 风险动作表或三行状态表承载风险/动作/来源，不要把 `H-402` 原段落直接堆入页面。
- - CN-R2-04（PPTX 追溯｜FINAL）：图表和表格对象需要在可解析的 PPTX 文本、speaker notes 或 alt text 中保留 `chart_id`、`html_anchor`、`metric_id` 中至少两类标记；这些标记可以分散在可见 chip、备注或对象描述里。
- | RC-01 | FINAL with SUPERSEDED context | `CN-R1-02`, `H-117`, `CH-01` | 把上一期触达行当作本季主证据 | 先看口径状态，再决定图表系列和来源 chip |
- | RC-02 | CONTEXT_ONLY | `CN-R1-03`, `H-205`, `CH-03` | 自动办结率主标题 | 解释效率时需同时核对时长、积压和复核背景 |
- | RC-03 | FORECAST_ONLY | `CN-R2-01`, `H-304`, `CH-02` | 把 Q3 预测当成本季执行率 | 预测只能作风险/下季动作注记 |
- | RC-04 | FINAL after SUPERSEDED claim | `CN-R2-02`, `H-402`, `CH-04` | “全部稳定扩围”的乐观旧句 | 风险动作需压缩呈现并保留来源，不提供最终措辞 |

## Public conflict index RC-01 through RC-04
- | RC-01 | FINAL with SUPERSEDED context | `CN-R1-02`, `H-117`, `CH-01` | 把上一期触达行当作本季主证据 | 先看口径状态，再决定图表系列和来源 chip |
- | RC-02 | CONTEXT_ONLY | `CN-R1-03`, `H-205`, `CH-03` | 自动办结率主标题 | 解释效率时需同时核对时长、积压和复核背景 |
- | RC-03 | FORECAST_ONLY | `CN-R2-01`, `H-304`, `CH-02` | 把 Q3 预测当成本季执行率 | 预测只能作风险/下季动作注记 |
- | RC-04 | FINAL after SUPERSEDED claim | `CN-R2-02`, `H-402`, `CH-04` | “全部稳定扩围”的乐观旧句 | 风险动作需压缩呈现并保留来源，不提供最终措辞 |

## Chart/draft mismatch inventory from public chart bindings
| chart | target quadrant | public anchors | public metrics | label | old/draft route | why wrong / warning | revision ref |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CH-01 | Q1_service_reach | H-117, H-117-a | M_COVER_VISITS_Q2, M_COVER_REPEAT_Q2, M_COVER_POPUP_Q2, M_COVER_VISITS_Q1 | SUPERSEDED | M_COVER_VISITS_Q1 | 旧稿曾把上一期触达行绑定为本季主证据，正式制作需查修订说明。 | CN-R1-02 |
| CH-02 | Q3_budget_pacing | H-304, H-402-b | M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2, M_BUDGET_FORECAST_Q3, M_BUDGET_RESERVE_Q2 | FORECAST_ONLY | 预算执行已达 89% | forecast row is not current-quarter actual | CN-R2-01 |
| CH-03 | Q2_flow_backlog | H-205, H-238 | M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2, M_FLOW_COMPLEX_SPLIT_Q2, M_FLOW_REVIEW_LOAD_Q2, M_FLOW_AUTO_RATE_Q2 |  |  |  |  |
| CH-04 | Q4_risk_actions | H-402, H-402-a, H-402-b | M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2, M_RISK_BUDGET_REVIEW_Q3, M_RISK_SUPPORT_QUEUE_Q2 | SUPERSEDED | 试点名单全部稳定扩围 | H-402 records staffing gaps and budget-review actions | CN-R2-02 |

## Bounded draft-preview mismatch excerpts
- 青穗街区协同项目｜2026 年第二季度运营看板（旧稿标题仍带 v0.3）
- 当前草稿误绑 M_COVER_VISITS_Q1；需保留此错位作为修订上下文。
- 旧稿把自动办结率写成主成效标题；本季不采用。
- 自动办结率只能作背景，不能替代时长和积压关系。
- Q3 预测 M_BUDGET_FORECAST_Q3 只能作风险注记，不能写成本季实绩。
- 删除旧稿“试点名单全部稳定扩围”的过度乐观句。
- 当前草稿 notes 中缺少 H-402 / CH-04 绑定标记。
