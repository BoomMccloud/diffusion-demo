# Judge evidence: submitted PPTX quadrant text

## Boundary
Derived only from the submitted candidate PPTX OOXML text, speaker notes, and shape name/description metadata. Candidate label: output/qingsui_q2_quadrant_board.pptx. No screenshots, OCR, VLM, pixel-derived text, model logs, hidden expected prose, or private services were used.

## Quadrant-local association summary
| quadrant | qid | shape count | visible chars | anchors found | chart IDs found | metric IDs found | binding classes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 服务覆盖与触达 | Q1_service_reach | 7 | 364 |  |  |  |  |
| 办理效率与积压 | Q2_flow_backlog | 7 | 364 |  |  |  |  |
| 资源投入与预算节奏 | Q3_budget_pacing | 14 | 666 | H-304 | CH-02 | M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2 | html_anchor, metric_id, chart_id |
| 风险纠偏与下季动作 | Q4_risk_actions | 12 | 589 | H-402 | CH-04 | M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2 | html_anchor, metric_id, chart_id |

## Quadrant-scoped PPTX text and metadata excerpts
### 服务覆盖与触达 (Q1_service_reach)
- selected shape indexes: [0, 1, 2, 3, 5, 6, 7]
- scoped speaker-note chars: 0
- visible text excerpt:
```text
青穗街区协同项目 ｜ 2026 年第二季度运营看板（四象限）
Service Coverage · Processing Efficiency · Budget Pacing · Risk Correction
服务覆盖与触达
本季触达人次：18,420
较上季回升（上季 15,980，旧稿引用，非本季实绩）
回访人群占比：23.4%（↑ 从 18.9%），有效触达质量提升
新增社区微站服务 46 场，重点覆盖雨季交通不便片区
热线 6,330 次 / 线上表单 4,870 次作为渠道背景
结论：规模回升且回访占比改善，但需关注预约未到率等周报口径
办理效率与积压
中位办理时长：5.8 天（↓ 从 7.1 天）
期末积压件数：312 件（↓ 从 428 件）
复杂件分流占比：27.6%（↑ 从 21.8%），人工分流与复核节奏调整驱动改善
自动办结率 41.2%（↓ 从 44%），仅作为背景参考
抽样回访满意度 88.5%，不替代主指标
结论：周期缩短与积压缓解同步实现，但需警惕自动化率下降的解读
```
- shape metadata excerpt:
```text
Rectangle 1
Q1_bg
Q1_strip
TextBox 4
Q2_bg
Q2_strip
TextBox 8
```
- scoped speaker notes excerpt:
```text
[no speaker-note block deterministically scoped to this quadrant]
```
### 办理效率与积压 (Q2_flow_backlog)
- selected shape indexes: [0, 1, 2, 3, 5, 6, 7]
- scoped speaker-note chars: 0
- visible text excerpt:
```text
青穗街区协同项目 ｜ 2026 年第二季度运营看板（四象限）
Service Coverage · Processing Efficiency · Budget Pacing · Risk Correction
服务覆盖与触达
本季触达人次：18,420
较上季回升（上季 15,980，旧稿引用，非本季实绩）
回访人群占比：23.4%（↑ 从 18.9%），有效触达质量提升
新增社区微站服务 46 场，重点覆盖雨季交通不便片区
热线 6,330 次 / 线上表单 4,870 次作为渠道背景
结论：规模回升且回访占比改善，但需关注预约未到率等周报口径
办理效率与积压
中位办理时长：5.8 天（↓ 从 7.1 天）
期末积压件数：312 件（↓ 从 428 件）
复杂件分流占比：27.6%（↑ 从 21.8%），人工分流与复核节奏调整驱动改善
自动办结率 41.2%（↓ 从 44%），仅作为背景参考
抽样回访满意度 88.5%，不替代主指标
结论：周期缩短与积压缓解同步实现，但需警惕自动化率下降的解读
```
- shape metadata excerpt:
```text
Rectangle 1
Q1_bg
Q1_strip
TextBox 4
Q2_bg
Q2_strip
TextBox 8
```
- scoped speaker notes excerpt:
```text
[no speaker-note block deterministically scoped to this quadrant]
```
### 资源投入与预算节奏 (Q3_budget_pacing)
- selected shape indexes: [1, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
- scoped speaker-note chars: 0
- visible text excerpt:
```text
本季触达人次：18,420
较上季回升（上季 15,980，旧稿引用，非本季实绩）
回访人群占比：23.4%（↑ 从 18.9%），有效触达质量提升
新增社区微站服务 46 场，重点覆盖雨季交通不便片区
热线 6,330 次 / 线上表单 4,870 次作为渠道背景
结论：规模回升且回访占比改善，但需关注预约未到率等周报口径
来源 H-117 · M_COVER_VISITS_Q2, M_COVER_REPEAT_Q2 · CH-01
中位办理时长：5.8 天（↓ 从 7.1 天）
期末积压件数：312 件（↓ 从 428 件）
复杂件分流占比：27.6%（↑ 从 21.8%），人工分流与复核节奏调整驱动改善
自动办结率 41.2%（↓ 从 44%），仅作为背景参考
抽样回访满意度 88.5%，不替代主指标
结论：周期缩短与积压缓解同步实现，但需警惕自动化率下降的解读
来源 H-205 · M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2 · CH-03
资源投入与预算节奏
已执行预算占全年口径：62%
已承诺未支付：74%
剩余机动额度：26%（目标带旁注）
承诺率上升主因：雨季临时服务点 + 复核班次预留
⚠ Q3 预测承诺率 89% → 风险注记，非本季实绩
结论：执行与承诺均在合理区间，需监控下季现金压力
来源 H-304 · M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2 · CH-02
风险纠偏与下季动作
南梧临时服务点排班缺口：等效 1.5 班次
北澜夜间咨询点轮值不足：2 名协同员
待补齐材料队列：64 件（≠ 已关闭事项）
下季首周行动：核对临时服务点预留、复核班次及材料补齐费用
⚠ 删除旧稿「试点名单全部稳定扩围」过度乐观表述
结论：两处人手缺口需优先处理，预算复核为关键行动项
来源 H-402 · M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2 · CH-04
```
- shape metadata excerpt:
```text
Q1_bg
TextBox 4
Q1_source_chip
Q2_bg
TextBox 8
Q2_source_chip
Q3_bg
Q3_strip
TextBox 12
Q3_source_chip
Q4_bg
Q4_strip
TextBox 16
Q4_source_chip
```
- scoped speaker notes excerpt:
```text
[no speaker-note block deterministically scoped to this quadrant]
```
### 风险纠偏与下季动作 (Q4_risk_actions)
- selected shape indexes: [1, 3, 5, 7, 8, 9, 10, 11, 13, 14, 15, 16]
- scoped speaker-note chars: 0
- visible text excerpt:
```text
本季触达人次：18,420
较上季回升（上季 15,980，旧稿引用，非本季实绩）
回访人群占比：23.4%（↑ 从 18.9%），有效触达质量提升
新增社区微站服务 46 场，重点覆盖雨季交通不便片区
热线 6,330 次 / 线上表单 4,870 次作为渠道背景
结论：规模回升且回访占比改善，但需关注预约未到率等周报口径
中位办理时长：5.8 天（↓ 从 7.1 天）
期末积压件数：312 件（↓ 从 428 件）
复杂件分流占比：27.6%（↑ 从 21.8%），人工分流与复核节奏调整驱动改善
自动办结率 41.2%（↓ 从 44%），仅作为背景参考
抽样回访满意度 88.5%，不替代主指标
结论：周期缩短与积压缓解同步实现，但需警惕自动化率下降的解读
来源 H-205 · M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2 · CH-03
资源投入与预算节奏
已执行预算占全年口径：62%
已承诺未支付：74%
剩余机动额度：26%（目标带旁注）
承诺率上升主因：雨季临时服务点 + 复核班次预留
⚠ Q3 预测承诺率 89% → 风险注记，非本季实绩
结论：执行与承诺均在合理区间，需监控下季现金压力
风险纠偏与下季动作
南梧临时服务点排班缺口：等效 1.5 班次
北澜夜间咨询点轮值不足：2 名协同员
待补齐材料队列：64 件（≠ 已关闭事项）
下季首周行动：核对临时服务点预留、复核班次及材料补齐费用
⚠ 删除旧稿「试点名单全部稳定扩围」过度乐观表述
结论：两处人手缺口需优先处理，预算复核为关键行动项
来源 H-402 · M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2 · CH-04
```
- shape metadata excerpt:
```text
Q1_bg
TextBox 4
Q2_bg
TextBox 8
Q2_source_chip
Q3_bg
Q3_strip
TextBox 12
Q4_bg
Q4_strip
TextBox 16
Q4_source_chip
```
- scoped speaker notes excerpt:
```text
[no speaker-note block deterministically scoped to this quadrant]
```
