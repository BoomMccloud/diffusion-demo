# Judge evidence: raw dump and debug density summary

## Boundary
This file reports bounded density indicators from the submitted PPTX visible text, with separate counts for notes and metadata. It does not include raw full source tables, full JSON blocks, screenshots, OCR, VLM, or hidden expected wording.

## Visible raw dump/debug indicators
- raw table or JSON dump hits: []
- debug/file/code/evaluator-language hits: []
- bulk ID detail: {"unique_id_count": 16, "total_id_count": 16, "max_ids_on_line": 4, "id_char_ratio": 0.2467, "bulk_line_samples": [], "passes": true}

## Visible versus notes/metadata ID split
- visible ID counts: {"total_id_count": 16, "unique_id_count": 16, "max_ids_on_line": 4, "unique_ids_sample": ["CH-01", "CH-02", "CH-03", "CH-04", "H-117", "H-205", "H-304", "H-402", "M_BUDGET_COMMIT_Q2", "M_BUDGET_SPEND_Q2", "M_COVER_REPEAT_Q2", "M_COVER_VISITS_Q2", "M_FLOW_BACKLOG_Q2", "M_FLOW_MEDIAN_DAYS_Q2", "M_RISK_STAFF_NORTH_Q2", "M_RISK_STAFF_SOUTH_Q2"]}
- notes ID counts: {"total_id_count": 65, "unique_id_count": 36, "max_ids_on_line": 5, "unique_ids_sample": ["BQ-01", "BQ-02", "BQ-03", "CH-01", "CH-02", "CH-03", "CH-04", "CN-R1-02", "CN-R1-03", "CN-R1-05", "CN-R2-01", "CN-R2-02", "CN-R2-03", "CN-R2-04", "CN-R2-05", "H-117", "H-205", "H-304", "H-402", "M_BUDGET_COMMIT_Q2", "M_BUDGET_FORECAST_Q3", "M_BUDGET_RESERVE_Q2", "M_BUDGET_SPEND_Q2", "M_COVER_POPUP_Q2", "M_COVER_REPEAT_Q2", "M_COVER_VISITS_Q1", "M_COVER_VISITS_Q2", "M_FLOW_AUTO_RATE_Q2", "M_FLOW_BACKLOG_Q2", "M_FLOW_COMPLEX_SPLIT_Q2"]}
- metadata ID counts: {"total_id_count": 24, "unique_id_count": 16, "max_ids_on_line": 8, "unique_ids_sample": ["CH-01", "CH-02", "CH-03", "CH-04", "H-117", "H-205", "H-304", "H-402", "M_BUDGET_COMMIT_Q2", "M_BUDGET_SPEND_Q2", "M_COVER_REPEAT_Q2", "M_COVER_VISITS_Q2", "M_FLOW_BACKLOG_Q2", "M_FLOW_MEDIAN_DAYS_Q2", "M_RISK_STAFF_NORTH_Q2", "M_RISK_STAFF_SOUTH_Q2"]}

## Bounded visible dump/debug example lines
- none observed

## Bounded visible ID-heavy lines
- none observed
