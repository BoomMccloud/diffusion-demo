# Judge evidence: normalized workbook and chart summary

## Boundary
Derived from public workbook `input/02_指标与图表数据_工作簿.xlsx` and public `input/03_chart_bindings.json` only. This file summarizes metric status, direction, chart/table bindings, target-band and forecast policies for Judge semantic review; it does not include hidden expected slide wording.

## Workbook parse status
- status: openpyxl import failed: ModuleNotFoundError: No module named 'openpyxl'
- relevant public metric IDs considered: M_COVER_VISITS_Q2, M_COVER_REPEAT_Q2, M_COVER_POPUP_Q2, M_COVER_VISITS_Q1, M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2, M_BUDGET_FORECAST_Q3, M_BUDGET_RESERVE_Q2, M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2, M_FLOW_COMPLEX_SPLIT_Q2, M_FLOW_REVIEW_LOAD_Q2, M_FLOW_AUTO_RATE_Q2, M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2, M_RISK_BUDGET_REVIEW_Q3, M_RISK_SUPPORT_QUEUE_Q2

## Public chart/table specs CH-01 through CH-04
| chart | title | target quadrant | anchors | metrics | revision refs | forecast policy | target band | series/status policy |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CH-01 | 服务触达与回访率 | Q1_service_reach | H-117, H-117-a | M_COVER_VISITS_Q2, M_COVER_REPEAT_Q2, M_COVER_POPUP_Q2, M_COVER_VISITS_Q1 | CN-R1-02, CN-R1-05 | not_applicable | simple_threshold_if_needed | current reach actual plus repeat-share context; micro-station count remains annotation/context |
| CH-02 | 预算执行与承诺节奏 | Q3_budget_pacing | H-304, H-402-b | M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2, M_BUDGET_FORECAST_Q3, M_BUDGET_RESERVE_Q2 | CN-R2-01, CN-R2-05 | annotation_only | band_not_single_goal_line | current actual and committed values are distinct; forecast is risk note only |
| CH-03 | 办理时长、积压与复杂件分流 | Q2_flow_backlog | H-205, H-238 | M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2, M_FLOW_COMPLEX_SPLIT_Q2, M_FLOW_REVIEW_LOAD_Q2, M_FLOW_AUTO_RATE_Q2 | CN-R1-03, CN-R1-05 | not_applicable | guardrail_lines_with_lower_is_better_label | duration and backlog lead; complex split and review load explain context; automation rate stays context-only |
| CH-04 | 风险纠偏与下季动作表 | Q4_risk_actions | H-402, H-402-a, H-402-b | M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2, M_RISK_BUDGET_REVIEW_Q3, M_RISK_SUPPORT_QUEUE_Q2 | CN-R2-02, CN-R2-03, CN-R2-04 | next_quarter_actions_must_be_labeled_as_actions_or_risks | not_applicable_for_action_table | risk/action/source rows should be compressed; do not copy full H-402 paragraph |

## Public chart series / action rows and row-state hints
| chart | binding | metric | period | unit | visual/source role | direction/source | row state |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CH-01 | B-01 | M_COVER_VISITS_Q2 | 2026Q2 | 人次 | bar | current_quarter_actual | current_period |
| CH-01 | B-02 | M_COVER_REPEAT_Q2 | 2026Q2 | 百分比 | line_or_side_note | current_quarter_actual | current_period |
| CH-01 | B-03 | M_COVER_POPUP_Q2 | 2026Q2 | 场次 | annotation | supporting_context | context_only |
| CH-02 | B-04 | M_BUDGET_SPEND_Q2 | 2026Q2 | 百分比 | solid_line | current_quarter_actual | actual_current |
| CH-02 | B-05 | M_BUDGET_COMMIT_Q2 | 2026Q2 | 百分比 | dashed_line | current_quarter_committed | committed_current |
| CH-02 | B-06 | M_BUDGET_FORECAST_Q3 | 2026Q3 forecast | 百分比 | risk_annotation_only | forecast_not_actual | forecast_only |
| CH-02 | B-07 | M_BUDGET_RESERVE_Q2 | 2026Q2 | 百分比 | target_band_note | supporting_context | context_only |
| CH-03 | B-08 | M_FLOW_MEDIAN_DAYS_Q2 | 2026Q2 | 天 | dot | lower_is_better | current_period |
| CH-03 | B-09 | M_FLOW_BACKLOG_Q2 | 2026Q2 | 件 | bar | lower_is_better | current_period |
| CH-03 | B-10 | M_FLOW_COMPLEX_SPLIT_Q2 | 2026Q2 | 百分比 | annotation | explanatory | context_only |
| CH-03 | B-11 | M_FLOW_REVIEW_LOAD_Q2 | 2026Q2 | 件 | small_note | context_not_main | context_only |
| CH-03 | context/excluded | M_FLOW_AUTO_RATE_Q2 |  |  | visible context but not main success claim | CONTEXT_ONLY | auto_rate_as_title |
| CH-04 | B-12 | M_RISK_STAFF_SOUTH_Q2 |  | 班次 | risk_current | risk_current | final_risk_anchor |
| CH-04 | B-13 | M_RISK_STAFF_NORTH_Q2 |  | 人 | risk_current | risk_current | final_risk_anchor |
| CH-04 | B-14 | M_RISK_BUDGET_REVIEW_Q3 |  | 动作 | next_quarter_action | next_quarter_action | next_quarter_action |
| CH-04 | B-15 | M_RISK_SUPPORT_QUEUE_Q2 |  | 件 | risk_context | risk_context | context_only |

## Bounded normalized workbook metric rows
No rows available.

## Public workbook revision anchor index
No rows available.
