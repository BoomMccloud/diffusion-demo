# Judge evidence: visible text summary

## Boundary
This summary uses only PPTX OOXML-extracted visible slide text. Speaker notes, shape metadata, and document metadata are summarized separately. No screenshots, OCR, VLM, or pixel evidence was used.

## Visible text metrics
- visible characters: 977
- compact visible characters: 766
- non-empty visible lines: 34
- CJK character count: 449
- ASCII word count: 27
- Chinese-dominant heuristic: True
- long visible lines (>=80 chars): 0

## Visible ID/debug/raw-dump indicators
- raw table or JSON dump hits: []
- debug/file dump hits: []
- bulk ID detail: {"unique_id_count": 16, "total_id_count": 16, "max_ids_on_line": 4, "id_char_ratio": 0.2467, "bulk_line_samples": [], "passes": true}
- visible ID counts: {"total_id_count": 16, "unique_id_count": 16, "max_ids_on_line": 4, "unique_ids_sample": ["CH-01", "CH-02", "CH-03", "CH-04", "H-117", "H-205", "H-304", "H-402", "M_BUDGET_COMMIT_Q2", "M_BUDGET_SPEND_Q2", "M_COVER_REPEAT_Q2", "M_COVER_VISITS_Q2", "M_FLOW_BACKLOG_Q2", "M_FLOW_MEDIAN_DAYS_Q2", "M_RISK_STAFF_NORTH_Q2", "M_RISK_STAFF_SOUTH_Q2"]}

## Bounded visible text excerpt
```text
青穗街区协同项目 ｜ 2026 年第二季度运营看板（四象限）
Service Coverage · Processing Efficiency · Budget Pacing · Risk Correction
服务覆盖与触达
本季触达人次：18,420
较上季回升（上季 15,980，旧稿引用，非本季实绩）
回访人群占比：23.4%（↑ 从 18.9%），有效触达质量提升
新增社区微站服务 46 场，重点覆盖雨季交通不便片区
热线 6,330 次 / 线上表单 4,870 次作为渠道背景
结论：规模回升且回访占比改善，但需关注预约未到率等周报口径
来源 H-117 · M_COVER_VISITS_Q2, M_COVER_REPEAT_Q2 · CH-01
办理效率与积压
中位办理时长：5.8 天（↓ 从 7.1 天）
期末积压件数：312 件（↓ 从 428 件）
复杂件分流占比：27.6%（↑ 从 21.8%），人工分流与复核节奏调整驱动改善
自动办结率 41.2%（↓ 从 44%），仅作为背景参考
抽样回访满意度 88.5%，不替代主指标
结论：周期缩短与积压缓解同步实现，但需警惕自动化率下降的解读
来源 H-205 · M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2 · CH-03
```

## Bounded long-line examples
- none observed
