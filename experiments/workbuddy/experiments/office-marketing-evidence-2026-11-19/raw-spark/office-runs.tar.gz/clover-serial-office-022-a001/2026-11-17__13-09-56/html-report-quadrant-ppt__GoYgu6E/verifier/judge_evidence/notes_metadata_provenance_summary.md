# Judge evidence: notes and metadata provenance summary

## Boundary
Derived only from submitted PPTX speaker notes, shape name/description metadata, and document XML/core/custom metadata. Provenance is assessed as public-safe IDs and local associations, not as hidden answer matching.

## Surface sizes
- speaker notes characters: 5686
- metadata characters: 3337
- notes parts parsed: 1
- shape items parsed: 17

## Per-quadrant provenance association
| quadrant | qid | visible region | scoped notes | shape metadata | anchors | charts | metrics | binding classes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 服务覆盖与触达 | Q1_service_reach | True | False | True |  |  |  |  |
| 办理效率与积压 | Q2_flow_backlog | True | False | True |  |  |  |  |
| 资源投入与预算节奏 | Q3_budget_pacing | True | False | True | H-304 | CH-02 | M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2 | html_anchor, metric_id, chart_id |
| 风险纠偏与下季动作 | Q4_risk_actions | True | False | True | H-402 | CH-04 | M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2 | html_anchor, metric_id, chart_id |

## Public-safety check on provenance surfaces
- private/source-locator hits in notes/metadata: []
- external URL/file URI hits in notes/metadata: ['http://schemas.openxmlformats.org/package/2006/metadata/core-properties', 'http://purl.org/dc/elements/1.1/', 'http://purl.org/dc/terms/', 'http://purl.org/dc/dcmitype/', 'http://www.w3.org/2001/XMLSchema-instance', 'http://schemas.openxmlformats.org/officeDocument/2006/extended-properties', 'http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes']
- email hits in notes/metadata: []
- secret-like hits in notes/metadata: []
- allowed provenance basis: visible source chips, speaker notes, shape alt text/name/description, and document metadata containing public synthetic IDs only.

## Bounded notes excerpt
```text
=== Quadrant Q1: 服务覆盖与触达 ===
PRIMARY CONTENT SOURCE:
  HTML section: <section id="H-H-117" ...>
METRIC BINDINGS (verified against workbook sheet):
  • M_COVER_VISITS_Q2
  • M_COVER_REPEAT_Q2
CHART BINDINGS:
  • CH-01: "服务触达与回访率" (combo_bar_line)
    target_quadrant=Q1_service_reach
    metrics=['M_COVER_VISITS_Q2', 'M_COVER_REPEAT_Q2', 'M_COVER_POPUP_Q2', 'M_COVER_VISITS_Q1']
    revision_notes=['CN-R1-02', 'CN-R1-05']
    ⚠ draft_mismatch: SUPERSEDED — 旧稿曾把上一期触达行绑定为本季主证据，正式制作需查修订说明。
REVISION CONTEXT (from 05_修订说明_两轮摘录.md):
  CN-R1-02: 旧稿 M_COVER_VISITS_Q1 (SUPERSEDED) → 改用 M_COVER_VISITS_Q2
  CN-R1-05: 每个象限至少保留一个 source chip / notes / alt text
BOARD QUESTION REFERENCE (from 07_董事会问题与呈现口径.md):
  Board question ref: BQ-01
TRACEABILITY SUMMARY:
  Visible source chip: H-H-117 + metrics + charts
  Shape name: Q1_bg, Q1_strip, Q1_source_chip
  Alt text on background shape includes anchors, metrics, charts
  Shape description stored in XML spDesc element
  Document core properties set with title, subject, comments
NON-INCLUDED ITEMS (per requirements):
  • No raw workbook rows pasted into visible text
  • No JSON fragments or file names in body
  • No line numbers, debug logs, or batch ID lists
  • Old draft claims marked SUPERSEDED are excluded from main conclusion
  • Forecast values labeled FORECAST_ONLY, never written as current actual
  • Supporting/context items clearly distinguished from main facts
=== Quadrant Q2: 办理效率与积压 ===
PRIMARY CONTENT SOURCE:
  HTML section: <section id="H-H-205" ...>
METRIC BINDINGS (verified against workbook sheet):
  • M_FLOW
[...bounded excerpt truncated...]
```

## Bounded metadata excerpt
```text
青穗街区协同项目 ｜ 2026 年第二季度运营看板（四象限）
Service Coverage · Processing Efficiency · Budget Pacing · Risk Correction
Rectangle 1


Q1_bg

服务覆盖与触达
Q1_strip

本季触达人次：18,420
较上季回升（上季 15,980，旧稿引用，非本季实绩）
回访人群占比：23.4%（↑ 从 18.9%），有效触达质量提升
新增社区微站服务 46 场，重点覆盖雨季交通不便片区
热线 6,330 次 / 线上表单 4,870 次作为渠道背景
结论：规模回升且回访占比改善，但需关注预约未到率等周报口径
TextBox 4

来源 H-117 · M_COVER_VISITS_Q2, M_COVER_REPEAT_Q2 · CH-01
Q1_source_chip


Q2_bg

办理效率与积压
Q2_strip

中位办理时长：5.8 天（↓ 从 7.1 天）
期末积压件数：312 件（↓ 从 428 件）
复杂件分流占比：27.6%（↑ 从 21.8%），人工分流与复核节奏调整驱动改善
自动办结率 41.2%（↓ 从 44%），仅作为背景参考
抽样回访满意度 88.5%，不替代主指标
结论：周期缩短与积压缓解同步实现，但需警惕自动化率下降的解读
TextBox 8

来源 H-205 · M_FLOW_MEDIAN_DAYS_Q2, M_FLOW_BACKLOG_Q2 · CH-03
Q2_source_chip


Q3_bg

资源投入与预算节奏
Q3_strip

已执行预算占全年口径：62%
已承诺未支付：74%
剩余机动额度：26%（目标带旁注）
承诺率上升主因：雨季临时服务点 + 复核班次预留
⚠ Q3 预测承诺率 89% → 风险注记，非本季实绩
结论：执行与承诺均在合理区间，需监控下季现金压力
TextBox 12

来源 H-304 · M_BUDGET_SPEND_Q2, M_BUDGET_COMMIT_Q2 · CH-02
Q3_source_chip


Q4_bg

风险纠偏与下季动作
Q4_strip

南梧临时服务点排班缺口：等效 1.5 班次
北澜夜间咨询点轮值不足：2 名协同员
待补齐材料队列：64 件（≠ 已关闭事项）
下季首周行动：核对临时服务点预留、复核班次及材料补齐费用
⚠ 删除旧稿「试点名单全部稳定扩围」过度乐观表述
结论：两处人手缺口需优先处理，预算复核为关键行动项
TextBox 16

来源 H-402 · M_RISK_STAFF_SOUTH_Q2, M_RISK_STAFF_NORTH_Q2 · CH-04
Q4_source_chip


<?xml version='1.0' encoding='UTF-8' standalone='yes'?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>青穗街区协同项目 2026年第二季度运营看板</dc:title><dc:subject>四象限单页汇报
[...bounded excerpt truncated...]
```
