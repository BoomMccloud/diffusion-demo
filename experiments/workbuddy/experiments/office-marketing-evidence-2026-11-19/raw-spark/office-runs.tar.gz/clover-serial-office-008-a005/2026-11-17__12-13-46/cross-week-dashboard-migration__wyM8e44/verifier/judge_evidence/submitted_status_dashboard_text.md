<!doctype html>
<html lang="zh-Hans">
<head>
  <meta charset="utf-8">
  <title>Week 21 Operations Dashboard / 第21周状态看板</title>
  <link rel="stylesheet" href="assets/dashboard.css">
</head>
<body data-workspace="community_training_ops" data-week-id="2026-W21" data-source-week="2026-W20">
  <header id="week-banner" data-bind="weekWindow">
    <h1>Week 21 Operations Dashboard / 第21周状态看板</h1>
    <p class="week-window">Mon 2026-05-18 to Sun 2026-05-24</p>
    <p class="calendar-note" data-calendar-anchor="holiday-shift">Wed 2026-05-20 is no-meeting day; reminder shifts to Tue 2026-05-19 morning</p>
  </header>

  <main>
    <section id="state-summary" data-bind="summaryByState" aria-label="status summary">
      <h2>Status summary / 状态摘要</h2>
      <dl>
        <dt>Historical completed / 历史完成</dt>
        <dd data-state="historical_done" data-count="3">OPS-201 FAQ refresh, OPS-207 label cleanup, OPS-212 chairs inventory</dd>
        <dt>Carry-forward open / 跨周未解决</dt>
        <dd data-state="carry_forward_open" data-count="1">OPS-214 import timeout still reproduces</dd>
        <dt>Deferred / 延后</dt>
        <dd data-state="deferred" data-count="1">OPS-219 volunteer roster waiting for confirmation</dd>
        <dt>Blocked / 卡住</dt>
        <dd data-state="blocked" data-count="1">OPS-224 door access approval external queue no reply</dd>
        <dt>Follow-up / 待追问</dt>
        <dd data-state="follow_up" data-count="1">OPS-230 EN one-pager with schedule section</dd>
        <dt>Watch-only / 观察</dt>
        <dd data-state="watch_only" data-count="1">OPS-236 Monday import watch, no owner assigned</dd>
      </dl>
    </section>

    <section id="carry-forward-board" data-bind="itemCards">
      <h2>Carry-forward board / 跨周看板</h2>
      <article class="item-card" data-item-id="OPS-214" data-source="2026-W20_ops_report" data-target-section="import-timeout-review">
        <h3>OPS-214 import timeout</h3>
        <p class="state-label">unresolved / Open</p>
        <p class="sync-note">CSV import timeout still reproduces on Friday sample import file; larger-sample evidence requested by Friday owner. Old export line says "resolved?" but this is lower-confidence clutter.</p>
      </article>
      <article class="item-card" data-item-id="OPS-219" data-source="2026-W20_ops_report" data-target-section="roster-calendar-review" data-calendar-sensitive="true">
        <h3>OPS-219 volunteer roster</h3>
        <p class="state-label">deferred / 延后</p>
        <p class="sync-note">Volunteer roster waiting for Wednesday confirmation. Calendar marks Wed 2026-05-20 as no-meeting day. Roster owner said "可能周三中午前给名单". Wait for roster arrival before scheduling.</p>
      </article>
      <article class="item-card" data-item-id="OPS-224" data-source="2026-W20_ops_report" data-target-section="approval-review">
        <h3>OPS-224 door access approval</h3>
        <p class="state-label">blocked / 卡住</p>
        <p class="sync-note">Door access approval not returned by Friday. Approval owner sits outside internal team. External queue; no internal workaround written.</p>
      </article>
      <article class="item-card" data-item-id="OPS-230" data-source="2026-W20_ops_report" data-target-section="partner-note-review" data-reminder-anchor="week21-followups">
        <h3>OPS-230 EN one-pager follow-up</h3>
        <p class="state-label">follow-up / 待追问</p>
        <p class="sync-note">Partner asked for EN one-pager with short schedule section. Reminder should happen before Friday partner check-in (Fri 2026-05-22 afternoon before 17:30). Tuesday morning acceptable since Wednesday is no-meeting day.</p>
      </article>
    </section>

    <section id="watch-notes" data-bind="watchOnlyNotes">
      <h2>Watch notes / 观察事项</h2>
      <ul>
        <li data-item-id="OPS-236" data-state="watch-only">Monday morning import watch. No owner assigned yet. Observation only.</li>
      </ul>
    </section>

    <section id="reminder-sync" data-bind="reminderQueue">
      <h2>Draft reminder cross-check / 提醒草稿核对</h2>
      <ul>
        <li data-item-id="OPS-214" data-reminder-file="03_reminders/week21_followups_draft.txt">import timeout unresolved; old export wording conflicts with Week 20 narrative</li>
        <li data-item-id="OPS-219" data-reminder-file="03_reminders/week21_followups_draft.txt">deferred roster wait; timing shifted from Wed to Tue due to no-meeting day</li>
        <li data-item-id="OPS-224" data-reminder-file="03_reminders/week21_followups_draft.txt">blocked external approval; do not mark as completed</li>
        <li data-item-id="OPS-230" data-reminder-file="03_reminders/week21_followups_draft.txt">follow-up partner one-pager; timing before Friday check-in</li>
      </ul>
    </section>
  </main>

  <script type="application/json" id="chart-spec-status-mix" data-bind="chartSpec.statusMix">
  {
    "chartType": "bar",
    "description": "Parseable status chart spec for the Week 21 status dashboard片段; pixels and visual styling are not part of this text update.",
    "source": "2026-W20_ops_report.md + week_rules.config.txt",
    "series": [
      {"state": "historical_done", "label": "历史完成", "count": 3},
      {"state": "carry_forward_open", "label": "未解决", "count": 1},
      {"state": "deferred", "label": "延后", "count": 1},
      {"state": "blocked", "label": "卡住", "count": 1},
      {"state": "follow_up", "label": "待追问", "count": 1},
      {"state": "watch_only", "label": "观察", "count": 1}
    ]
  }
  </script>

  <script type="application/json" id="data-binding-map">
  {
    "weekBanner": ["00_calendar/week_rules.config.txt", "01_reports/2026-W21_ops_report_template.md"],
    "itemCards": ["01_reports/2026-W20_ops_report.md", "01_reports/2026-W21_ops_report_template.md"],
    "reminderQueue": ["03_reminders/week21_followups_draft.txt"],
    "preserveAssets": ["02_dashboard/assets/dashboard.css", "02_dashboard/assets/status-icons.svg"],
    "needsReview": ["tmp/scratch_old_export.csv"]
  }
  </script>
</body>
</html>
