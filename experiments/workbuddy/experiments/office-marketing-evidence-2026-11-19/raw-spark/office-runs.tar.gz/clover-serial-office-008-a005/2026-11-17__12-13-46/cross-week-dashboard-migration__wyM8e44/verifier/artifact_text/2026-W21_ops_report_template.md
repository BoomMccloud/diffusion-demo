# Week 21 Ops Report / 第21周运营报告

Week window: Mon 2026-05-18 to Sun 2026-05-24

## A. Historical completions kept for context / 历史完成项（仅背景）

- OPS-201 FAQ refresh: FAQ v2 published to offline handbook. Owner role: Docs. No new action logged unless handbook feedback reopens it.
- OPS-207 Dashboard label cleanup: English status labels reviewed and merged into Week 20 HTML status board.
- OPS-212 Training room chairs: 32 chairs inventoried. Facilities side note, not tied to status-dashboard thread.

## B. Cross-week carry-forward items / 跨周待处理队列

| Item | Status | Source | Notes |
| --- | --- | --- | --- |
| OPS-214 | Unresolved / Open | 2026-W20_ops_report.md + oncall_handover.txt | CSV import timeout still reproduces on Friday sample import file. Larger-sample evidence requested by Friday owner. Old export line says "resolved?" but this is lower-confidence clutter; Week 20 narrative takes priority. |
| OPS-219 | Deferred / 延后 | 2026-W20_ops_report.md + oncall_handover.txt | Volunteer roster waiting for Wednesday confirmation. Calendar marks Wed 2026-05-20 as no-meeting day. Roster owner said "可能周三中午前给名单". Wait for roster arrival before scheduling. |
| OPS-224 | Blocked / 卡住 | 2026-W20_ops_report.md + vendor_window_note.txt | Door access approval not returned by Friday. Approval owner sits outside internal team. External queue; no internal workaround written. |
| OPS-230 | Follow-up / 待追问 | 2026-W20_ops_report.md + vendor_window_note.txt | Partner asked for EN one-pager with short schedule section. Reminder should happen before Friday partner check-in (Fri 2026-05-22 afternoon before 17:30). Tuesday morning acceptable since Wednesday is no-meeting day. |
| OPS-236 | Watch-only / 观察 | oncall_handover.txt | Monday morning import watch. No owner assigned yet. Observation only. |

## C. Reminder timing notes / 提醒时间口径

- No-meeting day: Wed 2026-05-20 → reminders shift to Tue 2026-05-19 morning.
- Partner check-in: Fri 2026-05-22 afternoon before 17:30. Context only, not completion evidence.
- Blocked items: Do not mark as completed. Keep blocker text visible.
- Deferred items: Keep reason/date condition (e.g., "wait for roster").
- Completed items: Do not create active reminders.

## D. Dashboard sync notes / 看板同步备注

- Visible DOM text, data attributes, embedded JSON must align with this report.
- Static assets (dashboard.css, status-icons.svg) preserved unchanged.
- Do not edit archived reports, sent reminders, or scratch exports.

## E. Non-target preservation note / 非目标文件保护

- Do not rewrite archived reports, sent reminders, static dashboard assets, source notes, calendar/config, README, role map, or scratch exports.
- Preserve file tree shape.
