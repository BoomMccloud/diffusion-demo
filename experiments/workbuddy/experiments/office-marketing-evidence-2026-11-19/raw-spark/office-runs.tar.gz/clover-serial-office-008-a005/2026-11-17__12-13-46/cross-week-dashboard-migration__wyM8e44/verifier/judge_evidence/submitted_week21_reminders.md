Subject: Week 21 follow-up / 第21周待跟进提醒
Audience: internal offline project roles
Week: 2026-W21

Sent reminder lines:

1. [OPS-214] CSV import timeout - unresolved
   - Reminder timing: Tue 2026-05-19 morning (shifted from Wed due to no-meeting day)
   - 中文备注: CSV import timeout still reproduces on Friday sample import file; larger-sample evidence requested by Friday owner. Old export line says "resolved?" but this is lower-confidence clutter.
   - Note: Open issue, not completed.

2. [OPS-219] Volunteer roster item - deferred
   - Reminder timing: Tue 2026-05-19 morning (shifted from Wed due to no-meeting day)
   - 中文备注: 等名单确认后再排班；Roster owner said "可能周三中午前给名单"。
   - Note: Deferred pending roster arrival; do not mark as blocked.

3. [OPS-224] Door access approval - blocked
   - Reminder timing: Mon 2026-05-18 after standup
   - 中文备注: 外部审批队列还没有回音；不要写成已经批准。
   - Note: Blocked on external queue; keep blocker text visible.

4. [OPS-230] Partner EN one-pager follow-up
   - Reminder timing: Tue 2026-05-19 morning (before Friday partner check-in; Wednesday is no-meeting day)
   - 中文备注: 请确认英文 one-pager 是否需要补充 schedule section。
   - Note: Partner check-in window is Fri 2026-05-22 afternoon before 17:30. Timing context only, not completion evidence.

Notes not to send until verified:

- OPS-236 import watch: handover says Monday watch, no owner assigned. Watch-only note.
- Office plant move: completed noise item, not operational follow-up.
- tmp/scratch_old_export.csv status text: 低优先级旧导出, not reminder source.
