# Judge Scope and Deterministic Gate Status

This Markdown evidence file is produced by the deterministic verifier for supplemental text-only WB Judge consumption.

## Deterministic status
- passed_count: 84
- total_count: 136
- pass_rate: 0.6176
- preflight_passed_count: 2
- preflight_total_count: 4
- deterministic_gated_pass: false
- deterministic_safety_or_leakage_failed: false
- llm_judge_activation_allowed: true
- failed_checks: report_required_sections_present, report_required_section_order, report_tables_present, report_section_week_boundary_present, report_section_source_boundary_present, report_week21_range_and_timezone, report_source_priority_and_source_binding_covered, report_item_OPS-214_state_migrated, report_item_OPS-219_state_migrated, report_item_OPS-224_state_migrated, report_item_OPS-230_state_migrated, report_ops214_stale_export_conflict_rejected, report_OPS214_conflict_evidence_completeness, report_preservation_statement_targets_only, report_no_wrong_status_claim_OPS-214, dashboard_week_window_and_shift_visible, dashboard_week_window_visible_offline_local, dashboard_summary_visible_count_text_blocked, dashboard_summary_visible_count_text_carry_forward_open, dashboard_summary_visible_count_text_deferred, dashboard_summary_visible_count_text_follow_up, dashboard_summary_visible_count_text_historical_done, dashboard_summary_visible_count_text_watch_only, dashboard_required_item_ids_present, dashboard_item_OPS-214_data_state, dashboard_item_OPS-214_visible_text_synced, dashboard_item_OPS-219_data_state, dashboard_item_OPS-219_reminder_anchor_present, dashboard_item_OPS-224_data_state, dashboard_item_OPS-224_reminder_anchor_present, dashboard_item_OPS-230_data_state, dashboard_item_OPS-236_data_state, dashboard_historical_done_items_not_active_cards, dashboard_chart_json_week_id_exact_value, dashboard_chart_json_week_window_exact_value, dashboard_chart_json_items_exact, dashboard_binding_map_required_keys, dashboard_binding_map_required_sources, dashboard_old_review_placeholders_removed, reminder_week_range_and_no_meeting_shift, reminder_send_ready_order_224_219_230, reminder_send_ready_no_OPS214, reminder_OPS-219_timing_correct, reminder_OPS-230_timing_correct, reminder_OPS-214_watch_or_context_not_send_ready, reminder_do_not_send_ops201, reminder_do_not_send_ops207, reminder_do_not_send_ops212, reminder_do_not_send_archive, final_response_mentions_three_updated_files, final_response_mentions_carry_forward_items, final_response_confirms_non_target_preservation
- preflight_failed_checks: gold_public_snapshot_matches_current_public_inputs, expected_gold_artifacts_hash_match_contract

WB Judge may run only when required judge_evidence files exist, deterministic safety/leakage checks pass, and deterministic component score, preflight status, failed_checks, and objective failure attribution are preserved separately.

## Judge modality and forbidden behavior
- Text-only semantic review of the submitted Week 21 report, dashboard text/JSON evidence, and reminder draft.
- No VLM/image/OCR/pixel-level visual scoring or dashboard rendering aesthetics.
- No browser/API/Skill/MCP/live-service behavior is required or allowed for Judge evidence.

## Deterministic-owned scope not scored by Judge
- file existence, path correctness, workspace state diff, protected-file preservation, and forbidden extra artifact detection
- Markdown/HTML/JSON parseability, required section/schema presence, data-state values, summary counts, chart JSON fields, data-binding keys/sources, exact reminder ordering, exact dates/times, and exact item membership
- objective safety/leakage checks, private/source leakage detection, secret detection, and live/external-service claims
- deterministic pass recovery, deterministic failed-check reinterpretation, hidden gold comparison, exact oracle wording, or numeric score adjustment

## Exclusion boundary
This file excludes hidden gold-only expected artifacts, private trace text, private paths, private URLs, credentials, account identifiers, customer data, proprietary code, and unpublished assets.
