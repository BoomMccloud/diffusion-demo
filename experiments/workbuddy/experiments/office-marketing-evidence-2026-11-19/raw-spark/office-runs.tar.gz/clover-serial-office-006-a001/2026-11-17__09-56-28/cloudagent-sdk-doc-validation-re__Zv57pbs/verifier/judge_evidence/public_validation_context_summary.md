# Public validation context summary

This bounded orientation is derived only from public runtime inputs under
`input/workspace/`. It is not an answer key and intentionally omits hidden gold,
oracle findings, exact expected source bindings, construction notes, private
trace content, model/tool logs, and external/live-service evidence.

## Task and artifact shape

The task asks for a Markdown validation report at
`input/workspace/output/validation_report.md` that reviews local CloudAgent SDK
documentation, examples, static mock API fixtures, config/setup files, prior
validation notes, logs, and changelog evidence. The workspace is text-only and
static; no live CloudAgent service, real registry, browser, MCP, Skill, network,
OCR, VLM, or executable mock server evidence is required for Judge.

## Visible public artifact families

- `input/workspace/docs/`: SDK overview, API, auth/permissions, runner, and setup documentation files. File count: 5.
- `input/workspace/examples/`: TypeScript/JavaScript example files and examples README. File count: 3.
- `input/workspace/mock_api/`: static OpenAPI, behavior matrix, schemas, and response fixtures. File count: 9.
- `input/workspace/config/`: local mock defaults and environment-example files. File count: 2.
- `input/workspace/reports/`: prior validation notes and local test/smoke logs. File count: 3.
- Root-level public context files such as README and CHANGELOG. File count: 2.
- `input/workspace/output/`: submitted report location. File count: 1.

## Safe evidence-use guidance for Judge

Judge may read the submitted report and this public context to decide whether the
report's prose clearly triangulates across visible artifact families, gives
actionable recommendations, avoids unsupported speculation, and explains
unresolved blockers. Judge should treat file paths, operation identifiers, case
identifiers, schema/response names, config keys, changelog entries, and pytest
node IDs as local public textual anchors when they appear in the submitted
report, but should not validate exact anchor correctness or exact fact coverage;
those remain deterministic-verifier responsibilities.
