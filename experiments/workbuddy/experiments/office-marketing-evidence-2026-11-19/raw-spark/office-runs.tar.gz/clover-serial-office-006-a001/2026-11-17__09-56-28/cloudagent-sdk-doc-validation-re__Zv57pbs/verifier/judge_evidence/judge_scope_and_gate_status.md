# Judge scope and deterministic gate status

Case: `cloudagent_sdk_doc_validation_report`
Runtime evidence root: `/logs/verifier/judge_evidence/`
Submitted artifact role: `input/workspace/output/validation_report.md`

## Deterministic verifier status

- Deterministic verifier completed: yes
- Deterministic checks passed: 101 / 120
- Deterministic pass rate: 0.8417
- Preflight checks passed: 7 / 8
- Deterministic safety/leakage failure detected: false
- Failed deterministic check groups, counts only:
- `citation_source_binding`: 5
- `non_issue_precision`: 3
- `precision_wrong_claims`: 4
- `recommendations`: 3
- `security_auth_boundary`: 3
- `setup_environment_classification`: 1

## Boundary for optional WB Judge

The deterministic verifier owns hard facts, exact output path/schema, parseability,
state-diff and side-effect boundaries, exact finding recall/precision,
source-binding validity, classification truth, recommendation coverage, unresolved
question presence, and objective safety/leakage checks.

Optional text-only Judge evidence may be used only for holistic report-quality
rubrics such as triangulation clarity, recommendation actionability,
unsupported-speculation avoidance, and unresolved-blocker clarity. Judge must not
use hidden gold, oracle text, construction notes, private trace/source context,
model/tool logs, external web or live-service evidence, screenshots, OCR, VLM, or
private/account/customer data. Judge must not rescore or compensate deterministic
fact, path, schema, citation, source-binding, safety, or state-diff failures.

If deterministic safety/leakage failure is true, the submitted report text is
withheld from Judge evidence and Judge should be skipped or treated as unready.
