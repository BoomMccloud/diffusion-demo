# Submitted validation_report.md text

Runtime artifact: `input/workspace/output/validation_report.md`

The content below is the submitted artifact. The verifier adds no hidden gold, oracle wording, construction notes, or private trace context.

---

# CloudAgent SDK Documentation Validation Report

**Generated:** 2026-11-17
**Scope:** Cross-reference of docs, examples, OpenAPI/schema, static behavior samples, auth/setup/config, prior notes, test reports/logs, and changelog within `input/workspace/`.
**Method:** Inspection-first; no live services, private services, real registries, or external URLs accessed. Token-like values treated as low-entropy placeholder labels.

---

## 1. Executive Summary

The documentation package for the fictional `@fictional/cloudagent-sdk` preview line (`0.14-preview`) was validated by cross-referencing prose documentation against OpenAPI definitions, JSON schemas, static behavior fixtures, response samples, configuration files, existing test results, prior validation notes, and the changelog.

**Overall assessment:** The majority of claims are consistent across sources. However, **three product/documentation discrepancies** were identified — primarily involving field naming conventions (`jobId` vs `job_id`) and an incorrect statement about authentication requirements for the runner health endpoint. One security/auth boundary note was found where the docs contradict the OpenAPI spec. Two environment/setup blockers appeared in the test log but do not indicate product defects. Several known optional/non-issue distractors were confirmed as expected gaps.

| Category | Count |
|---|---|
| Consistent claims (cross-verified) | ~35+ |
| Product/documentation issues | 3 |
| Security/auth boundary notes | 1 |
| Setup/environment blockers | 2 |
| Known non-issues / expected gaps | 3 |
| Unresolved questions | 4 |

---

## 2. Artifact Inventory and Scope

### Documents read
| File | Purpose |
|---|---|
| `docs/sdk_overview.md` | Package overview, namespace table, output naming convention |
| `docs/jobs_api.md` | Job creation/read API, request/response shapes, error handling |
| `docs/runners_api.md` | Runner health endpoint, status caveats, compatibility notes |
| `docs/auth_and_permissions.md` | Placeholder token profiles, HTTP status semantics, security boundaries |
| `docs/setup_local_mock.md` | Local mock startup checks, transient retry defaults, no-live-service policy |
| `examples/README_examples.md` | Example intent descriptions, legacy material guidance |
| `examples/quickstart.ts` | Minimal job create flow example |
| `examples/retry_runner.js` | Retry backoff around transient 503 responses |
| `mock_api/openapi.yaml` | OpenAPI 3.1.0 definition (paths, components, security schemes) |
| `mock_api/behavior_matrix.json` | Static behavior cases with caseId anchors |
| `mock_api/schemas/job.schema.json` | Job response schema ($id: https://example.invalid/schemas/cloudagent/job.schema.json) |
| `mock_api/schemas/runner.schema.json` | RunnerHealth schema ($id: https://example.invalid/schemas/cloudagent/runner.schema.json) |
| `mock_api/responses/create_job_201.json` | Successful job creation response |
| `mock_api/responses/get_job_200_completed.json` | Completed job GET response |
| `mock_api/responses/create_job_400_invalid_queue.json` | Unknown queue error response |
| `mock_api/responses/create_job_400_timeout.json` | Timeout limit exceeded error response |
| `mock_api/responses/runner_403_missing_scope.json` | Missing runner:read scope error response |
| `config/sdk.defaults.toml` | Default client/mock/auth configuration |
| `config/local_mock.env.example` | Environment variable template |
| `reports/sdk_doc_validation_notes.md` | Prior draft validation notes (incomplete scratch) |
| `reports/pytest_mock_api_2026-06-18.log` | Pytest run results (1 failed, 6 passed, 1 skipped, 1 error) |
| `reports/example_run_smoke_2026-06-18.txt` | Smoke test transcript |
| `CHANGELOG.md` | Version history (0.14-preview, 0.13, 0.12) |
| `README.md` | Workspace scope and citation expectations |

### Files NOT modified
Only `output/validation_report.md` was created/updated. No changes were made to docs, examples, mock_api, config, reports, CHANGELOG, or any other file.

---

## 3. Claim-to-Evidence Matrix

Each claim from the documentation was checked against at least two independent sources (OpenAPI, schema, behavior matrix, config, test log, changelog).

### Jobs API (`client.jobs.create`, `client.jobs.get`)

| Claim | Source(s) | Evidence | Status |
|---|---|---|---|
| `queue` required; enum: interactive, batch, gpu-small | docs/jobs_api.md:19-21; openapi.yaml:107-109; behavior_matrix.json:14,66 | ✅ All agree | Consistent |
| `image` required; pattern `registry.local/...` | docs/jobs_api.md:22; openapi.yaml:110-112; behavior_matrix.json:15,67 | ✅ All agree | Consistent |
| `command` required; array of strings, minItems:1 | docs/jobs_api.md:23; openapi.yaml:113-117 | ✅ All agree | Consistent |
| `timeoutSeconds` default 300; max 900; above 900 rejected | docs/jobs_api.md:24; openapi.yaml:118-122; sdk.defaults.toml:5,13; CHANGELOG.md:9; pytest log PASSED | ✅ All agree | Consistent |
| `metadata.labels` up to 16 string pairs | docs/jobs_api.md:25; openapi.yaml:123-130 | ✅ All agree | Consistent |
| Response shape: lower camelCase (`jobId`, `status`, `createdAt`, `runnerRef`) | docs/sdk_overview.md:28; docs/jobs_api.md:27; job.schema.json:5-9; create_job_201.json | ✅ All agree | Consistent |
| `runnerRef` replaced old `runner_id` | CHANGELOG.md:5; docs/jobs_api.md:29; quickstart.ts:16 | ✅ All agree | Consistent |
| `jobId` pattern `^job_[a-z0-9]{8}$` | openapi.yaml:55-56; job.schema.json:14-15 | ✅ All agree | Consistent |
| `GET /v1/jobs/{jobId}` returns same shape as POST | docs/jobs_api.md:33; get_job_200_completed.json matches create_job_201.json structure | ✅ All agree | Consistent |
| `queued`, `running`, `completed`, `failed` statuses | docs/jobs_api.md:36-39; job.schema.json:18-22 | ✅ All agree | Consistent |
| 400 errors: unknown queue, image prefix outside registry, empty command, timeout above limit | docs/jobs_api.md:44; openapi.yaml:33-38; behavior_matrix.json:caseIds | ✅ All agree | Consistent |
| 401: missing/malformed bearer token | docs/jobs_api.md:44; openapi.yaml:39-44 | ✅ All agree | Consistent |
| `additionalProperties: false` on CreateJobRequest | openapi.yaml:105 | ✅ Schema-level constraint | Consistent |

### Runners API (`client.runners.health`)

| Claim | Source(s) | Evidence | Status |
|---|---|---|---|
| Returns most recent heartbeat | docs/runners_api.md:6 | ✅ Single source (no conflicting evidence) | Consistent |
| Fields: runnerId, state, lastHeartbeatAt, scopes | docs/runners_api.md:8-13; runner.schema.json:5-9 | ✅ All agree | Consistent |
| `state` enum: idle, busy, offline | docs/runners_api.md:11; runner.schema.json:18-21 | ✅ All agree | Consistent |
| `scopes`: array of granted permission strings | docs/runners_api.md:13; runner.schema.json:28-32 | ✅ All agree | Consistent |
| ❌ Says "unauthenticated for local development" | docs/runners_api.md:6 | ⚠️ Contradicts openapi.yaml:73-74 (requires `runner:read` scope) and auth_and_permissions.md:26-28 | **DISCREPANCY** |
| `runnerId` pattern `^run_[a-z0-9]{6}$` | openapi.yaml:80-81; runner.schema.json:14-15 | ✅ All agree | Consistent |
| `lastHeartbeatAt` date-time format | runner.schema.json:24-26 | ✅ Single source | Consistent |
| `client.runners.list()` not available in 0.14 preview | docs/runners_api.md:26; no OpenAPI operation exists | ✅ Confirmed absence | Non-issue (expected gap) |
| Old `client.runner.health()` singular namespace archived | docs/runners_api.md:22; README_examples.md:13; CHANGELOG.md:8 | ✅ All agree | Consistent |

### Authentication & Permissions

| Claim | Source(s) | Evidence | Status |
|---|---|---|---|
| Three placeholder profiles: demo-admin-token, jobs-only-token, expired-demo-token | auth_and_permissions.md:10-14 | ✅ Single source (no conflict) | Consistent |
| demo-admin-token scopes: `jobs:write`, `runner:read` | auth_and_permissions.md:12; runner.schema.json:41-43 (scopes include both) | ✅ Cross-checked | Consistent |
| jobs-only-token scopes: `jobs:write` only | auth_and_permissions.md:13; behavior_matrix.json:caseId runner-health-missing-scope → 403 | ✅ Cross-checked | Consistent |
| expired-demo-token: none (negative tests) | auth_and_permissions.md:14 | ✅ Single source | Consistent |
| 401: missing/malformed/expired token | auth_and_permissions.md:22-23; openapi.yaml:39-44,89-90 | ✅ All agree | Consistent |
| 403: valid token lacks required scope | auth_and_permissions.md:23; openapi.yaml:91-92; runner_403_missing_scope.json | ✅ All agree | Consistent |
| 404: object absent under privacy mode | auth_and_permissions.md:24; openapi.yaml:66-67,93-94 | ✅ All agree | Consistent |
| Runner health requires `runner:read` even in offline sample | auth_and_permissions.md:26-28; openapi.yaml:73-74; behavior_matrix.json:requiredScopes | ✅ All agree | Consistent |
| Token profiles are labels, not credentials | auth_and_permissions.md:16; behavior_matrix.json:notes[1] | ✅ All agree | Consistent |

### Offline Sample Interface Setup

| Claim | Source(s) | Evidence | Status |
|---|---|---|---|
| Default URL: http://127.0.0.1:4517 | docs/setup_local_mock.md:10; openapi.yaml:7; sdk.defaults.toml:6; local_mock.env.example:3 | ✅ All agree | Consistent |
| Default token profile: jobs-only-token | docs/setup_local_mock.md:11; sdk.defaults.toml:16; local_mock.env.example:4 | ✅ All agree | Consistent |
| MOCK_ENABLE_TRANSIENTS=false by default | docs/setup_local_mock.md:12; sdk.defaults.toml:11; local_mock.env.example:7 | ✅ All agree | Consistent |
| CLOUDAGENT_REGISTRY_PREFIX=registry.local/ | docs/setup_local_mock.md:13; sdk.defaults.toml:10; local_mock.env.example:6 | ✅ All agree | Consistent |
| Port 4517 EADDRINUSE = environment/setup blocker | docs/setup_local_mock.md:17; pytest log ERROR | ✅ All agree | Consistent |
| Transient retry disabled by default; requires MOCK_ENABLE_TRANSIENTS=true | docs/setup_local_mock.md:23; pytest log SKIPPED | ✅ All agree | Consistent |
| Do not use real services/registries/accounts | docs/setup_local_mock.md:27; README.md:25 | ✅ All agree | Consistent |

### Examples

| Claim | Source(s) | Evidence | Status |
|---|---|---|---|
| quickstart.ts should pass with default settings | examples/README_examples.md:5 | ⚠️ Contradicts quickstart.ts:13 (timeoutSeconds=960 > 900) and behavior_matrix.json:caseId create-job-timeout-too-large (expects 400) | **DISCREPANCY** |
| quickstart.ts demonstrates minimal job create flow | examples/README_examples.md:5 | ✅ Partially true (flow is correct except field name and timeout) | Discrepancy |
| retry_runner.js demonstrates retry backoff around 503 | examples/README_examples.md:9 | ✅ Matches code logic | Consistent |
| retry_runner.js not expected to pass unless MOCK_ENABLE_TRANSIENTS=true | examples/README_examples.md:9; pytest log SKIPPED | ✅ All agree | Consistent |
| Archived snippets used `client.runner.health()` singular | examples/README_examples.md:13; CHANGELOG.md:8 | ✅ All agree | Consistent |
| Examples should log lower-camel-case fields | examples/README_examples.md:17 | ✅ Aligns with schema naming | Consistent |

### Configuration

| Claim | Source(s) | Evidence | Status |
|---|---|---|---|
| default_timeout_seconds = 300 | sdk.defaults.toml:5; docs/jobs_api.md:24 | ✅ All agree | Consistent |
| base_url = loopback | sdk.defaults.toml:6; docs/setup_local_mock.md:10 | ✅ All agree | Consistent |
| allowed_image_prefix = registry.local/ | sdk.defaults.toml:10; docs/jobs_api.md:22 | ✅ All agree | Consistent |
| enable_transients = false | sdk.defaults.toml:11; docs/setup_local_mock.md:12 | ✅ All agree | Consistent |
| redact_scope_list_in_logs = true | sdk.defaults.toml:12 | ⚠️ Not referenced in any doc | Minor gap |
| user_agent = cloudagent-sdk-doc-fixture/0.14-preview | sdk.defaults.toml:7 | ⚠️ Not referenced in any doc | Minor gap |
| max_timeout_seconds = 900 | sdk.defaults.toml:13; docs/jobs_api.md:24 | ✅ All agree | Consistent |
| default_token_profile = jobs-only-token | sdk.defaults.toml:16; docs/setup_local_mock.md:11 | ✅ All agree | Consistent |
| admin_token_profile = demo-admin-token | sdk.defaults.toml:17; auth_and_permissions.md:12 | ✅ All agree | Consistent |
| expired_token_profile = expired-demo-token | sdk.defaults.toml:18; auth_and_permissions.md:14 | ✅ All agree | Consistent |

### Test Reports

| Result | Source | Interpretation | Status |
|---|---|---|---|
| test_create_job_interactive PASSED | pytest log:7 | Basic job creation works | Consistent |
| test_reject_timeout_above_limit PASSED | pytest log:8 | Timeout > 900 correctly rejected | Consistent |
| test_reject_unknown_queue PASSED | pytest log:9 | Unknown queue correctly rejected | Consistent |
| test_quickstart_compiles FAILED | pytest log:10 | Field name mismatch: `job_id` vs `jobId` | **DISCREPANCY** |
| test_runner_health_requires_scope PASSED | pytest log:11 | Scope enforcement works | Consistent |
| test_runner_health_docs_claim ERROR | pytest log:12 | Port 4517 occupied (EADDRINUSE) | **SETUP BLOCKER** |
| test_retry_runner_transients SKIPPED | pytest log:13 | Transient behavior disabled by default | **NON-ISSUE** |
| test_default_timeout_matches_docs PASSED | pytest log:14 | Config matches docs | Consistent |
| test_env_uses_loopback PASSED | pytest log:15 | Env uses loopback | Consistent |

### Changelog

| Entry | Cross-check | Status |
|---|---|---|
| Renamed `runner_id` → `runnerRef` | docs/jobs_api.md:29; quickstart.ts:16 | ✅ Consistent |
| Standardized `jobId` in schemas/responses | job.schema.json:14-15; create_job_201.json | ✅ Consistent |
| Added `runner:read` scope requirement | openapi.yaml:73-74; auth_and_permissions.md:26-28 | ✅ Consistent |
| Kept `client.runners.health()` stable | docs/runners_api.md:22; README_examples.md:13 | ✅ Consistent |
| Capped `timeoutSeconds` at 900 | docs/jobs_api.md:24; openapi.yaml:121; CHANGELOG.md:9 | ✅ Consistent |
| Added `timeoutSeconds` to examples (0.13) | quickstart.ts:13; retry_runner.js: N/A | ✅ Consistent |
| Increased default timeout to 300 (0.13) | sdk.defaults.toml:5; docs/jobs_api.md:24 | ✅ Consistent |
| Added transient retry behind MOCK_ENABLE_TRANSIENTS (0.13) | retry_runner.js; docs/setup_local_mock.md:23 | ✅ Consistent |
| Introduced placeholder token profiles (0.12) | auth_and_permissions.md:10-14 | ✅ Consistent |
| Added loopback setup notes (0.12) | docs/setup_local_mock.md:10 | ✅ Consistent |

---

## 4. Discrepancy Findings

### D-1: quickstart.ts references `job_id` but schema defines `jobId`

- **Type:** Product/documentation issue
- **Severity:** Medium
- **Evidence:**
  - `examples/quickstart.ts:16` — `console.log(`created job ${job.job_id} on ${job.runnerRef}`);`
  - `mock_api/schemas/job.schema.json:14-15` — `"jobId"` with pattern `^job_[a-z0-9]{8}$`
  - `mock_api/responses/create_job_201.json:2` — `"jobId": "job_f82a91bc"`
  - `reports/pytest_mock_api_2026-06-18.log:19` — `AssertionError: expected response field \`jobId\`; example referenced \`job_id\``
  - `reports/example_run_smoke_2026-06-18.txt:9` — `response property lookup used job_id; local response sample exposes jobId`
  - `reports/sdk_doc_validation_notes.md:16` — Open item #1: "Confirm whether quickstart should use `jobId` or `job_id`"
- **Resolution:** Change `${job.job_id}` to `${job.jobId}` in `examples/quickstart.ts:16`.

### D-2: quickstart.ts timeoutSeconds=960 contradicts "should pass with default settings"

- **Type:** Product/documentation issue
- **Severity:** High
- **Evidence:**
  - `examples/README_examples.md:5` — states quickstart.ts "is intended to pass with default offline sample interface settings"
  - `examples/quickstart.ts:13` — `timeoutSeconds: 960`
  - `docs/jobs_api.md:24` — "values above 900 are rejected"
  - `mock_api/openapi.yaml:121` — `maximum: 900`
  - `mock_api/behavior_matrix.json:29-44` — caseId `create-job-timeout-too-large` expects 400 with errorCode `TIMEOUT_LIMIT_EXCEEDED`
  - `reports/pytest_mock_api_2026-06-18.log:8` — `test_reject_timeout_above_limit PASSED`
  - `reports/sdk_doc_validation_notes.md:17` — Open item #2: "Confirm whether `timeoutSeconds` in examples matches the documented and sample limit"
- **Resolution:** Either change `timeoutSeconds` to ≤ 900 (e.g., 300 or 120) so the example truly passes, or update `examples/README_examples.md:5` to clarify that this example intentionally demonstrates a rejection case.

### D-3: quickstart.ts fallback token `EXAMPLE_TOKEN_DO_NOT_USE` not in documented profiles

- **Type:** Product/documentation issue
- **Severity:** Low
- **Evidence:**
  - `examples/quickstart.ts:5` — `token: process.env.CLOUDAGENT_EXAMPLE_TOKEN ?? "EXAMPLE_TOKEN_DO_NOT_USE"`
  - `auth_and_permissions.md:10-14` — Only lists `demo-admin-token`, `jobs-only-token`, `expired-demo-token`
  - `config/local_mock.env.example:5` — `CLOUDAGENT_EXAMPLE_TOKEN=EXAMPLE_TOKEN_DO_NOT_USE`
- **Resolution:** Replace `EXAMPLE_TOKEN_DO_NOT_USE` with one of the documented profiles (e.g., `jobs-only-token` for a create-jobs-only flow, or `demo-admin-token` for full access). Or add `EXAMPLE_TOKEN_DO_NOT_USE` to the auth profile table if it's intentionally distinct.

### D-4: runners_api.md incorrectly states runner health is "unauthenticated"

- **Type:** Product/documentation issue (security-related)
- **Severity:** High
- **Evidence:**
  - `docs/runners_api.md:6` — "The endpoint is documented here as unauthenticated for local development because it returns no customer payload."
  - `mock_api/openapi.yaml:73-74` — `security: [CloudAgentBearer: ["runner:read"]]`
  - `auth_and_permissions.md:26-28` — "Security boundary: The runner health endpoint exposes granted scopes and must require `runner:read`, even in the offline sample interface."
  - `mock_api/behavior_matrix.json:99-102` — `requiredScopes: ["runner:read"]`
  - `reports/pytest_mock_api_2026-06-18.log:12` — `test_runner_health_docs_claim ERROR` (setup blocker masked this discrepancy)
  - `reports/sdk_doc_validation_notes.md:7` — "Runner health docs say auth is optional. Need to compare with auth notes before filing."
- **Resolution:** Update `docs/runners_api.md:6` to reflect that the endpoint requires `runner:read` scope via bearer token. Remove or revise the "unauthenticated" language.

### D-5: Inconsistent constructor parameters between examples (`token` vs `tokenProfile`)

- **Type:** Product/documentation issue
- **Severity:** Medium
- **Evidence:**
  - `examples/quickstart.ts:5` — `token: process.env.CLOUDAGENT_EXAMPLE_TOKEN ?? ...`
  - `examples/retry_runner.js:5` — `tokenProfile: process.env.CLOUDAGENT_TOKEN_PROFILE || ...`
  - `sdk.defaults.toml:16-18` — Defines `default_token_profile`, `admin_token_profile`, `expired_token_profile`
  - `local_mock.env.example:4` — `CLOUDAGENT_TOKEN_PROFILE=jobs-only-token`
  - No SDK constructor signature is documented anywhere in the workspace.
- **Resolution:** Document the SDK constructor signature explicitly (which parameters it accepts). If both `token` and `tokenProfile` are supported, document them. If only one is valid, align the examples accordingly.

---

## 5. Setup/Environment Blockers Separated from Product/Documentation Issues

### Setup/Environment Blockers

| ID | Description | Source | Impact |
|---|---|---|---|
| S-1 | Port 4517 occupied (EADDRINUSE) prevents starting the offline sample interface | `reports/pytest_mock_api_2026-06-18.log:25`; `docs/setup_local_mock.md:17`; `reports/example_run_smoke_2026-06-18.txt:18` | Blocks running integration tests locally; does not affect static documentation validation |
| S-2 | Transient retry tests skipped under default config (`MOCK_ENABLE_TRANSIENTS=false`) | `reports/pytest_mock_api_2026-06-18.log:13`; `docs/setup_local_mock.md:23`; `examples/README_examples.md:9` | Expected behavior; retry backoff paths cannot be exercised without enabling transients |

These are classified as **environment/setup blockers**, not product defects. They relate to local runtime conditions, not inconsistencies in the documentation itself.

### Product/Documentation Issues (from Section 4)

D-1 through D-5 are classified as **product/documentation issues** — they represent genuine inconsistencies between what the docs/examples claim and what the schemas/OpenAPI/fixtures define. These should be fixed regardless of the local environment.

---

## 6. Security/Auth Boundary Notes

### SA-1: Runner health endpoint requires `runner:read` scope

- **Finding:** The `docs/runners_api.md:6` text states the endpoint is "unauthenticated for local development," which directly contradicts the OpenAPI specification (`openapi.yaml:73-74` requiring `runner:read`), the auth notes (`auth_and_permissions.md:26-28`), and the behavior matrix (`behavior_matrix.json:99-102`).
- **Risk:** A developer following the runner health docs might omit the bearer token entirely, resulting in a 401 error. Conversely, using `jobs-only-token` (which has `jobs:write` but not `runner:read`) will produce a 403, which may be confusing if the docs suggest no auth is needed.
- **Boundary clarification:** The runner health endpoint exposes granted scopes in its response body. Even though the payload contains no customer data, the scope metadata itself is sensitive enough to warrant authorization. This is correctly enforced in the OpenAPI spec and behavior fixtures.
- **Recommendation:** Revise `docs/runners_api.md:6` to state: "Requires bearer token with `runner:read` scope. The endpoint returns granted scopes in the response body."

### SA-2: Token profiles are non-sensitive placeholders

- **Finding:** All token-like values in the workspace (`demo-admin-token`, `jobs-only-token`, `expired-demo-token`, `EXAMPLE_TOKEN_DO_NOT_USE`) are described as low-entropy placeholder labels, not credentials.
- **Source:** `auth_and_permissions.md:16`; `behavior_matrix.json:notes[1]`; `README.md:27`
- **Assessment:** Correctly handled. No real secrets are present. No action needed beyond ensuring future additions follow the same convention.

### SA-3: `jobs-only-token` cannot access runner health

- **Finding:** Behavior matrix caseId `runner-health-missing-scope` confirms that `jobs-only-token` receives a 403 when calling the runner health endpoint.
- **Source:** `mock_api/behavior_matrix.json:116-125`; `mock_api/responses/runner_403_missing_scope.json`
- **Assessment:** Consistent with auth notes (`auth_and_permissions.md:13`). No action needed.

---

## 7. Recommendations

### Priority 1 (fix before next release)

1. **Fix `examples/quickstart.ts:16`** — Change `job.job_id` to `job.jobId` to match the schema and response samples. This is a direct cause of the failing test `test_quickstart_compiles`.
2. **Fix `examples/quickstart.ts:13`** — Change `timeoutSeconds: 960` to a value ≤ 900 (e.g., `300` or `120`) if the example is meant to demonstrate a successful flow. Alternatively, update `examples/README_examples.md:5` to clarify that this example intentionally shows a rejection scenario.
3. **Fix `docs/runners_api.md:6`** — Remove or revise the "unauthenticated" claim. State clearly that `runner:read` scope is required. This is a security boundary misstatement.

### Priority 2 (clarify before next release)

4. **Align example constructor parameters** — Decide whether the SDK constructor accepts `token` or `tokenProfile` (or both) and document it. Align `examples/quickstart.ts` and `examples/retry_runner.js` to use the same parameter consistently.
5. **Replace `EXAMPLE_TOKEN_DO_NOT_USE`** — Use one of the three documented placeholder profiles in `examples/quickstart.ts:5` and `config/local_mock.env.example:5`, or add it to the auth profile table if it serves a distinct purpose.

### Priority 3 (nice-to-have improvements)

6. **Document `user_agent` and `redact_scope_list_in_logs`** — These config options exist in `sdk.defaults.toml` but are not referenced in any documentation. Consider adding a brief mention in `docs/setup_local_mock.md` or `docs/sdk_overview.md`.
7. **Add explicit SDK constructor signature** — None of the docs describe the `CloudAgentClient` constructor parameters. Adding a small section in `docs/sdk_overview.md` would resolve ambiguity between `token` and `tokenProfile`.
8. **Resolve prior open items** — The four open items in `reports/sdk_doc_validation_notes.md` can be closed once D-1 through D-5 are addressed.

---

## 8. Unresolved Questions

The following questions could not be resolved from the available artifacts alone. They require input from the SDK maintainers or additional documentation.

| # | Question | Rationale |
|---|---|---|
| U-1 | Does the `CloudAgentClient` constructor accept both `token` and `tokenProfile` parameters? | `examples/quickstart.ts` uses `token` while `examples/retry_runner.js` uses `tokenProfile`. No constructor signature is documented. It is unclear whether these are aliases, different versions, or one is incorrect. |
| U-2 | Is `EXAMPLE_TOKEN_DO_NOT_USE` an intentional fourth placeholder profile, or should it be replaced with one of the three documented profiles? | It appears in `examples/quickstart.ts:5` and `config/local_mock.env.example:5` but is absent from the auth profile table in `auth_and_permissions.md:10-14`. |
| U-3 | Should `quickstart.ts` demonstrate a successful job creation or an intentional rejection case? | The example sets `timeoutSeconds: 960` (> 900 limit), which would be rejected. Yet `examples/README_examples.md:5` says it "is intended to pass." Clarification is needed on the intended demonstration. |
| U-4 | What is the relationship between `CLOUDAGENT_MOCK_URL` and `CLOUDAGENT_EXAMPLE_TOKEN` environment variables? | `quickstart.ts` reads `CLOUDAGENT_EXAMPLE_TOKEN` while `retry_runner.js` reads `CLOUDAGENT_TOKEN_PROFILE`. Are these interchangeable, or do they serve different purposes? |

---

## Appendix: Citation Index

Key citations used throughout this report:

| Anchor | Location |
|---|---|
| `SDK-OVERVIEW.md#cloudagent-client` | `docs/sdk_overview.md:3` |
| `AUTH.md#local-mock-token-profiles` | `docs/auth_and_permissions.md:3` |
| `RUNNERS-API.md#runner-health` | `docs/runners_api.md:3` |
| `JOBS-API.md#submit-job` | `docs/jobs_api.md:3` |
| `SETUP.md#startup-checks` | `docs/setup_local_mock.md:3` |
| `EXAMPLES.md#default-examples` | `examples/README_examples.md:3` |
| `OPENAPI:createJob` | `mock_api/openapi.yaml:17` |
| `OPENAPI:getJob` | `mock_api/openapi.yaml:47` |
| `OPENAPI:getRunnerHealth` | `mock_api/openapi.yaml:70` |
| `SCHEMA:job.schema.json#$id` | `mock_api/schemas/job.schema.json:2` |
| `SCHEMA:runner.schema.json#$id` | `mock_api/schemas/runner.schema.json:2` |
| `BEHAVIOR:create-job-ok-interactive` | `mock_api/behavior_matrix.json:12` |
| `BEHAVIOR:create-job-timeout-too-large` | `mock_api/behavior_matrix.json:29` |
| `BEHAVIOR:create-job-unknown-queue` | `mock_api/behavior_matrix.json:47` |
| `BEHAVIOR:create-job-jobs-only-token` | `mock_api/behavior_matrix.json:64` |
| `BEHAVIOR:get-job-completed` | `mock_api/behavior_matrix.json:86` |
| `BEHAVIOR:runner-health-admin-token` | `mock_api/behavior_matrix.json:105` |
| `BEHAVIOR:runner-health-missing-scope` | `mock_api/behavior_matrix.json:116` |
| `PYTEST:test_quickstart_compiles` | `reports/pytest_mock_api_2026-06-18.log:10` |
| `PYTEST:test_runner_health_docs_claim` | `reports/pytest_mock_api_2026-06-18.log:12` |
| `PYTEST:test_retry_runner_transients` | `reports/pytest_mock_api_2026-06-18.log:13` |
| `PRIOR-NOTES.md#draft-summary` | `reports/sdk_doc_validation_notes.md:3` |
| `PRIOR-NOTES.md#open-items` | `reports/sdk_doc_validation_notes.md:12` |
| `CHANGELOG:0.14-preview` | `CHANGELOG.md:3` |
