# Workbook: fund_product_workbook.xlsx

## Sheet 1: product_comparison
Dimensions: 5 rows x 14 columns
R1: canonical_product_id | canonical_product_name | share_class | product_code | fund_type | operation_mode | open_frequency | min_holding_days | strategy_summary | risk_return_feature_text | standard_risk_level | sales_suitability_bucket | esg_tag_internal | source_trace
R2: FP-1301 | 安桥稳收一年持有 | A | FP1301A | 债券型 | 一年最短持有 | 每个开放日可申购；赎回受最短持有期限制 | 365天 | 以中短久期债券为主，可配置少量可转债增强资产 | 债券型产品，长期平均风险和预期收益低于股票型、混合型产品，高于货币市场产品。销售机构风险评价标签：稳健型客户可关注。 | R2 | 稳健型及以上 | 绿色债券配置说明 | anqiao_income_A_summary.pdf
R3: FP-1301 | 安桥稳收一年持有 | C | FP1301C | 债券型 | 一年最短持有 | 每个开放日可申购；赎回受最短持有期限制 | 365天 | 以中短久期债券为主，可配置少量可转债增强资产 | 债券型产品，长期平均风险和预期收益低于股票型、混合型产品，高于货币市场产品。销售机构风险评价标签：中低风险。 | R2 | 稳健型及以上 | 绿色债券配置说明 | anqiao_income_C_summary.pdf
R4: FP-1302 | 柏舟成长精选 | A | FP1302A | 混合型 | 普通开放式 | 每个开放日开放申购和赎回 | 无 | 围绕成长行业进行分散配置，并保留现金仓位应对申赎 | 混合型产品，权益资产占比较高，预期风险和收益高于债券型产品。销售机构风险评价标签：进取型。 | R4 | 积极型及以上 |  | baizhou_growth_A_summary.pdf
R5: FP-1303 | 澄岳均衡配置 | A | FP1303A | 混合型 | 普通开放式 | 每个开放日开放申购；赎回按销售规则确认 | 无 | 在权益、债券和现金类资产之间做均衡配置 | 混合型产品，风险和预期收益介于债券型和偏股型产品之间。销售机构风险评价标签：平衡型。 | R3 | 平衡型及以上 | 投研备注中出现ESG观察标签 | chengyue_balanced_A_summary.pdf

## Sheet 2: fee_schedule
Dimensions: 31 rows x 12 columns
R1: canonical_product_id | share_class | fee_section | fee_type | investor_group | condition | fee_value | fee_unit | fee_status | charge_party | effective_date | source_trace
R2: FP-1301 | A | sales_fee | subscription_frontend | 非特定投资群体 | M < 100万元 | 0.6 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R3: FP-1301 | A | sales_fee | subscription_frontend | 非特定投资群体 | 100万元 ≤ M < 500万元 | 0.4 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R4: FP-1301 | A | sales_fee | subscription_frontend | 非特定投资群体 | M ≥ 500万元 | 1000 | CNY_per_txn | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R5: FP-1301 | A | sales_fee | subscription_frontend | 特定投资群体 | M < 100万元 | 0.06 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R6: FP-1301 | A | sales_fee | redemption | 全部投资群体 | N < 7天 | 1.5 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R7: FP-1301 | A | sales_fee | redemption | 全部投资群体 | 7天 ≤ N < 365天 | 0.2 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R8: FP-1301 | A | sales_fee | redemption | 全部投资群体 | N ≥ 365天 | 0 | percent_per_year | waived | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R9: FP-1301 | A | operation_fee | management | 全部投资群体 | annual_rate | 0.46 | percent_per_year | active | 管理人和销售机构 | 2026-06-01 | raw_fee_table.xlsx
R10: FP-1301 | A | operation_fee | custody | 全部投资群体 | annual_rate | 0.08 | percent_per_year | active | 托管人 | 2026-06-01 | raw_fee_table.xlsx
R11: FP-1301 | A | operation_fee | sales_service | 全部投资群体 | annual_rate | 0 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R12: FP-1301 | A | comprehensive_fee | comprehensive | 全部投资群体 | annualized_estimate | 0.61 | percent_per_year | active | 产品资产 | 2026-06-01 | raw_fee_table.xlsx
R13: FP-1301 | C | sales_fee | subscription_frontend | 全部投资群体 | 全部金额 | 0 | percent_per_year | waived | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R14: FP-1301 | C | sales_fee | redemption | 全部投资群体 | N < 7天 | 1.5 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R15: FP-1301 | C | sales_fee | redemption | 全部投资群体 | N ≥ 7天 | 0 | percent_per_year | waived | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R16: FP-1301 | C | operation_fee | management | 全部投资群体 | annual_rate | 0.45 | percent_per_year | active | 管理人和销售机构 | 2026-06-01 | raw_fee_table.xlsx
R17: FP-1301 | C | operation_fee | custody | 全部投资群体 | annual_rate | 0.08 | percent_per_year | active | 托管人 | 2026-06-01 | raw_fee_table.xlsx
R18: FP-1301 | C | operation_fee | sales_service | 全部投资群体 | annual_rate | 0.2 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R19: FP-1301 | C | comprehensive_fee | comprehensive | 全部投资群体 | annualized_estimate | 0.73 | percent_per_year | active | 产品资产 | 2026-06-01 | raw_fee_table.xlsx
R20: FP-1302 | A | sales_fee | subscription_frontend | 非特定投资群体 | M < 100万元 | 1.2 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R21: FP-1302 | A | sales_fee | subscription_frontend | 非特定投资群体 | M ≥ 100万元 | 0.8 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R22: FP-1302 | A | sales_fee | redemption | 全部投资群体 | N < 30天 | 0.5 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R23: FP-1302 | A | sales_fee | redemption | 全部投资群体 | N ≥ 30天 | 0 | percent_per_year | waived | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R24: FP-1302 | A | operation_fee | management | 全部投资群体 | annual_rate | 1.2 | percent_per_year | active | 管理人和销售机构 | 2026-06-01 | raw_fee_table.xlsx
R25: FP-1302 | A | operation_fee | custody | 全部投资群体 | annual_rate | 0.1 | percent_per_year | active | 托管人 | 2026-06-01 | raw_fee_table.xlsx
R26: FP-1302 | A | comprehensive_fee | comprehensive | 全部投资群体 | annualized_estimate | 1.45 | percent_per_year | active | 产品资产 | 2026-06-01 | raw_fee_table.xlsx
R27: FP-1303 | A | sales_fee | redemption | 某渠道优惠 | 全部持有期 | 0 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R28: FP-1303 | A | operation_fee | management | 全部投资群体 | annual_rate |  | percent_per_year | active | 管理人和销售机构 | 2026-06-01 | raw_fee_table.xlsx
R29: FP-1303 | A | operation_fee | custody | 全部投资群体 | annual_rate | 0.1 | percent_per_year | active | 托管人 | 2026-06-01 | raw_fee_table.xlsx
R30: FP-1303 | A | operation_fee | sales_service | 全部投资群体 | annual_rate | 0 | percent_per_year | active | 销售机构 | 2026-06-01 | raw_fee_table.xlsx
R31: FP-1303 | A | comprehensive_fee | comprehensive | 全部投资群体 | annualized_estimate |  | percent_per_year | active | 产品资产 | 2026-06-01 | raw_fee_table.xlsx

## Sheet 3: risk_level_mapping
Dimensions: 5 rows x 8 columns
R1: canonical_product_id | share_class | source_risk_label | standard_risk_level | risk_order | sales_suitability_bucket | risk_return_feature_text | mapping_source
R2: FP-1301 | A | 稳健型客户可关注 | R2 | 2 | 稳健型及以上 | 债券型产品，长期平均风险和预期收益低于股票型、混合型产品，高于货币市场产品。 | risk_codebook.xlsx
R3: FP-1301 | C | 中低风险 | R2 | 2 | 稳健型及以上 | 债券型产品，长期平均风险和预期收益低于股票型、混合型产品，高于货币市场产品。 | risk_codebook.xlsx
R4: FP-1302 | A | 进取型 | R4 | 4 | 积极型及以上 | 混合型产品，权益资产占比较高，预期风险和收益高于债券型产品。 | risk_codebook.xlsx
R5: FP-1303 | A | 平衡型 | R3 | 3 | 平衡型及以上 | 混合型产品，风险和预期收益介于债券型和偏股型产品之间。 | risk_codebook.xlsx

## Sheet 4: exceptions
Dimensions: 6 rows x 8 columns
R1: exception_id | canonical_product_id | share_class | exception_type | field_name | source_value | resolution_action | source_trace
R2: EXC-001 | FP-1303 | A | missing_field | management_fee | None (empty) | 未提供具体数值，无法计算综合费率 | raw_fee_table.xlsx
R3: EXC-002 | FP-1303 | A | missing_field | comprehensive_fee | None (cannot compute) | 因管理费缺失，无法计算综合费率 | raw_fee_table.xlsx
R4: EXC-003 | FP-1303 | A | fee_waiver_note | redemption_fee | 0 (某渠道优惠) | 渠道优惠仅作为异常提示，不覆盖标准费率 | raw_fee_table.xlsx
R5: EXC-004 | FP-1301 | A | missing_field | fixed_fee_trap | 每笔1000元 | 固定费用陷阱已标注，需关注大额申购成本 | raw_fee_table.xlsx
R6: EXC-005 | FP-1302 | A | resolved_effective_date_conflict | risk_label | 高波动成长型（旧渠道备注） | 使用产品概要中的'进取型'标签，依据conflict_priority | ops_profile_notes.md
