import itertools
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1]) / 'pr4-6a3f36ed'
tasks = ('engineering', 'fiction', 'code', 'policy', 'science')
def load(path):
    return json.loads(path.read_text())
def answer(item):
    return item['response']['choices'][0]['message']['content']
def compare(a,b,names):
    rows = [(load(root/a/(k+'.json')),load(root/b/(k+'.json'))) for k in names]
    assert all(x['request']['messages'] == y['request']['messages'] for x,y in rows)
    return [answer(x) == answer(y) for x,y in rows]
groups = ['reverse','validation','confirm','confirm-new']
for group in groups:
    prefix = 'structured-'+group+'-'
    control = prefix+'ar-8-exact-off-km-nopack-plain-512'
    candidate = prefix+'6-8-exact-off-km-nopack-plain-512'
    names = [p.stem for p in (root/control).glob('*.json') if 'assessment' in load(p)]
    assert len(names) == (12 if group in ('validation','confirm-new') else 8)
    assert all(compare(control,candidate,names))
    assert all(load(root/control/(k+'.json'))['assessment']['task_check'] == load(root/candidate/(k+'.json'))['assessment']['task_check'] for k in names)
first='one-slot-8-6-threshold-on-q40-pack-fuse-8192'
second='confirmation-8-6-threshold-on-q40-pack-fuse-8192'
print('Long candidate matches across runs',dict(zip(tasks,compare(first,second,tasks))))
for name in [first,second,'one-slot-ar-8-exact-on-q40-pack-plain-8192','confirmation-ar-8-exact-on64-q40-pack-plain-8192']:
    xs=[load(root/name/(k+'.json'))['response'] for k in tasks]
    t=sum(x['timings']['predicted_n'] for x in xs); s=sum(x['timings']['predicted_ms'] for x in xs)/1000
    print(name,t,round(t/s,2),[x['choices'][0]['finish_reason'] for x in xs])
for f in (root/'ferry-pr-fourway').glob('*.json'):
    assert load(f)['reason']=='eos' and load(f)['loop'] is None
for label in ('grade-q40-fused','grade-q40-matched','grade-q40-short-history'):
    xs=[load(f) for f in (root/label).glob('*.json')]
    assert len(xs)==10
    print(label,sum(x['control'] for x in xs)/10,sum(x['candidate'] for x in xs)/10)
print('Verified 40 exact structured answer comparisons.')
