import ast
import json
from pathlib import Path
import re
import subprocess
import sys

root=Path(__file__).resolve().parent
for key in sys.argv[1:]:
    folder=root/key
    result=json.loads((folder/'code.json').read_text())['response']['choices'][0]['message']['content']
    blocks=re.findall(r'^```(?:python|py|python3)[^\n]*\n(.*?)^```',result,re.M|re.S|re.I)
    if not blocks: raise ValueError('unrecognized code fence: '+key)
    program=max(blocks,key=len)
    print(key,'program length',len(program))
    (folder/'cli-generated.py.txt').write_text(program)
    spec={'code':program}
    try:
        tree = ast.parse(program)
    except SyntaxError:
        tree = ast.Module(body=[], type_ignores=[])
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or getattr(node.func, "attr", "") != "add_argument":
            continue
        flag = next((arg.value for arg in node.args if isinstance(arg, ast.Constant)
                     and isinstance(arg.value, str) and arg.value.startswith("--")
                     and any(word in arg.value for word in ("json", "summary", "report"))), None)
        if flag:
            action = next((getattr(k.value, "value", "") for k in node.keywords if k.arg=="action"), "")
            spec["summary_args"] = [flag] if action in ("store_true","store_false") else [flag,"{summary}"]
            break
    override=folder/'cli-args.json' 
    if override.exists():spec['args']=json.loads(override.read_text())
    args=['docker','run','--rm','-i','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--user','65534:65534','--pids-limit','32','--memory','256m','--cpus','1','--tmpfs','/tmp:rw,nosuid,nodev,size=32m','-v',str(root/'code_checks.py')+':/check.py:ro','--entrypoint','python3','clover-llamacpp:pr31306','-I','/check.py']
    p=subprocess.run(args,input=json.dumps(spec),capture_output=True,text=True,check=True,timeout=90)
    (folder/'code-check.json').write_text(p.stdout)
    x=json.loads(p.stdout);print('checks',{k:v for k,v in x.items() if type(v)==bool},'sample error',x['first'][2][-350:])
