import json
import re
import sys
from pathlib import Path
from statistics import mean
root=Path(sys.argv[1])
for path in sorted(root.iterdir()):
    if not path.is_dir(): continue
    values={}
    for task in ('engineering','fiction','code','policy','science'):
        f=path/(task+'.json')
        if not f.exists(): continue
        d=json.loads(f.read_text())['response'];t=d['timings'];c=d['choices'][0]
        text=c['message']['content']; w=re.findall(r'\w+|[^\w\s]',text.lower()); g=[tuple(w[i:i+12]) for i in range(len(w)-11)]
        values[task]=dict(tokens=t['predicted_n'],ms=t['predicted_ms'],tps=t['predicted_per_second'],stop=c['finish_reason'],repeat=round(100*(1-len(set(g))/len(g)),2) if g else 0,words=len(text.split()))
    if not values:continue
    r=list(values.values())
    print(path.name,len(r),'pooled',round(1000*sum(t['tokens'] for t in r)/sum(t['ms'] for t in r),2),'macro',round(mean(t['tps'] for t in r),2))
    (path/'metrics.json').write_text(json.dumps(values,indent=2))
