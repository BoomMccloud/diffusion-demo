set -eu
cd ~/diffusion-demo/runs/dllm-inhouse-4257d3dd
d=pr4-6a3f36ed
for p in 18080 18081; do curl -fsS --retry 40 --retry-all-errors --retry-delay 2 "http://127.0.0.1:$p/health" >/dev/null; done
for service in dllm-clover-self-4257 dllm-clover-ar-4257; do
  docker logs "$service" 2>&1 | tail -30 | grep -q 'all slots are idle'
done
trap 'docker start dllm-clover-self-4257 dllm-clover-ar-4257 >/dev/null' EXIT
docker stop dllm-clover-self-4257 dllm-clover-ar-4257
TRIAL_TAG=reverse python3 -u "$d/structured.py" 512 8-6-threshold-light-km-nopack-plain ar-8-exact-off-km-nopack-plain 6-8-exact-off-km-nopack-plain
TRIAL_TAG=forward python3 -u "$d/structured.py" 512 ar-8-exact-off-km-nopack-plain 8-6-threshold-light-km-nopack-plain
VALIDATION=1 TRIAL_TAG=validation python3 -u "$d/structured.py" 512 8-6-threshold-light-km-nopack-plain ar-8-exact-off-km-nopack-plain 6-8-exact-off-km-nopack-plain
python3 -u "$d/layout-run.py" 8192 6-8-exact-on-km-pack-fuse 8-6-threshold-light-q40-pack-plain ar-8-exact-off-q40-pack-plain
