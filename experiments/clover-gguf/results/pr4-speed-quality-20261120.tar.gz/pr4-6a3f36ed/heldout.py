import sys
import json
import pathlib
import subprocess
import time
import urllib.request

root = pathlib.Path.cwd()
out = root / "pr4-6a3f36ed"
endpoint = "http://127.0.0.1:18195"
prompts = {}
for filename in ["varied-long-comparison.json", "varied-long-prose-comparison.json"]:
    saved = json.loads((root / filename).read_text())
    assert saved["settings"] == dict(temperature=0, seed=42, max_tokens=8192, context=131072, thinking=False, cache_prompt=False)
    prompts.update(saved["prompts"])
assert set(prompts) == {"fiction","engineering","policy","science","code"}

def docker(*args):
    return subprocess.check_output(["docker", *args], text=True).strip()

def run(config, limit):
    mode = f"heldout-{config}-{limit}"
    width, experts, policy, penalty, quant, pack, fuse = config.split("-")
    if config.startswith("ar-"):
        spec = []
    else:
        spec = ["--spec-type","self","--spec-self-width",width,"--spec-self-verify-experts",experts,"--spec-self-acceptance",policy]
    if pack == "pack":
        spec.append("--repack")
    experiment = "kernels" if fuse == "fuse" else "tuned"
    env = ["-e","CLOVER_CUDA_CONV=1","-e","CLOVER_READONLY_PREVIEW=1"] if fuse=="fuse" else []
    model = "/work/clover-public-Q4_K_M.gguf" if quant=="km" else "/work/pr4-6a3f36ed/clover-Q4_0.gguf"
    directory = out / mode
    directory.mkdir(exist_ok=True)
    name = "clover-five-prompt-" + mode
    if all((directory / (k+".json")).exists() for k in prompts): return
    docker("run", "-d", "--name", name, "--gpus", "all", "--memory", "38g", "--cpus", "8",
           "-p", "127.0.0.1:18195:18195", "-v", f"{root}:/work:ro",
           *env, "-e", f"LD_LIBRARY_PATH=/work/pr4-6a3f36ed/{experiment}/bin:/work/pr4-6a3f36ed/build/bin:/usr/local/cuda/lib64:/usr/lib/aarch64-linux-gnu",
           "--entrypoint", f"/work/pr4-6a3f36ed/{experiment}/bin/llama-server", "clover-llamacpp:pr31306",
           "-m", model, "--alias", "clover", "-lv", "3", *spec, "--fit", "off", "-c", "131072",
           "-ngl", "99", "-np", "1", "-t", "4", "--cache-ram", "0", "--host", "0.0.0.0", "--port", "18195")
    try:
        for _ in range(150):
            try:
                if json.load(urllib.request.urlopen(endpoint + "/health", timeout=2))["status"] == "ok":
                    break
            except OSError:
                pass
            if docker("inspect", "--format", "{{.State.Running}}", name) != "true":
                raise RuntimeError("server exited")
            time.sleep(1)
        else:
            raise RuntimeError("startup timeout")
        import importlib.util
        loader=importlib.util.spec_from_file_location("panel",root/"task_panel.py")
        panel=importlib.util.module_from_spec(loader);loader.loader.exec_module(panel)
        tasks={t["id"]:t for t in panel.TASKS if t["kind"] in ("json","code") or t["id"] == "fiction_station"}
        for task,description in tasks.items():
            prompt=description["prompt"]
            dest = directory / (task + ".json")
            if dest.exists():
                continue
            body = dict(model="clover", messages=[dict(role="user",content=prompt)], temperature=0, seed=42,
                        max_tokens=8192 if task == "fiction_station" else limit, cache_prompt=False, chat_template_kwargs=dict(enable_thinking=False))
            if penalty == "on":
                body.update(repeat_penalty=1.05, presence_penalty=0.9, frequency_penalty=0, repeat_last_n=-1)
            if penalty == "light":
                body.update(repeat_penalty=1.02, presence_penalty=0.3, frequency_penalty=0, repeat_last_n=-1)
            if not config.startswith("ar-"):
                body["speculative_penalties"] = dict(think_end_bias=0, length_bias=0)
            req = urllib.request.Request(endpoint+"/v1/chat/completions",data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
            with urllib.request.urlopen(req, timeout=1800) as f:
                result = json.load(f)
            choice = result["choices"][0]
            timings = result["timings"]
            assert choice["finish_reason"] in ["stop", "length"] and choice["message"]["content"]
            assert not choice["message"].get("reasoning_content") and timings["predicted_n"] == result["usage"]["completion_tokens"]
            temp = dest.with_suffix(".tmp")
            temp.write_text(json.dumps(dict(request=body,response=result,assessment=panel.assess(description,{"content":choice["message"]["content"],"reasoning":""})),ensure_ascii=False))
            temp.replace(dest)
            print(mode, task, choice["finish_reason"], timings["predicted_n"], round(timings["predicted_per_second"],2), flush=True)
        if config.startswith("6-4-"):
            def post(path, body):
                req = urllib.request.Request(endpoint + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
                return json.load(urllib.request.urlopen(req, timeout=45))
            template = post("/apply-template", {"messages": [{"role":"user","content":"Write one sentence about the sea."}], "chat_template_kwargs":{"enable_thinking":False}})["prompt"]
            close = post("/tokenize", {"content":"</think>","parse_special":True,"add_special":False})["tokens"]
            results = {}
            for bias in (0, 1000):
                settings = dict(think_end_bias=bias, think_end_start=0, think_end_window=1, length_bias=0)
                results[str(bias)] = post("/completion", dict(prompt=template, speculative_penalties=settings, temperature=0, seed=42, n_predict=12, return_tokens=True, cache_prompt=False))
            (directory/"think-state-probe.json").write_text(json.dumps(dict(template=template,close=close,results=results)))
            print("thinking-disabled close token", close, {k:v.get("tokens") for k,v in results.items()}, flush=True)
    finally:
        logs = subprocess.run(["docker","logs",name],text=True,capture_output=True)
        (directory / "server.log").write_text(logs.stdout+logs.stderr)
        docker("rm","-f",name)


for config in sys.argv[2:]:
    run(config, int(sys.argv[1]))
