import itertools
import json
import pathlib
import sys
root=pathlib.Path(sys.argv[1])
def piece(row,i):
    pairs=dict(row['pieces'])
    return pairs.get(i,'(multi-token chunk)')
cases={p.stem:json.loads(p.read_text()) for p in sorted(root.glob('*.json')) if p.stem != 'comparisons'}
for a,b in itertools.combinations(cases,2):
    x,y=cases[a],cases[b]
    n=next((i for i,(u,v) in enumerate(zip(x['ids'],y['ids'])) if u!=v),min(len(x['ids']),len(y['ids'])))
    print(a,b,n+1,repr(piece(x,n+1)),repr(piece(y,n+1)),x['ids'][n:n+1],y['ids'][n:n+1])
