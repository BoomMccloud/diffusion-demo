from guard_stream import request as guarded_request
import sys
import json
import pathlib
import subprocess
import time
import urllib.request

root = pathlib.Path.cwd()
out = root / "pr4-6a3f36ed"
endpoint = "http://127.0.0.1:18195"
prompts = {}
for filename in ["varied-long-comparison.json", "varied-long-prose-comparison.json"]:
    saved = json.loads((root / filename).read_text())
    assert saved["settings"] == dict(temperature=0, seed=42, max_tokens=8192, context=131072, thinking=False, cache_prompt=False)
    prompts.update(saved["prompts"])
assert set(prompts) == {"fiction","engineering","policy","science","code"}

def docker(*args):
    return subprocess.check_output(["docker", *args], text=True).strip()

def run(config, limit):
    mode = f"guard-{config}-{limit}"
    width, experts, policy, penalty, quant, pack, fuse = config.split("-")
    if config.startswith("ar-"):
        spec = []
    else:
        spec = ["--spec-type","self","--spec-self-width",width,"--spec-self-verify-experts",experts,"--spec-self-acceptance",policy]
    if pack == "pack":
        spec.append("--repack")
    experiment = "kernels" if fuse == "fuse" else "tuned"
    env = ["-e","CLOVER_CUDA_CONV=1","-e","CLOVER_READONLY_PREVIEW=1"] if fuse=="fuse" else []
    model = "/work/clover-public-Q4_K_M.gguf" if quant=="km" else "/work/pr4-6a3f36ed/clover-Q4_0.gguf"
    directory = out / mode
    directory.mkdir(exist_ok=True)
    name = "clover-five-prompt-" + mode
    if all((directory / (k+".json")).exists() for k in prompts): return
    docker("run", "-d", "--name", name, "--gpus", "all", "--memory", "38g", "--cpus", "8",
           "-p", "127.0.0.1:18195:18195", "-v", f"{root}:/work:ro",
           *env, "-e", f"LD_LIBRARY_PATH=/work/pr4-6a3f36ed/{experiment}/bin:/work/pr4-6a3f36ed/build/bin:/usr/local/cuda/lib64:/usr/lib/aarch64-linux-gnu",
           "--entrypoint", f"/work/pr4-6a3f36ed/{experiment}/bin/llama-server", "clover-llamacpp:pr31306",
           "-m", model, "--alias", "clover", "-lv", "3", *spec, "--fit", "off", "-c", "131072",
           "-ngl", "99", "-np", "1", "-t", "4", "--cache-ram", "0", "--host", "0.0.0.0", "--port", "18195")
    try:
        for _ in range(150):
            try:
                if json.load(urllib.request.urlopen(endpoint + "/health", timeout=2))["status"] == "ok":
                    break
            except OSError:
                pass
            if docker("inspect", "--format", "{{.State.Running}}", name) != "true":
                raise RuntimeError("server exited")
            time.sleep(1)
        else:
            raise RuntimeError("startup timeout")
        for task, prompt in prompts.items():
            dest = directory / (task + ".json")
            if dest.exists():
                continue
            body = dict(model="clover", messages=[dict(role="user",content=prompt)], temperature=0, seed=42,
                        max_tokens=limit, cache_prompt=False, chat_template_kwargs=dict(enable_thinking=False))
            if penalty == "on":
                body.update(repeat_penalty=1.05, presence_penalty=0.9, frequency_penalty=0, repeat_last_n=-1)
            if penalty == "light":
                body.update(repeat_penalty=1.02, presence_penalty=0.3, frequency_penalty=0, repeat_last_n=-1)
            if not config.startswith("ar-"):
                body["speculative_penalties"] = dict(think_end_bias=0, length_bias=0)
            item=guarded_request(endpoint,body,config.startswith("ar-"),endpoint)
            tmp=dest.with_suffix(".tmp");tmp.write_text(json.dumps(item,ensure_ascii=False));tmp.replace(dest)
            print(mode,task,[x['reason'] for x in item['attempts']],item['response']['usage']['completion_tokens'],round(item['delivered_tps'],2),flush=True)
    finally:
        logs = subprocess.run(["docker","logs",name],text=True,capture_output=True)
        (directory / "server.log").write_text(logs.stdout+logs.stderr)
        docker("rm","-f",name)


for config in sys.argv[2:]:
    run(config, int(sys.argv[1]))
