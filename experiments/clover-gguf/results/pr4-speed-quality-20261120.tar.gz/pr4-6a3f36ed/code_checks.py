"""Run inside a disposable network-isolated container. Read one JSON test bundle on stdin."""
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile
spec=json.load(sys.stdin)
work=pathlib.Path(tempfile.mkdtemp(dir='/tmp'))
app=work/'app.py'; app.write_text(spec['code'])
src=work/'source'; src.mkdir()
(src/'report.txt').write_text('report v1\n')
(src/'private.tmp').write_text('skip me')
(src/'nested').mkdir()
(src/'nested'/'note.txt').write_text('notes\n')
dst=work/'target'; dst.mkdir()
def call(*flags):
    args=[s.replace('{src}',str(src)).replace('{dst}',str(dst)) for s in spec.get('args',['{src}','{dst}'])]
    cmd=[sys.executable,'-I',str(app),*args,*flags]
    try:
        result=subprocess.run(cmd, cwd=work,capture_output=True,text=True,timeout=12)
        return result.returncode,result.stdout[-1400:],result.stderr[-500:]
    except subprocess.TimeoutExpired:
        return 124,'','timeout'
def content(path):
    return path.read_text() if path.is_file() else None
dry=call('--dry-run')
dry_ok=dry[0]==0 and not list(dst.rglob('*'))
dry_created=[str(v.relative_to(dst)) for v in dst.rglob('*')]
first=call()
copied=content(dst/'report.txt')==content(src/'report.txt') and content(dst/'nested'/'note.txt')==content(src/'nested'/'note.txt')
original_dst=dst
dst=work/'filtered';dst.mkdir()
filtered=call('--exclude','*.tmp')
excluded=filtered[0]==0 and content(dst/'report.txt')==content(src/'report.txt') and not (dst/'private.tmp').exists()
if not excluded:
    dst=work/'filtered-regex';dst.mkdir()
    regex_result=call('--exclude',r'.*\.tmp$')
    excluded=regex_result[0]==0 and content(dst/'report.txt')==content(src/'report.txt') and not (dst/'private.tmp').exists()
else:
    regex_result=None
dst=original_dst
(src/'report.txt').write_text('report v2 updated\n')
summary_file=work/'requested-summary.json'
summary_args=[str(summary_file) if arg=='{summary}' else arg for arg in spec.get('summary_args',[])]
second=call()
summary=call(*summary_args)
updated=content(dst/'report.txt')==content(src/'report.txt')
def has_summary():
    for s in [summary[1],content(summary_file) or '', *(p.read_text() for p in dst.glob('*summary*.json'))]:
        try:
            if isinstance(json.loads(s),dict): return True
        except ValueError: pass
    return False
print(json.dumps(dict(dry_run=dry_ok,copy=first[0]==0 and copied,exclude=excluded,update=second[0]==0 and updated,json_summary=summary[0]==0 and has_summary(),dry=dry,dry_created=dry_created,regex_result=regex_result,first=first,second=second,filtered=filtered,summary=summary)))
