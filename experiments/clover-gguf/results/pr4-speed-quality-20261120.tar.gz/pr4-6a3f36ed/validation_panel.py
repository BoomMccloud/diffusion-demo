"""Unseen deterministic tasks for validating structured response throughput."""
import json
from task_panel import assess

TASKS = []
def add_json(name, prompt, answer):
    TASKS.append(dict(id=name, kind="json", prompt=prompt+" Return only JSON.", expected=answer))
def add_code(name, prompt, answer):
    TASKS.append(dict(id=name, kind="code", prompt=prompt+" Return only the requested Python definition.", expected=answer))

# Deterministic fixtures, independent of the generated answers.
rows = [dict(id=f"T{i:02d}", team=("east","west","north")[i%3], active=i%4!=0, units=(7*i+11)%31) for i in range(1,19)]
data = json.dumps(rows, separators=(",",":"))
add_json("active_west", "From these records, list the id of each active west record in input order. "+data, [r["id"] for r in rows if r["active"] and r["team"]=="west"])
add_json("minimum_units", "From these records return the id and units of the one record with the lowest units as an object with keys id and units. "+data, {k:min(rows,key=lambda r:r["units"])[k] for k in ("id","units")})
add_json("transcribe", 'Convert these rows to an array of {"ticket":string,"owner":string} in order: K8 Mina; A2 Jia; R4 Leo; E7 Yu; P3 Amara; Q1 Theo; C9 Eli; W5 Ana.', [dict(ticket=k,owner=v) for k,v in (("K8","Mina"),("A2","Jia"),("R4","Leo"),("E7","Yu"),("P3","Amara"),("Q1","Theo"),("C9","Eli"),("W5","Ana"))])
add_json("coercion", 'Convert these values to native JSON types, preserving order: the string 0042, false, null, negative three, the empty string, true, zero.', ["0042",False,None,-3,"",True,0])
add_json("patch_order", 'Apply assignments in order to {"open":true,"owner":"Dee","count":3}. Set owner to Kai, count to 4, open to false, count to 7. Return the resulting object.', dict(open=False,owner="Kai",count=7))
add_json("schema", 'An event has id AA7, tags red and blue, approval false. The required object has id and metadata. metadata contains approved and tags. Preserve tag order.', dict(id="AA7",metadata=dict(approved=False,tags=["red","blue"])))
add_json("arithmetic", "Compute 218 times 37, and 9084 minus 2765. Use keys product and difference.",dict(product=218*37,difference=9084-2765))
add_json("net_units", "Stock has 682 items. Add 191, ship 247, scrap 16. Each remaining item costs 13 dollars. Use keys units and dollars.", dict(units=682+191-247-16,dollars=13*(682+191-247-16)))
add_json("calendar_call", 'Select the function create_event(title,day) or search_event(term). Schedule "Dock check" for 2027-02-04. Use keys name and arguments.',dict(name="create_event",arguments=dict(title="Dock check",day="2027-02-04")))
add_json("tool_projection", 'A search tool returned {"name":"Rhea","email":"r@example.org","dept":"ops","id":44}. User asks for department and identifier only; use keys department and identifier.', dict(department="ops",identifier=44))
add_code("off_by_one", 'Edit only the integer literal so the last five items are returned:\ndef tail(a):\n    return a[-4:]','def tail(a):\n    return a[-5:]')
add_code("safe_default", 'Replace only the constant None with 0 in this function:\ndef attempts(d):\n    return d.get("attempts", None)','def attempts(d):\n    return d.get("attempts", 0)')
