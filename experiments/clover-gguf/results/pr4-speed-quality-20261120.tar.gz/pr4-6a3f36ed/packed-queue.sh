set -eu
cd ~/diffusion-demo/runs/dllm-inhouse-4257d3dd
for service in dllm-clover-self-4257 dllm-clover-ar-4257; do
    docker logs "$service" 2>&1 | tail -1 | grep 'all slots are idle'
done
restore_services() {
    docker start dllm-clover-self-4257 dllm-clover-ar-4257 >/dev/null
}
trap restore_services EXIT
docker stop dllm-clover-self-4257 dllm-clover-ar-4257
d=pr4-6a3f36ed
# Matching 512-token, five-prompt screens with and without packed weights.
python3 -u "$d/layout-run.py" 512 ar-8-exact-off-q40-pack-plain 16-8-exact-on-q40-pack-plain 16-6-threshold-light-q40-pack-plain 8-8-exact-light-km-pack-plain 8-8-exact-light-km-pack-fuse
