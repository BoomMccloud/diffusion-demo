import json, os, pathlib, subprocess, time, urllib.request

root = pathlib.Path.cwd()
out = root / 'pr4-6a3f36ed' / 'ferry-pr-fourway'
out.mkdir(exist_ok=True)
panel = root / 'task-panel-20261120'
prompt = next(t['prompt'] for t in json.loads((panel/'manifest.json').read_text())['tasks'] if t['id']=='fiction_station')
base = 'http://127.0.0.1:18194'
def docker(*args):
    return subprocess.check_output(['docker',*args],text=True)
def post(path, data):
    return urllib.request.urlopen(urllib.request.Request(base+path, data=json.dumps(data).encode(),headers={'Content-Type':'application/json'}),timeout=450)
def cycle(ids):
    for period in range(1,min(len(ids)//6,256)+1):
        if 6*period < 96: continue
        tail=ids[-period:]
        if ids[-6*period:] == tail*6:
            start=len(ids)-6*period
            while start and ids[start-1]==ids[start-1+period]: start-=1
            return {'start_token':start+1,'period':period}
def run(experts, exact):
    tag=f'{experts}-'+('exact' if exact else 'threshold')
    name='dllm-pr4-ferry-'+tag
    upstream=experts==6 and not exact
    folder='/work/pr4-6a3f36ed/'+('build' if upstream else 'tuned')+'/bin/'
    flags=[] if upstream else ['--spec-self-width','16','--spec-self-verify-experts',str(experts),'--spec-self-acceptance','exact' if exact else 'threshold']
    docker('run','-d','--name',name,'--gpus','all','--memory','38g','--cpus','8',
           '-p','127.0.0.1:18194:18194','-v',f'{root}:/work:ro','-e','LD_LIBRARY_PATH='+folder+':/work/pr4-6a3f36ed/build/bin:/usr/local/cuda/lib64:/usr/lib/aarch64-linux-gnu',
           '--entrypoint',folder+'llama-server','clover-llamacpp:pr31306','-m','/work/clover-public-Q4_K_M.gguf',
           '--alias','clover','-np','1','--spec-type','self',*flags,'--fit','off','-c','131072','-ngl','99','-t','4','--cache-ram','0','--host','0.0.0.0','--port','18194')
    try:
        for attempt in range(150):
            try:
                if json.load(urllib.request.urlopen(base+'/health',timeout=2))['status']=='ok': break
            except OSError: pass
            if docker('inspect','-f','{{.State.Running}}',name).strip()!='true': raise RuntimeError('server exited')
            time.sleep(1)
        else: raise RuntimeError('startup timeout')
        with post('/apply-template',dict(messages=[dict(role='user',content=prompt)],chat_template_kwargs=dict(enable_thinking=False))) as f: template=json.load(f)['prompt']
        request=dict(prompt=template,seed=42,temperature=0,n_predict=65536,cache_prompt=False,return_tokens=True,stream=True,repeat_penalty=1.05,presence_penalty=0.9,frequency_penalty=0,repeat_last_n=-1,speculative_penalties=dict(think_end_bias=0,length_bias=0))
        ids=[]; pieces=[]; loop=None; reason=None
        with post('/completion',request) as stream:
            for line in stream:
                if not line.startswith(b'data: '): continue
                event=json.loads(line[6:])
                if 'error' in event: raise RuntimeError(event['error'])
                group=event.get('tokens',[])
                if group:
                    ids.extend(group)
                    pieces.append([len(ids),event['content']])
                if event.get('stop'):
                    reason=event['stop_type']; break
                if len(ids)%32==0 and len(ids)>=96:
                    loop=cycle(ids)
                    if loop: reason='loop cutoff'; break
        assert ids and reason
        result=dict(tag=tag,request=request,ids=ids,pieces=pieces,loop=loop,reason=reason)
        (out/(tag+'.json')).write_text(json.dumps(result))
        print(tag,len(ids),loop,reason,flush=True)
    finally:
        log=subprocess.run(['docker','logs',name],capture_output=True,text=True)
        (out/(tag+'.log')).write_text(log.stdout+log.stderr)
        docker('rm','-f',name)
if __name__=='__main__':
    for experts,exact in [(6,False),(8,False),(6,True),(8,True)]: run(experts,exact)
