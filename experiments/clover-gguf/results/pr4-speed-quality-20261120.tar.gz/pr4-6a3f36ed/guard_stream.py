import collections
import json
import pathlib
import re
import time
import urllib.request

def send(base,path,body):
    req=urllib.request.Request(base+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
    return urllib.request.urlopen(req,timeout=900)

def repeated_tail(text):
    words=re.findall(r'\w+|[^\w\s]',text.lower())
    if len(words)<160:
        return False
    seen=set(); repeat=[]
    for i in range(len(words)-11):
        gram=tuple(words[i:i+12]); repeat.append(gram in seen);seen.add(gram)
    return sum(repeat[-128:])>=84

def generate(base,prompt,body,watch):
    native={k:v for k,v in body.items() if k not in ('model','messages','chat_template_kwargs','max_tokens')}
    native.update(prompt=prompt,n_predict=body['max_tokens'],return_tokens=True,stream=True)
    pieces=[]; count=0; next_check=32; streak=0; reason=None; timing={}
    start=time.monotonic()
    with send(base,'/completion',native) as stream:
        for line in stream:
            if not line.startswith(b'data: '): continue
            e=json.loads(line[6:])
            if 'error' in e: raise RuntimeError(e['error'])
            pieces.append(e.get('content',''));count+=len(e.get('tokens',[]))
            if e.get('stop'):
                reason=e['stop_type'];timing=e['timings'];count=timing['predicted_n'];break
            if watch and count >= next_check:
                next_check = 32 * (1 + count // 32)
                streak=streak+1 if repeated_tail(''.join(pieces)) else 0
                if streak==2:
                    reason='repeated passage';break
    if reason is None:raise RuntimeError('truncated stream')
    return dict(content=''.join(pieces),tokens=count,reason=reason,seconds=time.monotonic()-start,timings=timing)

def request(base,body,is_ar,template_base):
    start=time.monotonic()
    with send(template_base,'/apply-template',{'messages':body['messages'],'chat_template_kwargs':body['chat_template_kwargs']}) as f:
        prompt=json.load(f)['prompt']
    ar='http://127.0.0.1:18083'
    neutral={k:v for k,v in body.items() if k not in ('speculative_penalties','repeat_penalty','presence_penalty','frequency_penalty','repeat_last_n')}
    first=generate(base,prompt,neutral if is_ar else body,not is_ar)
    attempts=[first]
    if not is_ar and first['reason'] in ('repeated passage','limit'):
        attempts.append(generate(ar,prompt,neutral,False))
    final=attempts[-1]
    elapsed=time.monotonic()-start
    assert final['timings'] and final['reason'] in ['eos','word','limit']
    result=dict(choices=[dict(finish_reason='length' if final['reason']=='limit' else 'stop',message=dict(role='assistant',content=final['content']))],
                usage=dict(completion_tokens=final['tokens']),timings=final['timings'])
    return dict(request=body,response=result,attempts=attempts,elapsed_s=elapsed,delivered_tps=final['tokens']/elapsed)
