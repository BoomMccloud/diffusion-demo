import ast
import json
from pathlib import Path

def score(folder, control, names):
    out = dict(tasks=len(names), passed=0, same_grade=0, same_text=0, same_parsed=0, tokens=0, decode_seconds=0, wall_seconds=0)
    for name in names:
        raw, ref = [json.loads((d / (name+'.json')).read_text()) for d in (folder,control)]
        answer, baseline = [r['response']['choices'][0]['message']['content'] for r in (raw, ref)]
        def parsed(text):
            text=text.strip()
            if text.startswith('```'):
                text='\n'.join(text.splitlines()[1:-1])
            try: return ('json',json.loads(text))
            except ValueError: pass
            try: return ('ast',ast.dump(ast.parse(text)))
            except SyntaxError: return ('text',text)
        out['passed'] += raw['assessment']['task_check']
        out['same_grade'] += raw['assessment']['task_check'] == ref['assessment']['task_check']
        out['same_text'] += answer == baseline
        out['same_parsed'] += parsed(answer) == parsed(baseline)
        t = raw['response']['timings']
        out['tokens'] += t['predicted_n']
        out['decode_seconds'] += .001*t['predicted_ms']
        if 'elapsed_s' in raw: out['wall_seconds'] += raw['elapsed_s']
    out['decode_tps'] = round(out['tokens']/out['decode_seconds'],2)
    if out['wall_seconds']: out['wall_tps'] = round(out['tokens']/out['wall_seconds'],2)
    return out

if __name__=='__main__':
    root=Path(__file__).resolve().parent
    for group in ('heldout','structured-forward','structured-reverse','structured-validation','structured-confirm','structured-confirm-new'):
        control=root/(group+'-ar-8-exact-off-km-nopack-plain-512')
        if not control.exists(): continue
        names=sorted(f.stem for f in control.glob('*.json') if f.stem not in ('fiction_station','think-state-probe','metrics'))
        for folder in sorted(root.glob(group+'-*-512')):
            if folder.name[len(group)+1:].startswith('new-'): continue
            if names and all((folder/(n+'.json')).is_file() for n in names):
                print(folder.name, json.dumps(score(folder,control,names)))
