set -eu
cd ~/diffusion-demo/runs/dllm-inhouse-4257d3dd
d=pr4-6a3f36ed
for p in 18080 18081; do curl -fsS --retry 40 --retry-all-errors --retry-delay 2 "http://127.0.0.1:$p/health" >/dev/null; done
for service in dllm-clover-self-4257 dllm-clover-ar-4257; do
  docker logs "$service" 2>&1 | tail -30 | grep -q 'all slots are idle'
done
restore_services() {
  docker start dllm-clover-self-4257 dllm-clover-ar-4257 >/dev/null
}
trap restore_services EXIT
docker stop dllm-clover-self-4257 dllm-clover-ar-4257
python3 -u "$d/heldout.py" 512 ar-8-exact-off-km-nopack-plain 6-4-threshold-on-km-nopack-plain 8-6-threshold-light-km-nopack-plain
python3 -u "$d/guard-run.py" 8192 ar-8-exact-off-km-nopack-plain 8-6-threshold-light-km-nopack-plain
(cd "$d" && python3 -u grade.py guard-ar-8-exact-off-km-nopack-plain-8192 guard-8-6-threshold-light-km-nopack-plain-8192 grade-guard)
