set -eu
cd ~/diffusion-demo/runs/dllm-inhouse-4257d3dd
d=pr4-6a3f36ed
for s in dllm-clover-self-4257 dllm-clover-ar-4257; do docker logs "$s" 2>&1 | tail -30 | grep -q 'all slots are idle'; done
trap 'docker start dllm-clover-self-4257 dllm-clover-ar-4257 >/dev/null' EXIT
docker stop dllm-clover-self-4257 dllm-clover-ar-4257
TRIAL_TAG=confirm python3 -u "$d/structured.py" 512 6-8-exact-off-km-nopack-plain ar-8-exact-off-km-nopack-plain
VALIDATION=1 TRIAL_TAG=confirm-new python3 -u "$d/structured.py" 512 6-8-exact-off-km-nopack-plain ar-8-exact-off-km-nopack-plain
python3 -u pr4-6a3f36ed/ferry-pr.py
python3 -u pr4-6a3f36ed/layout-run.py 8192 8-6-threshold-on-q40-pack-fuse
