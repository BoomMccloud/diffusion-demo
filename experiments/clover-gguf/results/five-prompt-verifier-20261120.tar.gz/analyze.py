import json, re, sys, itertools
from pathlib import Path
root=Path(sys.argv[1])
old=Path(sys.argv[2])
defs={}
rows=[]
def analyze(name,policy,res):
    c=res['choices'][0]
    msg=c['message']
    lex=re.findall(r'\w+|[^\w\s]',msg['content'].lower())
    grams=[tuple(lex[i:i+12]) for i in range(len(lex)-11)]
    t=res['timings']
    row=dict(task=name,mode=policy,finish=c['finish_reason'],tokens=t['predicted_n'],milliseconds=t['predicted_ms'],tps=t['predicted_per_second'],repeat=100*(1-len(set(grams))/len(grams)),draft_acceptance=t['draft_n_accepted']/t['draft_n'])
    assert t['predicted_n']==res['usage']['completion_tokens']
    rows.append(row)
for f in sorted(old.glob('varied-long*comparison.json')):
    doc=json.loads(f.read_text());defs.update(doc['prompts'])
    for r in doc['results']:
        if r['mode']=='self':
            analyze(r['name'],'6/threshold',r['response'])
for mode in ['threshold','exact']:
    for task in defs:
        data=json.loads((root/f'{mode}-{task}.json').read_text())
        assert data['request']['messages'][0]['content']==defs[task]
        assert f'self verifier: experts=8 acceptance={mode}' in (root/f'{mode}.log').read_text()
        analyze(task,'8/'+mode,data['response'])
        text=data['response']['choices'][0]['message']['content']
        print(mode,task,'Last 220 chars:',repr(text[-220:]))
for r in sorted(rows,key=lambda r:(r['task'],r['mode'])): print(r['task'],r['mode'],r['finish'],r['tokens'],round(r['repeat'],2),round(r['tps'],2),round(r['draft_acceptance']*100,2))
for mode in ['6/threshold','8/threshold','8/exact']:
    done=[r for r in rows if r['mode']==mode and r['finish']=='stop']
    print(mode,'natural stops',len(done), 'pooled TPS',sum(r['tokens'] for r in done)*1000/sum(r['milliseconds'] for r in done) if done else None)
done_sets=[{r['task'] for r in rows if r['mode']==mode and r['finish']=='stop'} for mode in ['8/threshold','8/exact']]
both=set.intersection(*done_sets)
for mode in ['8/threshold','8/exact']:
    done=[r for r in rows if r['mode']==mode and r['task'] in both]
    print('matched',mode,both, sum(r['tokens'] for r in done)*1000/sum(r['milliseconds'] for r in done) if done else None)
(root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
