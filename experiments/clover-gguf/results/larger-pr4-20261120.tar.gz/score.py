import json
import re
from pathlib import Path

from prompts import topics, beats, rows
from manifest import fixture

def recover_objects(text):
    # Objects in these two flat schemas contain no nested objects.
    objects=[]
    for match in re.finditer(r'\{[^{}]*\}',text):
        try: obj=json.loads(match.group())
        except ValueError: continue
        if isinstance(obj,dict): objects.append(obj)
    return objects

def score(task, record):
    res = record['response']
    choice = res['choices'][0]
    text = choice['message']['content']
    tokens = re.findall(r'\w+|[^\w\s]', text.casefold())
    grams = list(zip(*(tokens[i:] for i in range(12))))
    timing = res['timings']
    n = timing['predicted_n']
    out = dict(tokens=n, decode_s=timing['predicted_ms']/1000,
               wall_s=record['elapsed_s'], tps=timing['predicted_per_second'], stop=choice['finish_reason'],
               words=len(text.split()), repeat_pct=100*(1-len(set(grams))/len(grams)) if grams else 0)
    if task in ('catalog','manifest'):
        expected = rows if task=='catalog' else fixture()[1]
        found = recover_objects(text)
        out['recovered_objects'] = len(found)
        out['copied_fields_correct_by_position'] = sum(all(obj.get(k)==v for k,v in row.items()) for obj,row in zip(found,expected))
        out['unique_ids'] = len({obj.get('id') for obj in found})
        if task=='manifest':
            try: valid = json.loads(text)
            except ValueError: valid=None
            out['valid_array'] = isinstance(valid,list)
            out['exact_manifest'] = valid==expected
            return out

        lines = [line for line in text.splitlines() if line.strip()]
        parsed = []
        for line in lines:
            try: parsed.append(json.loads(line))
            except ValueError: parsed.append(None)
        matched = [isinstance(item,dict) and all(item.get(k)==v for k,v in row.items())
                   for item,row in zip(parsed,rows)]
        notes = [item.get('note','') for item in found if isinstance(item,dict) and isinstance(item.get('note'),str)]
        out.update(lines=len(lines),positions_correct=sum(matched),note_lengths_correct=sum(25<=len(s.split())<=35 for s in notes),
                   unique_notes=len(set(notes)),valid_objects=sum(isinstance(x,dict) for x in parsed))
    elif task in ('fiction','guide'):
        titles = topics if task=='guide' else beats
        headers = re.findall(r'^##\s+(\d{2})\s+(.+?)\s*$',text,re.M)
        wanted=[(f'{i:02d}',title.casefold()) for i,title in enumerate(titles,1)]
        got=[(num,title.casefold()) for num,title in headers]
        out.update(correct_headings=sum(v in got for v in wanted),exact_order=got==wanted,
                   end_marker=text.rstrip().endswith('END HANDBOOK' if task=='guide' else 'END NOVELLA'))
    return out

if __name__=='__main__':
    base=Path(__file__).resolve().parent
    results={}
    for mode in ['self','ar']:
        results[mode]={}
        for name in ('guide','catalog','fiction'):
            path=base/mode/(name+'.json')
            if path.exists(): results[mode][name]=score(name,json.loads(path.read_text()))
        folder=base/('book-'+mode)
        if (folder/'manifest.json').exists(): results[mode]['manifest']=score('manifest',json.loads((folder/'manifest.json').read_text()))
        paths=sorted(folder.glob('chapter-*.json'))
        if paths:
            records=[json.loads(path.read_text()) for path in paths]
            chapters=[score('chapter',item) for item in records]
            texts=[item['response']['choices'][0]['message']['content'] for item in records]
            sums={key:sum(ch[key] for ch in chapters) for key in ('tokens','words','wall_s','decode_s')}
            sums.update(tps=sums['tokens']/sums['decode_s'],chapters=len(paths),natural=sum(ch['stop']=='stop' for ch in chapters),
                        heading_matches=sum(f'## {i:02d} {title}' in txt for i,(title,txt) in enumerate(zip(beats,texts),1)),
                        end_marker=texts[-1].rstrip().endswith('END NOVELLA'),
                        in_word_range=sum(650<=ch['words']<=850 for ch in chapters))
            fake=dict(records[-1],response=dict(records[-1]['response'],choices=[dict(message=dict(content='\n'.join(texts)),finish_reason='stop')]))
            sums['repeat_pct']=score('chapter',fake)['repeat_pct']
            groups={}
            for i,txt in enumerate(texts,1):
                groups.setdefault(txt.split('\n',1)[-1].strip(),[]).append(i)
            sums['identical_body_groups']=[group for group in groups.values() if len(group)>1]
            results[mode]['book']=sums
    print(json.dumps(results,indent=2))
