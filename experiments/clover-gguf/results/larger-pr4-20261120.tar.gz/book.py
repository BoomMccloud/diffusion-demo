import sys
import json
import pathlib
import subprocess
import time
import urllib.request

root = pathlib.Path.cwd()
out = root / "pr4-6a3f36ed" / "larger-pr4-20261120"
endpoint = "http://127.0.0.1:18195"
from prompts import prompts

def docker(*args):
    return subprocess.check_output(["docker", *args], text=True).strip()

def run(config, limit):
    mode = "book-ar" if config.startswith("ar-") else "book-self"
    width, experts, policy, penalty, quant, pack, fuse = config.split("-")
    if config.startswith("ar-"):
        spec = []
    else:
        spec = ["--spec-type","self","--spec-self-width",width,"--spec-self-verify-experts",experts,"--spec-self-acceptance",policy]
    if pack == "pack":
        spec.append("--repack")
    experiment = "kernels" if fuse == "fuse" else "tuned"
    env = ["-e","CLOVER_CUDA_CONV=1","-e","CLOVER_READONLY_PREVIEW=1"] if fuse=="fuse" else []
    model = "/work/clover-public-Q4_K_M.gguf" if quant=="km" else "/work/pr4-6a3f36ed/clover-Q4_0.gguf"
    directory = out / mode
    directory.mkdir(exist_ok=True)
    name = "clover-larger-pr4-" + mode
    if all((directory / f"chapter-{i:02d}.json").exists() for i in range(1,17)): return
    docker("run", "-d", "--name", name, "--gpus", "all", "--memory", "38g", "--cpus", "8",
           "-p", "127.0.0.1:18195:18195", "-v", f"{root}:/work:ro",
           *env, "-e", f"LD_LIBRARY_PATH=/work/pr4-6a3f36ed/{experiment}/bin:/work/pr4-6a3f36ed/build/bin:/usr/local/cuda/lib64:/usr/lib/aarch64-linux-gnu",
           "--entrypoint", f"/work/pr4-6a3f36ed/{experiment}/bin/llama-server", "clover-llamacpp:pr31306",
           "-m", model, "--alias", "clover", "-lv", "4", *spec, "--fit", "off", "-c", "131072",
           "-ngl", "99", "-np", "1", "-t", "4", "--cache-ram", "0", "--host", "0.0.0.0", "--port", "18195")
    try:
        for _ in range(150):
            try:
                if json.load(urllib.request.urlopen(endpoint + "/health", timeout=2))["status"] == "ok":
                    break
            except OSError:
                pass
            if docker("inspect", "--format", "{{.State.Running}}", name) != "true":
                raise RuntimeError("server exited")
            time.sleep(1)
        else:
            raise RuntimeError("startup timeout")
        from prompts import beats
        messages = [dict(role="system",content="Write one continuous mystery novella about a conductor and an estranged sibling investigating a thirty-year-old ticket during the final week of a mountain railway. Preserve established facts. Deliver only the chapter requested in each turn. Keep the solution for the last two chapters. Chapter sequence: "+", ".join(beats))]
        for i,title in enumerate(beats,1):
            heading = f"## {i:02d} {title}"
            ask = f"Write chapter {i} of 16, headed exactly '{heading}'. Write 650 to 850 words of scene and dialogue. Advance the plot with fresh evidence or a consequential decision. Start directly with the heading."
            if i==16: ask += " Resolve both the mystery and the siblings' conflict. End with END NOVELLA on its own line."
            dest=directory/f"chapter-{i:02d}.json"
            messages.append(dict(role="user",content=ask))
            if dest.exists():
                old=json.loads(dest.read_text())
                messages.append(old["response"]["choices"][0]["message"])
                continue
            body=dict(model="clover",messages=messages,temperature=0,seed=42,max_tokens=2048,
                      cache_prompt=True,chat_template_kwargs=dict(enable_thinking=False),
                      repeat_penalty=1.05,presence_penalty=0.9,frequency_penalty=0,repeat_last_n=-1)
            if not config.startswith("ar-"): body["speculative_penalties"]=dict(think_end_bias=0,length_bias=0)
            req=urllib.request.Request(endpoint+"/v1/chat/completions",data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
            start=time.monotonic()
            with urllib.request.urlopen(req,timeout=900) as f: result=json.load(f)
            elapsed=time.monotonic()-start
            choice=result["choices"][0]
            assert choice["message"]["content"] and choice["finish_reason"] in ["stop","length"]
            # Save only the current turn. Preceding turns can be reconstructed from their chapter files.
            saved=dict(body,messages=[messages[0],messages[-1]])
            tmp=dest.with_suffix(".tmp")
            tmp.write_text(json.dumps(dict(request=saved,response=result,elapsed_s=elapsed),ensure_ascii=False))
            tmp.replace(dest)
            messages.append(dict(role="assistant",content=choice["message"]["content"]))
            if i in (1,8,16): print(mode,i,result["timings"]["predicted_n"],flush=True)
        from manifest import fixture
        body=dict(body,messages=[dict(role="user",content=fixture()[0])],cache_prompt=False,max_tokens=24576)
        req=urllib.request.Request(endpoint+"/v1/chat/completions",data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
        start=time.monotonic()
        with urllib.request.urlopen(req,timeout=1500) as f: result=json.load(f)
        elapsed=time.monotonic()-start
        (directory/"manifest.json").write_text(json.dumps(dict(request=body,response=result,elapsed_s=elapsed),ensure_ascii=False))
        print(mode,"manifest",result["choices"][0]["finish_reason"],result["timings"]["predicted_n"],flush=True)
    finally:
        logs = subprocess.run(["docker","logs",name],text=True,capture_output=True)
        (directory / "server.log").write_text(logs.stdout+logs.stderr)
        docker("rm","-f",name)


run(sys.argv[2], int(sys.argv[1]))
