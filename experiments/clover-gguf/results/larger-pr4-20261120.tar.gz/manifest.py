def fixture():
    sites=['North depot','South pier','West annex','East gallery','Central vault']
    actions=['inspect','rehouse','photograph','weigh']
    raw=[]
    expected=[]
    for i in range(1,561):
        site=(7*i+i//13)%5
        action=(i//5+3*i)%4
        qty=(i*37+9)%97+1
        raw.append(f"M{i:04d}|{site}|{action}|{qty}")
        expected.append(dict(id=f"M{i:04d}",site=sites[site],action=actions[action],qty=qty))
    prompt=("Expand this complete transfer manifest for an importer. Output one JSON array of exactly 560 objects in source order. "
            "For every input id|site_key|action_key|qty include exactly the keys id, site, action, qty. "
            "Keep the ID string and integer quantity; expand the two key codes using the following lookup tables. "
            "Site keys 0=North depot, 1=South pier, 2=West annex, 3=East gallery, 4=Central vault. "
            "Action keys 0=inspect, 1=rehouse, 2=photograph, 3=weigh. "
            "Use compact JSON, one object per line, no prose, no placeholders, no code fences. Include every input row.\n"
            + '\n'.join(raw))
    return prompt,expected
