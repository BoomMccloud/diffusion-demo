set -eu
cd ~/diffusion-demo/runs/dllm-inhouse-4257d3dd
for service in dllm-clover-self-4257 dllm-clover-ar-4257; do
  docker logs "$service" 2>&1 | grep -E 'all slots are idle|processing task|launch_slot_|n_decoded =' | tail -1 | grep -q 'all slots are idle'
done
trap 'docker start dllm-clover-self-4257 dllm-clover-ar-4257 >/dev/null' EXIT
docker stop dllm-clover-self-4257 dllm-clover-ar-4257
runner=pr4-6a3f36ed/larger-pr4-20261120/run.py
python3 -u "$runner" 24576 8-6-threshold-on-q40-pack-fuse guide
python3 -u "$runner" 24576 ar-8-exact-on-q40-pack-plain guide catalog fiction
python3 -u "$runner" 24576 8-6-threshold-on-q40-pack-fuse catalog fiction
