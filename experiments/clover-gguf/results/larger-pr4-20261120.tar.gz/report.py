import json, pathlib
p=pathlib.Path(__file__).parent
d=json.loads((p/'metrics.json').read_text())
rows=[]
for key,label in [('guide','24-section handbook'),('fiction','Single-response novella'),('catalog','180 catalog records'),('book','16-turn novella'),('manifest','560-record manifest')]:
    a,s=(d[k][key] for k in ('ar','self'))
    ratio=s['tps']/a['tps']; wa=a['tokens']/a['wall_s']; ws=s['tokens']/s['wall_s']
    rows.append(f"| {label} | {s['tokens']:,} / {a['tokens']:,} | {s['tps']:.2f} / {a['tps']:.2f} | {ratio:.2f}× | {s['wall_s']:.1f} / {a['wall_s']:.1f} | {ws/wa:.2f}× |")
print('\n'.join(rows))
for k in ('ar','self'):
    r=list(d[k].values())
    print(k,'pooled',*(sum(x['tokens'] for x in r)/sum(x[t] for x in r) for t in ('decode_s','wall_s')))
