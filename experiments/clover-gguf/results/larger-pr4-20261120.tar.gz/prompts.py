import json

topics = """intake triage|identity labels|accession photography|site mapping|paper stabilization|textile handling|ceramics packing|metal corrosion|glass fragments|oversize objects|cold storage|humidity monitoring|pest inspection|volunteer training|insurance valuation|donor restrictions|truck loading|elevator outages|after-hours handoff|public inquiries|missing objects|budget revision|return transport|final reconciliation""".split("|")
guide = ("Write the full operations handbook for moving a municipal museum collection after a burst pipe. "
         "It must be usable by staff who have never met. Write the 24 sections below in order, "
         "with exactly these headings formatted as '## 01 Intake triage' and so on. For each section "
         "write about 300 words, including a different worked example with quantities, a decision, a failure scenario and a handoff. "
         "Vary the prose and examples. Deliver the entire handbook, about 7200 words. "
         "After the last section put END HANDBOOK on a line of its own.\n" +
         "\n".join(f"{i:02d} {s.capitalize()}" for i,s in enumerate(topics,1)))
beats = """The returned ticket|An empty seat|The pencil mark|Night dispatch|The lunch tin|A misprinted map|The platform piano|The lost timetable|A witness changes trains|Receipts in the rain|The unsent telegram|The inspector's tally|A different signature|The wrong station|Opening the ledger|The last departure""".split("|")
fiction = ("Write the complete novella The Returned Ticket, set during the final week of a mountain railway. "
           "A conductor and an estranged sibling investigate why a ticket issued thirty years ago has just been used. "
           "Write sixteen chapters of about 480 words each, about 7680 words total. Use these exact chapter headings "
           "in order, each prefixed '## 01 ', '## 02 ', etc. Each chapter must advance the mystery through a new scene "
           "and action. Resolve the ticket's provenance and the siblings' conflict in the last chapter. "
           "End with END NOVELLA on a line of its own.\n" + "\n".join(f"{i:02d} {s}" for i,s in enumerate(beats,1)))
rows=[dict(id=f"R{i:03}",room=["Atrium","Vault","Gallery","Studio","Annex"][(i*3)%5],
           item=["map","clock","vase","print","lamp","chest","quilt"][(i*5)%7],count=(i*11)%47+1) for i in range(1,181)]
catalog=("Produce one JSON object per line for each of the 180 source records below, in source order. "
         "Copy the four fields id, room, item and count exactly and add a fifth string field named note. "
         "Each note must be a distinct, practical museum handling instruction of 25 to 35 words, relevant to that object. "
         "Return exactly 180 JSON lines without a code fence, introduction or closing text.\n"+
         "\n".join(json.dumps(r,separators=(',',':')) for r in rows))
prompts=dict(guide=guide,fiction=fiction,catalog=catalog)
